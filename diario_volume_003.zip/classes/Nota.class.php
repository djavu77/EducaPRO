<?php

class Nota
{
    protected static $is_round = false;

//    public static function setConnection(PDO $pdo = null)
//    {
//        if (! isset($pdo)) {
//            self::$pdo = new Conexao;
//        }
//
//        self::$pdo = $pdo;
//    }
    public static function notRound() {
        self::$is_round = false;
    }

    public static function roundValues() {
        self::$is_round = true;
    }

	public static function get($id_turma, $id_disciplina, $id_aluno, $situacaoAluno = '', $ataFinal = false, $substituiNotaPorRecuperacao = false) {
		$pdo = new Conexao;
		if ($ataFinal) {
			switch ($situacaoAluno) {
				case SituacaoAluno::REMANEJADO:
				case SituacaoAluno::TRANSFERIDO:
				case SituacaoAluno::DESISTENTE:
				case SituacaoAluno::EXCLUIDO:
				case SituacaoAluno::EVADIDO:
				case SituacaoAluno::PROMOVIDO:
					return null;
			}
		}

		$query = "SELECT h.codigo, h.descricao, p.legenda, p.descricao as componente_eliminado, c.*
                FROM componente_eliminado c
                INNER JOIN habilitacao h
                    ON h.codigo = c.id_disciplina
                INNER JOIN tp_provao p
                    ON p.id = c.tp_avaliacao
                WHERE c.id_aluno = :id_aluno
                    AND c.id_turma = :id_turma
                    AND c.id_disciplina = :id_disciplina
                    AND p.ativo = TRUE
                    AND c.cancelado = 'N'";
		$sth = $pdo->prepare($query);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_aluno', $id_aluno);
		$sth->bindParam(':id_disciplina', $id_disciplina);
		if ($sth->execute()) {
			$componente_eliminado = $sth->fetch();
			if (is_array($componente_eliminado)) {
				return self::preparaComponenteEliminado($componente_eliminado);
			}
		}

		$query = "SELECT h.codigo, h.descricao, CASE t.turno WHEN 'N' THEN g.ch_noite ELSE g.ch END AS ch, n.*
					FROM nota_aluno n
					INNER JOIN habilitacao h
						ON h.codigo = n.id_disciplina
					INNER JOIN turma t
						ON t.id = n.id_turma
					INNER JOIN grade_curricular g
						ON g.id_serie = t.id_grade
                        AND g.id_disciplina = n.id_disciplina
                        AND g.id_modalidade = t.modalidade
                        AND g.ano = t.ano
                        AND g.inep = t.inep
					WHERE n.id_aluno = :id_aluno
					    AND n.id_turma = :id_turma
					    AND n.id_disciplina = :id_disciplina";

		$sth = $pdo->prepare($query);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_aluno', $id_aluno);
		$sth->bindParam(':id_disciplina', $id_disciplina);

		if ($sth->execute()) {
			$nota = $sth->fetch();

			if (is_array($nota)) {
				return self::calculaMedias($nota, $substituiNotaPorRecuperacao);
			}
		}
		return null;
	}

	public static function format($item, $chave, $default = '-') {
	    if ($item == null) {
			return $default;
		}

		switch ($chave) {
			case 't_falta1':
			case 't_falta2':
			case 't_falta3':
			case 't_falta4':
			case 'faltas':
			case 'ch':
				return isset($item[$chave]) ? $item[$chave] : $default;
			case 'ma':
			case 'mf':
			    if(isset($item[$chave]))
				{
					$nota = $item[$chave];
					if(is_numeric($item[$chave])){
                        if($nota <> 10 && !self::$is_round)
                            $nota = substr($nota, 0, 4);

                        $nota = sprintf("%.2f", $nota);

						return $nota = str_replace(".", ",", $nota);
					}
					return $nota;
				}
				return $default;
			break;
			default:
				if(isset($item[$chave]))
				{
					$nota = $item[$chave];
					if(is_numeric($item[$chave])){
						if($nota <> 10 && !self::$is_round)
						    $nota = substr($nota,0,4);

                        $nota = sprintf("%.1f", $nota);

                        return $nota = str_replace(".",",",$nota);
					} 
					return $nota;
				}

				return $default;
		}
	}

	public static function getSituacao($notas, $totalFaltas, $id_turma, $situacao,$totalGradeTurma = null) {
		$turma = Turma::get($id_turma);
		$turmaEja = Turma::modalidadeEja($id_turma);
		$turmaMediacaoTecnologica = Turma::modalidadeMediacaoTecnologia($id_turma);

		switch ($situacao) {
			case SituacaoAluno::TRANSFERIDO:
				return 'TRANSFERIDO';
				break;
			case SituacaoAluno::REMANEJADO:
				return 'REMANEJADO';
				break;
			case SituacaoAluno::PROMOVIDO:
				return 'PROMOVIDO';
				break;
			case SituacaoAluno::DESISTENTE:
				return 'DESISTENTE';
				break;
			case SituacaoAluno::FALECIDO:
				return 'FALECIDO';
				break;
			case SituacaoAluno::EXCLUIDO:
				return 'EXCLUIDO';
				break;
			case SituacaoAluno::EVADIDO:
				return 'EVADIDO';
				break;
			default:
				$situacao = 'CURSANDO';
				break;
		}

		$anosIniciais = in_array($turma['turmas'], Serie::$anosIniciais);
		$turmasDependencia = in_array($turma['id_grade'], Turma::$turmasDependencia);
		$turmasRetencaoParcial = in_array($turma['id_grade'], Turma::$turmasRetencaoParcial);

		$cargaHorariaEliminada = 0;
		if (isset($notas[0]['id_aluno']) && $notas[0]['id_turma']) {
			$cargaHorariaEliminada = ComponenteEliminado::cargaHorariaEliminada($notas[0]['id_aluno'], $notas[0]['id_turma']);
		}
		if($totalGradeTurma == null)
		{
			$totalGradeTurma = GradeCurricular::totalCargaHoraria($turma['id'], $turma['ano'], $turma['inep'], true);	
		}
		$totalGradeTurma -= $cargaHorariaEliminada;
		$totalParaReprovar = $totalGradeTurma - (int)round($totalGradeTurma * (75/100), 0);

		if($turma['ano'] >= 2016)
		{
			if ($turmaEja && $turma['ano']==2016 && $turma['semestre']==1){ //no primeiro semestre de 2016, a hora aula era 1h
				$eja2016 = true;
			} 
			else {
				$eja2016 = false;
			}

			if(!$turmaMediacaoTecnologica && !$eja2016)
			{
				$minutoAula = ($turma['turno'] == 'N') ? 45 : 48;
				$totalParaReprovar = $totalParaReprovar*60/$minutoAula;
			}
			
		}

		if ((!$turmasDependencia || !$turmasRetencaoParcial)
		 	&& (
			(!$turmaEja && $anosIniciais && $totalFaltas > 50) ||
			($turmaEja && $anosIniciais && $totalFaltas > 25) ||
      		(!$anosIniciais && $totalFaltas > $totalParaReprovar)
      		)
      		) {

			return 'REPROVADO POR FALTA';
		}

		if (Escola::etapasFechadas($turma['inep'], $turma['ano'], $turma['modalidade'], $turma['semestre'])) {
			foreach ($notas as $nota) {

				if ($nota['reprova'] && !$nota['componente_eliminado']) {
					if (($nota['fezExameFinal'] && ''.$nota['mf'] < '5') || (!$nota['fezExameFinal'] && ''.$nota['mf'] < '6')) {
						return 'RETIDO';
					}
				}
				$situacao = 'APROVADO';
			}
		}

		return $situacao;
	}

    public static function getSituacaoProgressao($notas, $id_turma, $situacao, $data_fechamento) {
        switch ($situacao) {
            case SituacaoAluno::TRANSFERIDO:
                return 'TRANSFERIDO';
                break;
            case SituacaoAluno::REMANEJADO:
                return 'REMANEJADO';
                break;
            case SituacaoAluno::PROMOVIDO:
                return 'PROMOVIDO';
                break;
            case SituacaoAluno::DESISTENTE:
                return 'DESISTENTE';
                break;
            case SituacaoAluno::FALECIDO:
                return 'FALECIDO';
                break;
            case SituacaoAluno::EXCLUIDO:
                return 'EXCLUIDO';
                break;
            case SituacaoAluno::EVADIDO:
                return 'EVADIDO';
                break;
        }

        if(empty($notas) || date('Y-m-d') < $data_fechamento) {
            return 'CURSANDO';
        }

        foreach ($notas as $nota) {
            if (self::getNotaFinalDisciplinaProgressao($nota, $id_turma, $nota['id_aluno'], $nota['id_disciplina'])['nota'] < 5)
                return 'RETIDO';
        }

        return 'APROVADO';
    }

	public static function getSituacaoDisciplina($nota, $totalFaltas, $id_turma, $situacao) {
		$turma = Turma::get($id_turma);
//		$turmaMediacaoTecnologica = Turma::modalidadeMediacaoTecnologia($turma);

		switch ($situacao) {
			case SituacaoAluno::TRANSFERIDO:
				return 'TRANSFERIDO';
				break;
			case SituacaoAluno::REMANEJADO:
				return 'REMANEJADO';
				break;
			case SituacaoAluno::PROMOVIDO:
				return 'PROMOVIDO';
				break;
			case SituacaoAluno::DESISTENTE:
				return 'DESISTENTE';
				break;
			case SituacaoAluno::FALECIDO:
				return 'FALECIDO';
				break;
			case SituacaoAluno::EXCLUIDO:
				return 'EXCLUIDO';
				break;
			case SituacaoAluno::EVADIDO:
				return 'EVADIDO';
				break;
			default:
				$situacao = 'CURSANDO';
				break;
		}

		$totalGradeDisciplina = GradeCurricular::totalCargaHorariaDisciplina($turma['id'], $nota['id_disciplina'], $turma['ano'], $turma['inep'], true);
		$totalParaReprovar = $totalGradeDisciplina - (int)round($totalGradeDisciplina * (75/100), 0);

		if ($totalFaltas > $totalParaReprovar) {
			return 'REPROVADO POR FALTA';
		}

		if (Escola::etapasFechadas($turma['inep'], $turma['ano'], $turma['modalidade'], $turma['semestre'])) {
			if ($nota['reprova'] && !$nota['componente_eliminado']) {
				if (($nota['fezExameFinal'] && ''.$nota['mf'] < '5') || (!$nota['fezExameFinal'] && ''.$nota['mf'] < '6')) {
					return 'RETIDO';
				}
			}
			$situacao = 'APROVADO';
		}

		return $situacao;
	}

    public static function getSituacaoDisciplinaProgressao($notas, $id_turma, $id_disciplina, $id_aluno) {
	    $mediaProgressao = 5;

        $notaFinal = self::getNotaFinalDisciplinaProgressao($notas, $id_turma, $id_disciplina, $id_aluno);

        return ($notaFinal['nota'] >= $mediaProgressao) ? 'APROVADO' : 'RETIDO';

    }

    public static function getNotaFinalDisciplinaProgressao($notas, $id_turma, $id_aluno, $id_disciplina)
    {
        $componenteEliminado = ComponenteEliminado::get($id_turma, $id_disciplina, $id_aluno);

        $notasLista = self::ordenarNotas($notas, $componenteEliminado);

        $notaFinal['nota'] = $notasLista[0] ? self::format($notasLista, '0') : '0,0';
        $notaFinal['legenda'] = '';

        if ($componenteEliminado) {
            $pdo = new Conexao;
            $query = "SELECT legenda
                        FROM tp_provao
                        WHERE ativo = true
                        AND id = :id";
            $sth = $pdo->prepare($query);
            $sth->execute(['id' => $componenteEliminado['tp_avaliacao']]);
            $tipoProva = $sth->fetch();

            $notaFinal['legenda'] = $tipoProva['legenda'];
        }

        return $notaFinal;
    }

	private static function preparaComponenteEliminado($nota) {
		$nota['nota1'] = null;
		$nota['nota2'] = null;
		$nota['nota3'] = null;
		$nota['nota4'] = null;
		$nota['t_falta1'] = null;
		$nota['t_falta2'] = null;
		$nota['t_falta3'] = null;
		$nota['t_falta4'] = null;
		$nota['soma'] = null;
		$nota['ma'] = null;
		$nota['bim1'] = null;
		$nota['bim2'] = null;
		$nota['bim3'] = null;
		$nota['bim4'] = null;
		$nota['recuperacao1'] = null;
		$nota['recuperacao2'] = null;
		$nota['recuperacao3'] = null;
		$nota['recuperacao4'] = null;
		$nota['ch'] = null;
		$nota['faltas'] = null;
		$nota['fezExameFinal'] = false;
		$nota['eliminacao_componente'] = true;
		$nota['mf'] = $nota['legenda'] . number_format($nota['nota'], 2, ',', '');
		return $nota;
	}

	private static function calculaMedias($nota, $substituiNotaPorRecuperacao = false) {
		
		if (!isset($nota['id_turma'])) {
			return null;
		}
		$nota['componente_eliminado'] = false;

		$turma = Turma::get($nota['id_turma']);
		$tipoRecuperacao = Escola::tipoRecuperacao($turma['inep'], $turma['ano'], $turma['modalidade']);
		$turmaEja = Turma::modalidadeEja($turma['id']);
		$turmaMediacaoTecnologica = Turma::modalidadeMediacaoTecnologia($turma['id']);

		$cargaDisciplina = GradeCurricular::cargaDisciplina($turma['id'], $nota['id_disciplina']);
		
		$somaNota = 0;
		$mediaAnual = 0;
		$adereExameFinal = Escola::adereExameFinal($turma['inep'], $turma['ano'], $turma['modalidade']);
		$qntEtapa = $turmaEja ? 2 : 4;

        $avaliacaoForaDaRede = ComponenteEliminado::avaliacaoForaDaRede($nota['id_turma'], $nota['id_aluno']);
        if ($avaliacaoForaDaRede != null) {
            $qntEtapa -= $avaliacaoForaDaRede['id_etapa'];
        }

        if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL) {
			$n1 = $nota['nota1'] < 6 && $nota['recuperacao1'] > $nota['nota1'] ? $nota['recuperacao1'] : $nota['nota1'];
			$n2 = $nota['nota2'] < 6 && $nota['recuperacao2'] > $nota['nota2'] ? $nota['recuperacao2'] : $nota['nota2'];
			$somaNota = $n1 + $n2;

			if (!$turmaEja) {
				$n3 = $nota['nota3'] < 6 && $nota['recuperacao3'] > $nota['nota3'] ? $nota['recuperacao3'] : $nota['nota3'];
				$n4 = $nota['nota4'] < 6 && $nota['recuperacao4'] > $nota['nota4'] ? $nota['recuperacao4'] : $nota['nota4'];
				$somaNota += $n3 + $n4;
			}

			if ($substituiNotaPorRecuperacao) {
				$nota['nota1'] = $n1;
				$nota['nota2'] = $n2;
				if (!$turmaEja) {
					$nota['nota3'] = $n3;
					$nota['nota4'] = $n4;
				}
			}

			if (Aluno::alunoPromovidoParaTurma($nota['id_turma'], $nota['id_aluno'], $nota['ano'])) {
				$qntEtapa -= 1;
			}
			$mediaAnual = $somaNota / $qntEtapa;
		}

		if (!$turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL) {
			$n1 = $nota['nota1'] < 6 && $nota['recuperacao1'] > $nota['nota1'] ? $nota['recuperacao1'] : $nota['nota1'];
			$n2 = $nota['nota2'] < 6 && $nota['recuperacao1'] > $nota['nota2'] ? $nota['recuperacao1'] : $nota['nota2'];
			$n3 = $nota['nota3'] < 6 && $nota['recuperacao2'] > $nota['nota3'] ? $nota['recuperacao2'] : $nota['nota3'];
			$n4 = $nota['nota4'] < 6 && $nota['recuperacao2'] > $nota['nota4'] ? $nota['recuperacao2'] : $nota['nota4'];

			$somaNota = $n1 + $n2 + $n3 + $n4;

			if ($substituiNotaPorRecuperacao) {
				$nota['nota1'] = $n1;
				$nota['nota2'] = $n2;
				$nota['nota3'] = $n3;
				$nota['nota4'] = $n4;
			}

			if (Aluno::alunoPromovidoParaTurma($nota['id_turma'], $nota['id_aluno'], $nota['ano'])) {
				$qntEtapa -= 1;
			}

			$mediaAnual = $somaNota / $qntEtapa;
		}
		if ($tipoRecuperacao == TipoRecuperacao::ANUAL || ($turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL)) {
			$somaNota = $nota['nota1'] + $nota['nota2'];
			if (!$turmaEja) {
				$somaNota += $nota['nota3'] + $nota['nota4'];
			}
			$somaNota = (string)($somaNota);

			if (Aluno::alunoPromovidoParaTurma($nota['id_turma'], $nota['id_aluno'], $nota['ano'])) {
				$qntEtapa -= 1;
			}
			
			$mediaAnual = !empty($somaNota) ? $somaNota / $qntEtapa : 0;
			$mediaFinal = $nota['recuperacao1'] > $mediaAnual ? $nota['recuperacao1'] : $mediaAnual;

			if ($substituiNotaPorRecuperacao) {
				$nota['nota1'] = $nota['nota1'] < 6 && $nota['recuperacao1'] > $nota['nota1'] ? $nota['recuperacao1'] : $nota['nota1'];
				$nota['nota2'] = $nota['nota2'] < 6 && $nota['recuperacao1'] > $nota['nota2'] ? $nota['recuperacao1'] : $nota['nota2'];
				$nota['nota3'] = $nota['nota3'] < 6 && $nota['recuperacao1'] > $nota['nota3'] ? $nota['recuperacao1'] : $nota['nota3'];
				$nota['nota4'] = $nota['nota4'] < 6 && $nota['recuperacao1'] > $nota['nota4'] ? $nota['recuperacao1'] : $nota['nota4'];
			}
		}

		if ($tipoRecuperacao == TipoRecuperacao::PARALELA) {
			$notaRecuperacao = ($cargaDisciplina > GradeCurricular::CARGA_HORARIA_AVALICACAO) ? 1.8 : 2.7;

			$n1 = $nota['nota1'] < $notaRecuperacao && $nota['recuperacao1'] > $nota['nota1'] ? $nota['recuperacao1'] : $nota['nota1'];
			$n2 = $nota['nota2'] < $notaRecuperacao && $nota['recuperacao2'] > $nota['nota2'] ? $nota['recuperacao2'] : $nota['nota2'];
			$n3 = $nota['nota3'] < $notaRecuperacao && $nota['recuperacao3'] > $nota['nota3'] ? $nota['recuperacao3'] : $nota['nota3'];
			$n4 = $nota['nota4'];

			$somaNota = $n1 + $n2 + $n3 + $n4;
			$mediaAnual = $somaNota;
		}
		
		$nota['soma'] = (string) $somaNota;
		$nota['ma'] = (string) $mediaAnual;
		$nota['faltas'] = $nota['t_falta1'] + $nota['t_falta2'] + $nota['t_falta3'] + $nota['t_falta4'];
		$nota['mf'] =  isset($mediaFinal) ? $mediaFinal : $nota['ma'];
		
		
		if ($nota['mf'] < 6 && $adereExameFinal) {
			$mediaFinal = (($nota['mf']*6) + ($nota['examefinal']*4)) / 10;
			$mediaFinal = (string) $mediaFinal;
		
			$nota['fezExameFinal'] = true;
			if ($turmaMediacaoTecnologica) {
				if($nota['examefinal'] >= 5)
				{
					$mediaFinal = $nota['examefinal'];
				}
				else if($nota['examefinal'] >= $nota['mf']){
					$mediaFinal = $nota['examefinal'];
				}
				else {
					$mediaFinal =  $nota['mf'];
					$nota['fezExameFinal'] = false;
				}  
			}
			$nota['mf'] = $mediaFinal;
			
		} else {
			$nota['fezExameFinal'] = false;
		}

		return $nota;
	}

	public static function thRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal) {
		$th = '';
		if (($turmaEja && $tipoRecuperacao == TipoRecuperacao::BIMESTRAL) || (!$turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL) ) {
			$th = $th . '<th class="text-center">Rec. 1</th>';
			$th = $th . '<th class="text-center">Rec. 2</th>';
		}
		if (!$turmaEja && $tipoRecuperacao == TipoRecuperacao::BIMESTRAL) {
			$th = $th . '<th class="text-center">Rec. 1</th>';
			$th = $th . '<th class="text-center">Rec. 2</th>';
			$th = $th . '<th class="text-center">Rec. 3</th>';
			$th = $th . '<th class="text-center">Rec. 4</th>';
		}
		if ($tipoRecuperacao == TipoRecuperacao::PARALELA) {
			$th = $th . '<th class="text-center">I</th>';
			$th = $th . '<th class="text-center">II</th>';
			$th = $th . '<th class="text-center">III</th>';
		}
		if ($tipoRecuperacao == TipoRecuperacao::ANUAL || ($turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL)) {
			$th = $th . '<th class="text-center">Rec</th>';
		}
		if ($adereExameFinal) {
			$th = $th . '<th class="text-center">Ex.Final</th>';
		}
		return $th;
	}

	public static function tdRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal, $nota) {
		$td = '';
		if (($turmaEja && $tipoRecuperacao == TipoRecuperacao::BIMESTRAL) || (!$turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL)) {
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao1') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao2') . '</td>';
		}
		if (!$turmaEja && $tipoRecuperacao == TipoRecuperacao::BIMESTRAL) {
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao1') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao2') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao3') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao4') . '</td>';
		}
		if ($tipoRecuperacao == TipoRecuperacao::ANUAL || ($turmaEja && $tipoRecuperacao == TipoRecuperacao::SEMESTRAL)) {
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao1') . '</td>';
		}
		if ($tipoRecuperacao == TipoRecuperacao::PARALELA) {
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao1') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao2') . '</td>';
			$td = $td . '<td class="text-center">' . self::format($nota,'recuperacao3') . '</td>';
		}
		if ($adereExameFinal) {
			$td = $td . '<td class="text-center">' . self::format($nota,'examefinal') . '</td>';
		}
		return $td;
	}

	public static function insertOrUpdateNotas($id_turma, $id_disciplina, $id_aluno, $id_professor, $cpf, $notas, $faltas, $consideraBloqueio) {
 		$pdo = new Conexao;
 		$pdo->beginTransaction();

 		$turma = Turma::get($id_turma);
 		$turmaEja = Turma::modalidadeEja($id_turma);
		$now = date('Y-m-d');
        $existiaNota = self::exists($id_turma, $id_disciplina, $id_aluno);
 		if (!$existiaNota) {
	   		$query = "SELECT id FROM turmaprofessor WHERE id_disciplina = :id_disciplina AND id_turma = :id_turma";
	   		$sth = $pdo->prepare($query);
	   		$sth->bindParam('id_turma', $turma['id']);
	   		$sth->bindParam('id_disciplina', $id_disciplina);
	   		$id_turmaprofessor = $sth->execute() ? $sth->fetchColumn() : null;

 			$query = "INSERT INTO nota_aluno (id_turma, id_disciplina, id_professor, nota1, nota2, inep, ano, id_aluno, data, usuario, id_turmaprofessor ";

 			if(!Auth::verificaAmbiente('PROF')){
 				$query .=  ", t_falta1, t_falta2 ";
 			}

 			if(!$turmaEja) {
 				$query .= ", nota3, nota4 ";

 				if(!Auth::verificaAmbiente('PROF')) { 
	 				$query .= ", t_falta3 , t_falta4 ";	
	 			}

 			}
			
			$query .= ") VALUES (:id_turma, :id_disciplina, :id_professor, :n1, :n2, :inep, :ano, :id_aluno, :now, :usuario, :id_turmaprofessor ";

			if(!Auth::verificaAmbiente('PROF')){
				$query .= ", :f1, :f2 ";
			} 
			
			if (!$turmaEja) {
				$query .= ", :n3, :n4";

				if(!Auth::verificaAmbiente('PROF')){
					$query .= ", :f3, :f4 ";
				}
			}

			$query .= ");";
			
 			$sth = $pdo->prepare($query);

 			if (!$turmaEja) {
	   			$sth->bindParam(':n3', $notas['n3']);
	   			$sth->bindParam(':n4', $notas['n4']);
	   			
	   			if(!Auth::verificaAmbiente('PROF')){
		   			$sth->bindParam(':f3', $faltas['f3']);
		   			$sth->bindParam(':f4', $faltas['f4']);
		   		}
 			}

 			$sth->bindParam(':now', $now);
 			$sth->bindParam(':usuario', $cpf);
 			$sth->bindParam(':ano', $turma['ano']);
 			$sth->bindParam(':inep', $turma['inep']);
 			$sth->bindParam(':id_professor', $id_professor);
 			$sth->bindParam(':id_turmaprofessor', $id_turmaprofessor);

 		} else {
 			$notaAntiga = self::get($id_turma, $id_disciplina, $id_aluno);
 			
 			$query = "UPDATE nota_aluno n SET n.nota1 = :n1, n.nota2 = :n2, n.data = :dataalteracao,
 								n.usuario = :usuario, n.bim1 = :b1, n.bim2 = :b2 ";

 			if(!Auth::verificaAmbiente('PROF')) { 

 				$query .= ", n.t_falta1 = :f1 , n.t_falta2 = :f2 ";	
 			}
 			
 			if(!$turmaEja) { 
 				$query .= ", n.nota3 = :n3, n.nota4 = :n4, n.bim3 = :b3, n.bim4 = :b4 ";

 				if(!Auth::verificaAmbiente('PROF')) { 
	 				$query .= ", n.t_falta3 = :f3 , n.t_falta4 = :f4 ";	
	 			}
 			}

 			$query .= "	WHERE n.id_turma = :id_turma
						AND n.id_disciplina = :id_disciplina
						AND n.id_aluno = :id_aluno; ";
 					
 			$sth = $pdo->prepare($query);

 			if (!$turmaEja) {
	   			$sth->bindParam(':n3', $notas['n3']);
	   			$sth->bindParam(':n4', $notas['n4']);
		 		
		 		if(!Auth::verificaAmbiente('PROF'))
	 			{
		   			$sth->bindParam(':f3', $faltas['f3']);
	   				$sth->bindParam(':f4', $faltas['f4']);
		 		}

	   			$b3 = $notaAntiga['bim3'] == 'S' || $notaAntiga['nota3'] != $notas['n3'] ? 'S' : 'N';
	   			$b4 = $notaAntiga['bim4'] == 'S' || $notaAntiga['nota4'] != $notas['n4'] ? 'S' : 'N';
	   			$sth->bindParam(':b3', $b3);
	   			$sth->bindParam(':b4', $b4);
 			}

 			$sth->bindParam(':dataalteracao', $now);
 			$sth->bindParam(':usuario', $cpf);
 			$b1 = $notaAntiga['bim1'] == 'S' || $notaAntiga['nota1'] != $notas['n1'] ? 'S' : 'N';
 			$b2 = $notaAntiga['bim2'] == 'S' || $notaAntiga['nota2'] != $notas['n2'] ? 'S' : 'N';
 			$sth->bindParam(':b1', $b1);
 			$sth->bindParam(':b2', $b2);
 		}

		$sth->bindParam(':n1', $notas['n1']);
 		$sth->bindParam(':n2', $notas['n2']);
 		
 		if(!Auth::verificaAmbiente('PROF')) { 
			$sth->bindParam(':f1', $faltas['f1']);
		 	$sth->bindParam(':f2', $faltas['f2']);
		}

		$sth->bindParam(':id_turma', $id_turma, PDO::PARAM_INT);
		$sth->bindParam(':id_aluno', $id_aluno, PDO::PARAM_INT);
		$sth->bindParam(':id_disciplina', $id_disciplina, PDO::PARAM_INT);

		$pdo->commit();
		if (!$sth->execute()) {
			throw new Exception('['.$pdo->errorCode().'] - '.$pdo->errorInfo());
		}

        if ($existiaNota) {
        	if($notaAntiga['id'] != null)
        	{
            	self::insertHistoricoAlteracoes($notaAntiga['id'], $notas);
        	}

        } else {
     		$idNotaNova = $pdo->lastInsertId();
        	if($idNotaNova != null)
        	{
	            self::insertHistoricoAlteracoes($idNotaNova, $notas);
	        }
        }


        $sth->closeCursor();
	}

	public static function insertOrUpdateRecuperacao($id_turma, $id_disciplina, $id_aluno, $id_professor, $cpf, $recuperacoes, $faltas)
	{
 		$pdo = new Conexao;

 		$turma = Turma::get($id_turma);
 		$turmaEja = Turma::modalidadeEja($id_turma);
 		$tipoRecuperacao = Escola::tipoRecuperacao($turma['inep'], $turma['ano'], $turma['modalidade']);
 		$adereExameFinal = Escola::adereExameFinal($turma['inep'], $turma['ano'], $turma['modalidade']);
 		$etapa = 0;

 		if (self::exists($id_turma, $id_disciplina, $id_aluno)) {
   		switch ($tipoRecuperacao) {
   			case TipoRecuperacao::BIMESTRAL:
   				if ($turmaEja) {
   					# update rec do 1 e 2 bim
 						$query = "UPDATE nota_aluno n
											SET recuperacao1 = :r1, t_falta_rec1 = :f1,
											recuperacao2 = :r2, t_falta_rec2 = :f2 ";
						$etapa = 2;
   				} else {
   					# update rec do 1, 2, 3 e 4 bim
   					$query = "UPDATE nota_aluno n
											SET recuperacao1 = :r1, t_falta_rec1 = :f1,
												recuperacao2 = :r2, t_falta_rec2 = :f2,
												recuperacao3 = :r3, t_falta_rec3 = :f3,
												recuperacao4 = :r4, t_falta_rec4 = :f4 ";
						$etapa = 4;
   				}
 				break;

   			case TipoRecuperacao::SEMESTRAL:
   				if (!$turmaEja) {
   					# update rec do 1 e 2 semestre
   					$query = "UPDATE nota_aluno n
											SET recuperacao1 = :r1, t_falta_rec1 = :f1,
											recuperacao2 = :r2, t_falta_rec2 = :f2 ";
						$etapa = 2;
   					break;
   				} # Se nao for EJA, cai pra recuperacao anual

				case TipoRecuperacao::ANUAL:
					#update rec1, em eja e regular
					$query = "UPDATE nota_aluno n
										SET recuperacao1 = :r1, t_falta_rec1 = :f1 ";
					$etapa = 1;
				break;

				case TipoRecuperacao::PARALELA:
					$query = "UPDATE nota_aluno n
										SET recuperacao1 = :r1, t_falta_rec1 = :f1,
										recuperacao2 = :r2, t_falta_rec2 = :f2,
										recuperacao3 = :r3, t_falta_rec3 = :f3 ";
					$etapa = 3;
				break;
   		}
 		} else {
 			throw new Exception("Para lancar a recuperacao do aluno, é necessário antes ter lançado alguma nota bimestral.");
 		}

 		if ($adereExameFinal) {
 			$query = $query . ", examefinal = :examefinal ";
 		}

 		$query = $query . " WHERE n.id_turma = :id_turma
   											AND n.id_disciplina = :id_disciplina
   											AND n.id_aluno = :id_aluno;";
 		$sth = $pdo->prepare($query);

 		for ($i=1; $i <= $etapa; $i++) {
 			$indexr = 'rec' . $i;
 			$indexf = 'falta' . $i;
			$sth->bindParam(':r'.$i, $recuperacoes[$indexr]);
			$sth->bindParam(':f'.$i, $faltas[$indexf]);
 		}

 		if ($adereExameFinal) {
 			$sth->bindParam(':examefinal', $recuperacoes['examefinal']);
 		}

		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
		$sth->bindParam(':id_aluno', $id_aluno);

        try {
            $notaAntiga = self::get($id_turma, $id_disciplina, $id_aluno);
            if($notaAntiga['id'] != null)
        	{
            	self::insertHistoricoAlteracoes($notaAntiga['id'], $recuperacoes);
            }
        } catch (\Exception $e) {}

 		return $sth->execute();
	}

	public static function incrementQuery($query, $value, $name, $reference){
		
		return empty($value) ? $query : $query .= "$name = $reference,";

	}

	public static function insertOrUpdateRecuperacaoProfessor ($id_turma, $id_disciplina, $id_aluno, $id_professor, $cpf, $recuperacoes)
	{
 		$pdo = new Conexao;

 		$turma = Turma::get($id_turma);
 		$turmaEja = Turma::modalidadeEja($id_turma);
 		$tipoRecuperacao = Escola::tipoRecuperacao($turma['inep'], $turma['ano'], $turma['modalidade']);
 		$adereExameFinal = Escola::adereExameFinal($turma['inep'], $turma['ano'], $turma['modalidade']);
 		$etapa = 0;
 		if (self::exists($id_turma, $id_disciplina, $id_aluno)) {
 		
 		$query = "UPDATE nota_aluno n SET ";
   		switch ($tipoRecuperacao) {
 			
   			case TipoRecuperacao::BIMESTRAL:
				# update rec do 1 e 2 bim
				$etapa = 2;

				$query .= ' recuperacao1 = :r1,';
				$query .= ' recuperacao2 = :r2,';

 				if(!$turmaEja)
 				{
   					# update rec do 3 e 4 bim
					$etapa = 4;
					$query .= ' recuperacao3 = :r3,';
					$query .= ' recuperacao4 = :r4,';
				}
 			break;

   			case TipoRecuperacao::SEMESTRAL:
                $etapa = 2;
                if (!$turmaEja) {
                    # update rec do 1 e 2 semestre
 					$query .= ' recuperacao1 = :r1,';
					$query .= ' recuperacao2 = :r2,';
   				} else {
                    if (array_key_exists("rec1", $recuperacoes))
                        $query .= ' recuperacao1 = :r1,';
                    if (array_key_exists("rec2", $recuperacoes))
                        $query .= ' recuperacao2 = :r2,';
                }
   			break;

			case TipoRecuperacao::ANUAL:
				#update rec1, em eja e regular
				$query .= ' recuperacao1 = :r1,';
				$etapa = 1;
			break;

			case TipoRecuperacao::PARALELA:
				$query .= ' recuperacao1 = :r1,';
				$query .= ' recuperacao2 = :r2,';
				$query .= ' recuperacao3 = :r3,';
					
				$etapa = 3;
			break;
   		}
 		} else {
 			throw new Exception("Para lancar a recuperacao do aluno, é necessário antes ter lançado alguma nota bimestral.");
 		}

 		if ($adereExameFinal) {
 			$query .= " examefinal = :examefinal,";
 		}
        $query = substr($query,0,-1);

        $query .= " WHERE n.id_turma = :id_turma
   											AND n.id_disciplina = :id_disciplina
   											AND n.id_aluno = :id_aluno;";

        $sth = $pdo->prepare($query);

 		//for ($i=1; $i <= $etapa; $i++) {
 		//	$indexr = 'rec' . $i;
		//	$sth->bindParam(':r'.$i, $recuperacoes[$indexr]);
 		//}

        if (array_key_exists("rec1", $recuperacoes))
            $sth->bindValue(':r1', $recuperacoes['rec1']);

 		if (array_key_exists("rec2", $recuperacoes))
 			$sth->bindValue(':r2',$recuperacoes['rec2']);

 		if (array_key_exists("rec3", $recuperacoes))
 			$sth->bindValue(':r3',$recuperacoes['rec3']);

 		if (array_key_exists("rec4", $recuperacoes))
 			$sth->bindValue(':r4',$recuperacoes['rec4']);

        if ($adereExameFinal) {
 			$sth->bindValue(':examefinal', $recuperacoes['examefinal']);
 		}

		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
		$sth->bindParam(':id_aluno', $id_aluno);

        try {
            $notaAntiga = self::get($id_turma, $id_disciplina, $id_aluno);
            if($notaAntiga['id'] != null)
        	{
            	self::insertHistoricoAlteracoes($notaAntiga['id'], $recuperacoes);
            }
        } catch (\Exception $e) {}

 		return $sth->execute();
	}

	public static function exists($id_turma, $id_disciplina, $id_aluno) {
		$pdo = new Conexao;
		$query = "SELECT COUNT(n.id)
					FROM nota_aluno n
					WHERE n.id_turma = :id_turma
					AND n.id_disciplina = :id_disciplina
					AND n.id_aluno = :id_aluno;";
		$sth = $pdo->prepare($query);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
		$sth->bindParam(':id_aluno', $id_aluno);
		return $sth->execute() && $sth->fetchColumn() > 0;
	}

    public static function copiaNotasAluno($idTurmaAnterior, $idTurmaNova, $idAluno, $novoInep) {
    	$pdo = new Conexao;
			$sql = "INSERT INTO nota_aluno (id_turma,id_disciplina,id_professor,nota1,nota2,nota3,nota4,t_falta1,t_falta2,
								t_falta3,t_falta4,inep,ano,recuperacao1,recuperacao2,recuperacao3,recuperacao4,id_aluno,data,usuario,
								id_turmaprofessor,obs,bim1,bim2,bim3,bim4,final,rec1,rec2,rec3,rec4,examefinal,ano_fechado,t_falta_rec1,
								t_falta_rec2,t_falta_rec3,t_falta_rec4)
							SELECT :idTurmaNova, n.id_disciplina, n.id_professor, n.nota1, n.nota2, n.nota3, n.nota4, n.t_falta1, n.t_falta2,
								n.t_falta3, n.t_falta4, :inep, n.ano, n.recuperacao1, n.recuperacao2, n.recuperacao3, n.recuperacao4, n.id_aluno, n.data, n.usuario,
								n.id_turmaprofessor, n.obs, n.bim1, n.bim2, n.bim3, n.bim4, n.final, n.rec1, n.rec2, n.rec3, n.rec4, n.examefinal, n.ano_fechado, n.t_falta_rec1,
								n.t_falta_rec2, n.t_falta_rec3, n.t_falta_rec4
							FROM nota_aluno n
							LEFT JOIN nota_aluno n2 ON n2.id_turma = :idTurmaNova
								AND n2.id_aluno = :idAluno
								AND n2.id_disciplina = n.id_disciplina
							WHERE n.id_turma = :idTurmaAnterior
								AND n.id_aluno = :idAluno
								AND n2.id IS NULL";
			$sth = $pdo->prepare($sql);
			$sth->bindParam(':idTurmaNova', $idTurmaNova);
			$sth->bindParam(':inep', $novoInep);
			$sth->bindParam(':idTurmaAnterior', $idTurmaAnterior);
			$sth->bindParam(':idAluno', $idAluno);

			return $sth->execute();
    }

    public static function insertHistoricoAlteracoes($id_nota_aluno, $dados) {
        $pdo = new Conexao;
        $usuario = Auth::usuario();
        $dados = json_encode($dados);

        $sql = "INSERT INTO nota_aluno_alteracoes (id_nota_aluno, usuario, ambiente, dados, datahora)
                VALUES (:id_nota_aluno, :usuario, :ambiente, :dados, NOW());";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':id_nota_aluno', $id_nota_aluno);
        $sth->bindParam(':usuario', $usuario['cpf']);
        $sth->bindParam(':dados', $dados);
        $sth->bindParam(':ambiente', $usuario['ambienteNome']);

        @$sth->execute();
    }

    public static function verificaNotaVermelha($nota, $turmaEja) {
        $NOTA = 6;
        $notaVermelha = false;

        if ($turmaEja) {
            $campos = array('nota1', 'nota2');
        } else {
            $campos = array('nota1', 'nota2', 'nota3', 'nota4');
        }

        foreach ($campos as $key) {
            if ($nota[$key] < $NOTA && $nota[$key] != '') $notaVermelha = true;
        }

        return $notaVermelha;
    }

    private static function ordenarNotas($notas, $notaComponenteEliminado = null)
    {
        $notasLista[] = $notas['nota1'];
        $notasLista[] = $notas['nota2'];
        $notasLista[] = $notas['nota3'];
        $notasLista[] = $notas['nota4'];
        $notasLista[] = $notaComponenteEliminado;

        rsort($notasLista);

        return $notasLista;
    }
}