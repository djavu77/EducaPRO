<?php
require_once '../start.php';
$pdo = new Conexao;

Auth::blackList(array('PROF', 'NAM', 'BF'));

$title = 'Dados da Escola';

$escola = Escola::get($inep);
$transicao = Escola::getTransicao($inep);
$conselho = Escola::getConselho($inep);

$sql = "SELECT codigo, descricao FROM municipio ORDER BY descricao";
$municipios = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM regulariza_situacaoescolar ORDER BY descricao";
$regularizacaoSituacao = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM status_escola ORDER BY descricao";
$statusEscola = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM fonte_recurso ORDER BY descricao";
$fonteRecursos = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM tipo_eleicao ORDER BY descricao";
$tiposEleicao = $pdo->query($sql)->fetchAll();

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">
			<form id="form" class="submit-wait" action="insere_escola_gestao.php" method="post">
				<input readonly name="codigo" id="codigo" type="hidden" value="<?php echo $inep ?>">
				<div class="row">
					<div class="col-md-2">
						<div class="form-group">
							<label for="inep">INEP</label>
							<input class="form-control" name="inep" id="inep" readonly type="text" value="<?php echo $escola["inep"]; ?>">
						</div>
					</div>
					<div class="col-md-10">
						<div class="form-group">
							<label for="lbldtemissaote">Nome da escola</label>
							<input name="descricao" id="descricao" class="form-control" maxlength="60" type="text" value="<?php echo $escola["descricao"]; ?>" readonly>
						</div>
					</div>
				</div>
				<hr>

				<!-- Nav tabs -->
				<ul class="nav nav-tabs" role="tablist">
				  <li role="presentation" class="active"><a href="#escola" aria-controls="escola" role="tab" data-toggle="tab">Dados da escola</a></li>
				  <li role="presentation"><a href="#regularizacao" aria-controls="regularizacao" role="tab" data-toggle="tab">Ato de regulariza��o</a></li>
				  <li role="presentation"><a href="#ambientes" aria-controls="ambientes" role="tab" data-toggle="tab">Ambientes</a></li>
				  <li role="presentation"><a href="#conselho" aria-controls="conselho" role="tab" data-toggle="tab">Conselho</a></li>
				</ul>
				<br>

				<!-- Tab panes -->
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="escola">
						<fieldset class="well well-sm">
							<legend>
								Dire��o e Secretaria
							</legend>
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label for="diretor">Diretor(a)</label>
										<input name="diretor" type="text" id="diretor" class="form-control text-uppercase" size="60" maxlength="60" value="<?php echo $escola["diretor"]; ?>">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label for="vicediretor">Vice-diretor(a)</label>
										<input name="vicediretor" type="text" id="vicediretor" class="form-control text-uppercase" size="60" maxlength="60" value= "<?php echo $escola["vicediretor"]; ?>">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label for="secretario">Secret�rio(a)</label>
										<input name="secretario" type="text" id="secretario" class="form-control text-uppercase" size="60" maxlength="60" value="<?php echo $escola["secretario"]; ?>">
									</div>
								</div>
							</div>
						</fieldset>

						<fieldset class="well well-sm">
							<legend>Modalidades</legend>

							<div class="row">
								<div class="col-md-3">
									<div class="checkbox">
										<label for="modalidade1">
											<input name="modalidade1" type="checkbox" value="1" id="modalidade1" <?php echo ($escola["modalidade1"] == '1') ? 'checked' : '' ?>>
											Fundamental Regular 1 a 5
										</label>
									</div>
									<div class="checkbox">
										<label for="modalidade2">
											<input name="modalidade2" type="checkbox" value="1" id="modalidade2" <?php echo ($escola["modalidade2"] == '1') ? 'checked' : '' ?>>
											Fundamental Regular 6 a 9
										</label>
									</div>
								</div>
								<div class="col-md-3">
									<div class="checkbox">
										<label for="modalidade3">
											<input name="modalidade3" type="checkbox"     value ="1"  id="modalidade3" <?php echo ($escola["modalidade3"] == '1') ? 'checked' : '' ?>>
											Fundamental Regular 1 a 9
										</label>
									</div>
									<div class="checkbox">
										<label for="modalidade4">
											<input name="modalidade4" type="checkbox"     value ="1"  id="modalidade4" <?php echo ($escola["modalidade4"] == '1') ? 'checked' : '' ?>>
											Fundamental EJA
										</label>
									</div>
								</div>
								<div class="col-md-3">
									<div class="checkbox">
										<label for="modalidade5">
											<input name="modalidade5" type="checkbox"  value ="1"  id="modalidade5" <?php echo ($escola["modalidade5"] == '1') ? 'checked' : '' ?>>
											Ensino M�dio Regular
										</label>
									</div>
									<div class="checkbox">
										<label for="modalidade6">
											<input name="modalidade6" type="checkbox"  value ="1"  id="modalidade6" <?php echo ($escola["modalidade6"] == '1') ? 'checked' : '' ?>>
											Ensino M�dio EJA
										</label>
									</div>
								</div>
								<div class="col-md-3">
									<div class="checkbox">
										<label for="modalidade7">
											<input name="modalidade7" type="checkbox"  value ="1"  id="modalidade7" <?php echo ($escola["modalidade7"] == '1') ? 'checked' : '' ?>>
											Educa��o Especial
										</label>
									</div>
								</div>
							</div>
						</fieldset>

						<fieldset class="well well-sm">
							<legend>Endere�o e Contato</legend>

							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="endereco">Logradouro</label>
										<input name="endereco" type="text" id="endereco" class="form-control text-uppercase" maxlength="60" value="<?php echo $escola["endereco"]; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label for="nr">N�mero</label>
										<input name="nr" type="text" id="nr" class="form-control" maxlength="10" value="<?php echo $escola["numero"]; ?>">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label for="cod_municipio">Munic�pio</label>
										<select name="cod_municipio" id="cod_municipio" class="form-control chosen">
											<option value=""></option>
											<?php foreach ($municipios as $mu): ?>
												<option value="<?php echo $mu['codigo'] ?>" <?php echo ($mu['codigo'] == $escola['cod_municipio']) ? "selected" : '' ?>>
													<?php echo $mu['descricao']; ?>
												</option>
											<?php endforeach ?>
										</select>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="bairro">Bairro</label>
										<input name="bairro" type="text" id="bairro" class="form-control text-uppercase" maxlength="40" value="<?php echo $escola["bairro"]; ?>" />
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label for="txtcep">CEP</label>
										<input id="txtcep" name="txtcep" type="text" class="form-control" maxlength="8" value="<?php echo $escola["cep"]; ?>" onKeyPress="return Enum(event)">
									</div>
								</div>

								<div class="col-md-2">
									<div class="form-group">
										<label for="tipo">Zona</label>
										<select name="tipo" class="form-control">
											<option value="RURAL" <?php echo ($escola["zona"] == 'rural') ? 'selected' : ''  ?>>RURAL</option>
											<option value="URBANA" <?php echo ($escola["zona"] == 'URBANA') ? 'selected' : ''  ?>>URBANA</option>
										</select>
									</div>
								</div>

								<div class="col-md-2">
									<div class="form-group">
										<label for="fone">Telefone</label>
										<input class="form-control mask-telefone" name="fone" type="text" id="fone" maxlength="20" value="<?php echo $escola["fone"]; ?>" >
									</div>
								</div>
							</div>

							<fieldset class="gllpLatlonPicker">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="email">Email</label>
											<input class="form-control" name="email" type="email" value="<?php echo $escola["email"] ?>">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="latitude">Latitude</label>
											<input type="text" class="form-control gllpLatitude" name="latitude" id="latitude" value="<?php echo isset($escola['latitude']) ? $escola['latitude'] : '' ?>">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="longitude">Longitude</label>
											<input type="text" class="form-control gllpLongitude" name="longitude" id="longitude" value="<?php echo isset($escola['longitude']) ? $escola['longitude'] : '' ?>">
										</div>
									</div>
									<div class="col-md-8">
									</div>
								</div>
								
								<div class="form-group">
									<label for="q">Procure o endere�o</label>
									<div class="input-group">
										<?php $endereco = "{$escola['endereco']}, {$escola['numero']}, {$escola['bairro']}, {$escola['municipio']}"; ?>
										<input type="text" class="gllpSearchField form-control" placeholder="Digite o endere�o para procurar" value="<?php echo $endereco ?>">
										<div class="input-group-btn">
											<button type="button" class="gllpSearchButton btn btn-default">PROCURAR</button>
										</div>
									</div>
								</div>
								<div class="gllpMap well well-sm" style="height: 400px; width:100%">Google Maps</div>
								<input type="hidden" class="gllpLatitude" value="<?php echo isset($escola['latitude']) ? $escola['latitude'] : '-10' ?>">
								<input type="hidden" class="gllpLongitude" value="<?php echo isset($escola['longitude']) ? $escola['longitude'] : '-63' ?>">
								<input type="hidden" class="gllpZoom" value="<?php echo isset($escola['latitude']) && $escola['longitude'] ? 15 : 7 ?>">
							</fieldset>
						</fieldset>

					</div><!--/escolas-->

					<div role="tabpanel" class="tab-pane" id="regularizacao">
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectregularizacao">Ato Regulariza��o</label>
									<select id="selectregularizacao" name="selectregularizacao" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['regularizacao'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['regularizacao'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectsituacao">Situa��o</label>
									<select id="selectsituacao" name="selectsituacao" class="form-control">
										<option value=""></option>
										<?php foreach ($regularizacaoSituacao as $reg): ?>
										<option value="<?php echo $reg['id'] ?>" <?php echo ($reg['id']== $escola['situacao']) ? "selected" : '' ?>>
											<?php echo $reg['descricao']; ?>
										</option>
										<?php endforeach ?>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectpatrimonio">Patrim�nio</label>
									<select id="selectpatrimonio" name="selectpatrimonio" class="form-control">
										<option value="S" <?php echo ($transicao['patrimonio'] == 'S') ? 'selected' : ''  ?>>SIM</option>
										<option value="N" <?php echo ($transicao['patrimonio'] == 'N') ? 'selected' : ''  ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtportaria">Portaria / Decreto</label>
									<input type="text" name="txtportaria" class="form-control" id="txtportaria" value="<?php echo $escola["portaria"]; ?>" maxlength="12">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtdtemissao">Data Emiss�o</label>
									<input type="text" name="txtdtemissao" id="txtdtemissao" class="form-control mask-data" value="<?php echo formataData($escola['dtportaria']) ?>" >
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtdtvalidade">Data Validade</label>
									<input name= "txtdtvalidade" type="text" id="txtdtvalidade" class="form-control mask-data" value="<?php echo formataData($escola["dtvalidade"]) ?>" >
								</div>
							</div>
						</div>
						<hr>

						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="nprofessores">Professores estatut�rios</label>
									<input name="nprofessores" type="text" id="nprofessores" class="form-control" MAXLENGTH="5" value="<?php echo $escola["nprofessores"]; ?>" onkeypress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="nemergencial">Professores emergenciais</label>
									<input name="nemergencial" type="text" id="nemergencial" class="form-control" MAXLENGTH="5" value="<?php echo $escola["nemergencial"]; ?>" onkeypress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="nadm">T�cnicos administrativos</label>
									<input name="nadm" type="text" id="nadm" class="form-control" MAXLENGTH="5" value="<?php echo $escola["nadministrativo"]; ?>" onKeyPress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="nalunos">Estudantes</label>
									<input name="nalunos" type="text" id="nalunos" class="form-control" MAXLENGTH="5" value="<?php echo $escola["nalunos"]; ?>" onKeyPress="return Enum(event)">
								</div>
							</div>
						</div>
					</div>

					<div role="tabpanel" class="tab-pane" id="ambientes">
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtqdtasala">Salas de Aula</label>
									<input type="text" name="txtqdtasala" class="form-control" value="<?php echo $escola["qtdasala"] ?>" id="txtqdtasala" onKeyPress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Sala de Leitura?</label>
									<select id="selectleitura" name="selectleitura" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['sleitura'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['sleitura'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectlie" title="Laborat�rio de inform�tica">Lab. de Inform�tica?</label>
									<select id="selectlie" name="selectlie" class="form-control">
										<option value=""></option>
										<option value="N" <?php echo ($transicao['lie'] == 'N') ? 'selected' : '' ?>>N�O</option>
										<option value="S" <?php echo ($transicao['lie'] == 'S') ? 'selected' : '' ?>>SIM</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectquadra">Quadra de Esporte</label>
									<select id="selectquadra" name="selectquadra" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['quadra'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['quadra'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Situa��o</label>
									<select id="selectstatusqd" name="selectstatusqd" class="form-control">
										<option value=""></option>
										<?php foreach ($statusEscola as $se): ?>
										<option value="<?php echo $se['id'] ?>" <?php echo ($se['id']==$transicao['squadra']) ? "selected" : '' ?>>
											<?php echo $se['descricao']; ?>
										</option>
										<?php endforeach ?>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectcoberta">Coberta</label>
									<select id="selectcoberta" name="selectcoberta" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['qcoberta'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['qcoberta'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectpde">PDE</label>
									<select id="selectpde" name="selectpde" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo $escola['pde']=='S' ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo $escola['pde']=='N' ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectprogramas">Programas</label>
									<select id="selectprogramas" name="selectprogramas" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['programa'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['programa'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Qtd Programas</label>
									<input type="text" name="txtqdtaprograma" value="<?php echo $transicao['qtdaprograma'] ?>" class="form-control" id="txtqdtaprograma" maxlength="4" onKeyPress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectacervo">Acervo Bibliografico</label>
									<select id="selectacervo" name="selectacervo" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['acervo'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['acervo'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="selectstatus">Situa��o</label>
									<select id="selectstatus" name="selectstatus" class="form-control">
										<option value=""></option>
										<?php foreach ($statusEscola as $se): ?>
										<option value="<?php echo $se['id'] ?>" <?php echo ($se['id']==$transicao['squadra']) ? "selected" : '' ?>>
											<?php echo $se['descricao']; ?>
										</option>
										<?php endforeach ?>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Fonte de Recurso</label>
									<select id="selectfonte" name="selectfonte" class="form-control">
										<option value=""></option>
										<?php foreach($fonteRecursos as $fo): ?>
										<option value="<?php echo $fo['id'] ?>" <?php echo $fo['id']==$transicao['fonter'] ? "selected" : '' ?>>
											<?php echo $fo['descricao']; ?>
										</option>
										<?php endforeach ?>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldeficienten">IDEB</label>
									<input type="text" name="txtideb" class="form-control" id="txtideb" maxlength="3" value="<?php echo $escola["ideb"]; ?>" onKeyPress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldeficienten">ENEM</label>
									<input type="text" name="txtenem" class="form-control" id="txtenem" maxlength="3" value="<?php echo $escola["enem"]; ?>" onKeyPress="return Enum(event)">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtprasil">Prova Brasil</label>
									<input type="text" name="txtprasil" class="form-control" id="txtprasil" maxlength="3" value="<?php echo $escola["pbrasil"]; ?>" onKeyPress="return Enum(event)"/>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="txtprovlhabr">Provinha Brasil</label>
									<input type="text" name="txtprovlhabr" class="form-control" id="txtprovlhabr" maxlength="3" value="<?php echo $escola["provinhabr"]; ?>" onKeyPress="return Enum(event)"/>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Cantina Alugado</label>
									<select id="selectcantina" name="selectcantina" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['cantina'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['cantina'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="regularizacao">Mais Educa��o</label>
									<select id="selectmais" name="selectmais" class="form-control">
										<option value=""></option>
										<option value="S" <?php echo ($transicao['mais'] == 'S') ? 'selected' : '' ?>>SIM</option>
										<option value="N" <?php echo ($transicao['mais'] == 'N') ? 'selected' : '' ?>>N�O</option>
									</select>
								</div>
							</div>
						</div>
					</div>

					<div role="tabpanel" class="tab-pane" id="conselho">
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="cnpj">CNPJ <small class="text-muted">(Apenas n�meros)</small></label>
									<input name="cnpj" type="text" id="cnpj" class="form-control" MAXLENGTH="14" value= "<?php echo $conselho['cnpj']; ?>">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldtemissaote">Data de Registro</label>
									<input type="text" name="txtdtregistro" class="form-control mask-data" id="txtdtregistro" value="<?php echo formataData($conselho['dtregistro']); ?>">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldtemissaote">Tipo de Elei��o</label>
									<select name="tipoe" id="tipoe" class="form-control">
										<option value=""></option>
										<?php foreach($tiposEleicao as $te): ?>
										<option value="<?php echo $te['id'] ?>" <?php echo ($te['id']==$conselho["tpeleicao"]) ? "selected" : '' ?>>
											<?php echo $te['descricao']; ?>
										<?php endforeach ?>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldtemissaote">Data de In�cio de Mandato</label>
									<input type="text" name="txtdtmandatoi" id="txtdtmandatoi"  class="form-control mask-data" value="<?php echo formataData($conselho['dtinicio']); ?>">
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="lbldtemissaote">Data de Fim de Mandato</label>
									<input type="text" name="txtdtmandatof" id="txtdtmandatof"  class="form-control mask-data" value="<?php echo formataData($conselho['dtfim']); ?>" >
								</div>
							</div>
						</div>

						<hr>

						<fieldset class="well well-sm">
							<legend>
								<i class="fa fa-users text-muted"></i>
								Membros da composi��o atual
							</legend>

							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
							  <li role="presentation" class="active"><a href="#direxecutiva" aria-controls="direxecutiva" role="tab" data-toggle="tab">Diretoria Executiva</a></li>
							  <li role="presentation"><a href="#articulacao_pedagogica" aria-controls="articulacao_pedagogica" role="tab" data-toggle="tab">Comiss�o de Articula��o Pedag�gica</a></li>
							  <li role="presentation"><a href="#execucao_financeira" aria-controls="execucao_financeira" role="tab" data-toggle="tab">Comiss�o de Execu��o Financeira</a></li>
							  <li role="presentation"><a href="#conselho_fiscal" aria-controls="conselho_fiscal" role="tab" data-toggle="tab">Conselho Fiscal</a></li>
							</ul>

							<br>

							<!-- Tab panes -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane active" id="direxecutiva">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtpresidente">Presidente</label>
												<input name="txtpresidente" type="text" id="txtpresidente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?php echo $conselho['presidente']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente">Suplente</label>
												<input name="txtsuplente" type="text" id="txtsuplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?php echo $conselho['suplente_pres']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-2">
											<div class="form-group">
												<label for="txtsegmento1_de">Segmento</label>
												<select name="txtsegmento1_de" id="txtsegmento1_de" class="form-control">
													<option value="">Segmento</option>
													<option value="PAI" <?php echo ($conselho['segmento1de']=='PAI') ?  'selected' : '' ?>>PAI</option>
													<option value="ALUNO" <?php echo ($conselho['segmento1de']=='ALUNO') ?  'selected' : '' ?>>ALUNO</option>
													<option value="PROF" <?php echo ($conselho['segmento1de']=='PROF') ?  'selected' : '' ?>>PROFESSOR</option>
													<option value="FUNC" <?php echo ($conselho['segmento1de']=='FUNC') ?  'selected' : '' ?>>FUNCIONARIO</option>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="txtsecretario1_de">1� Secretario</label>
												<input name="txtsecretario1_de" type="text" id="txtsecretario1_de" class="form-control text-uppercase" MAXLENGTH="60" value= "<?php echo $conselho['secretario1de']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente1_de">Suplente</label>
												<input name="txtsuplente1_de" type="text" id="txtsuplente1_de" class="form-control text-uppercase" MAXLENGTH="60" value= "<?php echo $conselho['suplente_secr1']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-2">
											<div class="form-group">
												<label for="lbldtemissaote">Segmento</label>
												<select name="txtsegmento2_de" id="txtsegmento2_de" class="form-control">
													<option value="">Segmento</option>
													<option value="PAI" <?php echo ($conselho['segmento2de']=='PAI') ?  'selected' : '' ?>>PAI</option>
													<option value="ALUNO" <?php echo ($conselho['segmento2de']=='ALUNO') ?  'selected' : '' ?>>ALUNO</option>
													<option value="PROF" <?php echo ($conselho['segmento2de']=='PROF') ?  'selected' : '' ?>>PROFESSOR</option>
													<option value="FUNC" <?php echo ($conselho['segmento2de']=='FUNC') ?  'selected' : '' ?>>FUNCIONARIO</option>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="txtsecretario2_de">2� Secretario</label>
												<input name="txtsecretario2_de" type="text" id="txtsecretario2_de" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['secretario2de']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente2_de">Suplente</label>
												<input name="txtsuplente2_de" type="text" id="txtsuplente2_de" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente_secr2']; ?>">
											</div>
										</div>
									</div>
								</div>

								<div role="tabpanel" class="tab-pane" id="articulacao_pedagogica">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro1_cap">Conselheiro</label>
												<input name="txtconselheiro1_cap" type="text" id="txtconselheiro1_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe1cap']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente1_cap">Suplente</label>
												<input name="txtsuplente1_cap" type="text" id="txtsuplente1_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente1cap']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro2_cap">Conselheiro</label>
												<input name="txtconselheiro2_cap" type="text" id="txtconselheiro2_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe2cap']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente2_cap">Suplente</label>
												<input name="txtsuplente2_cap" type="text" id="txtsuplente2_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente2cap']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro3_cap">Conselheiro</label>
												<input name="txtconselheiro3_cap" type="text" id="txtconselheiro3_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe3cap']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente3_cap">Suplente</label>
												<input name="txtsuplente3_cap" type="text" id="txtsuplente3_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente3cap']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro4_cap">Conselheiro</label>
												<input name="txtconselheiro4_cap" type="text" id="conselheiro4_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe4cap']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente4_cap">Suplente</label>
												<input name="txtsuplente4_cap" type="text" id="txtsuplente4_cap" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente4cap']; ?>">
											</div>
										</div>
									</div>
								</div>

								<div role="tabpanel" class="tab-pane" id="execucao_financeira">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txttesoureiro1_cef">Tesoureiro</label>
												<input name="txttesoureiro1_cef" type="text" id="txttesoureiro1_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['tesoureiro']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplentetesouro">Suplente</label>
												<input name="txtsuplentetesouro" type="text" id="txtsuplentetesouro" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplentetesouro']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro1_cef">Conselheiro</label>
												<input name="txtconselheiro1_cef" type="text" id="txtconselheiro1_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe1cef']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente1_cef">Suplente</label>
												<input name="txtsuplente1_cef" type="text" id="txtsuplente1_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente1cef']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro2_cef">Conselheiro</label>
												<input name="txtconselheiro2_cef" type="text" id="txtconselheiro2_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe2cef']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente2_cef">Suplente</label>
												<input name="txtsuplente2_cef" type="text" id="txtsuplente2_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente2cef']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro3_cef">Conselheiro</label>
												<input name="txtconselheiro3_cef" type="text" id="txtconselheiro3_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe3cef']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente3_cef">Suplente</label>
												<input name="txtsuplente3_cef" type="text" id="txtsuplente3_cef" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente3cef']; ?>">
											</div>
										</div>
									</div>
								</div>

								<div role="tabpanel" class="tab-pane" id="conselho_fiscal">

									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro1_cf">Conselheiro</label>
												<input name="txtconselheiro1_cf" type="text" id="txtconselheiro1_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe1cf']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente1_cf">Suplente</label>
												<input name="txtsuplente1_cf" type="text" id="txtsuplente1_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente1cf']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="lblcod_cpf">Conselheiro</label>
												<input name="txtconselheiro2_cf" type="text" id="txtconselheiro2_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe2cf']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="lblcod_cpf">Suplente</label>
												<input name="txtsuplente2_cf" type="text" id="txtsuplente2_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente2cf']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="lblcod_cpf">Conselheiro</label>
												<input name="txtconselheiro3_cf" type="text" id="txtconselheiro3_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe3cf']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="lblcod_cpf">Suplente</label>
												<input name="txtsuplente3_cf" type="text" id="txtsuplente3_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente3cf']; ?>">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtconselheiro4_cf">Conselheiro</label>
												<input name="txtconselheiro4_cf" type="text" id="txtconselheiro4_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['conselhe4cf']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="txtsuplente4_cf">Suplente</label>
												<input name="txtsuplente4_cf" type="text" id="txtsuplente4_cf" class="form-control text-uppercase" MAXLENGTH="40" value= "<?php echo $conselho['suplente4cf']; ?>">
											</div>
										</div>
									</div>
								</div>
							</div>
						</fieldset>

					</div>

					<div class="well well-sm">
					   <input type="submit" class="btn btn-primary btn-submit-wait" value="SALVAR ALTERA��ES">
					   <input type="button" class="btn btn-default btn-back pull-right" value="Voltar">
					</div>
				</div>
			</form>
		</div>

		<?php require_once page_footer(); ?>

		<script src="<?php echo js('jquery-gmaps-latlon-picker.js') ?>" type="text/javascript"></script>
		<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDQoKEPOecap3ae6K2KEZLmaF10Kn25bLQ"></script>
	</body>
</html>