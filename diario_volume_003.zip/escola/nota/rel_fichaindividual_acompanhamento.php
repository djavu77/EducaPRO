<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }





   $sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }










  $id =  $_GET['codigo'];



/* $totalcaracter = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $turma           = substr($id, $posicao+1,  $totalcaracter);
  */
 $totalcaracter  = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $posicao2       = strpos($id, '-');
 $turma          = substr($id, $posicao+1,$posicao2-$posicao-1);
 $n_chamadax     = substr($id, $posicao2+1, $totalcaracter-$posicao2);



$sqlgerencia = "select * from ficha_individual_obs where inep ='$inep' and id_aluno = '$aluno' and ano= '$txtano'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =  mysql_num_rows($resultadoger);
if($linhas>0) // retorna para associar
{
  while($pegar=mysql_fetch_array($resultadoger))
      {
      $txtobs    = $pegar["obs"];
      }

}






$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni 
from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo ";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];



    }
 }


/**/

$sqlaluno="select count(ta.id_aluno) as total_repetido from turma t,turma_aluno ta where t.id=ta.id_turma  and ta.id_aluno = '$aluno' and t.ano='$txtano'
and t.id = $turma";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
        $total_aluno_repetido         = $pegaraluno["total_repetido"];
    }
 }




$sqlaluno="select * from turma t,turma_aluno ta where t.id=ta.id_turma  and ta.id_aluno = '$aluno' and t.ano='$txtano' and t.id = $turma
and n_chamada = '$n_chamadax'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
      $turmadesc            = $pegaraluno["DESCRICAO"];
	  $n_chamada            = $pegaraluno["n_chamada"];
	  $modalidade           = $pegaraluno["MODALIDADE"];
	  $turma_dep            = $pegaraluno["turmas"];
	  $id_grade             = $pegaraluno["id_grade"];
 	  $ano_letivo           = $pegaraluno["ANO"];
 	  $situacao_aluno       = $pegaraluno["situacao"];
      $grade_curricular_x   = $pegaraluno["id_grade"];
      $grade_curricular     = $pegaraluno["id_grade"];
      $dtfecha_turma        = date("d/m/Y",strtotime($pegaraluno["dtfecha_turma"]));
   	  $turma_dep            = $pegaraluno["TURMAS"];
   	  $semestre             = $pegaraluno["SEMESTRE"];
   	  $situacao             = $pegaraluno["situacao"];
 	  $turmasserie     = $pegaraluno["TURMAS"];

        if (($dtfecha_turma=='31/12/1969')  || ($dtfecha_turma=='30/11/-0001'))
		   {
		     $dtfecha_turma='Turma Aberta';
		   }
      }
 }




$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$dia.".".$mes.".".$ano;

$banco_vazio = 0;

//$re = mysql_query("select count(*) as total from nota_aluno n, habilitacao h where h.codigo = n.id_disciplina");

$re = mysql_query("select count(*) as total from nota_aluno  where  id_aluno = '$aluno' ");
$total = mysql_result($re, 0, "total");
if ($total==0)
  {
	
       $banco_vazio = 1;
   }



/*************************Totaliznado Faltas**********************************************************************************/

$total_conta_faltas = 0;
/*
 $re = mysql_query("select  sum( t_falta1 + t_falta2 + t_falta3 + t_falta4 ) as total from nota_aluno
 where  id_aluno = '$aluno'  and ano = '$txtano' and id_disciplina <> '20'");
 $total_conta_faltas = mysql_result($re, 0, "total");
 */

 $re_abono_faltas = mysql_query("select sum(falta) as t_faltas from abono_faltas where  id_aluno = '$aluno' and ano = '$txtano' and inep = '$inep' and cancelado = 'N'");
 $total_abono_faltas = mysql_result($re_abono_faltas, 0, "t_faltas");
     if ($total_abono_faltas=='')
          $total_abono_faltas =0;



/********************************Tipo de Recuperacao***************************************************************************/

 /*    $sql_tp_recuperacao = mysql_query("select id_recuperacao from recuperacao_escola
     where  ano = '$txtano' and inep = '$inep' and id_modalidade='$modalidade'");
     $tp_recuperacao = mysql_result($sql_tp_recuperacao, 0, "id_recuperacao ");

 */



$sql_tp_recuperacao = "select id_recuperacao from recuperacao_escola
     where  ano = '$txtano' and inep = '$inep' and id_modalidade='$modalidade'";
$resultado_tp_recuperacao=mysql_query($sql_tp_recuperacao) or die (mysql_error());
$linhas_tp_recuperacao   =  mysql_num_rows($resultado_tp_recuperacao);
if($linhas_tp_recuperacao>0) // retorna para associar
{
  while($pegar_tp_recuperacao=mysql_fetch_array($resultado_tp_recuperacao))
      {
         $tp_recuperacao    =  $pegar_tp_recuperacao["id_recuperacao"];
      }

}
else
{
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Recupera��o n�o definida!</font></center>";
    echo "<br><br><center><a href=\"form_imprimi_fichaindividual.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

}

//echo "tipo de recuperacao$tp_recuperacao";






/****************************************************************************************************************************/









if (($modalidade=='1') || ($modalidade=='3') )
 {
   if (($turma_dep=='75') || ($turma_dep=='76') || ($turma_dep=='77') ||($turma_dep=='78') ||($turma_dep=='79'))
       {



$sql=mysql_query(" SELECT * , (nota1 + nota2 + nota3 + nota4) AS soma, (nota1 + nota2 + nota3 + nota4) /4 media
FROM nota_aluno n, habilitacao h, turma_dep_aluno_disciplina t
WHERE h.codigo = n.id_disciplina
AND n.id_aluno = '$aluno'
AND n.ano = '$txtano'
AND n.id_turmaprofessor = '$turma'
AND t.id_turma = n.id_turmaprofessor
AND n.inep = t.inep
AND t.id_disciplina = h.codigo
AND t.id_aluno = n.id_aluno  order by h.impressao");



       }
     else
      {
   if ($total_aluno_repetido > 1)
         {
       $sql = mysql_query("SELECT * , (nota1 + nota2 + nota3 + nota4) AS soma, (nota1 + nota2 + nota3 + nota4) /4 media
				FROM nota_aluno n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.n_chamada = '$n_chamadax'
                AND t.situacao in (1,2,3) order by h.impressao");
         }
       else
        {

           if ($situacao=='7')
             {
               $sql=mysql_query("SELECT n.id_disciplina,n.nota,n.id_aluno
			 	FROM componente_eliminado n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.situacao = 7 order by h.impressao");

              }
            else
              {
               $sql=mysql_query("SELECT * , (nota1 + nota2 + nota3 + nota4) AS soma, (nota1 + nota2 + nota3 + nota4) /4 media
			 	FROM nota_aluno n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.situacao in (1,2,3) order by h.impressao");
               }
         }
     }

  }
else
  {

   $sql=mysql_query("select *,(nota1+nota2) as soma,(nota1+nota2)/2   media
   from nota_aluno n, habilitacao h, turma t
    where h.codigo = n.id_disciplina
    and id_aluno = '$aluno'
    and n.ano = '$txtano'
    and t.id = n.id_turma
    and t.semestre = '$semestre' 
    and t.modalidade = '$modalidade' 
    order by h.impressao");

 }






$conta = mysql_num_rows($sql);
/*Pegando o numero de chamado*/



$sqlaluno="SELECT *,id, nome  as nome_aluno, nome_pai, nome_mae, dt_nascimento, mod_certidao, n_certidao_novo, termo_certidao,foto, livro_certidao,
folha_certidao, dtemissao_certidao ,(YEAR(CURDATE( )) - YEAR(dt_nascimento )) as idade,uf_nascimento,muni_nascimento,
pais_estrangeiro,estado_estrangeiro,municipio_estrangeiro
FROM aluno  where id = '$id' order by nome";


$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {

      $alunodesc      = $pegaraluno["nome_aluno"];
      $nomepai        = $pegaraluno["nome_pai"];
      $nomemae        = $pegaraluno["nome_mae"];
      $endaluno       = $pegaraluno["endereco"];
      $numeroaluno    = $pegaraluno["numero"];
      $bairroaluno    = $pegaraluno["bairro"];
      $dtnacimento    = date("d/m/Y",strtotime($pegaraluno["dt_nascimento"]));
      $termo_certidao        = $pegaraluno["termo_certidao"];
      $livro_certidao        = $pegaraluno["livro_certidao"];
      $folha_certidao          = $pegaraluno["folha_certidao"];

      $dtemissao_certidao    = date("d/m/Y",strtotime($pegaraluno["dtemissao_certidao"]));
      $id_nacional        = $pegaraluno["id_nacional"];
      $id                 = $pegaraluno["id"];
      $cidade                 = $pegaraluno["cidade"];
      $idade                 = $pegaraluno["idade"];
      $sigla                 = $pegaraluno["sigla"];

      $mod_certidao            = $pegaraluno["mod_certidao"];
       $termo_certidao_nova          = $pegaraluno["n_certidao_novo"];
   
        $termo_certidao        = $pegaraluno["termo_certidao"];


      if ($termo_certidao=="")
              $termo_certidao =$termo_certidao_nova;
      
               

        if (($dtemissao_certidao=='31/12/1969')  || ($dtemissao_certidao=='30/11/-0001'))
		   {
		     $dtemissao_certidao='';
		   }


      $id_ufnascimento          = $pegaraluno["uf_nascimento"];
      $muni_nascimento     = $pegaraluno["muni_nascimento"];


       $pais_estrangeiro                   = $pegaraluno["pais_estrangeiro"];
       $estado_estrangeiro                 = $pegaraluno["estado_estrangeiro"];
       $municipio_estrangeiro              = $pegaraluno["municipio_estrangeiro"];







	}
 }




 $sqluf = "select *  from estados where cod_estados = '$id_ufnascimento'";
$resultadouf=mysql_query($sqluf) or die (mysql_error());
$linhasuf   =mysql_num_rows($resultadouf);
if($linhasuf >0)
{
   while($pegaruf=mysql_fetch_array($resultadouf))
	{
         	$sigla    = $pegaruf["sigla"];
    }
 }



$sqlmuni = "select *  from cidades where cod_ibge = '$muni_nascimento'";
$resultadomuni=mysql_query($sqlmuni) or die (mysql_error());
$linhasmuni   =mysql_num_rows($resultadomuni);
if($linhasmuni>0)
{
   while($pegarmuni=mysql_fetch_array($resultadomuni))
	{

    	$cidade    = $pegarmuni["nome"];
    }
 }
else
 {
      $sqlmuni = "select *  from cidades where cod_cidades = '$muni_nascimento'";
      $resultadomuni=mysql_query($sqlmuni) or die (mysql_error());
      $linhasmuni   =mysql_num_rows($resultadomuni);
      if($linhasmuni>0)
      {
          while($pegarmuni=mysql_fetch_array($resultadomuni))
	       {
         	$cidade    = $pegarmuni["nome"];
           }
       }
 }






      if ($id_ufnascimento=='28')
         {
             $sigla = $estado_estrangeiro." / ". $pais_estrangeiro;
             $cidade=  $municipio_estrangeiro;
         }







     if  ($mod_certidao== '1') //modelo novo
         {
          $termo_certidao =  $termo_certidao_nova;
          $livro_certidao        = "-";
          $folha_certidao          = "-";

         }









?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 9pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 9px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}


.imprimi
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}


.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>


<style media="print">
.botao {
display: none;
}
</style>



<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

</head>
<table width="100%">
<!--
<tr>
      <td class="nomecampo" align="center"><b><img src= "../img/brasao.jpg" /></b></td>
</tr>
-->

<tr>
 <td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
 </td>
</tr>

<tr>
	<td colspan="7"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>
  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="">&nbsp;Estadual</td>
	<td class="nomecampo"><b>Ano Letivo:</b></td>
       <td>&nbsp;<?echo $ano_letivo;?></td>

</tr>

</table>

<?

  while($pegar=mysql_fetch_array($resultado))
      {

        $iddisciplina           = $pegar["disciplina"];
        $idturma                = $pegar["idturma"];
        $cpfprofessor           = $pegar["cpf"];
     }
?>



<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="8"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Aluno(a)</b></td>
</tr>

<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td class = "escrita">&nbsp;<?echo $alunodesc;?></td>
	<td class="nomecampo"><b>Nascimento:</b></td>
	<td colspan="5" class = "escrita">&nbsp;<?echo $dtnacimento;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>Pai</b></td>
	<td class = "escrita">&nbsp;<?echo $nomepai;?></td>
	<td class="nomecampo"><b>M�e</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $nomemae;?></td>


</tr>
<tr>
	<td class="nomecampo"><b>Endere�o</b></td>
	<td class = "escrita">&nbsp;<?echo $endaluno;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairroaluno;?></td>
	<td class="nomecampo"><b>N�</b></td>
	<td class = "escrita" colspan="7" >&nbsp;<?echo $numeroaluno;?></td>
</tr>




<tr>
	<td class="nomecampo"><b>ID Nacional</b></td>
	<td class = "escrita">&nbsp;<?echo $id_nacional;?></td>
	<td class="nomecampo"><b>ID Estadual:</b></td>
	<td class= "escrita" colspan="7">&nbsp;<?echo $id;?></td>
</tr>


<tr>
	<td class="nomecampo"><b>Certid�o</b></td>
	<td class= "escrita">&nbsp;<?echo $termo_certidao;?></td>
	<td class="nomecampo"><b>Livro</b></td>
	<td class="escrita" >&nbsp;<?echo $livro_certidao;?></td>
	<td class="nomecampo"><b>Folha</b></td>
	<td class="escrita" >&nbsp;<?echo $folha_certidao;?></td>
	<td class="nomecampo"><b>Data Emiss�o</b></td>
	<td class="escrita" colspan="5" >&nbsp;<?echo $dtemissao_certidao;?></td>

</tr>








<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita">&nbsp;<?echo $turmadesc;?></td>
	<td class="nomecampo"><b>Chamada</b></td>
	<td class = "escrita" >&nbsp;<?echo $n_chamada;?></td>
	<td class="nomecampo"><b>Modalidade</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $modalidade;?></td>

</tr>


<tr>
	<td class="nomecampo"><b>Idade</b></td>
	<td class = "escrita">&nbsp;<?echo $idade;?></td>
	<td class="nomecampo"><b>Naturalidade</b></td>
	<td class = "escrita" >&nbsp;<?echo $cidade;?></td>
	<td class="nomecampo"><b>UF</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $sigla ;?></td>

</tr>






</table>



<table width="100%">

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="19"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>FICHA INDIVIDUAL - QUADRO DE NOTAS</b></td>
</tr>


<?

/***************************Banco Sem Informa��o***********************************************************/
if ($total==0)
  {






$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


 

$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }

if($id_situacao=='1')
  {
  $situa_desc='CURSANDO'; 
 }







?>
</table>



<br><br><br><br><br>
<br><br><br><br><br>


<table width="100%">
<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b><?echo $situa_desc;?>  </b></td>
</tr>

</table>

<br><br><br>
<br><br><br><br><br>

<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Total de Faltas :&nbsp<?echo  $soma_faltas;?> </b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Data de Fechamento :&nbsp<?echo  $dtfecha_turma;?> </b></td>
</tr>

</table>


<br><br><br><br><br>






<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Aux Secretaria</b></td>
	<td>&nbsp;</td>


	<td class="nomecampo"><b>Secretaria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;</td>
</tr>
</table>

<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao" ><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>















<?
exit;
}
/*************************** Fim  Banco Sem Informa��o***********************************************************/





if (($tp_recuperacao==1) ||  ($tp_recuperacao==2))
{

  if (($modalidade=='1')|| ($modalidade=='3'))
  {
?>

<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>3�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 3�B</b></td>
 <td class="nomecampo" align="center"><b>4�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 4�B</b></td>
 <td class="nomecampo" align="center"><b>R 1�B</b></td>
 <td class="nomecampo" align="center"><b>R 2�B</b></td>
 <td class="nomecampo" align="center"><b>R 3�B</b></td>
 <td class="nomecampo" align="center"><b>R 4�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
 <td class="nomecampo" align="center"><b>Situa��o</b></td>
</tr>

<?
}
else
{
?>



<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>R 1�B</b></td>
 <td class="nomecampo" align="center"><b>R 2�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
 <td class="nomecampo" align="center"><b>Situa��o</b></td>
</tr>

<?
}//else

//$totalfaltas = 0;
$soma_faltas=0;
$passou = 0;



while ($dado = mysql_fetch_array($sql))
  {

$total_faltas_final=0;


   $dtabertura     = date("d/m/Y",strtotime($dado["data"]));
   $id_disciplina  = $dado["id_disciplina"];
/*Verifica a situacao do aluno*/


$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }












   $mfinal=0;
   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];


   $examefinal =  $dado["examefinal"];


   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];


   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];
 if ($id_disciplina <> '20')
  {


   $t_falta1  =$dado["t_falta1"];
   $t_falta2 = $dado["t_falta2"];
   $t_falta3 = $dado["t_falta3"];
   $t_falta4 = $dado["t_falta4"];



   $total_faltas=($t_falta1+$t_falta2+$t_falta3+$t_falta4); //por disciplina

   $soma_faltas =$total_faltas +$soma_faltas;

   $total_faltas_final  = $total_faltas_final + $soma_faltas;
  }

   $id_disciplina = $dado["id_disciplina"];


   if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }



  /**/




 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {


        $reprova      =  $pegargrade["reprova"];

    }

  }



  /**/


if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {

if ($id_situacao=='1')
 {

   $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
   $media  = ($soma)/4;
   $mfinal = 0;



if  (($reprova=='S') || ($reprova==''))
{

  if (($media < 6.0))
     {
        
           $mfinal = ($media*6 + $examefinal*4);

//        echo $media;
//        echo $mfinal;

          if ($mfinal < 50.0)

            {
               $situacao = "RETIDO";
             }
          else
            {
               $situacao = "APROVADO";

            }
      }
   else
            $situacao = "APROVADO";
 }
else
       $situacao = "APROVADO";


  if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))
       $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


     }// if situacao
   else
      $situacao = $situa_desc;






/*******************Analisando Situacoes especiais como Provao Modular Enem*****/



$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'

                     and h.codigo = c.id_disciplina";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

      $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
      $tp__nota_especial        =  $pegar_prova_especial["nota"];
      $tp_obs                   =  $pegar_prova_especial["obs"];
      $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
      
	}

     if ($passou != '1')
           $situacao= "A";



     if ($passou_obs_provao==0)
        {
           $txtobs  =  $txtobs  ." * ".  $tp_obs;
           $passou_obs_provao++;
        }


         //         $total_conta_faltas = $total_conta_faltas - $somafalta;
          $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

         //$total_faltas_final =$total_faltas_final + $soma_faltas;
           $somafalta = 0;

?>
<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-"?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

        <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
        <td class = "escrita" align="center">&nbsp;<?echo $tp__nota_especial;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

<?


 }
else
{
?>
<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota4"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 1, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 1, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?
}

/********************************************************************************************************************/















if (($media<6.0))
{
?>
  <td  class = "imprimi" align="center"><font size="1" color="#FF0000"><?echo  $situacao;?></td>
<?
}
else
{
?>
 <td class = "imprimi" align="center"><?echo  $situacao;?></td>
<?
}
?>






</tr>
<?
 }
else
{




/*echo "disci $id_disciplina*";
echo "grade $grade_curricular*";
echo "ddalidade $modalidade*";
echo "*inep $inep";
*/

 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
      $reprova      =  $pegargrade["reprova"];
	}

  }


//echo "$reprova";


   $soma = ($notareal1+$notareal2);
   $media = ($soma)/2;

   $somafalta   = ($t_falta1+$t_falta2);
   $totalfaltas = $totalfaltas + $somafalta; 



     $soma   = ($notareal1+$notareal2);
    $media  = ($soma)/2;
    $mfinal = 0;


if ($id_situacao=='1')
 {

   $soma   = ($notareal1+$notareal2);
   $media  = ($soma)/2;
   $mfinal = 0;



if  (($reprova=='S'))
{


  if (($media < 6.0))
     {
           $mfinal = ($media*6 + $examefinal*4);
          if ($mfinal < 50.0)

            {
               $situacao = "RETIDO";
              }
          else
            {
               $situacao = "APROVADO";

            }
      }
   else
            $situacao = "APROVADO";
   }
   else
            $situacao = "APROVADO";


  if (($bim1 != 'S') || ($bim2 != 'S'))
       $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


}// if situacao
   else
      $situacao = $situa_desc;



                if ($situacao_aluno==2)
                     $situacao =  "DESISTENTE";





/*******************Analisando Situacoes especiais como Provao Modular Enem*****/



$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs from componente_eliminado c, tp_provao tp
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

      $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
      $tp__nota_especial        =  $pegar_prova_especial["nota"];
      $tp_obs                   =  $pegar_prova_especial["obs"];
	}
//     $situacao= "Dispensado - " ." * ". $tp__prova_descricao;

          $situacao= "* - Dispensado";



     if ($passou_obs_provao==0)
        {
           $txtobs  =  $txtobs  ." * ".  $tp_obs;
           $passou_obs_provao++;
        }


         $total_conta_faltas = $total_conta_faltas - $somafalta;

     $somafalta = 0;



   /*     if ($modalidade == 2)
                  if ($total_conta_faltas > 100)
                       $situacao =  "Reprovado por Falta";

     */


 }

/********************************************************************************************************************/











?>

<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita"  align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
         <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 1, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 1, ',', '.');
                                                          ?></td>

     	<td class = "escrita" align="center">&nbsp;<?echo $somafalta;?></td>

  <?
  if ($situacao=='APROVADO') 
   {
  ?>
        <td  class = "imprimi" align="center" ><font size="1" color="#000099"><?echo $situacao;?></td>
  <?
   }
  else
   {
 ?>
       <td class = "imprimi" align="center"><font size="1" color="#FF0000"><?echo $situacao;?></td>

   <?
   }
 ?> 
   
   
   
   </tr>
<?
 }
}//loop

}/*.aqui come�a...Recupera��o anual*/

/****************************************************************************************************************/












else
{



  if (($modalidade=='1')|| ($modalidade=='3'))
   {
?>

<tr>
 <td class="nomecampo"><b>Componente Curricular</b></td>
 <td class="nomecampo"><b>1�Bim</b></td>
 <td class="nomecampo"><b>F 1�B</b></td>
 <td class="nomecampo"><b>2�Bim</b></td>
 <td class="nomecampo"><b>F 2�B</b></td>
 <td class="nomecampo"><b>3�Bim</b></td>
 <td class="nomecampo"><b>F 3�B</b></td>
 <td class="nomecampo"><b>4�Bim</b></td>
 <td class="nomecampo"><b>F 4�B</b></td>
 <td class="nomecampo"><b>Soma </b></td>
 <td class="nomecampo"><b>M.A</b></td>
 <td class="nomecampo"><b>Rec</b></td>
 <td class="nomecampo"><b>Ex.Final</b></td>
 <td class="nomecampo"><b>M.F</b></td>
 <td class="nomecampo"><b>Total Faltas</b></td>
 <td class="nomecampo"><b>Situa��o</b></td>
</tr>

<?
}
else
{
?>



<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>REC</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
 <td class="nomecampo" align="center"><b>Situa��o</b></td>
</tr>

<?
}//else

//$totalfaltas = 0;
$soma_faltas=0;

$passou = 0;


$passou_obs_provao = 0;

while ($dado = mysql_fetch_array($sql))
  {
   $dtabertura    = date("d/m/Y",strtotime($dado["data"]));
   $id_disciplina = $dado["id_disciplina"];
/*Verifica a situacao do aluno*/


$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }



   $mfinal=0;
   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];

   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];

   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];

     if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }




   $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);

   $media  = ($soma)/4;


   $examefinal   =  $dado["examefinal"];






   $t_falta1  =$dado["t_falta1"];
   $t_falta2 = $dado["t_falta2"];
   $t_falta3 = $dado["t_falta3"];
   $t_falta4 = $dado["t_falta4"];



   $total_faltas=($t_falta1+$t_falta2+$t_falta3+$t_falta4); //por disciplina

   $soma_faltas =$total_faltas +$soma_faltas;

   $total_faltas_final  = $total_faltas_final + $total_faltas;


   $id_disciplina = $dado["id_disciplina"];



 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
        $reprova      =  $pegargrade["reprova"];

    }

  }



  /**/


if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {

if ($id_situacao=='1')
   {
       $mfinal = 0;


if  (($reprova=='S') || ($reprova==''))
{

  if (($media < 6.0))
     {
      if (($nrec1 < 6.0))
        {

                   if ($media > $nrec1)
                     {
                      $mediacalculo = $media;
                      }
                    else
                       {
                        $mediacalculo  = $nrec1;
                        }



                      $mfinal = ($mediacalculo*6 + $examefinal*4);


                      if ($mfinal < 50.0)
                          {
                          $situacao = "RETIDO";
                          }
                      else
                          {
                             $situacao = "APROVADO";

                           }

           }
          else
                $situacao = "APROVADO";


      }
   else
            $situacao = "APROVADO";
 }
else
       $situacao = "APROVADO";




  if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))
           $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


   }// if situacao == 1
   else
      $situacao = $situa_desc;






/*******************Analisando Situacoes especiais como Provao Modular Enem*****/


$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs from componente_eliminado c, tp_provao tp
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);

if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

      $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
      $tp__nota_especial        =  $pegar_prova_especial["nota"];
      $tp_obs                   =  $pegar_prova_especial["obs"];
	}
     $situacao= "Dispensado - " ." * ". $tp__prova_descricao;
     $txtobs  =  $txtobs  ." * ".  $tp_obs;
     $total_faltas = 0;

 }

/********************************************************************************************************************/

















?>
<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota4"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 1, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 1, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?
if (($media<6.0))
{
?>
  <td  class = "imprimi" align="center"><font size="1" color="#FF0000"><?echo  $situacao;?></td>
<?
}
else
{
?>
 <td class = "imprimi" align="center"><?echo  $situacao;?></td>
<?
}
?>






</tr>
<?
 }
else/*******************E J A******************************************************/
{




/*echo "disci $id_disciplina*";
echo "grade $grade_curricular*";
echo "ddalidade $modalidade*";
echo "*inep $inep";
*/

 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
      $reprova      =  $pegargrade["reprova"];
	}

  }


//echo "$reprova";


   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];





   $soma = ($n1+$n2);
   $media = ($soma)/2;


/***************Isto aconteceu pq muita gente tinha definido rec semestral pensando que era anual**********************************/

   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];

   if  ($nrec1 >=$nrec2)
          $rec_anual =$nrec1;
   else
        $rec_anual =$nrec2;

/*************************************************/

   $examefinal  =  $dado["examefinal"];

   $somafalta   = ($t_falta1+$t_falta2);
   $totalfaltas = $totalfaltas + $somafalta;



if ($id_situacao=='1') //MATRICULADO
 {

   $mfinal = 0;

if  (($reprova=='S'))
{


  if (($media < 6.0))
     {

      if (($rec_anual < 6.0))
           {

                   if ($media > $rec_anual)
                     {
                      $mediacalculo = $media;
                      }
                    else
                       {
                        $mediacalculo  = $rec_anual;
                        }



                     $mfinal = ($mediacalculo*6 + $examefinal*4);
                        if ($mfinal < 50.0)
                           {
                               $situacao = "RETIDO";
                           }
                        else
                           {
                               $situacao = "APROVADO";
                           }

           }
        else
            $situacao = "APROVADO";
      }
     else
       $situacao = "APROVADO";
 }
  else
     $situacao = "APROVADO";


  if (($bim1 != 'S') || ($bim2 != 'S'))
       $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


}// if situacao
   else
      $situacao = $situa_desc;

/*              if ($modalidade == 2)
                  if ($total_conta_faltas >100)
                       $situacao =  "Reprovado por Falta";
  */

                if ($situacao_aluno==2)
                     $situacao =  "DESISTENTE";






/*******************Analisando Situacoes especiais como Provao Modular Enem*****/



$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs from componente_eliminado c, tp_provao tp
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {
 
      $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
      $tp__nota_especial        =  $pegar_prova_especial["nota"];
      $tp_obs                   =  $pegar_prova_especial["obs"];
	}
//     $situacao= "Dispensado - " ." * ". $tp__prova_descricao;

          $situacao= "* - Dispensado";



     if ($passou_obs_provao==0)
        {
           $txtobs  =  $txtobs  ." * ".  $tp_obs;
           $passou_obs_provao++;
        }


         $total_conta_faltas = $total_conta_faltas - $somafalta;

     $somafalta = 0;

 }

/********************************************************************************************************************/














?>

<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>


        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 1, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 1, ',', '.');
                                                          ?></td>

     	<td class = "escrita" align="center">&nbsp;<?echo $somafalta;?></td>

  <?
  if ($situacao=='APROVADO')
   {
  ?>
        <td  class = "imprimi" align="center" ><font size="1" color="#000099"><?echo $situacao;?></td>
  <?
   }
  else
   {
 ?>
       <td class = "imprimi" align="center"><font size="1" color="#FF0000"><?echo $situacao;?></td>

   <?
   }
 ?>



   </tr>
<?
   }
  }//loop recuperacao anual
}


?>









<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Total de Faltas Registradas :&nbsp<?echo  $total_faltas_final;?>
                   <b>&nbspTotal de Falta(s) Amparada(s) :&nbsp</b>
                   <?echo $total_abono_faltas;

                          if  ($total_faltas_final < $total_abono_faltas)
                                {
                                 $diferenca_total_faltas =0;
                                }
                          else
                                {
                                    $diferenca_total_faltas = $total_faltas_final - $total_abono_faltas;
                                 }

                          
                          
                  ?>
                   <b>&nbspTotal de Faltas :&nbsp <?echo  $diferenca_total_faltas;?> </b>
                  <?
                  if ($modalidade =="2")
                      if ($diferenca_total_faltas >100)
                          echo " Aluno Reprovado Por Falta.";

//                          echo " Aluno "." - ".$situacao ;
                  ?>


</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Data de Fechamento :&nbsp<?echo  $dtfecha_turma;?> </b></td>
</tr>



<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Componente Curricular</b></td>
</tr>




<?


  $sqlgrade="select g.id_modalidade,g.id_disciplina,g.ch as ch,g.ano,h.descricao as descricao from grade_curricular g,habilitacao h
  where id_modalidade='$modalidade'
  and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep' AND g.id_serie = ' $grade_curricular' order by h.impressao";
  $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
  $linhasgrade=mysql_num_rows($resultadograde);
  
//and g.id_s = $grade_curricular
$total_ch=0;
if ($linhasgrade>0)
   {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
        $descdisciplina            = $pegargrade["descricao"];

        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $ch  = "0";
          }

      else if (($turmasserie>=17) && ($turmasserie<=21))  // cba eja
          {
                 $ch  = "0";
          }
         else
          { 
              $ch  = $pegargrade["ch"];
              $total_ch = $total_ch+ $ch;
          }
?>

<tr>
	<td class="escrita">Componente Curricular</td>
	<td class="escrita">&nbsp<?echo  $descdisciplina;?></td>
	<td class="escrita">Carga Horaria</td>
	<td class="escrita" align="center">&nbsp<?echo  $ch;?> </td>
	<td class="escrita">Aulas Dadas</td>
	<td class="escrita" align="right"><?echo  "                           ";?>   </td>
	
</tr>

<?
	}


        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $total_ch  = "800";
          }

        if (($turmasserie>=17) && ($turmasserie<=21))
          {
                 $total_ch  = "350";
          }


         else
            {
             /*  
               $re    = mysql_query("SELECT sum(ch) as total from grade_curricular g,habilitacao h where id_modalidade='$modalidade'
               and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep'  AND g.id_serie = '$turmasserie'");
               $total = mysql_result($re, 0, "total");
              */
              }




  if (($turmasserie>=2) && ($turmasserie<=6))
          {
?>
	<td class="escrita" align = "center"><b> Dias Letivos  </b></td>
	<td align = "center">&nbsp200</td>
<?
         }
else if (($turmasserie>=17) && ($turmasserie<=21))
           {
?>
	<td class="escrita" align = "center"><b>  -  </b></td>
	<td align = "center">&nbsp - </td>

<?
         }
      else
        {
?>
	<td class="escrita" align = "center"><b>  -  </b></td>
	<td align = "center">&nbsp - </td>

<?
         }
?>
	<td class="escrita" ><b>Total   </b></td>
	<td class="escrita" align="right">&nbsp<?echo  $total_ch;?> - Horas</td>

<?
  }
?>

</table>





<table width="100%">
<tr>
      <td class = "escrita" align="Justify">
<h3> <?echo  $txtobs;?></h3>
      </td>
</tr>
</table>






<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Aux Secretaria</b></td>
	<td>&nbsp;</td>


	<td class="nomecampo"><b>Secretaria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;</td>
</tr>








</table>





<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao" ><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>

