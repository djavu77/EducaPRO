<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }




$total_aprovado = 0;


$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;


$txtturma=$_GET["codigo"];

if(!empty($_GET["codigo"]))
 {



$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni
from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];
    }
 }


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }






$sqlaluno="select * from turma t where id = '$txtturma' ";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
           $turmadesc             = $pegaraluno["DESCRICAO"];
	       $modalidade            = $pegaraluno["MODALIDADE"];
	       $grade_turma           = $pegaraluno["id_grade"];
           $ata                   = $pegaraluno["ATA"];
           $dtfecha_turma         = date("d/m/Y",strtotime($pegaraluno["dtfecha_turma"]));
           $semestre       = $pegaraluno["SEMESTRE"];
      	   $turma_dep            = $pegaraluno["TURMAS"];
 	       $turmasserie     = $pegaraluno["TURMAS"];



        if (($dtfecha_turma=='31/12/1969')  || ($dtfecha_turma=='30/11/-0001'))
		   {
		     $dtfecha_turma='Turma Aberta';
		   }

	}

 }






/*  $sqlcontagrade="select count(id) as t_grade_disciplina from grade_curricular where
 id_serie = '$grade_turma' and id_modalidade = '$modalidade'   and  inep = '$inep'";
 $resultadocontagrade=mysql_query($sqlcontagrade) or die (mysql_error());
 $linhascontagrade=mysql_num_rows($resultadocontagrade);
 if ($linhascontagrade>0)
  {
     while($pegarcontagrade=mysql_fetch_array($resultadocontagrade))
         {
           $t_grade_disciplina      =  $pegarcontagrade["t_grade_disciplina"];

         }

  }

 */



$adere_exame_final = 0;

$sqletapa = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa  =  '9'
               and id_modalidade = '$modalidade'
               and inep = '$inep'";
$resultadoetapa=mysql_query($sqletapa) or die (mysql_error());
$linhasetapa   =  mysql_num_rows($resultadoetapa);
if($linhasetapa>0) // retorna para associar
{
  while($pegaretapa=mysql_fetch_array($resultadoetapa))
      {
           $adere_exame_final = 1;
      }

}






 /*********************Tipo de Recupera��o*****************************/

$sql_tp_recuperacao = "select id_recuperacao from recuperacao_escola
     where  ano = '$txtano'
     and inep = '$inep'
     and id_modalidade='$modalidade'";
$resultado_tp_recuperacao=mysql_query($sql_tp_recuperacao) or die (mysql_error());
$linhas_tp_recuperacao   =  mysql_num_rows($resultado_tp_recuperacao);
if($linhas_tp_recuperacao>0) // retorna para associar
{
  while($pegar_tp_recuperacao=mysql_fetch_array($resultado_tp_recuperacao))
      {
         $tp_recuperacao    =  $pegar_tp_recuperacao["id_recuperacao"];
      }

}
else
{
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Recupera��o n�o definida!</font></center>";
    echo "<br><br><center><a href=\"nota/form_turma_atafina_ef.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

}

/******************************************************************************/


            $total_aprovado  = 0;
            $total_reprovado = 0;
            $total_transferido = 0;
            $total_remanejado = 0;
            $total_desistente = 0;
            $total_aluno_turma = 0;
            $total_reprovadofalta = 0;

            $total_promovido = 0;
            $total_falecido  = 0;
/********Total de Alunos na Turma*********************************************************************/
 $sql_total_aluno="select count(ta.id) AS total_aluno_turma
       from aluno a,turma_aluno ta,turma t
       where  t.inep = '$inep'
	   and    ta.id_aluno = a.id
	   and    ta.id_turma = t.id
       and    t.id = '$txtturma'
       order by ta.n_chamada";
$resultado_total_aluno=mysql_query($sql_total_aluno) or die (mysql_error());
$linhas_total_aluno=mysql_num_rows($resultado_total_aluno);
if($linhas_total_aluno>0)
 {
   while($pegar_total_aluno =mysql_fetch_array($resultado_total_aluno))
	{
         	$total_aluno_turma    = $pegar_total_aluno["total_aluno_turma"];
    }

 }











$sql="select ta.id,a.nome,ta.situacao,ta.n_chamada,
       ta.id_aluno,t.descricao,ta.id_turma
       from aluno a,turma_aluno ta,turma t
       where  t.inep = '$inep'
	   and    ta.id_aluno = a.id
	   and    ta.id_turma = t.id
       and    t.id = '$txtturma'
       order by ta.n_chamada";


$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if($linhas>0)
 {

$conta_obs_conselho_professores =0;
$conta_obs_provao= 0;
$conta_obs_enem  = 0;
$conta_obs_modular=0;
$conta_obs_telensino = 0;
$conta_obs_reclassificacao = 0;
$conta_obs_proenco=0;
$conta_obs_enceja = 0;
$conta_obs_lacuna=0;
$conta_obs_provao= 0;


?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}



.cabecalho
{
	font-family: verdana ;
	font-size: 7pt;
    color: #22408f;
	font-weight: bold;
}


.subtitulo
{
	font-family: verdana ;
	font-size: 8pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 9px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}


.escritagrade
{
    font-size: 7px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>


<style media="print">
.botao {
display: none;
}
</style>


<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

</head>
<table width="100%">
<tr>


      <td class="botao" align="center"><b><img src= "../img/brasao.jpg" /></b></td>


</tr>
<tr>
<td>







<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="cabecalho"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="cabecalho"><b>Raz�o Social:</b></td>
	<td class = "cabecalho">&nbsp;<?echo $descescola;?></td>
	<td class="cabecalho"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="cabecalho"><b>Endere�o:</b></td>
	<td class = "cabecalho">&nbsp;<?echo $endereco;?></td>
	<td class="cabecalho"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="cabecalho"><b>Bairro</b></td>
	<td class = "cabecalho">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="cabecalho"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="cabecalho"><b>Munic�pio:</b></td>
	<td class = "cabecalho">&nbsp;<?echo $descmunici;?></td>
	<td class="cabecalho"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="cabecalho"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="cabecalho"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>

</table>



<table width="100%">


<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita">&nbsp;<?echo $turmadesc;?></td>
</tr>
</table>



<table width="100%">
<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
 <td class="nomecampo"><b>N�</b></td>
 <td colspan="3" class="nomecampo"><b>Nome</b></td>
 <?

//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//
//***********************************Cabecalho das disciplinas******************************//

if (($modalidade=='1') || ($modalidade=='3'))
{
$sqldisc="  SELECT DISTINCT h.codigo
FROM turma t, habilitacao h, grade_curricular g
WHERE t.inep = '$inep'
AND t.id = '$txtturma'
AND h.codigo = g.id_disciplina
AND t.id_grade = g.id_serie
AND t.inep = g.inep
GROUP BY h.codigo
ORDER BY h.codigo";
}
else
{
$sqldisc="  SELECT DISTINCT h.codigo
FROM turma t, habilitacao h, grade_curricular g
WHERE t.inep = '$inep'
AND t.id = '$txtturma'
AND h.codigo = g.id_disciplina
and t.semestre = '$semestre'
and t.modalidade = '$modalidade'
AND t.id_grade = g.id_serie
AND t.inep = g.inep
GROUP BY h.codigo
ORDER BY h.codigo";


}
$resultadodisc=mysql_query($sqldisc) or die (mysql_error());
$linhassoma=mysql_num_rows($resultadodisc);
while($pegardisc=mysql_fetch_array($resultadodisc))
{

   $retido      =0;


   $disciplina  =  $pegardisc["codigo"];
   $aluno       =  $pegardisc["id_aluno"];

   $sqldisciplina = ("select sigla from  habilitacao where codigo = '$disciplina'");
   $respostadisc = mysql_query($sqldisciplina) or die(mysql_error());
   while ($dado = mysql_fetch_array($respostadisc))
    {
?>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["sigla"];?></td>


<?
   }//while externo
}

/********************************************************/











?>
   <td class = "escrita" align="center">SIT</td>
<?

while($pegar=mysql_fetch_array($resultado))
{

$passou = 0;  /******flag para identifica��o de alunos reprovados*********/
$aluno_foi_promovido_ano_corrente=0;
$aluno_eliminacao_componente = 0;












 $aluno           = $pegar["id_aluno"];
 $situacao_aluno  = $pegar["situacao"];




$sqlaluno="select count(ta.id_aluno) as total_repetido from turma t,turma_aluno ta where t.id=ta.id_turma
and ta.id_aluno = '$aluno' and t.ano='$txtano'
and t.id = '$turma'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
        $total_aluno_repetido         = $pegaraluno["total_repetido"];
    }
 }




$sql_promovido = "select ta.situacao,t.id from turma_aluno ta, turma t
where ta.inep ='$inep'
and ta.id_aluno = '$aluno'
and ta.ano= '$txtano'
and ta.situacao = '7'
and t.id=ta.id_turma
and t.ano= ta.ano
and t.inep = ta.inep
and t.ano= '$txtano'";
$resultado_promovido=mysql_query($sql_promovido) or die (mysql_error());
$linhas_promovido   =  mysql_num_rows($resultado_promovido);
if($linhas_promovido>0) // retorna para associar
{
  while($pegar_promovido=mysql_fetch_array($resultado_promovido))
      {
          $id_turma_promovido  =  $pegar_promovido["id"];
          $aluno_foi_promovido_ano_corrente =  '1';
      }

}





$total_etapas_ava_fora_rede = 0;

/********************************Avalia��o fora do estado*****************************************************/
$sql_avaliaca_fora_rede = "select *  from tp_avaliacao_recebida where id_aluno  = '$aluno'";
$resultado_avaliaca_fora_rede=mysql_query($sql_avaliaca_fora_rede) or die (mysql_error());
$linhas_avaliaca_fora_rede   =mysql_num_rows($resultado_avaliaca_fora_rede);
if($linhas_avaliaca_fora_rede> 0)
{
   while($pegar_avaliaca_fora_rede=mysql_fetch_array($resultado_avaliaca_fora_rede))
	{
         	$total_etapas_ava_fora_rede    = $pegar_avaliaca_fora_rede["id_etapa"];
    }
 }




 /*************************Totaliznado Faltas**********************************************************************************/






$diferenca_total_faltas = 0;
$total_conta_faltas=0;
$total_abono_faltas=0;
 
 $re = mysql_query("select  sum( t_falta1 + t_falta2 + t_falta3 + t_falta4 ) as total
  FROM nota_aluno n, turma t
  where n.id_aluno = '$aluno'
  and  t.ano = '$txtano'
  and t.semestre = '$semestre'
  and t.modalidade = '$modalidade'
  and id_disciplina <> '20'
  AND t.id = n.id_turma
  ");
 $total_conta_faltas = mysql_result($re, 0, "total");


 $re_abono_faltas = mysql_query("select sum(falta) as t_faltas from abono_faltas where  id_aluno = '$aluno' and ano = '$txtano' and inep = '$inep' and cancelado = 'N'");
 $total_abono_faltas = mysql_result($re_abono_faltas, 0, "t_faltas");
     if ($total_abono_faltas=='')
          $total_abono_faltas =0;



$diferenca_total_faltas   =   $total_conta_faltas - $total_abono_faltas;


/***********************************************************************************************************/






 $sqlsitua="select * from tipo_mov_aluno  where id = '$situacao_aluno'";
 $resultadositua=mysql_query($sqlsitua) or die (mysql_error());
 $linhassitua=mysql_num_rows($resultadositua);
 if ($linhassitua>0)
 {
     while($pegarsitua=mysql_fetch_array($resultadositua))
       {
          $situadesc       = $pegarsitua["descricao"];
	   }
 }






?>


<tr>
    	<td class = "escrita">&nbsp;<?echo $pegar["n_chamada"];?></td>
    	<td colspan="3" class = "escritanormal">&nbsp;<?echo $pegar["nome"];?></td>

<?
/**************************Conta Notas****************************************************************************************/
$linhast_notas = 0;

if (($modalidade=='1') || ($modalidade=='3'))
{


/*       $sqlt_notas="SELECT count(n.id) as t_notas
       FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta, grade_curricular g
       where   t.ano = '$txtano'
       AND     n.id_aluno = '$aluno'
       AND     h.codigo = n.id_disciplina
       AND     n.id_turma = t.id
       AND     ta.id_aluno = n.id_aluno
       AND     ta.id_turma = t.id
       AND     t.id_grade = g.id_serie
       AND     h.codigo = g.id_disciplina
       AND     g.inep = t.inep
       GROUP BY h.codigo ";*/


       $sqlt_notas="SELECT count(n.id) as t_notas
       FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta, grade_curricular g
       where   t.ano = '$txtano'
       AND     n.id_aluno = '$aluno'
       AND     h.codigo = n.id_disciplina
       AND     ta.id_aluno = n.id_aluno
       AND     ta.id_turma = t.id
       AND     t.id_grade = g.id_serie
       AND     h.codigo = g.id_disciplina
       AND     g.inep = t.inep
       GROUP BY h.codigo ";



}
else
{
$sqlt_notas="SELECT count(n.id) as t_notas
FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta, grade_curricular g
where   t.ano = '$txtano'
AND     n.id_aluno = '$aluno'
AND     h.codigo = n.id_disciplina
AND     n.id_turma = t.id
AND     ta.id_aluno = n.id_aluno
AND     ta.id_turma = t.id
AND     t.id_grade = g.id_serie
AND     h.codigo = g.id_disciplina
and     t.semestre = '$semestre'
and     t.modalidade = '$modalidade'
AND     g.inep = t.inep
GROUP BY h.codigo ";
}


$resultadot_notas=mysql_query($sqlt_notas) or die (mysql_error());
$linhast_notas = mysql_num_rows($resultadot_notas);
while($dadot_notas=mysql_fetch_array($resultadot_notas))
 {
     $t_notas    = $dadot_notas["t_notas"];
 }




// ********************************lancamento de nota******##################################################**************************


//**********Verifica se o aluno tem nota lancada no ano corrente******************//
//**********Verifica se o aluno tem nota lancada no ano corrente******************//
//**********Verifica se o aluno tem nota lancada no ano corrente******************//
//**********Verifica se o aluno tem nota lancada no ano corrente******************//
if ($linhast_notas>0)
{

$falta_lancamento=0;
$linha_tabela= 1;
$conta_registro = 1;

if (($modalidade=='1') || ($modalidade=='3'))
{
     $sqldisciplina="  SELECT DISTINCT h.codigo
     FROM turma t, habilitacao h, grade_curricular g
     WHERE t.inep = '$inep'
     AND t.id = '$txtturma'
     AND h.codigo = g.id_disciplina
     AND t.id_grade = g.id_serie
     AND t.inep = g.inep
     GROUP BY h.codigo
     ORDER BY h.codigo";
}
else
{

$sqldisciplina="  SELECT DISTINCT h.codigo
FROM turma t, habilitacao h, grade_curricular g
WHERE t.inep = '$inep'
AND t.id = '$txtturma'
and     t.semestre = '$semestre'
and     t.modalidade = '$modalidade'
AND h.codigo = g.id_disciplina
AND t.id_grade = g.id_serie
AND t.inep = g.inep
GROUP BY h.codigo
ORDER BY h.codigo";
}

$resultadodisciplina=mysql_query($sqldisciplina) or die (mysql_error());
while($pegardisciplina=mysql_fetch_array($resultadodisciplina))
{
   $id_disciplina_compara  =  $pegardisciplina["codigo"];







if (($modalidade=='1') || ($modalidade=='3') )
  {
   

if (($turma_dep=='75') || ($turma_dep=='76') || ($turma_dep=='77') ||($turma_dep=='78') ||($turma_dep=='79')
|| ($turma_dep   = '100')  || ($turma_dep   = '101'))

       {



          $sqlnota="SELECT n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, n.examefinal,
          n.id_disciplina, n.recuperacao3,n.recuperacao4, t_falta1, h.codigo, ta.situacao, bim1, bim2,bim3,bim4
          FROM nota_aluno n, habilitacao h, turma_dep_aluno_disciplina t, turma_aluno ta
          WHERE h.codigo = n.id_disciplina
          AND n.id_aluno = '$aluno'
          AND n.ano = '$txtano'
          AND n.id_turma = '$txtturma'
          AND t.id_turma = n.id_turmaprofessor
          AND ta.id_aluno = n.id_aluno
          AND n.inep = t.inep
          AND   h.codigo = '$id_disciplina_compara'
          AND t.id_disciplina = h.codigo
          AND t.id_aluno = n.id_aluno
          GROUP BY h.codigo";




        }
    else
       {
   if ($total_aluno_repetido > 1)
         {

           $sqlnota="SELECT n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, n.examefinal,
              n.id_disciplina, n.recuperacao3,
                 n.recuperacao4, t_falta1, h.codigo, ta.situacao, bim1, bim2,bim3,bim4
                    FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta,
                       grade_curricular g
                          where t.ano = '$txtano'
                             AND   n.id_aluno = '$aluno'
                                AND   h.codigo = n.id_disciplina
                                   AND   n.id_disciplina = g.id_disciplina
                                      AND   h.codigo = g.id_disciplina
                                         AND   n.id_turma = t.id
                                            AND   ta.id_aluno = n.id_aluno
                                               AND   ta.situacao = '$situacao_aluno'
                                                  AND   t.id_grade = g.id_serie
                                                     AND   h.codigo = '$id_disciplina_compara'
                                                        AND   t.semestre = '$semestre'
                                                           AND   g.inep = t.inep
                                                              GROUP BY h.codigo ";
                                                              
           }
         else
           {


           if ($situacao_aluno=='7')
             {


                     $sqlnota="select c.id_disciplina
                     from componente_eliminado c
                     where c.id_aluno = '$aluno'
                     and   c.cancelado = 'N'
                     and   c.ano = '$txtano'
                     AND   c.id_disciplina = '$id_disciplina_compara'
                     group by c.id_disciplina ";



              }
            else
              {

                if ($aluno_foi_promovido_ano_corrente==0)
                 {

                $sqlnota="SELECT n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, n.examefinal,
                n.id_disciplina, n.recuperacao3,
                 n.recuperacao4, t_falta1, h.codigo, ta.situacao, bim1, bim2,bim3,bim4
                    FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta

                          where t.ano = '$txtano'
                             AND   n.id_aluno = '$aluno'
                                AND   h.codigo = n.id_disciplina
                                       AND   n.id_turma = ta.id_turma
                                            AND   ta.id_aluno = n.id_aluno
                                                     AND   h.codigo = '$id_disciplina_compara'
                                                           and ta.situacao in (1,2,3)
                                                              GROUP BY h.codigo ";

                  }
                 else
                 {
                  $sqlnota="SELECT n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, n.examefinal,
                  n.id_disciplina, n.recuperacao3,
                   n.recuperacao4, t_falta1, h.codigo, ta.situacao, bim1, bim2,bim3,bim4
                    FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta,
                       grade_curricular g
                          where t.ano = '$txtano'
                             AND   n.id_aluno = '$aluno'
                                AND   h.codigo = n.id_disciplina
                                   AND   n.id_disciplina = g.id_disciplina
                                      AND   h.codigo = g.id_disciplina
                                            AND   ta.id_aluno = n.id_aluno
                                               AND   ta.situacao = '$situacao_aluno'
                                                  AND   t.id_grade = g.id_serie
                                                     AND   h.codigo = '$id_disciplina_compara'
                                                        AND   t.semestre = '$semestre'
                                                           AND   g.inep = t.inep
                                                            and ta.situacao in (1,2,3)
                                                              GROUP BY h.codigo ";


                  }

               }
            }
       }
  }
else
{


$sqlnota="SELECT n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, n.examefinal,
n.id_disciplina, n.recuperacao3,
n.recuperacao4, t_falta1, h.codigo, ta.situacao, bim1, bim2,bim3,bim4
FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta,
grade_curricular g
where t.ano = '$txtano'
AND   n.id_aluno = '$aluno'
AND   h.codigo = n.id_disciplina
AND   n.id_disciplina = g.id_disciplina
AND   h.codigo = g.id_disciplina
AND   n.id_turma = t.id
AND   ta.id_aluno = n.id_aluno
AND   ta.situacao = '$situacao_aluno'
AND   t.id_grade = g.id_serie
AND   h.codigo = '$id_disciplina_compara'
and     t.semestre = '$semestre'
and     t.modalidade = '$modalidade'
AND   g.inep = t.inep
GROUP BY h.codigo ";
}




/*********Aqui come�a o calculo das notas seja zero ou n�o**********/
$resultadonota=mysql_query($sqlnota) or die (mysql_error());
$linhasnota=mysql_num_rows($resultadonota);
if($linhasnota > 0)
{




$soma=0;
$media=0 ;
while($dado=mysql_fetch_array($resultadonota))
 {
     $dtabertura    = date("d/m/Y",strtotime($dado["data"]));






   $mfinal=0;
   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];


   $examefinal =  $dado["examefinal"];


   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];


   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];




   $id_disciplina = $dado["id_disciplina"];


/*************Recupera��o Bimestral e semestral*/


if (($tp_recuperacao==1) ||  ($tp_recuperacao==2))
{

   if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }





 if( $aluno_foi_promovido_ano_corrente==0)
    {

       $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
       $media  = ($soma)/4;




     }
 else
    {
       $soma   = ($notareal2+$notareal3+$notareal4);
       $media  = ($soma)/3;
     }


//if ($aluno == '346581')
//    echo "$media*";


 if ($total_etapas_ava_fora_rede > 0)
      {
              $soma   = ($notareal2+$notareal3+$notareal4);
             $media  = ($soma)/(4- $total_etapas_ava_fora_rede);
      }




   $mfinal = 0;






}
/*Recupera��o anual*/
/*Recupera��o anual*/
/*Recupera��o anual*/
else
 {



/***************Aluno Promovido************************/
 if( $aluno_foi_promovido_ano_corrente==0)
    {
      $soma   = ($n1+$n2+$n3+$n4);
      $media  = ($soma)/4;
     }
 else
    {
   $soma   = ($n2+$n3+$n4);
   $media  = ($soma)/3;
     }



    if ($nrec1 > $media)
           $media=$nrec1;







 if ($total_etapas_ava_fora_rede > 0)
      {
         $soma   = ($n2+$n3+$n4);
         $media  = ($soma)/(4- $total_etapas_ava_fora_rede);
      }

 }
 /*********Fim recupera��o anual************/


















    $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
    and id_serie = '$grade_turma' and id_modalidade = '$modalidade'     and inep = '$inep'";
    $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
    $linhasgrade=mysql_num_rows($resultadograde);
    if ($linhasgrade>0)
     {
       while($pegargrade=mysql_fetch_array($resultadograde))
        {
           $reprova      =  $pegargrade["reprova"];
        }

     }









/*******************Analisando Situacoes especiais como Provao Modular Enem*****/
/*

Faz primeiramente uma leitura na base normal logo ap�s faz busca na tabela de prova especiais.

*/


//if ($aluno == '306550')
//   echo "$id_disciplina*";


$tp_avaliacao_especial=0;
$media_promovido="-";
$media_real =0;




/********caso o aluno seja promovido no ano corrente  mas a turma analisada n�o e a turma de promo��o n�o podera entrar em avalia��o especial******************/
/********caso o aluno seja promovido no ano corrente  mas a turma analisada n�o e a turma de promo��o n�o podera entrar em avalia��o especial******************/
/********caso o aluno seja promovido no ano corrente  mas a turma analisada n�o e a turma de promo��o n�o podera entrar em avalia��o especial******************/

$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and  c.cancelado = 'N'";

$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
       {


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp__legenda              =  $pegar_prova_especial["legenda"];






          $aluno_eliminacao_componente = 1;



         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-".$pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }
  /* $media_real � uma variavel que guarda o valor real da media pois caso o aluno seja promovido no ano corrente e n�o seja a turma que ele foi
  promovido a media devera ser igual al valor real*/

         $media_real =  $media;
     //atribui��o de nota de aproveitamento especial

          if ($tp_avaliacao_especial!=3)
            {
               if($situacao_aluno != '7')
                     $media                              = $tp__nota_especial;
                 else
                     $media_promovido                     = $tp__nota_especial;
             }
          else  //conselho de professores
            {
                    $media = $media;

             }


            /* if ($aluno=='319805')
                 {
                   echo "$aluno_foi_promovido_ano_corrente*";
                   echo "$id_turma_promovido";
                 }

                 */
            if (($aluno_foi_promovido_ano_corrente==1) && ($id_turma_promovido!='$txtturma'))
                            $media = $media_real;



       }




   if ($aluno_eliminacao_componente==0)
     {
      if (($media < 6.0))
       {
        if ($adere_exame_final==1)
          {

            $mfinal = ($media*6 + $examefinal*4);

               if ($mfinal < 50.0)
                  {
                      $situacao = "R";
                      $passou = '1';


                   if ($examefinal > $media)
                           $media = $mfinal/10;
                          // $media = $examefinal; conforme orienta��o do antonio pinto
                         // $media = $examefinal; conforme orienta��o do antonio pinto
                    else
                          $media = $mfinal/10;

                 }
              else
                  {
                          $situacao = "A";
                          $media = $mfinal/10;

                 }

           }
          else   //*nao adere exame final**//
             {
                 $mfinal =$media/10;
                 $situacao = "R";
                 $passou = '1';
             }
        }

     }

/*passou indica que e reprovado*/
     $passou = 0;

     if ($passou != '1')
           $situacao= "A";





 }
/***************************************Fim de prova Especiais*****************************************************************************/
/***************************************Fim de prova Especiais*****************************************************************************/
/***************************************Fim de prova Especiais*****************************************************************************/
else
 {





/*******Verificando se o aluno foi transferido e se tranferido foi concluido ou cursando****/






$sqltransferencia = "SELECT ma.id_status FROM
movimenta_aluno ma, turma_aluno ta
WHERE ma.id_aluno = '$aluno'
and ma.id_turmaaluno = ta.id
and ta.inep = '$inep'";
$resultadotransferencia = mysql_query($sqltransferencia) or die (mysql_error());
$linhastransferencia     =mysql_num_rows($resultadotransferencia);
if($linhastransferencia > 0)
{
   while($pegartransferencia=mysql_fetch_array($resultadotransferencia))
	{
    	$id_status_transferencia  =$pegartransferencia["id_status"];
    }
 }
/***********************************************************************************************************/



if (($situacao_aluno =='1')  || ($situacao_aluno =='8')   || (($situacao_aluno =='3') && ($id_status_transferencia=='1')))
 {

//  if ($aluno == "135943")
//   echo "* $aluno_eliminacao_componente";


if ($aluno_eliminacao_componente==0)
 {
 if  ($reprova=='S')
  {
   if (($media < 6.0))
       {

      if ($adere_exame_final==1)
          {

            $mfinal = ($media*6 + $examefinal*4);



               if ($mfinal < 50.0)
                  {
                      $situacao = "R";
                      $passou = '1';


                   if ($examefinal > $media)
                           $media = $mfinal/10;
                          // $media = $examefinal; conforme orienta��o do antonio pinto
                         // $media = $examefinal; conforme orienta��o do antonio pinto
                    else
                          $media = $mfinal/10;

                 }
              else
                  {
                          $situacao = "A";
                          $media = $mfinal/10;
 
                 }

           }
          else /*Nao adere exame final*/
             {
                $mfinal =$media/10;
                      $situacao = "R";
                      $passou = '1';


             }
        }
      else
            $situacao = "A";
       }
    else
      {
       $situacao = "A";
      }
    }


 }

else
  {
 if ($situacao_aluno =='2')
         $situacao = "RE"; //remanejado de turma;

 else if (($situacao_aluno =='3') && ($id_status_transferencia != '1'))
         $situacao = "TR"; //Transferido

   else if ($situacao_aluno =='4')
         $situacao = "FA"; //Falecido

   else if ($situacao_aluno =='5')
         $situacao = "DE"; //desistente

   else if ($situacao_aluno =='7')
         $situacao = "PR"; //PROMOVIDO

   else if ($situacao_aluno =='8')
        $situacao = "DP"; //DEPENDENCIA
 }
}//else de avaliacao de prova especial























   if ($passou==1)
      {  
         $situacao = "R";
        //echo "passou";
       }

// if ($aluno == "205531")
//       echo "* $situacao";




//**********************Verificando CBA***************************************************************//
  if (($turmasserie=='2') || ($turmasserie=='3'))
     {
         $situacao = "A";
     }
//**********************Fim***************************************************************//


//**********************Verificando Bimestre fechados***************************************************************//

if ((($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S')) & (($situacao_aluno!='7')))
       {
             $situacao = "C";

       }
//**********************Fim***************************************************************//





if ($situacao != "D")
 if (($falta_lancamento == 1) && ($situacao_aluno!='7'))
       $situacao = "C";




 if ($situacao_aluno!=2)
   if ($diferenca_total_faltas >200)
             $situacao = 'RF';



                         if ($modalidade== '1')
                            {
                             if (($turmasserie>=2) && ($turmasserie<=6))
                              {
                                if ($diferenca_total_faltas > 50)
                                 {
                                  $situacao ="RF";
                                }
                              }
                            }




/*********Verificando se a situa��o do aluno   1 - cursando or  transferido******************************************************/

/*********Verificando se a situa��o do aluno   1 - cursando or  transferido******************************************************/




if (($situacao_aluno =='1')  || ($situacao_aluno =='8')  || (($situacao_aluno =='3') && ($id_status_transferencia=='1')))
 {


if ( $tp_avaliacao_especial == 0)
{
?>
    <td class = "escrita"  align="center" >&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
<?

}
else
{

 if (($aluno_foi_promovido_ano_corrente==1) && ($id_turma_promovido!='$txtturma'))
   {
     ?>
       <td class = "escrita"  align="center" >&nbsp;<?echo  number_format($media, 2, ',', '.'); ?></td>
    <?
   }
 else
  {
  ?>
       <td class = "escrita"  align="center" >&nbsp;<?echo  $tp__legenda. number_format($media, 2, ',', '.'); ?></td>
  <?
   }

}



 }
else if ($situacao_aluno =='7')
  {



   if ($media_promovido!='-')
          {

            ?>
                  <td class = "escrita"  align="center" >&nbsp;<?echo  $tp__legenda.number_format($tp__nota_especial, 1, ',', '.'); ?></td>
            <?

           }
    else
      {

            ?>
                  <td class = "escrita"  align="center" >&nbsp;<?echo $tp__legenda.$media_promovido; ?></td>
            <?


      }
   }
else
   {

?>



    <td class = "escrita"  align="center" >&nbsp;<?echo "-"; ?></td>
<?
    }
              $linha_tabela++;



 } // fim do while





/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
} //fim do if que filtra as notas dos alunos

//**************se nota n�o localizada***********falta lancamento ou o componente n�o esta na grade***********************************************************
//**************se nota n�o localizada***********falta lancamento ou o componente n�o esta na grade***********************************************************//**************se nota n�o localizada***********falta lancamento ou o componente n�o esta na grade***********************************************************
//**************Alunos  n�o que fazem dependencia tb n�o existem disciplina***********************************************************
//**************Alunosn�o n�o que fazem dependencia tb n�o existem disciplina***********************************************************
else
   {



       $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina_compara'
       and id_serie = '$grade_turma' and id_modalidade = '$modalidade'     and inep = '$inep'";
       $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
       $linhasgrade=mysql_num_rows($resultadograde);
       if ($linhasgrade>0)
       {
          while($pegargrade=mysql_fetch_array($resultadograde))
           {
                $reprova      =  $pegargrade["reprova"];
            }
        }





      //5 - evadido   e 3 traferido
     if ($situacao_aluno=='3')
        {
            $situacao = "-";
        }




 //if ($situacao_aluno !='8')
//   if (($situacao =='A') && ($situacao_aluno !='8'))
  if (($situacao =='A') && ($situacao_aluno !='8'))
         {
            $situacao = "-";
         }
  else  if (($t_grade_disciplina != $linha_tabela) && ($situacao_aluno =='1'))
        {
                       $situacao = "-";
        }

    else if ($situacao_aluno =='5')
      {
       $situacao = "-";
      }
   else
      {
         if ($reprova!="S")  //($id_disciplina_compara != "20")  //Disciplina que s�o dispensadas
            {
                        if ($situacao_aluno == '2')
                              $situacao =  "-";   //$situacao =  "DE";
            }
          else
           {
             // $situacao =  "-";
           }
     }


 /**Caso n�o tenha disciplina e n�o pertenca a turma de dependencia ai ele retem o aluno pois o numero de disciplina e menor que a grade*/
    if (($reprova=="S") && (!(($turma_dep=='75') || ($turma_dep=='76') || ($turma_dep=='77') ||($turma_dep=='78') ||($turma_dep=='79'))))
        {
           $falta_lancamento = 1;
           $situacao = "R";
           $passou =  "1";
         }






































/*******************Analisando Situacoes especiais como Provao Modular Enem*****/
/*

Faz primeiramente uma leitura na base normal logo ap�s faz busca na tabela de prova especiais.

*/




$tp_avaliacao_especial=0;
$media_promovido="-";





$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina_compara'
                     and tp.id= c.tp_avaliacao 	 and  c.cancelado = 'N'";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
       {


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp__legenda              =  $pegar_prova_especial["legenda"];







          $aluno_eliminacao_componente = 1;



         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-".$pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }




          if ($tp_avaliacao_especial!=3)
            {
               if($situacao_aluno != '7')
                  $media                              = $tp__nota_especial;
              else
                 $media_promovido                     = $tp__nota_especial;
            }
          else  //conselho de professores
            {
              $media = $media;

          }

       }


   if ($aluno_eliminacao_componente==0)
     {
      if (($media < 6.0))
       {
        if ($adere_exame_final==1)
          {

            $mfinal = ($media*6 + $examefinal*4);

               if ($mfinal < 50.0)
                  {
                      $situacao = "R";
                      $passou = '1';


                   if ($examefinal > $media)
                           $media = $mfinal/10;
                          // $media = $examefinal; conforme orienta��o do antonio pinto
                         // $media = $examefinal; conforme orienta��o do antonio pinto
                    else
                          $media = $mfinal/10;

                 }
              else
                  {
                          $situacao = "A";
                          $media = $mfinal/10;

                 }

           }
          else   //*nao adere exame final**//
             {
                 $mfinal =$media/10;
                 $situacao = "R";
                 $passou = '1';
             }
        }

     }

/*passou indica que e reprovado*/

     if ($passou != '1')
           $situacao= "A";


       $passou = 0;




 }
/***************************************Fim de prova Especiais*****************************************************************************/
/***************************************Fim de prova Especiais*****************************************************************************/
/***************************************Fim de prova Especiais*****************************************************************************/














/*o retido e visto por uma unica nota menor que a media desta forma se ele for diferente lanca a situacao
se nao tra�a*/





if (($situacao !='R') &&  ($situacao_aluno !='8'))
 {


/*****************Totalizador*************/
/*****************Totalizador*************/

   if ($situacao=='A')
        {
            $total_aprovado  = $total_aprovado +1;
        }
   else if ($situacao=='R')
       {
            $total_reprovado = $total_reprovado +1;
       }
   else if ($situacao=='TR')
       {
            $total_transferido = $total_transferido +1;
       }
   else if ($situacao=='RE')
       {
            $total_remanejado = $total_remanejado +1;
       }

   else if ($situacao=='DE')
       {
            $total_desistente = $total_desistente +1;
       }
   else if ($situacao=='RF')
       {
            $total_reprovadofalta = $total_reprovadofalta +1;
       }
   else if ($situacao=='PR')
       {
            $total_promovido = $total_promovido +1;
       }
   else if ($situacao=='FA')
       {
            $total_falecido = $total_falecido +1;
       }


/***************** Fim do Totalizador*************/

//           if ($aluno == "337657")
//            echo "* $situacao";


?>
    <td class = "escrita"  align="center" >&nbsp;<?echo $situacao; ?></td>
<?

}
else
 {
?>
    <td class = "escrita"  align="center" >&nbsp;<?echo "-"; ?></td>
<?

}






if (($situacao_aluno =='7'))
 {
 if ( $tp_avaliacao_especial == 1)
  {
   ?>
    <td class = "escrita"  align="center" >&nbsp;<?echo  $tp__legenda. number_format($media, 2, ',', '.'); ?></td>
   <?
  }
 }






     //} // if caso o aluno pertencaca a turma de depencia
  } // else caso n�o localiza nota


 $aluno_eliminacao_componente = 0;
 } // while disciplina grade varre




//if ($aluno=='219483')
//     echo "* $media";

 $aluno_eliminacao_componente = 0;
}//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************
//***************************SE N�O EXISTE NOTAS*****************************************************************

else
 {
 /***********************Conta Grade Disciplina**************************************************************************************************/



if ($situacao!="D")
 {

 $sqlcontagrade="select count(id) as t_grade_disciplina from grade_curricular where
 id_serie = '$grade_turma' and id_modalidade = '$modalidade'   and  inep = '$inep'";
 $resultadocontagrade=mysql_query($sqlcontagrade) or die (mysql_error());
 $linhascontagrade=mysql_num_rows($resultadocontagrade);
 if ($linhascontagrade>0)
  {
     while($pegarcontagrade=mysql_fetch_array($resultadocontagrade))
         {
           $t_grade_disciplina      =  $pegarcontagrade["t_grade_disciplina"];
         }

  }


$sql_conta_nota="SELECT count(id) t_conta_nota from nota_aluno
 where  inep = '$inep'
 and    id_aluno = '$aluno'
 and    ano = '$txtano'";
 $resultadocontanota=mysql_query($sql_conta_nota) or die (mysql_error());
 $linhascontanota=mysql_num_rows($resultadocontanota);
 if ($linhascontanota>0)
  {
     while($pegar_t_nota=mysql_fetch_array($resultadocontanota))
         {
               $t_conta_nota      =  $pegar_t_nota["t_conta_nota"];
         }

     $situacao = 'R';

  }


/*filtro com disciplina*/
if ($t_conta_nota == 0)
   {
   while( $t_grade_disciplina > 0)
      {

 ?>
      <td class = "escrita"  align="center" >&nbsp;<?echo "-"; ?></td>
 <?

      $t_grade_disciplina= $t_grade_disciplina-1;

      }

   }



 if (($t_grade_disciplina != $t_conta_nota) && ($situacao_aluno =='1'))
      {
                       $situacao = "-";
      }


if ($disciplina != "20") //religiao
 {
//  if ($situacao_aluno !='8')
    {
       if ($t_grade_disciplina != $t_conta_nota)
         {
          if ($diferenca_total_faltas >200)
             $situacao = 'RF';


            if ($situacao_aluno == '2')
               {
                 $situacao =  "-";
               }
            else if ($situacao_aluno =='1')
                  {
                    $situacao = "-";
                  }
           else
                 $situacao =  "Falta Lan�amento";


// echo "linha $linhast_notas";
//echo  "t_grade $t_grade_disciplina";






     }
                       else  if ($modalidade== '1')
                            {
                             if (($turmasserie>=2) && ($turmasserie<=6))
                              {
                                if ($diferenca_total_faltas > 50)
                                 {
                                  $situacao ="RF";
                                }
                              }
                            }





  }
 }
else
 {
          $situacao =  "-";
 }




  }// fim se

}// fim else

/*************************************************************************************************************************/


//         if  (($aluno == "170520"))
//                       echo "$situacao ";    

















//if (($situacao_aluno =='1') || (($situacao_aluno =='3') && ($id_status_transferencia=='1')))

if (($situacao_aluno == 1) || ($situacao_aluno == 8))
 {
//   if ($aluno=='282453')
//       echo "passou $situacao" ;

/*****************Totalizador*************/
/*****************Totalizador*************/

   if ($situacao=='A')
        {
            $total_aprovado  = $total_aprovado +1;
        }
   else if ($situacao=='R')
       {
            $total_reprovado = $total_reprovado +1;
       }
   else if ($situacao=='TR')
       {
            $total_transferido = $total_transferido +1;
       }
   else if ($situacao=='RE')
       {
            $total_remanejado = $total_remanejado +1;
       }

   else if ($situacao=='DE')
       {
            $total_desistente = $total_desistente +1;
       }
   else if ($situacao=='RF')
       {
            $total_reprovadofalta = $total_reprovadofalta +1;
       }

   else if ($situacao=='PR')
       {
            $total_promovido = $total_promovido +1;
       }
   else if ($situacao=='FA')
       {
            $total_falecido = $total_falecido +1;
       }


/***************** Fim do Totalizador*************/


      ?>
        <td  class = "escrita" align="center"><font size="2" color="#FF0000"><?echo $situacao;?></td>
      <?
   }
else
   {

   if ($situacao_aluno =='2')
          $situacao = "RE"; //remanejado de turma;
  else if (($situacao_aluno =='3') && ($id_status_transferencia!='1'))
         $situacao = "TR"; //Transferido

   else if ($situacao_aluno =='4')
         $situacao = "FA"; //Falecido

   else if ($situacao_aluno =='5')
         $situacao = "DE"; //desistente

   else if ($situacao_aluno =='7')
         $situacao = "PR"; //PROMOVIDO

   else if ($situacao_aluno =='8')
         $situacao = "DP"; //DEPENDENCIA






/*****************Totalizador*************/
/*****************Totalizador*************/

   if ($situacao=='A')
        {
            $total_aprovado  = $total_aprovado +1;
        }
   else if ($situacao=='R')
       {
            $total_reprovado = $total_reprovado +1;
       }
   else if ($situacao=='TR')
       {
            $total_transferido = $total_transferido +1;
       }
   else if ($situacao=='RE')
       {
            $total_remanejado = $total_remanejado +1;
       }

   else if ($situacao=='DE')
       {
            $total_desistente = $total_desistente +1;
       }
   else if ($situacao=='RF')
       {
            $total_reprovadofalta = $total_reprovadofalta +1;
       }

   else if ($situacao=='PR')
       {
            $total_promovido = $total_promovido +1;
       }
   else if ($situacao=='FA')
       {
            $total_falecido = $total_falecido +1;
       }

/***************** Fim do Totalizador*************/

   ?>




       <td align="center"><font size="2"><?echo $situacao;?></td>
   <?
   }









 }//while turma aluno
 /**************************************************************************************************///if
?>



  </tr>
<?



   }//alunos


/*******Fim**Turma de aluno **************************************/
/*******Fim**Turma de aluno **************************************/
/*******Fim**Turma de aluno **************************************/




  }



 $sql = "select count(*) as total           from aluno a,turma_aluno ta,turma t
       where  t.inep = '$inep'
	   and    ta.id_aluno=a.id
	   and    ta.id_turma=t.id
	   and    t.id= '$txtturma'
       order by ta.n_chamada, ta.n_chamada";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];

}//while


if ($total>0)
  {
?>


<?
}
else
{
?>



<?
 }
?>
</table>





<table width="100%">
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escrita" align="justify"><?echo $tp_obs_ava_especial;?></td>
</tr>
</table>



<table width="100%">
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escrita" align="left">E para constar, lavrei a presente ata que vai assinada por mim e pelo Diretor(a)</td>
</tr>
</table>


<table width="100%">
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>Secret�ria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Diretor(a)</b></td>
	<td>&nbsp;</td>
</tr>
</table>


<table width="100%">
<table border="0"  class="bordasimples" cellspacing="0"  align="justify" width="100%" bgcolor=#ffffff>
<tr>
	<td colspan="6"   class="escrita"><?echo  $ata;?></td>
</tr>

</table>




<table border="0"  class="bordasimples" cellspacing="0"  align="left" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="center"><b>Legenda /Descri��o</b></td>
</tr>

<?

$descricao_legenda ="";

  $sqlgrade="select *  from tp_provao";
  $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
  $linhasgrade=mysql_num_rows($resultadograde);
if ($linhasgrade>0)
   {
while($pegargrade=mysql_fetch_array($resultadograde))
    {

        $descricao_grade            = $pegargrade["descricao"];
        $legenda_grade              = $pegargrade["legenda"];
        $descricao_legenda =  $descricao_legenda. $legenda_grade.$descricao_grade.";";
?>


<?
    }
   }

?>

<tr>
	<td colspan="6" class="escritagrade"><?echo  $descricao_legenda;?></td>
</tr>

</table>




<table border="0"  class="bordasimples" cellspacing="0"  align="left" width="100%" bgcolor=#ffffff>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="center"><b>Estat�stica</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="left"><b>
    Total de Alunos = <?echo  $total_aluno_turma;?>
    Aprovados =<?echo  $total_aprovado;?>
     Retidos =  <?echo  $total_reprovado;?>
     Transferidos = <?echo  $total_transferido;?>
     Desistente = <?echo  $total_desistente;?>
     Reprovado Por Falta(s) = <?echo  $total_reprovadofalta;?>
     Remanejado(s) = <?echo  $total_remanejado;?>


     Promovido(S)     = <?echo  $total_promovido;?>
     Falecido(s)    = <?echo  $total_falecido;?>



     </b></td>
    </tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="left">
    <b>
       Aprovados = <?echo  number_format((($total_aprovado*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Retido(s) =  <?echo  number_format((($total_reprovado*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Transferido(s) = <?echo  number_format((($total_transferido*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Desistente(s) =  <?echo  number_format((($total_desistente*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Reprovado Por Falta(s) =  <?echo  number_format((($total_reprovadofalta*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Remanejado(s) =  <?echo  number_format((($total_remanejado*100)/$total_aluno_turma), 2, ',', '.')."%";?>


       Promovido(S) =  <?echo  number_format((($total_promovido*100)/$total_aluno_turma), 2, ',', '.')."%";?>
       Falecido(s) =   <?echo  number_format((($total_falecido*100)/$total_aluno_turma), 2, ',', '.')."%";?></b></td>


    </tr>




</table>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao"><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir - formul�rio em modo paissagem."/></b></td>
</tr>
</table>








