<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }




if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $txtturmadiario	           = $_POST["txtid_turma"];
    $txtdisciplina   	       = $_POST["txtid_disciplina"];
    $idaluno    	           = $_POST["txtid_aluno"];
    $txtetapa	               = $_POST["txtetapa"];
    $nota    	               = $_POST["txtnota"];
    $falta  	               = $_POST["txtfalta"];
}


$media = 6.0;

if ($txtetapa == '1')
  {
    $desc_etapa = '1� BIM';
    $desc_grava = '1BIM';
  }

else if ($txtetapa == '2')
  {
    $desc_etapa = '2� BIM';
    $desc_grava = '2BIM';
  }

elseif ($txtetapa == '3')
  {
    $desc_etapa = '3� BIM';
    $desc_grava = '3BIM';
  }
else if ($txtetapa == '4')
  {
    $desc_etapa = '4� BIM';
    $desc_grava = '4BIM';
  }
else if ($txtetapa == '5')
  {
    $desc_etapa = 'REC 1� BIM';
    $desc_grava = 'REC1';
  }

else if ($txtetapa == '6')
  {
    $desc_etapa = 'REC 2� BIM';
    $desc_grava = 'REC2';
  }
else if ($txtetapa == '7')
  {
    $desc_etapa = 'REC 3� BIM';
    $desc_grava = 'REC3';
  }
else if ($txtetapa == '8')
  {
    $desc_etapa = 'REC 4� BIM';
    $desc_grava = 'REC4';
  }

else if ($txtetapa == '9')
  {
    $desc_etapa = 'EXAME FINAL';
    $desc_grava = 'FINAL';
  }

else if ($txtetapa == '10')
  {
    $desc_etapa = 'REC 1� SEMESTRE';
      $desc_grava = 'R1R2';
  }
else if ($txtetapa == '11')
  {
    $desc_etapa = 'REC ANUAL';
    $desc_grava = 'RRRR';
    
  }
else if ($txtetapa == '12')
  {
    $desc_etapa = 'REC 2� SEMESTRE';
    $desc_grava = 'R2R3';
  }



if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }




if (trim($txtturmadiario)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Turma n�o definida.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



$sqlgerencia = "select * from turma where id  = '$txtturmadiario'
               and modalidade = '2'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
  if (($txtetapa=='3') or ($txtetapa=='4')  or ($txtetapa=='7') or ($txtetapa=='8') or ($txtetapa=='11') or ($txtetapa=='12'))
          {

                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Modalidade da turma n�o aceita essa etapa.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
           }
}
























$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }




$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$ano.".".$mes.".".$dia;




$sql="SELECT semestre,modalidade FROM turma where id = '$txtturmadiario' and  inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $id_semestre         = $pegar["semestre"];
         $id_modalidade       = $pegar["modalidade"];


   }
 }







/*primeiro bimestre*****************************************************************/

$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa = '$txtetapa'
               and situacao = 'F'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
 /************* O lan�amento est� dentro do prazo*****************************/
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">
                      <b>Per�odo de lan�amento encerrado.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
}




$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and situacao = 'A'
               and id_etapa = '$txtetapa'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas <= 0)
{


    /************* O lan�amento est� dentro do prazo*****************************/
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido para  Lan�amento.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
}

if (($id_modalidade=='1') || ($id_modalidade=='3'))
{
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and dt_inicio <= '$data'
               and dt_fim    >= '$data'
               and situacao  = 'A'
               and id_etapa  = '$txtetapa'
               and id_modalidade = '$id_modalidade'";
}
else
{
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and dt_inicio <= '$data'
               and dt_fim    >= '$data'
               and situacao  = 'A'
               and id_etapa  = '$txtetapa'
               and id_modalidade = '$id_modalidade'
               and id_semestre = '$id_semestre'";

}


$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
    /************* O lan�amento est� dentro do prazo*****************************/

}
else
{

                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Lan�amento de nota fora do per�do.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;


}

/***************************************************************************************************************/





$sqlcabeca="select * from  nota_cabecalho where id_turma = '$txtturmadiario'  and inep= '$inep' and id_disciplina='$txtdisciplina'
and ano='$txtano' and bimestre = '$desc_grava'";
$resultado=mysql_query($sqlcabeca) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
$achou = $linhas;

if ($linhas<=0)
{

      $sql    = "insert into nota_cabecalho (inep,id_turma,data,usuario,ano,id_disciplina,id_turmaprofessor,bimestre)
      values ('$inep','$txtturmadiario','$data','$cpf','$txtano','$txtdisciplina','$txtturmadiario','$desc_grava')";



   if (@mysql_query($sql))
      {
        if(mysql_affected_rows() == 1)
    		{
            }
       }
    else
      {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
          }
        @mysql_close();
     }
   }







if($_SERVER["REQUEST_METHOD"] == "POST")
         {


      $sql_situacao="SELECT situacao FROM turma_aluno where id_aluno = '$idaluno'
      and inep = '$inep'
      and id_turma = '$txtturmadiario'";
      $resultado_situacao=mysql_query($sql_situacao) or die (mysql_error());
      $linhas_situacao=mysql_num_rows($resultado_situacao);
      if ($linhas_situacao>0)
       {
         while($pegar_situacao=mysql_fetch_array($resultado_situacao))
        {
         $situacao_aluno       = $pegar_situacao["situacao"];
        }
       }






      $sql_professor="SELECT cpf FROM turmaprofessor where id_disciplina = '$txtdisciplina'
      and inep = '$inep'   and id_turma = '$txtturmadiario' and ano = '$txtano'";
      $resultado_professor=mysql_query($sql_professor) or die (mysql_error());
      $linhas_professor=mysql_num_rows($resultado_professor);
      if ($linhas_professor > 0)
       {
         while($pegar_professor=mysql_fetch_array($resultado_professor))
        {
            $txtprofessor       = $pegar_professor["cpf"];
        }
       }






 if (($situacao_aluno == '1') || ($situacao_aluno == '8'))
{

    if ($situacao_aluno == '1')
     {
   /*Verifica se a turma e de dependencia para permitir lancamento de nota tanto regular como dependencia   */


         $sqlturma_nota="select * from  nota_aluno where  id_aluno = '$idaluno' and inep= '$inep'
         and id_disciplina='$txtdisciplina' and ano = '$txtano' and id_turma='$txtturmadiario'";
         $resultado_diario_nota=mysql_query($sqlturma_nota) or die (mysql_error());
         $linhasturma_diario_nota=mysql_num_rows($resultado_diario_nota);
         if ($linhasturma_diario_nota>0)
               {
              while($pegar_nota=mysql_fetch_array($resultado_diario_nota))
                  	  {
             	        $id_turma_bd_nota    =$pegar_nota["id_turma"];
                       }
               }





         $sqlturma_diario="select * from  turma  where  id = '$id_turma_bd_nota'
                            and ((turmas = '75')
                            or (turmas = '76')
                            or (turmas = '77')
                            or (turmas = '78')
                            or (turmas = '79'))";
         $resultado_diario=mysql_query($sqlturma_diario) or die (mysql_error());
         $linhasturma_diario=mysql_num_rows($resultado_diario);
         if ($linhasturma_diario>0)
               {
               $turma_de_dependencia = '1';
               }
          else
              {
              $turma_de_dependencia = '0';

              }
            


        if   ($turma_de_dependencia == '1')
        /*Turma dependencia*/
            {
             if ($txtetapa == '1')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota1 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                             }

                           else if ($txtetapa == '2')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota2 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                             }
                            elseif ($txtetapa == '3')
                              {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota3 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                              }
                            else if ($txtetapa == '4')
                              {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                              }
                             else if ($txtetapa == '5')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec1 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                               }
                             else if ($txtetapa == '6')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec2 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                               }
                            else if ($txtetapa == '7')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec3 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                                }
                            else if ($txtetapa == '8')
                                {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                                 }
                            else if ($txtetapa == '9')
                                    {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	examefinal >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                                    }
                           else if ($txtetapa == '10')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	recuperacao1 >=0 and recuperacao2 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                             }
                          else if ($txtetapa == '11')
                            {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and recuperacao1 >=0 and recuperacao2 >=0 and recuperacao3 >=0 and recuperacao4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                            }
                           else if ($txtetapa == '12')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	recuperacao3 >=0 and recuperacao4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                             }






            }
        else
            {



               if ($txtetapa == '1')  //1 bimestre
                             {

               $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
               and n.id_disciplina='$txtdisciplina'
               and t.ano = '$txtano'
               and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota1 >=0";
               $resultado=mysql_query($sql) or die (mysql_error());
               $linhas=mysql_num_rows($resultado);
                             }

               else if ($txtetapa == '2')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota2 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                             }
                            elseif ($txtetapa == '3')
                              {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota3 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                              }
                            else if ($txtetapa == '4')
                              {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                              }
                             else if ($txtetapa == '5')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec1 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                               }
                             else if ($txtetapa == '6')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec2 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                               }
                            else if ($txtetapa == '7')
                               {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec3 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                                }
                            else if ($txtetapa == '8')
                                {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and  not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and rec4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                                 }
                            else if ($txtetapa == '9')
                                    {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	examefinal >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);
                                    }
                           else if ($txtetapa == '10')
                             {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79'))  and  	recuperacao1 >=0  and  	recuperacao2 >=0 ";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                             }
                          else if ($txtetapa == '11')
                            {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	recuperacao1 >=0  and  	recuperacao2 >=0 and  	recuperacao3 >=0  and  	recuperacao4 >=0";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                            }


                          else if ($txtetapa == '12')
                            {
                 $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
                 and n.id_disciplina='$txtdisciplina'
                 and t.ano = '$txtano'
                 and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and  	recuperacao3 >=0  and  	recuperacao4 >=0 ";
                           $resultado=mysql_query($sql) or die (mysql_error());
                           $linhas=mysql_num_rows($resultado);

                            }




            }
/**********************************************/
   }

else if ($situacao_aluno == '8')
     {
         $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
         and inep= '$inep'
         and id_disciplina='$txtdisciplina'
         and ano = '$txtano'
         and id_turma = '$txtturmadiario'";
         $resultado=mysql_query($sql) or die (mysql_error());
         $linhas=mysql_num_rows($resultado);
      }


/*****************************************Inclus�o*************************************************************/
if ($linhas<=0)
 {

         $nota_bim1           = mysql_result($resultado, 0, "nota1");
         $nota_bim2           = mysql_result($resultado, 0, "nota2");
         $nota_bim3           = mysql_result($resultado, 0, "nota3");
         $nota_bim4           = mysql_result($resultado, 0, "nota4");








      $sql_situacao="SELECT situacao FROM turma_aluno where id_aluno = '$idaluno'
      and inep = '$inep'
      and id_turma = '$txtturmadiario'";
      $resultado_situacao=mysql_query($sql_situacao) or die (mysql_error());
      $linhas_situacao=mysql_num_rows($resultado_situacao);
      if ($linhas_situacao>0)
       {
         while($pegar_situacao=mysql_fetch_array($resultado_situacao))
        {
         $situacao_aluno       = $pegar_situacao["situacao"];
        }
       }


if (($situacao_aluno == '1') || ($situacao_aluno == '8'))
{

         if ($txtetapa == '1')  //1 bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota1,t_falta1,id_disciplina,id_turmaprofessor, bim1)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }

        else if ($txtetapa == '2')  //2 bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota2,t_falta2,id_disciplina,id_turmaprofessor, bim2)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }

        else if ($txtetapa == '3')  //3 bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota3,t_falta3,id_disciplina,id_turmaprofessor, bim3)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }

        else if ($txtetapa == '4')  //4 bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota4,t_falta4,id_disciplina,id_turmaprofessor, bim4)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }


        else if ($txtetapa == '5')  //4 rec 1� bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao1,t_falta_rec1,id_disciplina,id_turmaprofessor, rec1)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }

        else if ($txtetapa == '6')  // rec 2� bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao2,t_falta_rec2,id_disciplina,id_turmaprofessor, rec2)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }
        else if ($txtetapa == '7')  //4 rec 3� bimestre
            {
          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao3,t_falta_rec3,id_disciplina,id_turmaprofessor, rec3)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
            }
        else if ($txtetapa == '8')  //4 rec 4� bimestre
             {
              $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao4,t_falta_rec4,id_disciplina,id_turmaprofessor, rec4)
              values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$txtdisciplina','$txtturmadiario','S')";
             }
        else if ($txtetapa == '9')  // exame final
             {
              $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,examefinal,id_disciplina,id_turmaprofessor, final)
              values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$txtdisciplina','$txtturmadiario','S')";
             }

        else if ($txtetapa == '10')  // REC SEMESTRAL  1� SEMESTRE  AS NOTAS VAO PARA RECUPERA��O DO 1 E 2 BIMESTRE
             {

              if ($nota_bim1 >=$media)
                  $recuperacao1 = 0;
              else
                 $recuperacao1 = $nota;


              if ($nota_bim2 >=$media)
                  $recuperacao2 = 0;
              else
                 $recuperacao2 = $nota;


              $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao1,t_falta_rec1,recuperacao2,t_falta_rec2,id_disciplina,id_turmaprofessor, rec1,rec2)
              values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$recuperacao1','$falta','$recuperacao2','$falta','$txtdisciplina','$txtturmadiario','S','S')";
             }


        else if ($txtetapa == '11')  // recupera��o anual
             {

/*
              if ($nota_bim1 >=$media)
                  $recuperacao1 = 0;
              else
                 $recuperacao1 = $nota;

              if ($nota_bim2 >=$media)
                  $recuperacao2 = 0;
              else
                 $recuperacao2 = $nota;


              if ($nota_bim3 >=$media)
                  $recuperacao3 = 0;
              else
                 $recuperacao3 = $nota;


              if ($nota_bim4 >=$media)
                  $recuperacao4 = 0;
              else
                 $recuperacao4 = $nota;

  */


              $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao1,t_falta_rec1,recuperacao2,t_falta_rec2,recuperacao3,t_falta_rec3,recuperacao4,t_falta_rec4,id_disciplina,id_turmaprofessor, rec1,rec2,rec3,rec4)
              values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$nota','$falta','$nota','$falta','$nota','$falta','$nota','$falta','$txtdisciplina','$txtturmadiario','S','S','S','S')";
             }


        else if ($txtetapa == '12')  // REC SEMESTRAL  2� SEMESTRE  AS NOTAS VAO PARA RECUPERA��O DO 1 E 2 BIMESTRE
             {

              if ($nota_bim3 >=$media)
                  $recuperacao3 = 0;
              else
                 $recuperacao3 = $nota;


              if ($nota_bim4 >=$media)
                  $recuperacao4 = 0;
              else
                 $recuperacao4 = $nota;



              $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,recuperacao3,t_falta_rec3,recuperacao4,t_falta_rec4,id_disciplina,id_turmaprofessor,rec3,rec4 )
              values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$txtano','$recuperacao3','$falta','$recuperacao4','$falta','$txtdisciplina','$txtturmadiario','S','S')";
             }

     if (@mysql_query($sql))
      {
        if(mysql_affected_rows() == 1)
    		{
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Gravados com sucesso! <b></b></font></center>";
	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";
    exit;
            }
       }
    else
      {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
          }
        @mysql_close();
     }
   }

}
else
 {


         $nota_bim1           = mysql_result($resultado, 0, "nota1");
         $nota_bim2           = mysql_result($resultado, 0, "nota2");
         $nota_bim3           = mysql_result($resultado, 0, "nota3");
         $nota_bim4           = mysql_result($resultado, 0, "nota4");




         $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
         and id_disciplina='$txtdisciplina'
         and ano = '$txtano'";
         $resultado=mysql_query($sql) or die (mysql_error());
         $linhas=mysql_num_rows($resultado);




      if ($txtetapa == '1')  //1 bimestre
            {

            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and nota1 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

              $sqlaltera = "update nota_aluno set  nota1 ='$nota', t_falta1 = '$falta', bim1 = 'S'
              where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }

        else if ($txtetapa == '2')  //2 bimestre
            {


            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and nota2 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

         $sqlaltera = "update nota_aluno set  nota2 ='$nota', t_falta2 = '$falta', bim2 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }

        else if ($txtetapa == '3')  //3 bimestre
            {
            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and nota3 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }




         $sqlaltera = "update nota_aluno set  nota3 ='$nota', t_falta3 = '$falta', bim3 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }

        else if ($txtetapa == '4')  //4 bimestre
            {
            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and nota4 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

         $sqlaltera = "update nota_aluno set  nota4 ='$nota', t_falta4 = '$falta', bim4 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }


        else if ($txtetapa == '5')  //4 rec 1� bimestre
            {

            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao1 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

         $sqlaltera = "update nota_aluno set  recuperacao1 ='$nota',  	t_falta_rec1 = '$falta', rec1 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";


            }

        else if ($txtetapa == '6')  // rec 2� bimestre
            {

            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao2 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas_professor > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

         $sqlaltera = "update nota_aluno set  recuperacao2 ='$nota',  	t_falta_rec2 = '$falta', rec2 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }
        else if ($txtetapa == '7')  //4 rec 3� bimestre
            {
            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao3 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

         $sqlaltera = "update nota_aluno set  recuperacao3 ='$nota',  	t_falta_rec3 = '$falta', rec3 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
            }
        else if ($txtetapa == '8')  //4 rec 1� bimestre
             {

            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao4 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

              $sqlaltera = "update nota_aluno set  recuperacao4 ='$nota',  	t_falta_rec4 = '$falta', rec4 = 'S'
             where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
             }
        else if ($txtetapa == '9')  // exame final
             {

            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and examefinal > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

                $sqlaltera = "update nota_aluno set  examefinal ='$nota', final = 'S'
                where   id_aluno = '$idaluno'  and id_disciplina = '$txtdisciplina' and ano = '$txtano'";
             }




        else if ($txtetapa == '10')  // REC SEMESTRAL  1� SEMESTRE  AS NOTAS VAO PARA RECUPERA��O DO 1 E 2 BIMESTRE
             {


              if ($nota_bim1 >=$media)
                  $recuperacao1 = 0;
              else
                 $recuperacao1 = $nota;


              if ($nota_bim2 >=$media)
                  $recuperacao2 = 0;
              else
                 $recuperacao2 = $nota;


            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao1 > 0 and recuperacao2 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

                   $sqlaltera = "update nota_aluno set
                                 recuperacao1 ='$recuperacao1',
                  	             t_falta_rec1 = '$falta',
                                 recuperacao2 ='$recuperacao2',
                               	 t_falta_rec2 = '$falta',
                                 rec1 = 'S',
                                 rec2 = 'S'
                                 where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
             }


        else if ($txtetapa == '11')  // recupera��o anual
             {


              if ($nota_bim1 >=$media)
                  $recuperacao1 = 0;
              else
                 $recuperacao1 = $nota;

              if ($nota_bim2 >=$media)
                  $recuperacao2 = 0;
              else
                 $recuperacao2 = $nota;


              if ($nota_bim3 >=$media)
                  $recuperacao3 = 0;
              else
                 $recuperacao3 = $nota;


              if ($nota_bim4 >=$media)
                  $recuperacao4 = 0;
              else
                 $recuperacao4 = $nota;



            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao1 > 0 and recuperacao2 > 0 and recuperacao3 > 0 and recuperacao4 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }

                   $sqlaltera = "update nota_aluno set

                                 recuperacao1 ='$recuperacao1',
                  	             t_falta_rec1 = '$falta',
                                 recuperacao2 ='$recuperacao2',
                  	             t_falta_rec3 = '$falta',
                                 recuperacao3 ='$recuperacao3',
                  	             t_falta_rec3 = '$falta',
                                 recuperacao4 ='$recuperacao4',
                               	 t_falta_rec4 = '$falta',
                                 rec1 = 'S',
                                 rec2 = 'S',
                                 rec3 = 'S',
                                 rec4 = 'S'
                                 where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";

             }


        else if ($txtetapa == '12')  // REC SEMESTRAL  2� SEMESTRE  AS NOTAS VAO PARA RECUPERA��O DO 1 E 2 BIMESTRE
             {

              if ($nota_bim3 >=$media)
                  $recuperacao3 = 0;
              else
                 $recuperacao3 = $nota;


              if ($nota_bim4 >=$media)
                  $recuperacao4 = 0;
              else
                 $recuperacao4 = $nota;



            $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
            and id_disciplina='$txtdisciplina'
            and ano = '$txtano'
            and recuperacao3 > 0 and recuperacao4 > 0";
            $resultado=mysql_query($sql) or die (mysql_error());
            $linhas=mysql_num_rows($resultado);
            if ($linhas > 0)
               {
                	echo "<html><head><title>Resposta !!!</title></head>";
                  	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                   	echo "<br><br><br>";
                   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno j� possui  nota lan�ada! <b></b></font></center>";
                   	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                   	echo "</body></html>";
                    exit;
               }


                   $sqlaltera = "update nota_aluno set
                                 recuperacao3 ='$recuperacao3',
                  	             t_falta_rec3 = '$falta',
                                 recuperacao4 ='$recuperacao4',
                               	 t_falta_rec4 = '$falta',
                                 rec3 = 'S',
                                 rec4 = 'S'
                                 where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$txtano'";
             }






         if (@mysql_query($sqlaltera))
              {

                if(mysql_affected_rows() == 1)
    		         {
                       $contaaceito=$contaaceito+1;
                       /*Dados Gravado*/
                     }
              }

       else
          {
             //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
             if(mysql_errno() == 1062)
		       {
                 echo $erros[mysql_errno()];
                 exit;
               }
		     else
		       {
                  echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                  exit;
               }
             @mysql_close();
           }


	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Gravados com sucesso! <b></b></font></center>";
	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";
    exit;

 }



}//situacao


} //post
else
 {
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\"><b>Dados n�o passado pelo m�todo</b></font></center>";
	echo "<br><br><center><a href=\"form_lanca_nota_individual_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";
    exit;
  }

//*******Arquivo de log********************************************************
                  $datalog=date("d-m-Y-H:i:s");
                  $fp = fopen("log/logs.txt", "a",0);
                  // Escreve "exemplo de escrita" no bloco1.txt
                  $assunto="lancamento de nota 2 bimestre";
                  $escreve = fwrite($fp, "$cpf,$login,$inep,$nte,$ntelogin,$assunto,$datalog.\r\n");
                  // Fecha o arquivo
                    fclose($fp);
    exit;

?>












