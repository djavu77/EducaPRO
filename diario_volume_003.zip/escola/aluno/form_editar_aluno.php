<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Editar dados de estudante';

$aluno = Aluno::get($_GET['id']);

if (!$aluno) {
    Notification::error("Aluno ID Estadual <b>{$_GET['id']}</b> n�o localizado.");
    redirect('escola/aluno/form_pesquisa_aluno_turma.php');
}

$sql = "SELECT id, descricao FROM tipo_necessidade ORDER BY descricao";
$necessidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT * FROM cor_raca ORDER BY descricao";
$etnias = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_estados, CONCAT(sigla, ' ', nome) AS sigla FROM estados ORDER BY sigla";
$estados = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_cidades AS id, nome FROM cidades WHERE estados_cod_estados = '{$aluno['uf_nascimento']}';";
$cidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM grau_parentesco ORDER BY id";
$grauParentescos = $pdo->query($sql)->fetchAll();

$sql = "SELECT codigo, descricao FROM municipio ORDER BY descricao";
$municipios = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM unidade_saude_familia ORDER BY descricao";
$unidadesSaudeFamilia = $pdo->query($sql)->fetchAll();

$programasAluno = array('ALUNO DIGITAL', 'MEDIA��O TECNOL�GICA', 'PROUCA');

function exibeFoto($foto) {
    if (!is_null($foto) && file_exists(ROOT_DIR . "/escola/aluno/fotos/{$foto}")) {
        return url("escola/aluno/fotos/{$foto}", true);
    }

    return url('/public/img/foto-vazia.png', true);
}

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form name="form" class="submit-wait" action="editar_aluno.php" method="POST" enctype="multipart/form-data">
        <fieldset class="well well-sm">
            <legend>Dados do estudante</legend>
            <div class="row">
                <div class="col-md-2">
                    <label for="imagem">
                        Foto do estudante
                        <img src="<?php echo exibeFoto($aluno['foto']) ?>" style="width:200px" class="img-thumbnail">
                        <input type="file" id="imagem" name="imagem" class="form-control">
                    </label>
                </div>
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="id">ID Estadual</label>
                                <input type="text" name="id" class="form-control" value="<?php echo $aluno['id'] ?>" id="id" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="text-danger" for="txtnaluno">Nome completo do estudante <small class="text-muted">(Sem abrevia��es)</small></label>
                                <input autofocus type="text" name="txtnaluno" class="form-control text-uppercase" maxlength="100" value="<?php echo $aluno['nome'] ?>" id="txtnaluno" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="text-danger" for="txtdtnascimento">Data Nascimento</label>
                                <input type="text" name="txtdtnascimento" value="<?php echo formataData($aluno['dt_nascimento']) ?>" class="form-control mask-data" maxlength="10" id="txtdtnascimento" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="fom-group">
                                <label class="text-danger" for="selectsexo">Sexo</label>
                                <select id="selectsexo" name="selectsexo" class="form-control" required>
                                    <option value=""></option>
                                    <option value="1" <?php selected($aluno['sexo'] == '1') ?>>Masculino</option>
                                    <option value="2" <?php selected($aluno['sexo'] == '2') ?>>Feminino</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtdt_matricula">Data de cadastro</label>
                                <input type="text" name="txtdt_matricula" value="<?php echo formataData($aluno['dt_matricula']) ?>" class="form-control mask-data" id="txtdt_matricula">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="idnacional">ID Nacional</label>
                                <input type="text" name="idnacional" class="form-control" value="<?php echo $aluno['id_nacional'] ?>" maxlength="20" id="idnacional" onKeyPress="return Enum(event)">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="selecttransporte">Transporte escolar</label>
                                <select id="selecttransporte" name="selecttransporte" class="form-control">
                                    <option value=""></option>
                                    <option value="N" <?php selected($aluno['transporte'] == 'N') ?>>N�o utiliza</option>
                                    <option value="S" <?php selected($aluno['transporte'] == 'S') ?>>Utiliza</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="selectacesso">Portal do Aluno</label>
                                <select id="selectacesso" name="selectacesso" class="form-control">
                                    <option value=""></option>
                                    <option value="N" <?php selected($aluno['acesso_portal'] == 'N') ?>>N�o acessa</option>
                                    <option value="S" <?php selected($aluno['acesso_portal'] == 'S') ?>>Acessa</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="select_altera_cod_acesso">Restaurar senha</label>
                                <select id="select_altera_cod_acesso" name="select_altera_cod_acesso" class="form-control">
                                    <option value="N">N�o</option>
                                    <option value="S">Sim</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="selectdeficiente" class="text-danger">Tem necessidade especial?</label>
                                <select id="selectdeficiente" required name="selectdeficiente" class="form-control" onchange="tp_necessidade(this.value)">
                                    <option value=""></option>
                                    <option value="N" <?php selected(in_array($aluno['deficiente'], [0, 'N'])) ?>>N�o</option>
                                    <option value="S" <?php selected(in_array($aluno['deficiente'], [1, 'S'])) ?>>Sim</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="form-group">
                                <label for="selecttipo_necessidade">Selecione o tipo de necessidade</label>
                                <select name="selecttipo_necessidade" id="selecttipo_necessidade" class="form-control" <?= ($aluno['deficiente'] == 'S') ? 'required' : 'disabled' ?>>
                                    <option value=""></option>
                                    <?php foreach($necessidades as $ne): ?>
                                        <option value="<?php echo $ne['id'] ?>" <?php selected($aluno['tipo_necessidade'] == $ne['id']) ?>><?php echo $ne['descricao'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Equipamento de programa</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="equipamento_programa">Programa</label>
                        <select name="equipamento_programa" id="equipamento_programa" class="form-control">
                            <option value=""></option>
                            <?php foreach ($programasAluno as $prog): ?>
                                <option value="<?php echo $prog ?>" <?php selected($prog == $aluno['equipamento_programa']) ?>><?php echo $prog ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="equipamento_nu_tombamento">N�mero de Tombamento</label>
                        <input type="text" name="equipamento_nu_tombamento" id="equipamento_nu_tombamento" class="form-control" value="<?php echo $aluno['equipamento_nu_tombamento'] ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_nu_serie">N�mero de S�rie</label>
                        <input type="text" name="equipamento_nu_serie" id="equipamento_nu_serie" class="form-control" value="<?php echo $aluno['equipamento_nu_serie'] ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="equipamento_chave_office">Chave do Office</label>
                        <input type="text" name="equipamento_chave_office" id="equipamento_chave_office" class="form-control" value="<?php echo $aluno['equipamento_chave_office'] ?>">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_data_recebimento">Data de Recebimento</label>
                        <input type="text" name="equipamento_data_recebimento" id="equipamento_data_recebimento" class="form-control mask-data" value="<?php echo formataData($aluno['equipamento_data_recebimento']) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_data_devolucao">Data de Devolu��o</label>
                        <input type="text" name="equipamento_data_devolucao" id="equipamento_data_devolucao" class="form-control mask-data" value="<?php echo formataData($aluno['equipamento_data_devolucao']) ?>">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="form-group">
                        <label for="equipamento_obs">Observa��es</label>
                        <input type="text" name="equipamento_obs" id="equipamento_obs" class="form-control" maxlength="255" value="<?php echo $aluno['equipamento_obs'] ?>">
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Documentos</legend>

            <?php
            $tipoDocumentoNovoSelecionado = in_array($aluno['mod_certidao'], array('1', 'Modelo Novo'));
            $tipoDocumentoAntigoSelecionado = in_array($aluno['mod_certidao'], array('2', 'Modelo Antigo'));
            ?>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="selecttp_certidao">Tipo de Certid�o</label>
                        <select id="selecttp_certidao" name="selecttp_certidao" class="form-control" onchange="tp_certidao(this.value)" required>
                            <option value="">Selecione o Tipo</option>
                            <option value="2" <?php selected($tipoDocumentoAntigoSelecionado) ?>>Modelo Antigo</option>
                            <option value="1" <?php selected($tipoDocumentoNovoSelecionado) ?>>Modelo Novo</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtcertidao">N�mero da Certid�o de Nascimento</label>
                        <input type="text" name="txtcertidao" value="<?php echo $aluno['termo_certidao'] ?>" class="form-control" id="txtcertidao" maxlength="50" <?php readonly($tipoDocumentoNovoSelecionado) ?>>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtfolha">Certid�o Folha N�</label>
                        <input type="text" name="txtfolha" class="form-control" value="<?php echo $aluno['folha_certidao'] ?>" id="txtfolha" maxlength="5" <?php readonly($tipoDocumentoNovoSelecionado) ?>>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtlivro">Certid�o Livro N�</label>
                        <input id="txtlivro" name="txtlivro" type="text" class="form-control" value="<?php echo $aluno['livro_certidao'] ?>" maxlength="8" <?php readonly($tipoDocumentoNovoSelecionado) ?>>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="dtemissao_certidao">Data de Emiss�o</label>
                        <input type="text" name="dtemissao_certidao" class="form-control mask-data" value="<?php echo formataData($aluno['dtemissao_certidao']) ?>" maxlength="10" id="dtemissao_certidao" <?php readonly($tipoDocumentoNovoSelecionado) ?>>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-offset-2 col-md-5">
                    <div class="form-group">
                        <label class="text-danger" for="txtcertidaonovo">Certid�o Nascimento Modelo Novo</label>
                        <input type="text" name="txtcertidaonovo" value="<?php echo $aluno['n_certidao_novo'] ?>" id="txtcertidaonovo" maxlength="50" class="form-control" <?php readonly($tipoDocumentoAntigoSelecionado) ?>>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="txtcertidaocasamento">Certid�o de Casamento</label>
                        <input type="text" name="txtcertidaocasamento" value="<?php echo $aluno['certidao_casamento'] ?>" id="txtcertidaocasamento" maxlength="120" class="form-control" placeholder="N�mero, Folha e Livro">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="selectcorraca">Etnia</label>
                        <select name="selectcorraca" id="selectcorraca" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($etnias as $et): ?>
                                <option value="<?php echo $et['id'] ?>" <?php selected($aluno['car_raca'] == $et['id']) ?>><?php echo $et['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="cpfaluno">CPF</label>
                        <input type="text" name="cpfaluno" class="form-control" value="<?php echo $aluno['cpf_aluno'] ?>" maxlength="11" id="cpfaluno" onKeyPress="return Enum(event)">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtRGaluno">RG</label>
                        <input type="text" name="txtRGaluno" class="form-control" value="<?php echo $aluno['rg_aluno'] ?>" id="txtRGaluno" maxlength="20">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtOrgaoExpaluno">Org�o Expedidor RG</label>
                        <input type="text" name="txtOrgaoExpaluno" value="<?php echo $aluno['orgaoexp_aluno'] ?>" class="form-control text-uppercase" id="txtOrgaoExpaluno" maxlength="20">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtdtemissaorgaluno">Data Emiss�o RG</label>
                        <input type="text" name="txtdtemissaorgaluno" value="<?php echo formataData($aluno['dtemissaorg_aluno']) ?>" class="form-control mask-data" id="txtdtemissaorgaluno" maxlength="10">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtnacionalidade">Nacionalidade</label>
                        <input type="text" name="txtnacionalidade" class="form-control text-uppercase" value="<?php echo $aluno['nacionalidade'] ?>" id="txtnacionalidade"  maxlength="50" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="cod_estado">Naturalidade UF</label>
                        <select name="cod_estado" id="cod_estado" onchange="estrangeiro(this.value)" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($estados as $es): ?>
                                <option value="<?php echo $es['cod_estados'] ?>" <?php selected($aluno['uf_nascimento'] == $es['cod_estados']) ?>><?php echo $es['sigla'] ?></option>
                            <?php endforeach  ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="cod_cidades">Naturalidade Cidade</label>
                        <select name="cod_cidades" id="cod_cidades" class="form-control" required>
                            <?php foreach ($cidades as $cid): ?>
                                <option value="<?php echo $cid['id'] ?>" <?php selected($aluno['muni_nascimento'] == $cid['id']) ?>><?php echo $cid['nome'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <?php $alunoEstrangeiro = ($aluno['uf_nascimento'] != 28) ?>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtpaisestrangeiro">Pa�s estrangeiro</label>
                        <input type="text" name="txtpaisestrangeiro" class="form-control text-uppercase" value="<?php echo $aluno['pais_estrangeiro'] ?>" id="txtpaisestrangeiro"  maxlength="30" <?php readonly($alunoEstrangeiro) ?>>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtestadoestrangeiro">Estado estrangeiro</label>
                        <input type="text" name="txtestadoestrangeiro" value="<?php echo $aluno['estado_estrangeiro'] ?>" class="form-control text-uppercase" id="txtestadoestrangeiro" maxlength="30" <?php readonly($alunoEstrangeiro) ?>>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtmunicipioestrangeiro">Cidade estrangeira</label>
                        <input type="text" name="txtmunicipioestrangeiro" class="form-control text-uppercase" value="<?php echo $aluno['municipio_estrangeiro'] ?>" id="txtmunicipioestrangeiro"  maxlength="40" <?php readonly($alunoEstrangeiro) ?>>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="selectsexo" class="text-danger">Bolsa Fam�lia?</label>
                        <select id="selectbosaf" name="selectbosaf" required class="form-control" onChange="tp_bosa_familia(this.value)">
                            <option value=""></option>
                            <option value="N" <?php selected($aluno['bolsa_familia'] == 'N') ?>>N�o</option>
                            <option value="S" <?php selected($aluno['bolsa_familia'] == 'S') ?>>Sim</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCPF">N� Cart�o Bolsa Fam�lia</label>
                        <input type="text" name="nbolsa" class="form-control" value="<?php echo $aluno['n_bolsa_fam'] ?>" maxlength="19" id="nbolsa"  onKeyPress="return Enum(event)" <?php readonly($aluno['bolsa_familia'] == 'N') ?>>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCPF">N� Cart�o SUS</label>
                        <input type="text" name="nsus" class="form-control" value="<?php echo $aluno['sus'] ?>" maxlength="20" id="nsus"  onKeyPress="return Enum(event)">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="unidade_saude_familia_id">Unidade de Sa�de da Fam�lia</label>
                        <select name="unidade_saude_familia_id" id="unidade_saude_familia_id" class="form-control chosen-deselect">
                            <option value=""></option>
                            <?php foreach ($unidadesSaudeFamilia as $unidadeSaude): ?>
                                <option value="<?php echo $unidadeSaude['id'] ?>" <?php selected($unidadeSaude['id'] == $aluno['unidade_saude_familia_id']) ?>><?php echo $unidadeSaude['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Dados do respons�vel</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="text-danger" for="selectgrauparente" >Grau de Parentesco</label>
                        <select name="selectgrauparente" id="selectgrauparente" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($grauParentescos as $grau): ?>
                                <option value="<?php echo $grau['id'] ?>" <?php selected($aluno['grau_parentesco'] == $grau['id']) ?>><?php echo $grau['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtresponsavel">Nome do Respons�vel</label>
                        <input type="text" name="txtresponsavel" class="form-control text-uppercase" maxlength="60" value="<?php echo $aluno['responsavel'] ?>" id="txtresponsavel" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="cpfresp">CPF</label>
                        <input type="text" name="cpfresp" class="form-control" value="<?php echo $aluno['cpfresp'] ?>" maxlength="11" id="cpf" onKeyPress="return Enum(event)" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtRGresp">RG</label>
                        <input type="text" name="txtRGresp" class="form-control" value="<?php echo $aluno['rgresponsavel'] ?>" id="txtRGresp"  maxlength="20" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtOrgaoExpresp">Org�o Expedidor RG</label>
                        <input type="text" name="txtOrgaoExpresp" value="<?php echo $aluno['orgaoexpresp'] ?>" class="form-control text-uppercase" id="txtOrgaoExpresp"  maxlength="20" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtdtemissaorgresp">Data de Emiss�o RG</label>
                        <input type="text" name="txtdtemissaorgresp" value="<?php echo formataData($aluno['dtemissaorgresp']) ?>" class="form-control mask-data" id="txtdtemissaorgresp" maxlength="10" required>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>Filia��o</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="filiacao" class="text-danger">Filia��o</label>
                        <select id="filiacao" required name="filiacao" class="form-control" onchange="tp_filiacao(this.value)">
                            <option value=""></option>
                            <option value="0" <?php selected($aluno['filiacao'] == '0') ?>>N�O DECLARADO</option>
                            <option value="1" <?php selected($aluno['filiacao'] == '1') ?>>PAI E/OU M�E</option>
                        </select>
                    </div>
                </div>
            </div>

            <div id="divFiliacao">
                <fieldset class="well well-sm">
                    <legend>Dados do pai</legend>

                    <?php $alunoTemFiliacao = ($aluno['filiacao'] == '0') ?>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="txtpai">Nome do Pai</label>
                                <input type="text" name="txtpai" class="form-control text-uppercase" maxlength="60" value="<?php echo $aluno['nome_pai'] ?>" id="txtpai" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="cpfpai">CPF</label>
                                <input type="text" name="cpfpai" class="form-control" value="<?php echo $aluno['cpf'] ?>" maxlength="11" id="cpfpai"  onKeyPress="return Enum(event)" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtRGpai">RG</label>
                                <input type="text" name="txtRGpai" class="form-control" value="<?php echo $aluno['rg_pai'] ?>" id="txtRGpai"  maxlength="20" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtOrgaoExppai">Org�o Expedidor RG</label>
                                <input type="text" name="txtOrgaoExppai" value="<?php echo $aluno['orgexprg_pai'] ?>" class="form-control text-uppercase" id="txtOrgaoExppai"  maxlength="20" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtdtemissaorgpai">Data de Emiss�o RG</label>
                                <input type="text" name="txtdtemissaorgpai" value="<?php echo formataData($aluno['dtrg_pai']) ?>" class="form-control mask-data" id="txtdtemissaorgpai" maxlength="10" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="well well-sm">
                    <legend>Dados da m�e</legend>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="txtmae">Nome da M�e</label>
                                <input type="text" name="txtmae" class="form-control text-uppercase" maxlength="60" value="<?php echo $aluno['nome_mae'] ?>" id="txtmae" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="cpfmae">CPF</label>
                                <input type="text" name="cpfmae" class="form-control" value="<?php echo $aluno['cpf_mae'] ?>" maxlength="11" id="cpfmae"  onKeyPress="return Enum(event)" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtRGmae">RG</label>
                                <input type="text" name="txtRGmae" class="form-control" value="<?php echo $aluno['rg_mae'] ?>" id="txtRGmae"  maxlength="20" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtOrgaoExpmae">Org�o Expedidor RG</label>
                                <input type="text" name="txtOrgaoExpmae" value="<?php echo $aluno['orgexprg_mae'] ?>" class="form-control text-uppercase" id="txtOrgaoExpmae"  maxlength="20" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtdtemissaorgmae">Data Emiss�o RG</label>
                                <input type="text" name="txtdtemissaorgmae" value="<?php echo formataData($aluno['dtrg_mae']) ?>" class="form-control mask-data" id="txtdtemissaorgmae" maxlength="10" <?php readonly($alunoTemFiliacao) ?>>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Endere�o</legend>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtcep">CEP</label>
                        <div class="input-group">
                            <input id="txtcep" name="txtcep" type="text" class="form-control mask-cep" maxlength="8" value="<?php echo $aluno['cep'] ?>" required>
                            <div class="input-group-btn">
                                <button type="button" id="btnCep" class="btn btn-default">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtEndereco">Logradouro (Av, Rua)</label>
                        <input type="text" name="txtEndereco" class="form-control text-uppercase" value="<?php echo $aluno['endereco'] ?>" required maxlength="40" size="40" id="txtEndereco" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtnr">N�mero</label>
                        <input type="text" name="txtnr" class="form-control" value="<?php echo $aluno['numero'] ?>" id="txtnr" maxlength="10" onKeyPress="return Enum(event)" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtBairro">Bairro</label>
                        <input type="text" name="txtBairro" value="<?php echo $aluno['bairro'] ?>" class="form-control text-uppercase" id="txtBairro" maxlength="40" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="lblcomplemento">Complemento</label>
                        <input type="text" name="txtcomplemento" class="form-control text-uppercase" value="<?php echo $aluno['complemento'] ?>"  maxlength="40" size="60" id="txtcomplemento"/>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="text-danger" for="cod_muni">Munic�pio</label>
                        <select name="cod_muni" id="cod_muni" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($municipios as $muni): ?>
                                <option value="<?php echo $muni['codigo']?>" <?php selected($aluno['cidade'] == $muni['codigo']) ?>><?php echo $muni['descricao'];?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtcontato">Telefone para Contato</label>
                        <input type="text" name="txtcontato" class="form-control mask-telefone" value="<?php echo $aluno['fonecontato'] ?>" id="txtcontato" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCelular">Celular</label>
                        <input type="text" name="txtCelular" class="form-control mask-telefone" value="<?php echo $aluno['fonecelular'] ?>" id="txtCelular" maxlength="20">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="form-group">
                        <label for="txtEmail">E-mail</label>
                        <input type="email" name="txtEmail" class="form-control" value="<?php echo $aluno['email'] ?>" id="txtEmail" maxlength="60">
                    </div>
                </div>
            </div>
        </fieldset>

        <div class="form-group">
            <label for="txtobs">Observa��es</label>
            <textarea name="txtobs" rows="4" id="txtobs" class="form-control"><?php echo $aluno['obs'] ?></textarea>
        </div>

        <div class="well well-sm">
            <button type="submit" class="btn btn-primary btn-submit-wait">SALVAR ALTERA��ES</button>
            <button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
        </div>
    </form>
</div>
<?php require_once page_footer(); ?>
<script src="generic1.js" type="text/javascript"></script>

</body>
</html>