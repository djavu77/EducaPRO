<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
  	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
	 include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }






//include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}








$id=  $_GET['codigo'];



if ($id != '')
   $_SESSION["id_aluno"] = $id;
else
  $id = $_SESSION["id_aluno"];



if(!empty($id))
{


$sql="SELECT * from aluno where id = '$id'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {
    $id                 =$pegar["id"];
    $nome               =trim($pegar["nome"]);

    $dt_nascimento      = date("m/d/Y",strtotime($pegar["dt_nascimento"]));

    $sexo               =$pegar["sexo"];
    $termo_certidao     =$pegar["termo_certidao"];
    $folha_certidao     =$pegar["folha_certidao"];
    $livro_certidao         =$pegar["livro_certidao"];


    $n_certidao_novo     =$pegar["n_certidao_novo"];





    $dtemissao_certidao      = date("m/d/Y",strtotime($pegar["dtemissao_certidao"]));


    $uf_nascimento          =$pegar["uf_nascimento"];
    $muni_nascimento        =$pegar["muni_nascimento"];
    $nome_pai               =trim($pegar["nome_pai"]);
    $rg_pai                 =$pegar["rg_pai"];
    $orgexprg_pai           =$pegar["orgexprg_pai"];

    $dtrg_pai              =$pegar["dtrg_pai"];
    $dtrg_pai    =date("m/d/Y",strtotime($pegar["dtrg_pai"]));
    $cpf                   =$pegar["cpf"];

    $nome_mae              =trim($pegar["nome_mae"]);
    $rg_mae                =$pegar["rg_mae"];
    $orgexprg_mae          =$pegar["orgexprg_mae"];
    $dtrg_mae              =$pegar["dtrg_mae"];
    $dtrg_mae    =date("m/d/Y",strtotime($pegar["dtrg_mae"]));


    $acesso_portal           =$pegar["acesso_portal"];


    $cpf_mae                 =$pegar["cpf_mae"];
    $endereco                =trim($pegar["endereco"]);
    $bairro                  =trim($pegar["bairro"]);
    $numero                   =$pegar["numero"];
    $cep                     =$pegar["cep"];
    $complemento             =trim($pegar["complemento"]);
    $cidade                 =$pegar["cidade"];

    $fonecontato              =$pegar["fonecontato"];
    $fonecelular              =$pegar["fonecelular"];
    $email                    =$pegar["email"];
    $obs                      =$pegar["obs"];

    $foto                     =$pegar["foto"];
    
    $txtresponsavel         = trim($pegar["responsavel"]);
    $selectgrauparente      = $pegar["grau_parentesco"];
    $txtRGresp              = $pegar["rgresponsavel"];
    $txtOrgaoExpresp        = $pegar["orgaoexpresp"];
    $txtdtemissaorgresp     = $pegar["dtemissaorgresp"];
    $txtdtemissaorgresp    =date("m/d/Y",strtotime($pegar["dtemissaorgresp"]));

    $cpfresp                = $pegar["cpfresp"];


    $n_bolsa_fam                = $pegar["n_bolsa_fam"];
    $id_nacional                = $pegar["id_nacional"];
    $filiacao                   = $pegar["filiacao"];
    $car_raca                   = $pegar["car_raca"];



    $inepbanco                =$pegar["inep"];
    $status                   =$pegar["status"];

    $deficiente                       = $pegar["deficiente"];
    $tipo_necessidade                = $pegar["tipo_necessidade"];
    $bolsa_familia                = $pegar["bolsa_familia"];



$txtpaisestrangeiro       = $pegar['pais_estrangeiro'];
$txtestadoestrangeiro     = $pegar['estado_estrangeiro'];
$txtnacionalidade         = $pegar['nacionalidade'];
$txtmunicipioestrangeiro  = $pegar['municipio_estrangeiro'];

$mod_certidao  = $pegar['mod_certidao'];



$cpfaluno                 = trim($pegar["cpf_aluno"]);
$txtRGaluno               = $pegar["rg_aluno"];
$txtOrgaoExpaluno         = $pegar["orgaoexp_aluno"];
$txtdtemissaorgaluno      =date("m/d/Y",strtotime($pegar["dtemissaorg_aluno"]));





//   echo "passou $filiacao";
    
 }

}}


    if (($dt_nascimento=='31/12/1969') || ($dt_nascimento=='30/11/-0001'))
          {
            $dt_nascimento='';
          }



    if (($dtemissao_certidao=='31/12/1969') || ($dtemissao_certidao=='30/11/-0001'))
          {
            $dtemissao_certidao='';
          }


    if (($dtrg_pai=='31/12/1969') || ($dtrg_pai=='30/11/-0001'))
          {
            $dtrg_pai='';
          }


    if (($dtrg_mae=='31/12/1969') || ($dtrg_mae=='30/11/-0001'))
          {
            $dtrg_mae='';
          }
          
    if (($dtemissaorg_aluno=='31/12/1969') || ($dtemissaorg_aluno=='30/11/-0001'))
          {
            $dtemissaorg_aluno='';
          }

          

          

if (($inepbanco)!='')
 {

if (($inep)!=($inepbanco) && (($status=='1') || ($status=='2') || ($status=='4') || ($status=='5')))
   {
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Escola sem permiss�o! <b></b></font></center>";
	echo "<br><br><center><a href=\"form_pesquisa_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";
       exit;

    }
}


/*****************************************************************************/
$sql_movimento = "select * from movimenta_aluno where inep ='$inep' and id_aluno= '$id'";
$resultadoger=mysql_query($sql_movimento) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$dt_matricula    = $pegar["dt_situacao"];

        $dt_matricula    =date("m/d/Y",strtotime($pegar["dt_situacao"]));


    if (($dt_matricula=='31/12/1969') || ($dt_matricula=='30/11/-0001'))
          {
            $dt_matricula='';
          }





    }
 }





/*****************************************************************************/








?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

	<title>Gerencia de Tecnologia da Informa��o</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css" />

	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>




<style type="text/css">

div.fileinputs {
	position: relative;
}

div.fakefile {
	position: absolute;
	top: 0px;
	left: 0px;
	z-index: 1;
}

input.file {
	position: relative;
	text-align: right;
	-moz-opacity:0 ;
	filter:alpha(opacity: 0);
	opacity: 0;
	z-index: 2;
}
</style>



<script src="script.js"></script>

<script>
function pesquisa(form)
{

  var valor = document.form.txtturma.value;
  url="busca_kit.php?valor="+valor;
  ajax(url);
}
</script>






</head>
<body>
	<div id="warpper">
		<div id="header">
            <center>
           <img src= "../img/chamadaescolar.jpg"/>
            </center>
		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="altera_dados_cons.php" method="POST" enctype="multipart/form-data" style="padding-left:1px">
				 <div id="tema"> 
					   <p><center>Dados do Aluno</center></p>
				  </div>

      	     <!-- AQUI SER� APRESENTADO O RESULTADO DA BUSCA DIN�MICA.. OU SEJA OS NOMES -->
					<p>
                        <div id="pagina">
                        </div>
             		</p>




<!--    <p>
    <div class="fileinputs">

    <input type="file" name="imagem" Title = "Alterar Foto" class="file"/>
     <div class="fakefile">
		<input />
		<img src="../img/foto.png" />
	</div>
</div>
					</p>
                        -->

					<p>

						<label for="txtCPF" style="width:120px">Selecione Foto</label>
                        <input type="file" name="imagem" />

					</p>

                        
				<p>

                        <label for="lblpai">Foto</label>
                        <img  src="fotos/<?echo $foto;?>" width='150' height='100'   style="width:90px" />
                    </p>




					<p>
                        <label for="lblpai">ID Estadual<img src= "../img/check.gif"/></label>
						<input type="text" name="txtid" style="width:150px" maxlength="100" value="<?echo $id;?>" id="txtid" readonly="true" />
					</p>

					<p>
						<label for="lblpai">Nome do Aluno<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnaluno" style="width:565px" maxlength="100" value="<?echo $nome;?>" id="txtnaluno" />
					</p>


					<p>
						<label for="txtCPF">ID Nacional</label>
						<input type="text" name="idnacional" style="width:250px" value="<?echo $id_nacional;?>" maxlength="20" id="idnacional"  onKeyPress="return Enum(event)"/>
					</p>
 


 		       <p>
						<label for="lbldtnascimento">Data Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="<?echo $dt_nascimento;?>" style="width:100px" maxlength="10" id="txtdtnascimento" />


		<label for="selectsexo">Sexo</label>
             <select id="selectsexo" name="selectsexo" style="width:140px">
                            <?
                         if($sexo == '1')
					         {
					          ?>
                               <option value="1">MASCULINO</option>
                               <option value="2">FEMININO</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="2">FEMININO</option>
                               <option value="1">MASCULINO</option>
						      <?
						       }
						      ?>
						   </select>


                    </p>










					<p>
						<label for="selectsexo">Necessidade Especial<img src= "../img/check.gif"/></label>
 			               <select id="selectdeficiente" name="selectdeficiente"  style="width:140px"   onChange = "tp_necessidade(form)"/>
                            <?
                         if(($deficiente == '0')|| ($deficiente  == ''))
					         {
					          ?>
                               <option value="0">N�O</option>
                               <option value="1">SIM</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="1">SIM</option>
                               <option value="0">N�O</option>
						      <?
						       }
						      ?>
						   </select>

					</p>




                <p>
          		<label for="lblcod_cidades">Tipo de Necessidade:<img src= "../img/check.gif"/></label>
						<select name="selecttipo_necessidade" id="selecttipo_necessidade" style="width:200px">
			           <option value="">-- Qual --</option>
					<?php
						$sql = "select * from tipo_necessidade";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $tipo_necessidade){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
						</p>


    		<p>
						<label for="lblpai">Documentos </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>




					<p>
						<label for="selectsexo">Necessidade Especial<img src= "../img/check.gif"/></label>
 			               <select id="selecttp_certidao" name="selecttp_certidao"  style="width:140px"   onChange = "tp_necessidade(form)"/>
                            <?
                         if ($mod_certidao == '1')
					         {
					          ?>
                               <option value="1">Modelo Novo</option>
                               <option value="2">Modelo Antigo</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="1">Modelo Novo</option>
                               <option value="2">Modelo Antigo</option>
						      <?
						       }
						      ?>
						   </select>

					</p>

 				 	<p>
						<label for="lblBairro" style="width:250px">Certid�o Nascimento Modelo Novo<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcertidaonovo" value="<?echo $n_certidao_novo;?>" style="width:450px" id="txtcertidaonovo" maxlength="50"/>

</p>
<p>						
<label for="lblBairro">N da Certid�o Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcertidao" value="<?echo $termo_certidao;?>" id="txtcertidao" maxlength="25"/>
                     		 	</p>
                     			 	<p>
                        <label for="lblBairro">Folha n<img src= "../img/check.gif"/></label>
						<input type="text" name="txtfolha" style="width:60px" value="<?echo $folha_certidao;?>" id="txtfolha"  maxlength="5"/>
			            <label for="txtCEP">Livro n<img src= "../img/check.gif"/></label>
            			<input id="txtlivro" name="txtlivro" value="<?echo $livro_certidao;?>"  type="text" style="width:90px" maxlength="8" onKeyPress="return Enum(event)"/>
						<label for="lbldtnascimento">Data Emiss�o<img src= "../img/check.gif"/></label>
						<input type="text" name="dtemissao_certidao" value="<?echo $dtemissao_certidao;?>" style="width:100px" maxlength="10" id="dtemissao_certidao" />

					</p>







                     <p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGaluno" style="width:110px" value="<?echo $txtRGaluno;?>" id="txtRGaluno"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExpaluno" value="<?echo $txtOrgaoExpaluno;?>" style="width:110px" id="txtOrgaoExpaluno"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgaluno" value="<?echo $txtdtemissaorgaluno;?>" style="width:100px" id="txtdtemissaorgaluno" maxlength="10" />

                    </p>

					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfaluno" style="width:110px" value="<?echo $cpfaluno;?>" maxlength="11" id="cpfaluno"  onKeyPress="return Enum(event)"/>
					</p>



                <p>
            		<label for="lblcod_cidades">Cor/Ra�a:<img src= "../img/check.gif"/></label>
						<select name="selectcorraca" id="selectcorraca" style="width:200px">
			           <option value="">-- Escolha uma op��o --</option>
					<?php
						$sql = "select * from cor_raca";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $car_raca){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
    			</p>



                   <p>
						<label for="txtRG">Nacionalidade</label>
						<input type="text" name="txtnacionalidade" style="width:500px" value="<?echo $txtnacionalidade;?>" id="txtnacionalidade"  maxlength="50" />
                  </p>






                  <p>
					<label for="lblcod_estados">Naturalidade - Estado:</label>
					   <select name="cod_estado" id="cod_estado" >
					   <option value=""></option>
  					  <?php
						   $sql = "select cod_estados, sigla FROM estados order by sigla";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['cod_estados']?>"
						        <?php if($row['cod_estados'] == $uf_nascimento){ echo "selected";}?>>
								<?php echo $row['sigla'];?>
								<?php
							      } }
						        ?>
					   </select>

          		<label for="lblcod_cidades">Cidade:</label>
		          <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha  estado --</option>
					<?php
						$sql = "select * from cidades order by nome";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['cod_cidades']; ?>"
								<?php if($linhas['cod_cidades'] == $muni_nascimento){ echo "selected";  } ?>>
								<?php echo $linhas['nome'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
						</p>



                     <p>
						<label for="txtRG">Pa�s</label>
						<input type="text" name="txtpaisestrangeiro" style="width:250px" value="<?echo $txtpaisestrangeiro;?>" id="txtpaisestrangeiro"  maxlength="30"/>
						<label for="txtOrgaoExp" >Estado</label>
						<input type="text" name="txtestadoestrangeiro" value="<?echo $txtestadoestrangeiro;?>" style="width:300px" id="txtestadoestrangeiro"  maxlength="30"/>

                    </p>
                     <p>
						<label for="txtRG">Munic�pio</label>
						<input type="text" name="txtmunicipioestrangeiro" style="width:500px" value="<?echo $txtmunicipioestrangeiro;?>" id="txtmunicipioestrangeiro"  maxlength="40" />
                    </p>


    		<p>
						<label for="lblpai">Dados do Pai - M�e </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>




  		       <p>

			<label for="selectsexo">Filia��o</label>
             <select id="filiacao" name="filiacao" style="width:200px" onChange = "tp_filiacao(form)"/>
                            <?
                         if($filiacao == '0')
					         {
					          ?>
                               <option value="0">N�O DECLARADO</option>
                               <option value="1">PAI E/OU M�E</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="1">PAI E/OU M�E</option>
                               <option value="0">N�O DECLARADO</option>
						      <?
						       }
						      ?>
						   </select>


                    </p>




					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="<?echo $nome_pai;?>" id="txtpai" />
					</p>



					<p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGpai" style="width:110px" value="<?echo $rg_pai;?>" id="txtRGpai"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExppai" value="<?echo $orgexprg_pai;?>" style="width:70px" id="txtOrgaoExppai"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgpai" value="<?echo $dtrg_pai;?>" style="width:100px" id="txtdtemissaorgpai" maxlength="10" />

                    </p>
					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfpai" style="width:110px" value="<?echo $cpf;?>" maxlength="11" id="cpfpai"  onKeyPress="return Enum(event)"/>
					</p>



					<p>
						<label for="lblmae">Nome M�e<img src= "../img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="<?echo $nome_mae;?>" id="txtmae" />
					</p>


					<p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGmae" style="width:110px" value="<?echo $rg_mae;?>" id="txtRGmae"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExpmae" value="<?echo $orgexprg_mae;?>" style="width:70px" id="txtOrgaoExpmae"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgmae" value="<?echo $dtrg_mae;?>" style="width:100px" id="txtdtemissaorgmae" maxlength="10" />
					</p>




					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfmae" style="width:110px" value="<?echo $cpf_mae;?>" maxlength="11" id="cpfmae"  onKeyPress="return Enum(event)"/>

					</p>



     					<p>
						<label for="lblpai">Dados do Respons�vel </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>

                <p>
          		<label for="lblcod_cidades">Grau de Parentesco:<img src= "../img/check.gif"/></label>
						<select name="selectgrauparente" id="selectgrauparente" style="width:200px">
			           <option value="">-- Escolha uma op��o --</option>
					<?php
						$sql = "select * from grau_parentesco";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $selectgrauparente){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
						</p>





                    	<p>
						<label for="lblmae">Nome Respons�vel<img src= "../img/check.gif"/></label>
						<input type="text" name="txtresponsavel" style="width:565px" maxlength="60" value="<?echo $txtresponsavel;?>" id="txtresponsavel" />
    					</p>

                        <p>
						<label for="txtRG">RG<img src= "../img/check.gif"/></label>
						<input type="text" name="txtRGresp" style="width:110px" value="<?echo $txtRGresp;?>" id="txtRGresp"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp<img src= "../img/check.gif"/></label>
						<input type="text" name="txtOrgaoExpresp" value="<?echo $txtOrgaoExpresp;?>" style="width:70px" id="txtOrgaoExpresp"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtemissaorgresp" value="<?echo $txtdtemissaorgresp;?>" style="width:100px" id="txtdtemissaorgresp" maxlength="10" />
                        </p>

                        <p>
						<label for="txtCPF">CPF<img src= "../img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="<?echo $cpfresp;?>" maxlength="11" id="cpf"  onKeyPress="return Enum(event)"/>
     					</p>


					<p>
						<label for="selectsexo">Permitir Acesso ao Portal<img src= "../img/check.gif"/></label>
 			               <select id="selectacesso" name="selectacesso"  style="width:140px">
                            <?

                         if(($acesso_portal == 'N') || ($acesso_portal == ''))
					         {
					          ?>
                               <option value="N">N�O</option>
                               <option value="S">SIM</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="S">SIM</option>
                               <option value="N">N�O</option>
						      <?
						       }
						      ?>
						   </select>

					</p>


					<p>
						<label for="selectsexo">Restaurar Senha<img src= "../img/check.gif"/></label>
 			               <select id="select_altera_cod_acesso" name="select_altera_cod_acesso" style="width:140px">
            		          <option value="N">N�o</option>
              		          <option value="S">Sim</option>
    		               </select>
					</p>


     					<p>
						<label for="lblpai">Dados Logradouro </label>
                        <label for="lblpai">*************************************************************** </label>
					    </p>



					<p>
						<label for="lblEndereco">Endere�o(Rua/Avenida)<img src= "../img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value="<?echo $endereco;?>"  maxlength="40" size="40" id="txtEndereco" />
					</p>
					<p>
						<label for="lblBairro">Bairro<img src= "../img/check.gif"/></label>
						<input type="text" name="txtBairro" value="<?echo $bairro;?>" id="txtBairro" maxlength="25"/>
						<label for="lblBairro">Nr<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="<?echo $numero;?>" id="txtnr"  maxlength="5"/>
			            <label for="txtCEP">CEP<img src= "../img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" value="<?echo $cep;?>" onKeyPress="return Enum(event)"/>
					</p>




					<p>
						<label for="lblcomplemento">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:298px" value="<?echo $complemento;?>"  maxlength="40" size="60" id="txtcomplemento"/>
					</p>
                 <p>
					<label for="lblcod_estados">Municipio<img src= "../img/check.gif"/></label>
					   <select name="cod_muni" id="cod_muni" >
					   <option value=""></option>
  					  <?php
						   $sql = "select codigo, descricao FROM municipio order by descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $cidade){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>



					<p>
						<label for="txtFoneSetor">Telefone Para Contato<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:110px" value="<?echo $fonecontato;?>" id="txtcontato" />
						<label for="txtCelular">Celular<img src= "../img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:90px" value="<?echo $fonecelular;?>" id="txtCelular" maxlength="20"/>
					</p>
					<p>
						<label for="txtEmail1">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="<?echo $email;?>" id="txtEmail" maxlength="60"/>
						
					</p>



   	
					<p>
						<label for="selectsexo">Bolsa Fam�lia<img src= "../img/check.gif"/></label>
 			               <select id="selectbosaf" name="selectbosaf"  style="width:140px">
                            <?
                         if(($bolsa_familia == 'N')|| ($bolsa_familia == ''))
					         {
					          ?>
                               <option value="N">N�O</option>
                               <option value="S">SIM</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="S">SIM</option>
                               <option value="N">N�O</option>
						      <?
						       }
						      ?>
						   </select>

					</p>


                                  <p>
						<label for="txtCPF">N� Cart�o Bolsa Familia</label>
						<input type="text" name="nbolsa" style="width:250px" value="<?echo $n_bolsa_fam;?>" maxlength="13" id="nbolsa"  onKeyPress="return Enum(event)"/>
					</p>



   

                     <p>
						<label for="txtCPF">N� Cart�o SUS</label>
						<input type="text" name="nsus" style="width:250px" value="<?$nsus;?>" maxlength="20" id="nsus"  onKeyPress="return Enum(event)"/>
  					</p>






		<p>
						<label for="selectsexo">Utiliza Transporte Escolar<img src= "../img/check.gif"/></label>
 			               <select id="selecttransporte" name="selecttransporte"  style="width:140px">
                            <?
                         if(($selecttransporte == 'N')|| ($selecttransporte == ''))
					         {
					          ?>
                               <option value="N">N�O</option>
                               <option value="S">SIM</option>
				              <?
					         }
                            else
				             {
						      ?>
                               <option value="S">SIM</option>
                               <option value="N">N�O</option>
						      <?
						       }
						      ?>
						   </select>

					</p>











 <p>
            <label for="lblcod_cpf">Obs.:</label>
 			<textarea name = "txtobs"  maxlength= "200" cols="80" rows = "5" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtdescvolume.value)"><?echo $obs;?></textarea>
       </p>










                    <p>
						<label for="lblDataEmissao">Data Matricula<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdt_matricula"    value="<?echo $dt_matricula;?>"  style="width:100px" id="txtdt_matricula" maxlength="10" />

					</p>





					<p>
						<label for="txtFoneSetor">Situa��o<img src= "../img/check.gif"/></label>
						<input type="text" name="txtsituacao" style="width:50px" value="<?echo $status;?>" id="txtsituacao"   readonly="true"/>
					</p>



	<p id="finish">
            <input type="submit"  class="btn btn-primary" value="Gravar" name = "cadastrar" />
            <input type="button" class="btn" value=" Voltar " onclick="location.href='form_pesquisa_aluno_turma.php';">
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados SEDUC/GTI-RO</p>
		</div>
	</div>
</body>
