<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Matricular estudante';

$sql = "SELECT id, descricao FROM tipo_necessidade ORDER BY descricao";
$necessidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT * FROM cor_raca ORDER BY descricao";
$etnias = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_estados, CONCAT(sigla, ' ', nome) AS sigla FROM estados ORDER BY sigla";
$estados = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM grau_parentesco ORDER BY id";
$grauParentescos = $pdo->query($sql)->fetchAll();

$sql = "SELECT codigo, descricao FROM municipio WHERE (descricao != '1' AND descricao != '') ORDER BY descricao";
$municipios = $pdo->query($sql)->fetchAll();

$chamadaEscolar = isset($_GET['chamada']) && $_GET['chamada']=='1' ? true : false;

if ($chamadaEscolar) {
    $anoLetivo = date('Y');
    $subtitle = 'Chamada Escolar '.$anoLetivo;
    $sql = "SELECT id, descricao, t_vagas FROM vagaschamadaescolar
					WHERE inep = '{$inep}' AND ano = '{$anoLetivo}'
					ORDER BY descricao;";
    $vagas = $pdo->query($sql)->fetchAll();
}

$programasAluno = array('ALUNO DIGITAL', 'MEDIA��O TECNOL�GICA', 'PROUCA');

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <?php if ($chamadaEscolar): ?>
        <?php include '../../partials/tabela_faixa_etaria.php' ?>
    <?php endif ?>

    <form name="form" class="submit-wait" action="insere_dados.php" method="POST" enctype="multipart/form-data">
        <?php if ($chamadaEscolar): ?>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="distorcao">Distor��o</label>
                        <select name="distorcao" id="distorcao" class="form-control">
                            <option value="N">N�O</option>
                            <option value="S">SIM</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="text-danger" for="txtturma">Selecione a turma da chamada escolar</label>
                        <select name="txtturma" id="txtturma" class="form-control" onchange="consultavagas(this.value)" required>
                            <option value=""></option>
                            <?php foreach($vagas as $vaga): ?>
                                <option value="<?php echo $vaga['id'] ?>"><?php echo $vaga['descricao']; echo " (vagas dispon�veis: ".$vaga['t_vagas'].")" ?> </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <div id="pagina"></div>
                    </div>
                </div>
            </div>
        <?php endif ?>

        <fieldset class="well well-sm">
            <legend>Dados do estudante</legend>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="text-danger" for="txtnaluno">Nome completo do estudante</label>
                        <input type="text" name="txtnaluno" class="form-control text-uppercase" maxlength="100" value="<?php echo isset($_GET['nome']) ? strtoupper($_GET['nome']) : '' ?>" id="txtnaluno" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtdtnascimento">Data de Nascimento</label>
                        <input type="text" name="txtdtnascimento" value="<?php echo isset($_GET['nascimento']) ? $_GET['nascimento'] : '' ?>" class="form-control" id="txtdtnascimento" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="fom-group">
                        <label class="text-danger" for="selectsexo">Sexo</label>
                        <select id="selectsexo" name="selectsexo" class="form-control" required>
                            <option value=""></option>
                            <option value="1">Masculino</option>
                            <option value="2">Feminino</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtdt_matricula">Data de cadastro</label>
                        <input type="text" name="txtdt_matricula" value="<?php echo date('d/m/Y') ?>" class="form-control mask-data" id="txtdt_matricula" maxlength="10" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="idnacional">ID Nacional</label>
                        <input type="text" name="idnacional" class="form-control" maxlength="20" id="idnacional" onKeyPress="return Enum(event)">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="selectsexo" class="text-danger">Bolsa Familia?</label>
                        <select id="selectbosaf" required name="selectbosaf" class="form-control" onChange="tp_bosa_familia(this.value)">
                            <option value=""></option>
                            <option value="N">N�o</option>
                            <option value="S">Sim</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCPF">N� Cart�o Bolsa Fam�lia</label>
                        <input type="text" name="nbolsa" class="form-control" value="" maxlength="13" id="nbolsa"  onKeyPress="return Enum(event)" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="selectdeficiente" class="text-danger">Necessidade especial?</label>
                        <select id="selectdeficiente" required name="selectdeficiente" class="form-control" onchange="tp_necessidade(this.value)">
                            <option value=""></option>
                            <option value="N">N�o</option>
                            <option value="S">Sim</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="selecttipo_necessidade">Selecione o tipo de necessidade</label>
                        <select name="selecttipo_necessidade" id="selecttipo_necessidade" class="form-control" readonly>
                            <option value=""></option>
                            <?php foreach($necessidades as $ne): ?>
                                <option value="<?php echo $ne['id'] ?>"><?php echo $ne['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <label for="imagem">Foto do estudante</label>
                    <input type="file" name="imagem" class="form-control">
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCPF">N� Cart�o SUS</label>
                        <input type="text" name="nsus" class="form-control" value="" maxlength="20" id="nsus"  onKeyPress="return Enum(event)">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="selecttransporte">Utiliza Transporte escolar?</label>
                        <select id="selecttransporte" name="selecttransporte" class="form-control">
                            <option value="N">N�o</option>
                            <option value="S">Sim</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="selectacesso">Permitir acesso ao Portal do Aluno?</label>
                        <select id="selectacesso" name="selectacesso" class="form-control">
                            <option value="N">N�o</option>
                            <option value="S">Sim</option>
                        </select>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Equipamento de programa</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="equipamento_programa">Programa</label>
                        <select name="equipamento_programa" id="equipamento_programa" class="form-control">
                            <option value=""></option>
                            <?php foreach ($programasAluno as $prog): ?>
                                <option value="<?php echo $prog ?>"><?php echo $prog ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="equipamento_nu_tombamento">N�mero de Tombamento</label>
                        <input type="text" name="equipamento_nu_tombamento" id="equipamento_nu_tombamento" class="form-control">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_nu_serie">N�mero de S�rie</label>
                        <input type="text" name="equipamento_nu_serie" id="equipamento_nu_serie" class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="equipamento_chave_office">Chave do Office</label>
                        <input type="text" name="equipamento_chave_office" id="equipamento_chave_office" class="form-control">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_data_recebimento">Data de Recebimento</label>
                        <input type="text" name="equipamento_data_recebimento" id="equipamento_data_recebimento" class="form-control mask-data">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="equipamento_data_devolucao">Data de Devolu��o</label>
                        <input type="text" name="equipamento_data_devolucao" id="equipamento_data_devolucao" class="form-control mask-data">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="form-group">
                        <label for="equipamento_obs">Observa��es</label>
                        <input type="text" name="equipamento_obs" id="equipamento_obs" class="form-control" maxlength="255">
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Documentos</legend>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="selecttp_certidao">Tipo de Certid�o</label>
                        <select id="selecttp_certidao" name="selecttp_certidao" class="form-control" onchange="tp_certidao(this.value)" required>
                            <option value="">Selecione o Tipo</option>
                            <option value="2">Modelo Antigo</option>
                            <option value="1">Modelo Novo</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtcertidao">N�mero da Certid�o de Nascimento</label>
                        <input type="text" name="txtcertidao" value="" class="form-control" id="txtcertidao" maxlength="50" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtfolha">Certid�o Folha N�</label>
                        <input type="text" name="txtfolha" class="form-control" value="" id="txtfolha" maxlength="5" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtlivro">Certid�o Livro N�</label>
                        <input id="txtlivro" name="txtlivro" type="text" class="form-control" maxlength="8" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="dtemissao_certidao">Data de Emiss�o</label>
                        <input type="text" name="dtemissao_certidao" value="" class="form-control mask-data" maxlength="10" id="dtemissao_certidao" readonly>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-offset-2 col-md-5">
                    <div class="form-group">
                        <label class="text-danger" for="txtcertidaonovo">Certid�o Nascimento Modelo Novo</label>
                        <input type="text" name="txtcertidaonovo" value="" id="txtcertidaonovo" maxlength="50" class="form-control" readonly>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="txtcertidaocasamento">Certid�o de Casamento</label>
                        <input type="text" name="txtcertidaocasamento" value="" id="txtcertidaocasamento" maxlength="120" class="form-control" placeholder="N�mero, Folha e Livro">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="selectcorraca">Etnia</label>
                        <select name="selectcorraca" id="selectcorraca" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($etnias as $et): ?>
                                <option value="<?php echo $et['id'] ?>"><?php echo $et['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCPF">CPF</label>
                        <input type="text" name="cpfaluno" class="form-control" value="" maxlength="11" id="cpfaluno" onKeyPress="return Enum(event)">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtRGaluno">RG</label>
                        <input type="text" name="txtRGaluno" class="form-control" value="" id="txtRGaluno" maxlength="20">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtOrgaoExp">Org�o Expedidor RG</label>
                        <input type="text" name="txtOrgaoExpaluno" value="" class="form-control text-uppercase" id="txtOrgaoExpaluno" maxlength="20">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="lblDataEmissao">Data Emiss�o RG</label>
                        <input type="text" name="txtdtemissaorgaluno" value="" class="form-control mask-data" id="txtdtemissaorgaluno" maxlength="10">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtnacionalidade">Nacionalidade</label>
                        <input type="text" name="txtnacionalidade" class="form-control text-uppercase" value="" id="txtnacionalidade"  maxlength="50" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="text-danger" for="cod_estado">Naturalidade UF</label>
                        <select name="cod_estado" id="cod_estado" onchange="estrangeiro(this.value)" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($estados as $es): ?>
                                <option value="<?php echo $es['cod_estados'] ?>"><?php echo $es['sigla'] ?></option>
                            <?php endforeach  ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label class="text-danger" for="cod_estado">Naturalidade Munic�pio</label>
                        <select name="cod_cidades" id="cod_cidades" class="form-control" required>
                            <option value="">Escolha um estado</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtpaisestrangeiro">Pa�s estrangeiro</label>
                        <input type="text" name="txtpaisestrangeiro" class="form-control text-uppercase" value="" id="txtpaisestrangeiro"  maxlength="30" readonly>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtestadoestrangeiro">Estado estrangeiro</label>
                        <input type="text" name="txtestadoestrangeiro" value="" class="form-control text-uppercase" id="txtestadoestrangeiro" maxlength="30" readonly>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="txtmunicipioestrangeiro">Cidade estrangeira</label>
                        <input type="text" name="txtmunicipioestrangeiro" class="form-control text-uppercase" value="" id="txtmunicipioestrangeiro"  maxlength="40" readonly>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Dados do respons�vel</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="text-danger" for="selectgrauparente" >Grau de Parentesco</label>
                        <select name="selectgrauparente" id="selectgrauparente" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($grauParentescos as $grau): ?>
                                <option value="<?php echo $grau['id'] ?>"><?php echo $grau['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtresponsavel">Nome do Respons�vel <small class="text-muted">(Sem abrevia��es)</small></label>
                        <input type="text" name="txtresponsavel" class="form-control text-uppercase" maxlength="60" value="" id="txtresponsavel" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="cpfresp">CPF</label>
                        <input type="text" name="cpfresp" class="form-control" value="" maxlength="11" id="cpfresp" onKeyPress="return Enum(event)" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtRGresp">RG</label>
                        <input type="text" name="txtRGresp" class="form-control" value="" id="txtRGresp"  maxlength="20" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtOrgaoExpresp">Org�o Expedidor RG</label>
                        <input type="text" name="txtOrgaoExpresp" value="" class="form-control text-uppercase" id="txtOrgaoExpresp"  maxlength="20" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtdtemissaorgresp">Data de Emiss�o RG</label>
                        <input type="text" name="txtdtemissaorgresp" value="" class="form-control mask-data" id="txtdtemissaorgresp" maxlength="10" required>
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>Filia��o</legend>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="filiacao" class="text-danger">Filia��o</label>
                        <select id="filiacao" required name="filiacao" class="form-control" onchange="tp_filiacao(this.value)">
                            <option value=""></option>
                            <option value="0">N�O DECLARADO</option>
                            <option value="1">PAI E/OU M�E</option>
                        </select>
                    </div>
                </div>
            </div>

            <div id="divFiliacao">
                <fieldset class="well well-sm">
                    <legend>Dados do pai</legend>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="txtpai">Nome do Pai</label>
                                <input type="text" name="txtpai" class="form-control text-uppercase" maxlength="60" value="" id="txtpai" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="cpfpai">CPF</label>
                                <input type="text" name="cpfpai" class="form-control" value="" maxlength="11" id="cpfpai"  onKeyPress="return Enum(event)" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtRGpai">RG</label>
                                <input type="text" name="txtRGpai" class="form-control" value="" id="txtRGpai"  maxlength="20" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtOrgaoExppai">Org�o Expedidor RG</label>
                                <input type="text" name="txtOrgaoExppai" value="" class="form-control text-uppercase" id="txtOrgaoExppai"  maxlength="20" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtdtemissaorgpai">Data de Emiss�o RG</label>
                                <input type="text" name="txtdtemissaorgpai" value="" class="form-control mask-data" id="txtdtemissaorgpai" maxlength="10" readonly>
                            </div>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="well well-sm">
                    <legend>Dados da m�e</legend>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="txtmae">Nome da M�e</label>
                                <input type="text" name="txtmae" class="form-control text-uppercase" maxlength="60" value="" id="txtmae" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="cpfmae">CPF</label>
                                <input type="text" name="cpfmae" class="form-control" value="" maxlength="11" id="cpfmae"  onKeyPress="return Enum(event)" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtRGmae">RG</label>
                                <input type="text" name="txtRGmae" class="form-control" value="" id="txtRGmae"  maxlength="20" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtOrgaoExpmae" >Org�o Expedidor RG</label>
                                <input type="text" name="txtOrgaoExpmae" value="" class="form-control text-uppercase" id="txtOrgaoExpmae"  maxlength="20" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtdtemissaorgmae">Data Emiss�o RG</label>
                                <input type="text" name="txtdtemissaorgmae" value="" class="form-control mask-data" id="txtdtemissaorgmae" maxlength="10" readonly>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Endere�o</legend>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtcep">CEP</label>
                        <div class="input-group">
                            <input id="txtcep" name="txtcep" type="text" class="form-control mask-cep" maxlength="8" required>
                            <div class="input-group-btn">
                                <button type="button" id="btnCep" class="btn btn-default">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtEndereco">Logradouro (Av, Rua)</label>
                        <input type="text" name="txtEndereco" class="form-control text-uppercase" value="" required maxlength="40" size="40" id="txtEndereco" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtnr">N�mero</label>
                        <input type="text" name="txtnr" class="form-control" value="" id="txtnr" maxlength="10" onKeyPress="return Enum(event)" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="text-danger" for="txtBairro">Bairro</label>
                        <input type="text" name="txtBairro" value="" class="form-control text-uppercase" id="txtBairro" maxlength="40" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="lblcomplemento">Complemento</label>
                        <input type="text" name="txtcomplemento" class="form-control text-uppercase" value=""  maxlength="40" size="60" id="txtcomplemento"/>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="text-danger" for="cod_muni">Munic�pio</label>
                        <select name="cod_muni" id="cod_muni" class="form-control" required>
                            <option value=""></option>
                            <?php foreach($municipios as $muni): ?>
                                <option value="<?php echo $muni['codigo']?>"><?php echo $muni['descricao'];?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label class="text-danger" for="txtcontato">Telefone para Contato</label>
                        <input type="text" name="txtcontato" class="form-control mask-telefone" value="" id="txtcontato" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="txtCelular">Celular</label>
                        <input type="text" name="txtCelular" class="form-control mask-telefone" value="" id="txtCelular" maxlength="20">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="form-group">
                        <label for="txtEmail">E-mail</label>
                        <input type="email" name="txtEmail" class="form-control" value="" id="txtEmail" maxlength="60">
                    </div>
                </div>
            </div>
        </fieldset>

        <div class="form-group">
            <label for="txtobs">Observa��es</label>
            <textarea name="txtobs" cols="80" rows="3" id="txtobs" class="form-control"></textarea>
        </div>

        <div class="well well-sm">
            <button type="submit" class="btn btn-primary btn-submit-wait">MATRICULAR</button>
            <button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
        </div>
    </form>
</div>
<?php require_once page_footer(); ?>
<script src="generic1.js" type="text/javascript"></script>
</body>
</html>