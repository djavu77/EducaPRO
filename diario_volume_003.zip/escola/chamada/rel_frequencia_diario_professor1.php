<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     
	 include ("../funcoes.php");
//     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

    // include ("../funcoes.php");




if($_SERVER["REQUEST_METHOD"] == "POST")
{


$idturmaprofessor1	         = $_POST['cod_estado'];
$idturmaprofessor	         = $_POST['cod_estado'];
$id_tp_rel       	         = $_POST['selecttp_pesquisa'];
$txtetapa       	         = $_POST['txtetapa'];


$selectmes       	         = $_POST['selectmes'];
$cpf_prof                    = $_POST['txtcpf'];
$id_disciplina_prof          = $_POST['cod_cidades'];
$txtturma_prof               = $_POST['cod_estado'];





$cpfx                =   $cpf_prof;
$professorx          =    $cpfx;
$id_habilita         =   $id_disciplina_prof;
$id_turmax           =  $idturmaprofessor1;









$id_tp_rel = 'M';

 if($id_tp_rel=="E")
 {
      $id_etapa =$txtetapa;
     

     $sql="SELECT * FROM etapa_ano where id = '$txtetapa'";
     $resultado=mysql_query($sql) or die (mysql_error());
     $linhas=mysql_num_rows($resultado);
     if ($linhas>0)
      {
          while($pegar=mysql_fetch_array($resultado))
             {
                      $txtdesc_etapa       = $pegar["descricao"];
             }
       }

 }
else
  {
       $id_etapa =$selectmes;
       $txtmes = $selectmes;
       
      switch($selectmes) {
		case"01": $txtdesc_etapa = "Janeiro";       break;
		case"02": $txtdesc_etapa = "Fevereiro"; break;
		case"03": $txtdesc_etapa = "Marco";   break;
		case"04": $txtdesc_etapa = "Abril";  break;
		case"05": $txtdesc_etapa = "Maio";  break;
		case"06": $txtdesc_etapa = "Junho";   break;
		case"07": $txtdesc_etapa = "Julho";        break;
        case"08": $txtdesc_etapa = "Agosto";        break;
		case"09": $txtdesc_etapa = "Setembro";        break;
		case"10": $txtdesc_etapa = "Outubro";        break;
		case"11": $txtdesc_etapa = "Novembro";        break;
		case"12": $txtdesc_etapa = "Dezembro";        break;
	}

       
       
       
       
       
   } 
}








               if($id_tp_rel=="")
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Selecione o tipo de relat�rio.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }



               if (($id_etapa == "") && ($selectmes== ""))
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Selecione a etapa ou o m�s.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }










//echo "$idturmaprofessor*";
//echo "$id_tp_rel*";
//echo "mes $selectmes ";
 /* $id = $_GET["valor"];


 $totalcaracter       = strlen($id);
 $posicao1            = strpos($id, '*');
 $posicao2            = strpos($id, '-');
 $txtturma            = substr($id, 0, $posicao1);
 $idturmaprofessor    = substr($id, 0, $posicao1);
 $txtmes              = substr($id, $posicao1+1,  $posicao2 - ($posicao1)-1);
 $id_tp_rel           = substr($id, $posicao2+1,  $totalcaracter-$posicao2-1);

//echo "turma $idturmaprofessor-";
//echo " mes $txtmes-";
//echo "id $id";
//echo "* $mes";
//echo "tipo rel $id_tp_rel";


//********* Turma di�rio criado para calculo de horas****************************
 $turmadiario =$idturmaprofessor;


 $id_etapa = $txtmes;

//*********Caso relatorio seja mensal****************************
 $data =    $id_etapa;


/*  $totalcaracter       = strlen($id); //conta caracter
  $posicao1            = strpos($id, '-');  //localiza -
  $txtmes                 = substr($id, 0, $posicao1);
  $txtturma               = substr($id, $posicao1+1,  $totalcaracter);




 /* $txtturma='42758';
  $cpfx = '38645491249';
  $id_turmax = '8063';
  $id_habilita = '1';
  $txtmes   = '02';
 */

// echo "$inep";


/************************Escola*****************************************************/
$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni from escola e , municipio m
where inep = '$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];


    }
 }















/***************************************************************************************/

$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }


/*$sqlturmaprof="SELECT id_turma,cpf,id_disciplina FROM turmaprofessor where id = '$idturmaprofessor1'";
$resultadoturmaprof=mysql_query($sqlturmaprof) or die (mysql_error());
$linhasturmaprof=mysql_num_rows($resultadoturmaprof);
if ($linhasturmaprof > 0)
 {
    while($pegarturmaprof=mysql_fetch_array($resultadoturmaprof))
   {
         $txtturma_prof                 = $pegarturmaprof["id_turma"];
         $cpf_prof                      = $pegarturmaprof["cpf"];
         $id_disciplina_prof            = $pegarturmaprof["id_disciplina"];
         $idurma = $txtturma_prof; // variavel usada la embaixo
         $idturmaprofessor              = $idurma;

   }
 }

  */


$sqlturma="SELECT modalidade,semestre FROM turma where inep = '$inep' and id = '$txtturma_prof'";
$resultadoturma=mysql_query($sqlturma) or die (mysql_error());
$linhasturma=mysql_num_rows($resultadoturma);
if ($linhasturma>0)
 {
    while($pegarturma=mysql_fetch_array($resultadoturma))
   {
         $txtmodalidade       = $pegarturma["modalidade"];
         $id_semestre         = $pegarturma["semestre"];
   }
 }






if($id_tp_rel=="E")
{

if (($txtmodalidade=='1') || ($txtmodalidade =='3'))
{
               $sqlgerencia = "select * from  etapa_liberacao
               where inep  = '$inep'
               and   ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa = '$id_etapa'";


               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
 }
else
{




               $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa = '$id_etapa'";
               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido ou j� fechado.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
  }
}








if($id_tp_rel=="E")
{
if (($txtmodalidade=='1') || ($txtmodalidade=='3'))
{
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
                 $dt_inicio   = $pega_dados["dt_inicio"];
                 $dt_fim       = $pega_dados["dt_fim"];
               }
	}
}
else
{



              $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
                  $dt_inicio   = $pega_dados["dt_inicio"];
                  $dt_fim       = $pega_dados["dt_fim"];
               }
	}


}
}





/***************************************************************************************/




//$txtturma_prof = 'turma professor 13';
//$idurma = $txtturma_prof = 'turma dos alunos 340'



//if($_SERVER["REQUEST_METHOD"] == "POST")
{




/*
  $sql="select t.id,h.descricao as descdisciplina,tu.descricao as descturma,s.nome,s.cpf,t.id_turma,h.codigo
  from turmaprofessor t,habilitacao h,turma tu,servidorrec s
  where  t.id_disciplina = h.codigo
  and tu.id=t.id_turma
  and s.cpf=t.cpf
  and t.id  = '$idturmaprofessor1'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
   while($pegar=mysql_fetch_array($resultado))
     {

              $cpfx            =   $pegar["cpf"];
              $professorx      =   $pegar["nome"];
              $descdisciplinax =   $pegar["descdisciplina"];
              $id_habilita     =   $pegar["codigo"];
              $id_turmax       =   $pegar["id_turma"];
     }
   }

*/



  
/*echo "cpf -> $cpfx"."  ";
echo "Professor -> $professorx"."  ";
echo "Disciplina -> $descdisciplinax"."  ";
echo "Mes -> $txtmes";
echo "id_turmax $id_turmax";
echo "disciplina $id_habilita";
echo "Turma $txtturma";
*/
/**************criando tabela temporaria******************************************************/
   $sql_criando_temp="CREATE TABLE IF NOT EXISTS temp (
  `id` int(11) NOT NULL default '0',
  `professor` varchar(11) default NULL,
  `id_turma` int(11) default NULL,
  `inep` varchar(20) default NULL,
  `frequencia` char(1) default NULL,
  `id_disciplina` int(11) default NULL,
  `data_chamada` date default NULL,
  `n_chamada` int(2) default NULL,
  `id_aluno` int(11) default NULL) ENGINE=MEMORY";
   $resultado_criando_temp=mysql_query($sql_criando_temp) or die (mysql_error());




          $sql_deletando_paratemp="delete from temp where inep = '$inep'";
          $resultado_deletando_paratemp =mysql_query($sql_deletando_paratemp) or die (mysql_error());



/*echo "cpf -> $cpfx"."  ";
echo "id_turmax $id_turmax";
echo "Disciplina -> $id_habilita"."  ";
echo "Mes -> $txtmes";
echo "inep -> $inep";
*/






if($id_tp_rel=="E")
{



          $sql_copiando_paratemp="insert into temp SELECT id, professor, id_turma, inep,
          situacao, id_disciplina, data_chamada, n_chamada,id_aluno
          FROM frequencia_aluno
          WHERE professor = '$cpfx'
          AND id_turma = '$id_turmax'
          AND inep = '$inep'
          AND id_disciplina = '$id_disciplina_prof'
          AND data_chamada >= '$dt_inicio' and  data_chamada <= '$dt_fim'
          ORDER BY n_chamada";
}
else
{
          $sql_copiando_paratemp="insert into temp SELECT id, professor, id_turma, inep,
          situacao, id_disciplina, data_chamada, n_chamada,id_aluno
          FROM frequencia_aluno
          WHERE professor = '$cpfx'
          AND id_turma = '$id_turmax'
          AND inep = '$inep'
          AND id_disciplina = '$id_disciplina_prof'
          AND Month(data_chamada) = '$txtmes'
          ORDER BY n_chamada";
}



              $resultado_copiando_paratemp =mysql_query($sql_copiando_paratemp) or die (mysql_error());



                $sql_conta_temp=mysql_query("SELECT count(*) as total_frequencia FROM temp");
                $total_frequencia_temp = mysql_result($sql_conta_temp, 0, "total_frequencia");
                
                  if($total_frequencia_temp<=0)
                    {
                     echo "<html><head><title>Resposta !!!</title></head>";
                     echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                     echo "<br><br><br>";
                     echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Base sem informa��o.! <b></b></font></center>";
                     echo "</body></html>";
//                     exit;
                   }
/************************************************************************/

     $sql_criando_dias_temp="CREATE TABLE IF NOT EXISTS dias_diario_temp (
       `id` int(11) NOT NULL auto_increment,
       `id_turma` int(11) default NULL,
       `id_disciplina` int(11) default NULL,
       `data` date default NULL,
       `inep` varchar(20) default NULL,
       `ano` varchar(4) default NULL,
       `usuario` varchar(11) default NULL,
       `id_turmaprofessor` int(11) default NULL,
       `cpf` varchar(11) default NULL,
       `mes` char(2) default NULL,
       `dia` char(2) default NULL,
       `tempo_aula` int(11) default '0',
       `tipo_aula` int(11) default '0',
       `registrado` char(1) default 'N',
       `tpbloqueio` char(1) default NULL,
        PRIMARY KEY  (`id`)) ENGINE=MEMORY";
       $resultado_dias_temp=mysql_query($sql_criando_dias_temp) or die (mysql_error());



          $sql_deletando_diastemp="delete from dias_diario_temp where inep = '$inep'";
          $resultado_deletando_paratemp =mysql_query($sql_deletando_diastemp) or die (mysql_error());





     if($id_tp_rel=="E")
       {


          $sql_copiando_diastemp="insert into dias_diario_temp  SELECT * FROM dias_diario where inep = '$inep'
          and id_turma = '$id_turmax'
          and id_disciplina = '$id_habilita'
          and data >= '$dt_inicio' and  data <= '$dt_fim'
          and cpf = '$cpfx' order by dia";
      }
else
       {

          $sql_copiando_diastemp="insert into dias_diario_temp  SELECT * FROM dias_diario where inep = '$inep'
          and id_turma = '$id_turmax'
          and id_disciplina = '$id_habilita'
          and mes = '$txtmes'
          and cpf = '$cpfx' order by dia";
      }

          $resultado_copiando_diastemp =mysql_query($sql_copiando_diastemp) or die (mysql_error());



                $sql_conta_temp=mysql_query("SELECT count(*) as total_frequencia FROM dias_diario_temp");
                $total_dias_temp = mysql_result($sql_conta_temp, 0, "total_frequencia");

                  if($total_dias_temp<=0)
                    {
                     echo "<html><head><title>Resposta !!!</title></head>";
                     echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                     echo "<br><br><br>";
                     echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Base sem informa��o.! <b></b></font></center>";
                     echo "</body></html>";
  //                   exit;
                   }



















?>
<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 10px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 9pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 9px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>
<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GER�NCIA DE TECNOLOGIA DA INFORMA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>

</table>


<?


$sql="SELECT t.id, h.descricao AS descdisciplina, tu.descricao AS descturma, s.nome, h.codigo as disciplina, t.id as idturma, s.cpf, tu.id AS idturma
FROM turmaprofessor t, habilitacao h, turma tu, servidorrec s
WHERE t.id_disciplina = h.codigo
AND tu.id = t.id_turma
AND s.cpf = t.cpf
AND t.id = '$idturmaprofessor1'";

  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
  while($pegar=mysql_fetch_array($resultado))
      {

        $iddisciplina           = $pegar["disciplina"];
        $idturma                = $pegar["idturma"];
        $cpfprofessor           = $pegar["cpf"];

?>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Professor(a)</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td>&nbsp;<?echo $pegar["nome"];?></td>
	<td class="nomecampo"><b>Disciplina</b></td>
	<td>&nbsp;<?echo $pegar["descdisciplina"];?></td>
</tr>
<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td colspan="5">&nbsp;<?echo $pegar["descturma"];?></td>
</tr>
</table>




<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Frequ�ncia Referente :  <?echo $txtdesc_etapa ."/". $txtano;?>   </b></td>
</tr>


<?
     }
   }
?>





<table width="100%">
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
<!--<td class="nomecampo"><b>ID</b></td>-->
<td class="nomecampo"><b>N�</b></td>
<td class="nomecampo"><b>Nome</b></td>
<td class="nomecampo"><b>Status</b></td>



<?


  $sqldia="SELECT * FROM dias_diario_temp where inep = '$inep'
     order by data";

  $resultadodia=mysql_query($sqldia) or die (mysql_error());
  $linhasdia=mysql_num_rows($resultadodia);
  $conta_dia =$linhasdia;

  if($linhasdia>0)
    {
    $total_dia_supervisa=$linhasdia;

   while($pegardia=mysql_fetch_array($resultadodia))
     {
          $dia =$pegardia["dia"]."/".$pegardia["mes"];
?>


<td class="nomecampo"> <?echo $dia;?> </td>

<?
      }
    }

?>
<td class="nomecampo"><b>Faltas</b></td>

<tr>
<?
/*   Seleciona a turma e Tabela turma de alunos*/



//    echo "--- $id_turmax --";
    $sql_turma_aluno ="select  ta.id_aluno,a.nome, ta.n_chamada, ta.situacao as situa_aluno
    FROM   turma_aluno ta,aluno a
    where  ta.id_turma = '$id_turmax'
    and a.id=ta.id_aluno
    order by ta.n_chamada";

    $resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
    $linhas_turma_aluno=mysql_num_rows($resultado_turma_aluno);
    if($linhas_turma_aluno>0)
      {
       while($pegardia_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
          {

           $id_aluno_turma =$pegardia_turma_aluno["id_aluno"];
           $situacao_aluno =$pegardia_turma_aluno["situa_aluno"];
           $nchamada_aluno =$pegardia_turma_aluno["n_chamada"];

    //     echo "$id_aluno_turma";
          /**************Filtra na tabela frequencia de aluno por aluno*/



          $sql_conteudo="SELECT id, professor, id_turma, inep,frequencia,
          id_disciplina, data_chamada, n_chamada
          FROM temp
          WHERE id_aluno = '$id_aluno_turma'
          and inep = '$inep'
          ORDER BY n_chamada";
          $resultado_conteudo=mysql_query($sql_conteudo) or die (mysql_error());
          $linhas=mysql_num_rows($resultado_conteudo);
          if($linhas>0)
           {
            $total_faltas=0;
            while($pegar_conteudo=mysql_fetch_array($resultado_conteudo))
               {
            $dt_data_registrada=0;



?>


           <tr>
             <!-- <td class="nomecampo"> <?echo $id_aluno_turma;?> </td>-->
              <td class="nomecampo"> <?echo $pegardia_turma_aluno["n_chamada"];?> </td>
 	          <td class="nomecampo"> <?echo $pegardia_turma_aluno["nome"];?> </td>
              <td class="nomecampo"> <?echo  $situacao_aluno;?> </td>
<?


/*********************Tabela Dias Diario********************************************/


     $sqldia_filtro="SELECT * FROM dias_diario_temp where inep = '$inep'
     order by dia";
     $resultadodia_filtro=mysql_query($sqldia_filtro) or die (mysql_error());
     $linhasdia_filtro = mysql_num_rows($resultadodia_filtro);
     $conta_dia = $linhasdia; //8 dias
     while($pegardia_filtro=mysql_fetch_array($resultadodia_filtro))
        {
                $dt_diasdiario  =   $pegardia_filtro["data"];
               /*Calcula o total de aulas registrada pelas supervisao*/


         $sql_total_dia_calendario=mysql_query("SELECT count(*) as total FROM dias_diario_temp where inep = '$inep'
         and data = '$dt_diasdiario'");
         $total_dia_calendario = mysql_result($sql_total_dia_calendario, 0, "total");

               /*Calcula o total de aulas registrada no calendario*/

                $sql_frequencia_data="SELECT data_chamada, n_chamada,frequencia
                FROM temp   WHERE
                id_aluno = '$id_aluno_turma'
                and data_chamada = '$dt_diasdiario'
                and inep = '$inep'
                and n_chamada = '$nchamada_aluno'";
                $resultado_frequencia_data = mysql_query($sql_frequencia_data) or die (mysql_error());
                $linhas_frequencia_data= mysql_num_rows($resultado_frequencia_data);
                $Totaldata_registrada_profe = $linhas_frequencia_data;
               /*Calcula o total de aulas registradas pelo professor*/





                $sql_frequencia_data=mysql_query("SELECT count(*) as total_frequencia FROM temp
                WHERE id_aluno = '$id_aluno_turma'
                AND data_chamada = '$dt_diasdiario'
                AND inep = '$inep'");
                $total_frequencia_data = mysql_result($sql_frequencia_data, 0, "total_frequencia");
               /*Calcula o total de frequencia por data aqui se calcula o total de aulas por dia*/


                 // echo "$total_frequencia_data *";
                 // echo "* $Totaldata_registrada_profe *";

       if($total_frequencia_data > 0)
            {
/***************************************************************/
             if ($total_dia_calendario >=2)
                {

                  if ($dt_diasdiario != $dt_data_registrada)
                    {
                      $conta_frequencia = 0;
                      $sql_registro_prof_data="SELECT data_chamada,n_chamada,frequencia
                      FROM temp
                      WHERE id_aluno = '$id_aluno_turma'
                      AND data_chamada = '$dt_diasdiario'
                      AND inep = '$inep'";
                      $resultado_registro_prof_data = mysql_query($sql_registro_prof_data) or die (mysql_error());
                      $linhas_registro_prof_data= mysql_num_rows($resultado_registro_prof_data);
                       if ($total_frequencia_data >1) // se o professor registrou mais de um dia dias_frequencia
                           {

                            while($pegar_registro_prof_data=mysql_fetch_array($resultado_registro_prof_data))
                               {
                                  if ($pegar_registro_prof_data["frequencia"]=="F")
                                       $total_faltas +=1;
                                   ?>
                                    <td><font size="2"> <?echo $pegar_registro_prof_data["frequencia"];?> </td>
                                   <?

                                  /****Registrado mais de duas aulas por falha do sistema***/
                                   if ($total_frequencia_data > 2)
                                      {
                                       $conta_frequencia += 1;

                                       if  ($conta_frequencia==2)
                                             break;
                                      }

                                }
                            }
                          else
                            {
                               ?>
                               <td class="nomecampo"> <?echo mysql_result($resultado_frequencia_data,0,"frequencia");?> </td>
                               <td class="nomecampo"> <?echo "/";?> </td>
                              <?

                             }
                      $dt_data_registrada  =    $dt_diasdiario;

                      }

                 }
             else
                {
                   if (mysql_result($resultado_frequencia_data,0,"frequencia")=="F")
                       $total_faltas +=1;

                       ?>
                         <td><font size="2"> <?echo mysql_result($resultado_frequencia_data,0,"frequencia");?> </td>
                       <?
                }

                     /**************************************************************/




/*Se o professor nao marcou nada*/
           }
        else
            {
                   ?>
     	            <td class="nomecampo"> <?echo "/";?> </td>
                  <?
             }


        }//fim pegardia


/*
             {


             }*/


?>

	     <td class="nomecampo"> <?echo $total_faltas;?> </td>
  </tr>
<?

$total_faltas=0;

break;
    } // whiele pegar conteudo
  } // if pegar conteudo
  }// while $pegardia_turma_aluno
 }// if $pegardia_turma_aluno
}  // post

  $sql = "select count(*) as total from aluno a,turma_aluno ta,turma t where  t.inep = '$inep' and ta.id_aluno=a.id and ta.id_turma=t.id
  and status = '1' and t.id='$txtturma' ";
 
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];
}//while
if ($total>0)
  {
?>
<!--

  <tr><td>Total</td>
    	  <td><font size="2"> <?echo $total;?>
  </tr>

-->




<?
}
else
{
?>

<!--
<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>

-->
<?
 }
?>
</table>







<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Homologado</b></td>
</tr>

<tr>
	<td class="nomecampo"><b>Supervis�o:</b></td>
	<td class = "escrita">______________________________________</td>
	<td class="nomecampo"><b>Professor(a)</b></td>
	<td class = "escrita">________________________________________________________</td>


</tr>
</table>






</body>
</html>





<script>
function diasemana($data) {
	$ano =  substr("$data", 0, 4);
	$mes =  substr("$data", 5, -3);
	$dia =  substr("$data", 8, 9);

	$diasemana = date("w", mktime(0,0,0,$mes,$dia,$ano) );

	switch($diasemana) {
		case"0": $diasemana = "Domingo";       break;
		case"1": $diasemana = "Segunda-Feira"; break;
		case"2": $diasemana = "Terca-Feira";   break;
		case"3": $diasemana = "Quarta-Feira";  break;
		case"4": $diasemana = "Quinta-Feira";  break;
		case"5": $diasemana = "Sexta-Feira";   break;
		case"6": $diasemana = "Sabado";        break;
	}

     return $diasemana;
}




function mesatual($mes){

	switch($mes) {
		case"01": $mes = "Janeiro";       break;
		case"02": $mes = "Fevereiro"; break;
		case"03": $mes = "Marco";   break;
		case"04": $mes = "Abril";  break;
		case"05": $mes = "Maio";  break;
		case"06": $mes = "Junho";   break;
		case"07": $mes = "Julho";        break;
        case"08": $mes = "Agosto";        break;
		case"09": $mes = "Setembro";        break;
		case"10": $mes = "Outubro";        break;
		case"11": $mes = "Novembro";        break;
		case"12": $mes = "Dezembro";        break;
	}

     return $mes;
}


</script>

