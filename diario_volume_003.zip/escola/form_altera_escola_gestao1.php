<?php
require_once __DIR__ . '../../start.php';

$title = 'Escola';

$id = $inep;

/* * **********************transicao************************************************ */
$sqltransicao = "select * from transicao where inep = $id";
$respostatransicao = mysql_query($sqltransicao);
while ($linhatransicao = mysql_fetch_array($respostatransicao)) {
    $regularizacao = $linhatransicao["REGULARIZACAO"];
    $patrimonio = $linhatransicao["PATRIMONIO"];
    $spatrimonio = $linhatransicao["SPATRIMONIO"];
    $sleitura = $linhatransicao["SLEITURA"];
    $lie = $linhatransicao["LIE"];
    $quadra = $linhatransicao["QUADRA"];
    $qcoberta = $linhatransicao["QCOBERTA"];
    $programa = $linhatransicao["PROGRAMA"];
    $fonter = $linhatransicao["FONTER"];
    $squadra = $linhatransicao["SQUADRA"];
    $spatrimonio = $linhatransicao["SPATRIMONIO"];
    $cantina = $linhatransicao["CANTINA"];
}

/* * **********************escola************************************************ */
$sql = "select * from escola where inep = $id";
$resposta = mysql_query($sql);
$linha = mysql_fetch_array($resposta);
$codmuni = $linha["MUNICIPIO"];
$recuperacao = isset($linha["RECUPERACAO"]) ? $linha["RECUPERACAO"] : null;
$situa_regulariza = $linha["SITUACAO"];

$sqlconselho = "select * from conselhoe where inep = $id";
$respostaconselho = mysql_query($sqlconselho);
while ($linhaconselho = mysql_fetch_array($respostaconselho)) {

    $dtregistro = date("d/m/Y", strtotime($linhaconselho["DTREGISTRO"]));
    $dtinicio = date("d/m/Y", strtotime($linhaconselho["DTINICIO"]));
    $dtfim = date("d/m/Y", strtotime($linhaconselho["DTFIM"]));

    $cnpj = $linhaconselho["CNPJ"];
    $presidente = $linhaconselho["PRESIDENTE"];
    $suplente_pres = $linhaconselho["SUPLENTE_PRES"];
    $secretariode = $linhaconselho["SECRETARIO1DE"];
    $suplente_secr1 = $linhaconselho["SUPLENTE_SECR1"];
    $secretario2de = $linhaconselho["SECRETARIO2DE"];
    $suplente_secr2 = $linhaconselho["SUPLENTE_SECR2"];
    $conselhe1cap = $linhaconselho["CONSELHE1CAP"];
    $suplente1cap = $linhaconselho["SUPLENTE1CAP"];
    $conselhe2cap = $linhaconselho["CONSELHE2CAP"];
    $suplente2cap = $linhaconselho["SUPLENTE2CAP"];
    $conselhe3cap = $linhaconselho["CONSELHE3CAP"];
    $suplente3cap = $linhaconselho["SUPLENTE3CAP"];
    $conselhe4cap = $linhaconselho["CONSELHE4CAP"];
    $suplente4cap = $linhaconselho["SUPLENTE4CAP"];
    $tesoureiro = $linhaconselho["TESOUREIRO"];
    $suplentetesoureiro = $linhaconselho["SUPLENTETESOURO"];
    $conselhe1cef = $linhaconselho["CONSELHE1CEF"];
    $suplente1cef = $linhaconselho["SUPLENTE1CEF"];
    $conselhe2cef = $linhaconselho["CONSELHE2CEF"];
    $suplente2cef = $linhaconselho["SUPLENTE2CEF"];
    $conselhe3cef = $linhaconselho["CONSELHE3CEF"];
    $suplente3cef = $linhaconselho["SUPLENTE3CEF"];
    $conselhe1cf = $linhaconselho["CONSELHE1CF"];
    $suplente1cf = $linhaconselho["SUPLENTE1CF"];
    $conselhe2cf = $linhaconselho["CONSELHE2CF"];
    $suplente2cf = $linhaconselho["SUPLENTE2CF"];
    $conselhe3cf = $linhaconselho["CONSELHE3CF"];
    $suplente3cf = $linhaconselho["SUPLENTE3CF"];
    $conselhe4cf = $linhaconselho["CONSELHE4CF"];
    $suplente4cf = $linhaconselho["SUPLENTE4CF"];
}

?><!DOCTYPE html>
<html>
    <head>
        <?php require_once page_head(); ?>
    </head>
    <body>
        <?php require_once page_header(); ?>
        
        <div class="container">
            <form id="form" class="" action="insere_escola_gestao.php" method="post">
                
                <input readonly name="codigo" id="codigo" type="hidden" value="<?php echo $id ?>">
                
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active"><a href="#escola" aria-controls="escola" role="tab" data-toggle="tab">Dados da escola</a></li>
                  <li role="presentation"><a href="#regularizacao" aria-controls="regularizacao" role="tab" data-toggle="tab">Ato de regulariza��o</a></li>
                  <li role="presentation"><a href="#ambientes" aria-controls="ambientes" role="tab" data-toggle="tab">Ambientes</a></li>
                  <li role="presentation"><a href="#conselho" aria-controls="conselho" role="tab" data-toggle="tab">Conselho</a></li>
                </ul>
                <br>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="escola">
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="inep">INEP</label>
                                    <input class="form-control" name="inep" id="inep" readonly type="text" value="<?php echo $linha["INEP"]; ?>">
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="lbldtemissaote">Nome</label>
                                    <input name="descricao" id="descricao" class="form-control" maxlength="60" type="text" value="<? echo $linha["DESCRICAO"]; ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cod_estado">Munic�pio</label>
                                    <select name="cod_estado" id="cod_estado" class="form-control" readonly>
                                        <option value=""></option>
                                        <?php
                                        $sql = "select codigo, descricao FROM municipio order by descricao";
                                        $res = mysql_query($sql);
                                        while ($row = mysql_fetch_array($res)) { ?>
                                            <option value="<?php echo $row['codigo'] ?>" <?php echo ($row['codigo'] == $codmuni) ? "selected" : '' ?>><?php echo $row['descricao']; ?>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group" title="Definida conforme Portaria N� 0522/14-GAB/SEDUC">
                                    <label for="selectrecuperacao">Forma de Recupera��o</label>
                                    <select id="selectrecuperacao" name="selectrecuperacao" class="form-control">
                                        <?php
                                        $sql = "select id, descricao from tipo_recuperacao order by descricao";
                                        $res = mysql_query($sql);
                                        while ($row = mysql_fetch_array($res)) { ?>
                                        <option value="<?php echo $row['id'] ?>" <?php echo ($row['id']==$recuperacao) ? "selected" : '' ?>><?php echo $row['descricao']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>                                
                        <hr>
                        
                        <fieldset class="well well-sm">
                            <legend>Endere�o e Contato</legend>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="endereco">Logradouro</label>
                                        <input name="endereco" type="text" id="endereco" class="form-control" maxlength="60" value="<?php echo $linha["ENDERECO"]; ?>">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="nr">N�mero</label>
                                        <input name="nr" type="text" id="nr" class="form-control" maxlength="4" value="<?php echo $linha["NUMERO"]; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="bairro">Bairro</label>
                                        <input name="bairro" type="text" id="bairro" class="form-control" maxlength="40" value="<?php echo $linha["BAIRRO"]; ?>" />
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="txtcep">CEP</label>
                                        <input id="txtcep" name="txtcep" type="text" class="form-control" maxlength="8" value="<?php echo $linha["CEP"]; ?>" onKeyPress="return Enum(event)">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="tipo">Zona</label>
                                        <select name="tipo" class="form-control">                                            
                                            <option value="RURAL" <?php echo ($linha["TIPO"] == 'RURAL') ? 'selected' : ''  ?>>RURAL</option>
                                            <option value="URBANA" <?php echo ($linha["TIPO"] == 'URBANA') ? 'selected' : ''  ?>>URBANA</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="fone">Telefone</label>
                                        <input class="form-control" name="fone" type="text" id="fone" maxlength="20" value="<?php echo $linha["FONE"]; ?>" >
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        
                        <fieldset class="well well-sm">
                            <legend>Dire��o</legend>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="diretor">Diretor</label>
                                        <input name="diretor" type="text" id="diretor" class="form-control" size="60" maxlength="60" value="<?php echo $linha["DIRETOR"]; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="vicediretor">Vice-diretor</label>
                                        <input name="vicediretor" type="text" id="vicediretor" class="form-control" size="60" maxlength="60" value= "<?php echo $linha["VICEDIRETOR"]; ?>">
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        
                        <fieldset class="well well-sm">
                            <legend>Modalidades</legend>
                            
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="checkbox">
                                        <label for="modalidade1">
                                            <input name="modalidade1" type="checkbox" value="1" id="modalidade1" <?php echo ($linha["MODALIDADE1"] == '1') ? 'checked' : '' ?>>
                                            Fundamental Regular 1 a 5
                                        </label>
                                    </div>
                                    <div class="checkbox">                                    
                                        <label for="modalidade2">
                                            <input name="modalidade2" type="checkbox" value="1" id="modalidade2" <?php echo ($linha["MODALIDADE2"] == '1') ? 'checked' : '' ?>>
                                            Fundamental Regular 6 a 9
                                        </label>                                
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="checkbox">
                                        <label for="modalidade3">
                                            <input name="modalidade3" type="checkbox"     value ="1"  id="modalidade3" <?php echo ($linha["MODALIDADE3"] == '1') ? 'checked' : '' ?>>
                                            Fundamental Regular 1 a 9
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label for="modalidade4">
                                            <input name="modalidade4" type="checkbox"     value ="1"  id="modalidade4" <?php echo ($linha["MODALIDADE4"] == '1') ? 'checked' : '' ?>>
                                            Fundamental EJA
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="checkbox">
                                        <label for="modalidade5">
                                            <input name="modalidade5" type="checkbox"  value ="1"  id="modalidade5" <?php echo ($linha["MODALIDADE5"] == '1') ? 'checked' : '' ?>>
                                            Ensino M�dio Regular
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label for="modalidade6">
                                            <input name="modalidade6" type="checkbox"  value ="1"  id="modalidade6" <?php echo ($linha["MODALIDADE6"] == '1') ? 'checked' : '' ?>>
                                            Ensino M�dio EJA
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="checkbox">
                                        <label for="modalidade7">
                                            <input name="modalidade7" type="checkbox"  value ="1"  id="modalidade7" <?php echo ($linha["MODALIDADE7"] == '1') ? 'checked' : '' ?>>
                                            Educa��o Especial
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div><!--/escolas-->
                    
                    <div role="tabpanel" class="tab-pane" id="regularizacao">
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectregularizacao">Ato Regulaliza��o</label>
                                    <select id="selectregularizacao" name="selectregularizacao" class="form-control">
                                        <option value="S" <?php echo ($regularizacao == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($regularizacao == 'N') ? 'selected' : '' ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectsituacao">Situa��o</label>
                                    <select id="selectsituacao" name="selectsituacao" class="form-control">
                                    <?php
                                    $sql = "select id, descricao from regulariza_situacaoescolar order by descricao";
                                    $res = mysql_query($sql);
                                    if ($res) {
                                        while ($row = mysql_fetch_array($res)) { ?>
                                        <option value="<?php echo $row['id'] ?>" <?php if ($row['id'] == $situa_regulariza) { echo "selected"; } ?>><?php echo $row['descricao']; ?></option>
                                    <?php }
                                    } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectpatrimonio">Patrim�nio</label>
                                    <select id="selectpatrimonio" name="selectpatrimonio" class="form-control">
                                        <option value="S" <?php echo ($patrimonio == 'S') ? 'selected' : ''  ?>>Sim</option>
                                        <option value="N" <?php echo ($patrimonio == 'N') ? 'selected' : ''  ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="txtportaria">Portaria / Decreto</label>
                                    <input type="text" name="txtportaria" class="form-control" id="txtportaria" value="<?php echo $linha["PORTARIA"]; ?>" maxlength="12" />
                                </div>
                            </div>
                            <div class="col-md-2">
                                <?php
                                $dataEmissao = date("d/m/Y", strtotime($linha["DTPORTARIA"]));
                                $dataEmissao = ($dataEmissao == '31/12/1969') ? "" : $dataEmissao;
                                ?>
                                <div class="form-group">
                                    <label for="txtdtemissao">Data Emiss�o</label>
                                    <input type="text" name="txtdtemissao" id="txtdtemissao" class="form-control" value="<?php echo $dataEmissao ?>" >
                                </div>
                            </div>
                            <div class="col-md-2">
                                <?php
                                $dataValidade = date("d/m/Y", strtotime($linha["DTVALIDADE"]));
                                $dataValidade = ($dataValidade == '31/12/1969') ? "" : $dataValidade;
                                ?>
                                <div class="form-group">
                                    <label for="txtdtvalidade">Data Validade</label>
                                    <input name= "txtdtvalidade" type="text" id="txtdtvalidade" class="form-control" value="<?php echo $dataValidade ?>" >
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="nprofessores">Professores estatut�rios</label>
                                    <input name="nprofessores" type="text" id="nprofessores" class="form-control" MAXLENGTH="5" value="<? echo $linha["NPROFESSORES"]; ?>" onkeypress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="nemergencial">Professores emergenciais</label>
                                    <input name="nemergencial" type="text" id="nemergencial" class="form-control" MAXLENGTH="5" value="<? echo $linha["NEMERGENCIAL"]; ?>" onkeypress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="nadm">T�cnicos administrativos</label>
                                    <input name="nadm" type="text" id="nadm" class="form-control" MAXLENGTH="5" value="<? echo $linha["NADMINISTRATIVO"]; ?>" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="nalunos">Alunos</label>
                                    <input name="nalunos" type="text" id="nalunos" class="form-control" MAXLENGTH="5" value="<? echo $linha["NALUNOS"]; ?>" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                        </div>
                    </div>                            
                    
                    <div role="tabpanel" class="tab-pane" id="ambientes">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="txtqdtasala">Sala de Aula</label>
                                    <input type="text" name="txtqdtasala" value="0" class="form-control" id="txtqdtasala" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Sala de Leitura</label>
                                    <select id="selectleitura" name="selectleitura" class="form-control">
                                        <option value="S" <?php echo ($sleitura == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($sleitura == 'N') ? 'selected' : '' ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectlie">Laborat�rio Inform�tica</label>
                                    <select id="selectlie" name="selectlie" class="form-control">
                                        <option value="N" <?php echo ($lie == 'N') ? 'selected' : '' ?>>N�o</option>
                                        <option value="S" <?php echo ($lie == 'S') ? 'selected' : '' ?>>Sim</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectquadra">Quadra de Esporte</label>
                                    <select id="selectquadra" name="selectquadra" class="form-control">
                                        <option value="S" <?php echo ($quadra == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($quadra == 'N') ? 'selected' : '' ?>>N�o</option>                                            
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Situa��o</label>
                                    <select id="selectstatusqd" name="selectstatusqd" class="form-control">
                                    <?php
                                    $sql = "select id, descricao from status_escola order by descricao";
                                    $res = mysql_query($sql);
                                    if ($res) {
                                        while ($row = mysql_fetch_array($res)) { ?>
                                        <option value="<?php echo $row['id'] ?>" <?php if ($row['id'] == $squadra) { echo "selected"; } ?>>
                                            <?php echo $row['descricao']; ?>
                                        </option>
                                    <?php }                                    
                                    } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectcoberta">Coberta</label>
                                    <select id="selectcoberta" name="selectcoberta" class="form-control">
                                        <option value="S" <?php echo ($qcoberta == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($qcoberta == 'N') ? 'selected' : '' ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectpde">PDE</label>
                                    <select id="selectpde" name="selectpde" class="form-control">
                                        <option value="S">Sim</option>
                                        <option value="N">N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectprogramas">Programas</label>
                                    <select id="selectprogramas" name="selectprogramas" class="form-control">
                                        <option value="S" <?php echo ($programa == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($programa == 'N') ? 'selected' : '' ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Qtd Programas</label>
                                    <input type="text" name="txtqdtaprograma" value="0" class="form-control" id="txtqdtaprograma" maxlength="4" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectacervo">Acervo Bibliografico</label>
                                    <select id="selectacervo" name="selectacervo" class="form-control">
                                        <option value="S">Sim</option>
                                        <option value="N">N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="selectstatus">Status</label>
                                    <select id="selectstatus" name="selectstatus" class="form-control">
                                    <?php
                                    $sql = "select id, descricao from status_escola order by descricao";
                                    $res = mysql_query($sql);
                                    if ($res) {
                                        while ($row = mysql_fetch_array($res)) { ?>
                                        <option value="<?php echo $row['id'] ?>"<?php if ($row['id'] == $spatrimonio) { echo "selected"; } ?>>
                                            <?php echo $row['descricao']; ?>
                                        </option>
                                        <?php
                                        }
                                    } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Fonte de Recurso</label>
                                    <select id="selectfonte" name="selectfonte" class="form-control">
                                    <?php
                                    $sql = "select id, descricao from fonte_recurso order by descricao";
                                    $res = mysql_query($sql);
                                    if ($res) {
                                        while ($row = mysql_fetch_array($res)) { ?>
                                        <option value="<?php echo $row['id'] ?>" <?php if ($row['id'] == $fonter) { echo "selected"; } ?>>
                                            <?php echo $row['descricao']; ?>
                                        </option>
                                        <?php }                                        
                                        } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldeficienten">IDEB</label>
                                    <input type="text" name="txtideb" class="form-control" id="txtideb" maxlength="3" value="<? echo $linha["IDEB"]; ?>" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldeficienten">ENEM</label>
                                    <input type="text" name="txtenem" class="form-control" id="txtenem" maxlength="3" value="<? echo $linha["ENEM"]; ?>" onKeyPress="return Enum(event)">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="txtprasil">Prova Brasil</label>
                                    <input type="text" name="txtprasil" class="form-control" id="txtprasil" maxlength="3" value="<? echo $linha["PBRASIL"]; ?>" onKeyPress="return Enum(event)"/>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="txtprovlhabr">Provinha Brasil</label>
                                    <input type="text" name="txtprovlhabr" class="form-control" id="txtprovlhabr" maxlength="3" value="<? echo $linha["PROVINHABR"]; ?>" onKeyPress="return Enum(event)"/>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Cantina Alugado</label>
                                    <select id="selectcantina" name="selectcantina" class="form-control">
                                        <option value="S" <?php echo ($cantina == 'S') ? 'selected' : '' ?>>Sim</option>
                                        <option value="N" <?php echo ($cantina == 'N') ? 'selected' : '' ?>>N�o</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="regularizacao">Mais Educa��o</label>
                                    <select id="selectmais" name="selectmais" class="form-control">
                                        <option value="S">SIM</option>
                                        <option value="N">N�O</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div role="tabpanel" class="tab-pane" id="conselho">
                        
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="cnpj">CNPJ</label>
                                    <input name="cnpj" type="text" id="cnpj" class="form-control" MAXLENGTH="18" value= "<? echo $cnpj; ?>">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldtemissaote">Data de Registro</label>
                                    <input type="text" name="txtdtregistro" class="form-control" id="txtdtregistro"
                                           value="<?php if ($dtregistro == '31/12/1969') { $dtregistro = ""; } echo $dtregistro; ?>">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldtemissaote">Tipo de Elei��o</label>
                                    <select name="tipoe" id="tipoe" class="form-control">
                                        <?php
                                        $sql = "select id, descricao from tipo_eleicao order by descricao";
                                        $res = mysql_query($sql);
                                        if ($res) {
                                            while ($row = mysql_fetch_array($res)) { ?>
                                                <option value="<?php echo $row['id'] ?>" <?php if ($row['id'] == $linhaconselho["TPELEICAO"]) { echo "selected"; } ?>>
                                            <?php echo $row['descricao']; ?>
                                        <?php }
                                        } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldtemissaote">Data de In�cio de Mandato</label>
                                    <input type="text" name="txtdtmandatoi" id="txtdtmandatoi"  class="form-control" value="
                                    <?
                                    if ($dtinicio == '31/12/1969') {
                                        $dtinicio = "";
                                        echo $dtinicio;
                                    } else {

                                        echo $dtinicio;
                                    }
                                    ?>" >
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="lbldtemissaote">Data de Fim de Mandato</label>
                                    <input type="text" name="txtdtmandatof" id="txtdtmandatof"  class="form-control" value="<?php if ($dtfim == '31/12/1969') { $dtfim = ""; } echo $dtfim; ?>" >
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h3>Membros da composi��o atual</h3>
                        
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                          <li role="presentation" class="active"><a href="#direxecutiva" aria-controls="direxecutiva" role="tab" data-toggle="tab">Diretoria Executiva</a></li>
                          <li role="presentation"><a href="#articulacao_pedagogica" aria-controls="articulacao_pedagogica" role="tab" data-toggle="tab">Comiss�o de Articula��o Pedag�gica</a></li>
                          <li role="presentation"><a href="#execucao_financeira" aria-controls="execucao_financeira" role="tab" data-toggle="tab">Comiss�o de Execu��o Financeira</a></li>
                          <li role="presentation"><a href="#conselho_fiscal" aria-controls="conselho_fiscal" role="tab" data-toggle="tab">Conselho Fiscal</a></li>
                        </ul>
                        
                        <br>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="direxecutiva">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtpresidente">Presidente</label>
                                            <input name="txtpresidente" type="text" id="txtpresidente" class="form-control" MAXLENGTH="60" value= "<? echo $presidente; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente">Suplente</label>
                                            <input name="txtsuplente" type="text" id="txtsuplente" class="form-control" MAXLENGTH="60" value= "<? echo $suplente_pres; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="txtsegmento1_de">Segmento</label>
                                            <select name="txtsegmento1_de" id="txtsegmento1_de" class="form-control">
                                                <option value="">Segmento</option>
                                                <option value="PAI">PAI</option>
                                                <option value="ALUNO">ALUNO</option>
                                                <option value="PROF">PROFESSOR</option>
                                                <option value="FUNC">FUNCIONARIO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="txtsecretario1_de">1� Secretario</label>
                                            <input name="txtsecretario1_de" type="text" id="txtsecretario1_de" class="form-control" MAXLENGTH="60" value= "<? echo $secretariode; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente1_de">Suplente</label>
                                            <input name="txtsuplente1_de" type="text" id="txtsuplente1_de" class="form-control" MAXLENGTH="60" value= "<? echo $suplente_secr1; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="lbldtemissaote">Segmento</label>
                                            <select name="txtsegmento2_de" id="txtsegmento2_de" class="form-control">
                                                <option value="">Segmento</option>
                                                <option value="PAI">PAI</option>
                                                <option value="ALUNO">ALUNO</option>
                                                <option value="PROF">PROFESSOR</option>
                                                <option value="FUNC">FUNCIONARIO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="txtsecretario2_de">2� Secretario</label>
                                            <input name="txtsecretario2_de" type="text" id="txtsecretario2_de" class="form-control" MAXLENGTH="40" value= "<? echo $secretario2de; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente2_de">Suplente</label>
                                            <input name="txtsuplente2_de" type="text" id="txtsuplente2_de" class="form-control" MAXLENGTH="40" value= "<? echo $suplente_secr2; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div role="tabpanel" class="tab-pane" id="articulacao_pedagogica">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro1_cap">Conselheiro</label>
                                            <input name="txtconselheiro1_cap" type="text" id="txtconselheiro1_cap" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe1cap; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente1_cap">Suplente</label>
                                            <input name="txtsuplente1_cap" type="text" id="txtsuplente1_cap" class="form-control" MAXLENGTH="40" value= "<? echo $suplente1cap; ?>">
                                        </div>
                                    </div>
                                </div>                            
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro2_cap">Conselheiro</label>
                                            <input name="txtconselheiro2_cap" type="text" id="txtconselheiro2_cap" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe2cap; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente2_cap">Suplente</label>
                                            <input name="txtsuplente2_cap" type="text" id="txtsuplente2_cap" class="form-control" MAXLENGTH="40" value= "<? echo $suplente2cap; ?>">
                                        </div>
                                    </div>
                                </div>                            
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro3_cap">Conselheiro</label>
                                            <input name="txtconselheiro3_cap" type="text" id="txtconselheiro3_cap" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe3cap; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente3_cap">Suplente</label>
                                            <input name="txtsuplente3_cap" type="text" id="txtsuplente3_cap" class="form-control" MAXLENGTH="40" value= "<? echo $suplente3cap; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro4_cap">Conselheiro</label>
                                            <input name="txtconselheiro4_cap" type="text" id="conselheiro4_cap" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe4cap; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente4_cap">Suplente</label>
                                            <input name="txtsuplente4_cap" type="text" id="txtsuplente4_cap" class="form-control" MAXLENGTH="40" value= "<? echo $suplente4cap; ?>">
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            
                            <div role="tabpanel" class="tab-pane" id="execucao_financeira">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txttesoureiro1_cef">Tesoureiro</label>
                                            <input name="txttesoureiro1_cef" type="text" id="txttesoureiro1_cef" class="form-control" MAXLENGTH="40" value= "<? echo $tesoureiro; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplentetesouro">Suplente</label>
                                            <input name="txtsuplentetesouro" type="text" id="txtsuplentetesouro" class="form-control" MAXLENGTH="40" value= "<? echo $suplentetesoureiro; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro1_cef">Conselheiro</label>
                                            <input name="txtconselheiro1_cef" type="text" id="txtconselheiro1_cef" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe1cef; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente1_cef">Suplente</label>
                                            <input name="txtsuplente1_cef" type="text" id="txtsuplente1_cef" class="form-control" MAXLENGTH="40" value= "<? echo $suplente1cef; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro2_cef">Conselheiro</label>
                                            <input name="txtconselheiro2_cef" type="text" id="txtconselheiro2_cef" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe2cef; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente2_cef">Suplente</label>
                                            <input name="txtsuplente2_cef" type="text" id="txtsuplente2_cef" class="form-control" MAXLENGTH="40" value= "<? echo $suplente2cef; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro3_cef">Conselheiro</label>
                                            <input name="txtconselheiro3_cef" type="text" id="txtconselheiro3_cef" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe3cef; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente3_cef">Suplente</label>
                                            <input name="txtsuplente3_cef" type="text" id="txtsuplente3_cef" class="form-control" MAXLENGTH="40" value= "<? echo $suplente3cef; ?>">
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            
                            <div role="tabpanel" class="tab-pane" id="conselho_fiscal">
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro1_cf">Conselheiro</label>
                                            <input name="txtconselheiro1_cf" type="text" id="txtconselheiro1_cf" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe1cf; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente1_cf">Suplente</label>
                                            <input name="txtsuplente1_cf" type="text" id="txtsuplente1_cf" class="form-control" MAXLENGTH="40" value= "<? echo $suplente1cf; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="lblcod_cpf">Conselheiro</label>
                                            <input name="txtconselheiro2_cf" type="text" id="txtconselheiro2_cf" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe2cf; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="lblcod_cpf">Suplente</label>
                                            <input name="txtsuplente2_cf" type="text" id="txtsuplente2_cf" class="form-control" MAXLENGTH="40" value= "<? echo $suplente2cf; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="lblcod_cpf">Conselheiro</label>
                                            <input name="txtconselheiro3_cf" type="text" id="txtconselheiro3_cf" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe3cf; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="lblcod_cpf">Suplente</label>
                                            <input name="txtsuplente3_cf" type="text" id="txtsuplente3_cf" class="form-control" MAXLENGTH="40" value= "<? echo $suplente3cf; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtconselheiro4_cf">Conselheiro</label>
                                            <input name="txtconselheiro4_cf" type="text" id="txtconselheiro4_cf" class="form-control" MAXLENGTH="40" value= "<? echo $conselhe4cf; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="txtsuplente4_cf">Suplente</label>
                                            <input name="txtsuplente4_cf" type="text" id="txtsuplente4_cf" class="form-control" MAXLENGTH="40" value= "<? echo $suplente4cf; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <hr>        
                    <p id="finish">
                       <input type="submit" class="btn btn-primary" value="Salvar altera��es">
                       <input type="button" class="btn btn-default pull-right" value="Voltar" onclick="location.href = 'mnadmescola.php';">
                    </p>
                </div>              
            </form>
        </div>
        
        <?php require_once page_footer(); ?>
        <script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
        <script src="lib/validate.js" type="text/javascript"></script>
        <script src="lib/forms.js" type="text/javascript"></script>
        <script src="generic2.js" type="text/javascript"></script>
        <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
        <link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
        <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>
        <script src="../script.js"></script>
    </body>
</html>