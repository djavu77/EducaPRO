
<?php

include ("conexao_mysql.php");



$cpf=  $_POST["cpf"];



if(!empty($_POST["cpf"])) 
{ 

$sql="select * from servidorrec where cpf = '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {
           $dtabertura    = date("d/m/Y",strtotime($dado["DATA"]));

   
    $cpf              =$pegar["cpf"];
    $pis              =$pegar["pis"]; 	
    $rg               =$pegar["rg"]; 	
	$orgaoexp         =$pegar["orgaoexp"]; 	
    $cep              =$pegar["cep"];



	$dtemissaorg      =date("d/m/Y",strtotime($pegar["dtemissaorg"]));

	$te               =$pegar["te"]; 	
	$zona             =$pegar["zona"]; 	
	$secao            =$pegar["secao"]; 	

	$dtemissaote      =date("d/m/Y",strtotime($pegar["dtemissaote"]));

	$nome             =$pegar["nome"]; 	
	$estcivil         =$pegar["estcivil"]; 	
	$numero           =$pegar["numero"]; 		


	$dtnascimento      =date("d/m/Y",strtotime($pegar["dtnascimento"]));

	$sexo             =$pegar["sexo"]; 	
	$conjuge          =$pegar["conjuge"]; 	
	$mae              =$pegar["mae"]; 	
    $pai              =$pegar["pai"]; 	
	$endereco         =$pegar["endereco"]; 	
	$bairro           =$pegar["bairro"]; 	
	
	$fonesetor        =$pegar["fonesetor"]; 	
	$fonecontato      =$pegar["fonecontato"]; 	
	$foneresidencial  =$pegar["foneresidencial"]; 	
	$celular          =$pegar["celular"]; 	

	
	$email            =$pegar["email"]; 	




//*************Estado******************************
$estado           =$pegar["estado"]; 	

$sqlestados="select * from estados where cod_estados = '$estado'";
$resultadoestados=mysql_query($sqlestados) or die (mysql_error());
$linhasestados   =mysql_num_rows($resultadoestados);

if($linhasestados>0)
{
   while($pegarestados=mysql_fetch_array($resultadoestados))
	{
    	$descrciaoestados    =$pegarestados["sigla"]; 	
	}
 }	


//*************Municipio******************************
$cidade           =$pegar["cidade"]; 	

$sqlcidade="select * from cidades where cod_cidades = '$cidade'";
$resultadocidade=mysql_query($sqlcidade) or die (mysql_error());
$linhascidade   =mysql_num_rows($resultadocidade);

if($linhascidade>0)
{
   while($pegarcidade=mysql_fetch_array($resultadocidade))
	{
    	$descrciaocidade    =$pegarcidade["nome"]; 	
	}
 }	
//*********************************************************	



	

//*************Grau de Instrução******************************
$grauinstrucao    =$pegar["grauinstrucao"]; 

$sqlinstrucao="select * from grauinstrucao where codigo = '$grauinstrucao'";
$resultadoinstrucao=mysql_query($sqlinstrucao) or die (mysql_error());
$linhasinstrucao   =mysql_num_rows($resultadoinstrucao);

if($linhasinstrucao>0)
{
   while($pegarinstrucao=mysql_fetch_array($resultadoinstrucao))
	{
    	$descrciaoinstrucao    =$pegarinstrucao["descricao"]; 	
	}
 }	
//*********************************************************	
	
	
	
	
	
	
		
	$preaposentadoria =$pegar["preaposentadoria"]; 	
	$complemento      =$pegar["complemento"]; 	
	$fonecontato      =$pegar["fonecontato"]; 	
	$tpservidor       =$pegar["tpservidor"]; 	
	$ncontrato        =$pegar["ncontrato"]; 	
	$banco            =$pegar["banco"]; 	
	$agencia          =$pegar["agencia"]; 	
	$cc               =$pegar["cc"]; 	
 } 


/*--------------------Contrato-------------------------------------- */


/*$sqlcontrato="select * from contrato where cpf = '$cpf'";
$resultadocontrato=mysql_query($sqlcontrato) or die (mysql_error());
$linhascontrato=mysql_num_rows($resultadocontrato);

if($linhascontrato>0)
{
   while($pegar=mysql_fetch_array($resultadocontrato))
   {
            $txtid                 =$pegar["id"];
			$txtMatricula1         =$pegar["matricula"]; 	
			$txtcod_cargo          =$pegar["cargo"]; 	
			$cod_funcao0           =$pegar["funcao"]; 	
			$selectcontrato1       =$pegar["regime"]; 	
			$txtdtadmissao1        =$pegar["dtadmissao"]; 	
			$selectch1             =$pegar["chcontrato"]; 	
			$txtdecreto1           =$pegar["decreto"]; 	
			
			$txtdtdecreto1         =$pegar["dtdecreto"]; 	
			$txtdiario1            =$pegar["dof"]; 	
			$txtdtdiario1          =$pegar["dtdof"]; 	
			$selectlotacao1        =$pegar["lotado"]; 	
			$txtcargo_comisionado  =$pegar["preaposentadoria"]; 	
			$selectlicenca         =$pegar["preaposentadoria"]; 	
			$selectcadm1           =$pegar["preaposentadoria"]; 	
			$txtdpto               =$pegar["dpto"]; 	


   }
}

*/


     $dia = date('d');
     $mes = date('m');
     $ano = date('Y');
  
     $data1 =$dia.".".$mes.".".$ano;

}}




?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="nam/style/forms.css" type="text/css" />
	<link rel="stylesheet" href="nam/estilo.css" type="text/css" />
	<link rel="stylesheet" href="nam/style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="nam/text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="nam/lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="nam/lib/validate.js" type="text/javascript"></script>
	<script src="nam/lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="nam/lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />




</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "nam/img/seduc_topo.jpg"/>

		</div>



			<div id="content">

				<form name = "recadastramento" class="form" action="altera_servidor.php" method="post">
				 <div id="tema"> 
					   <p><center>Dados Pessoais</center></p>
				  </div>

					<p>
						<label for="txtCPF">CPF<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>" onKeyPress="return Enum(event)"  readonly="true"/>

  				 <label for="txtPisPasep">PIS/PASEP:</label>
				<input type="text" name="pis" id="pis" style="width:110px" value= "<? echo $pis; ?>" maxlength="25" onKeyPress="return Enum(event)"/>

					</p>

					<p>
						<label for="txtRG">RG<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="txtRG" style="width:110px" value= "<? echo $rg; ?>" id="txtRG" maxlength="20" />
						<label for="txtOrgaoExp" >Orgo Exp<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtOrgaoExp" value= "<? echo $orgaoexp; ?>" style="width:70px" id="txtOrgaoExp"  maxlength="10"/>
						<label for="txtDataEmissao">Data Emisso<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtDataEmissao" value= "<? echo $dtemissaorg; ?>" style="width:80px" id="txtDataEmissao" maxlength="12" OnKeyUp="mascaradtrg(txtDataEmissao.value)"/>
					</p>

					<p>
						<label for="lblte">Ttulo Eleitor<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtte" style="width:100px" value= "<? echo $te; ?>" id="txtte" maxlength="20" onKeyPress="return Enum(event)"/>
						<label for="lblzona" >Zona<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtzona" value= "<? echo $zona; ?>" style="width:50px" id="txtzona" maxlength="10" onKeyPress="return Enum(event)"/>
						<label for="lblsecao">Seção<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtsecao" value= "<? echo $secao; ?>" style="width:50px" id="txtsecao" maxlength="5" onKeyPress="return Enum(event)"/>
						<label for="lbldtemissaote">Data Emisso<img src= "public/img/check.gif"/></label>
						<input type="text" name="txttdtte" value= "<? echo $dtemissaote; ?>" style="width:80px" id="txttdtte" maxlength="12" OnKeyUp="mascaradtte(txttdtte.value)"/>

					</p>



					<p>
						<label for="txtNome">Nome<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" />
					</p>


					<p>
						<label for="lblselectecivil">Estado Civil<img src= "public/img/check.gif"/></label>
 			               <select id="selectcivil" name="selectcivil" style="width:150px" value= "<? echo $estcivil; ?>">
              		          <option value="CASADO">CASADO</option>
            		          <option value="SOLTEIRO">SOLTEIRO</option>
              		          <option value="VIUVO">VIUVO</option>
            		          <option value="DESQUITADO">DESQUITADO</option>
              		          <option value="DIVORCIADO">DIVORCIADO</option>
            		          <option value="UNIAOESTAVEL">UNIAO ESTAVEL</option>
    		               </select>
						<label for="lbldtnascimento">Data Nascimento<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value= "<? echo $dtnascimento; ?>" style="width:70px" id="txtdtnascimento" OnKeyUp="mascaradtnasc(txtdtnascimento.value)"/>
                         </p> 
						
						
						<p>
						  <label for="lblSexo1">Sexo Cadastrado<img src= "public/img/check.gif"/></label>
					  	   <input type="text" name="selectsexo"  value= "<? echo $sexo; ?>" id="selectsexo"  style="width:140px"  readonly="true"/>
				     	</p>

	
	    		       <p> 
						<label for="selectsexo">Sexo</label>
 			               <select id="selectsexo1" name="selectsexo1" style="width:140px" onChange="alterasexo(this.value)">
              		          <option value="M">Masculino</option>
            		          <option value="F">Feminino</option>
    		               </select>


					</p>


					<p>
						<label for="lblconjuge">Conjuge</label>
						<input type="text" name="txtconjuge" style="width:565px" maxlength="60" value= "<? echo $conjuge; ?>" id="txtconjuge" />
					</p>

					<p>
						<label for="lblmae">Nome Mãe<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" />
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai" />
					</p>


					<p>
						<label for="lblEndereco">Endereo<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" />
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" />
					</p>


					<p>
						<label for="lblBairro">Bairro<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtBairro" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40"/>
						<label for="lblBairro">N.<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $numero; ?>" id="txtnr" maxlength="5"/>
			            <label for="txtCEP">CEP<img src= "public/img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $cep; ?>" maxlength="8" onKeyPress="return Enum(event)"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20"/>
						<label for="txtCelular">Contato<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80"/>
					</p>


					<p>
						<label for="txtEmail">Naturalidade Cadastrada</label>
						<input type="text" name="cod_estado1" style="width:40px" value= "<? echo $estado; ?>" id="cod_estado1" maxlength="80" readonly="true"/>
<label for="txtEmail">UF</label>
<input type="text" name="cod_estado1desc" style="width:40px" value= "<? echo $descrciaoestados; ?>" id="cod_estado1desc" maxlength="80" readonly="true"/>
						
<label for="txtEmail">Código</label> 	
<input type="text" name="cod_cidades1" style="width:40px" value= "<? echo $cidade; ?>" id="cod_cidades1" maxlength="80" readonly="true"/>

<label for="txtEmail">Município</label> 	
<input type="text" name="cod_cidades1desc" style="width:250px" value= "<? echo $descrciaocidade; ?>" id="cod_cidades1desc" maxlength="80" readonly="true"/>


						
					</p>


					<p>

					<label for="lblcod_estados">Naturalidade - Estado:</label>
						<select name="cod_estado" id="cod_estado"  onChange="alteraestado(this.value)">
						<option value=""></option>
					<?php
		     				include ("recadastramento/conexao_mysql.php");
							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}
	
					?>
					</select>
          		<label for="lblcod_cidades">Cidade:</label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_cidades" id="cod_cidades"  onChange="alteracidade(this.value)">
			           <option value="">-- Escolha um estado --</option>
            	 </select>

		</p>


					<p>
						<label for="txtEmail">Grau de Instrução Cadastrada</label>
						<input type="text" name="txtinstrucao1" style="width:40px" value= "<? echo $grauinstrucao; ?>" id="txtinstrucao1" maxlength="80" readonly="true"/>
						<label for="txtEmail">Descrição</label>
						<input type="text" name="txtdescinstrucao" style="width:400px" value= "<? echo $descrciaoinstrucao; ?>" id="txtdescinstrucao" maxlength="80" readonly="true"/>

						
					</p>



					<p>
	 
					<label for="lblinstrucao">Grau de Instrucao</label>
						<select name="txtinstrucao" id="txtinstrucao"   onChange="alterainstrucao(this.value)">
						<option value="">Grau de Instrução</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
							
							
									FROM grauinstrucao
									ORDER BY codigo";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>

					<p>
						<label for="txtEmail">Grau de Instrução Cadastrada</label>
						<input type="text" name="anoaposentadoria1" style="width:40px" value= "<? echo $preaposentadoria; ?>" id="anoaposentadoria1" maxlength="80" readonly="true"/>
					
					</p>



					<p>
					<label for="lblinstrucao">Previsão de Aposentadoria</label>
						  <select name="anoaposentadoria"  id="anoaposentadoria"   onChange="alteraaposentadoria(this.value)">
						    <option value="">...Selecione Ano...</option>
						    <option value="2011">2011</option>		
						    <option value="2012">2012</option>		
						    <option value="2013">2013</option>		
						    <option value="2014">2014</option>		
							<option value="2015">2015</option>		
						    <option value="2016">2016</option>		
						    <option value="2017">2017</option>		
						    <option value="2018">2018</option>		
						    <option value="2019">2019</option>		  
						    <option value="2020">2020</option>			
							<option value="2021">2021</option>
						    <option value="2022">2022</option>		
						    <option value="2023">2023</option>		
						    <option value="2024">2024</option>		
						    <option value="2025">2025</option>		
							<option value="2026">2026</option>		
						    <option value="2027">2027</option>		
						    <option value="2028">2028</option>		
						    <option value="2029">2029</option>		
						    <option value="2030">2030</option>		  
						    <option value="2031">2031</option>			
							<option value="2032">2032</option>
						    <option value="2033">2033</option>		
						    <option value="2034">2034</option>		
						    <option value="2035">2035</option>		
						    <option value="2036">2036</option>		
							<option value="2037">2037</option>		
						    <option value="2038">2038</option>		
						    <option value="2039">2039</option>		
						    <option value="2040">2040</option>		
						    <option value="2041">2041</option>		  
						    <option value="2042">2042</option>			
						    <option value="2043">2043</option>		
						    <option value="2044">2044</option>		
						    <option value="2045">2045</option>		  
						    <option value="2046">2046</option>			
						    <option value="2046">2047</option>			
						    <option value="2048">2048</option>		  
						    <option value="2049">2049</option>			
						    <option value="2050">2050</option>			
						  </select>
					
					
					</p>



					 <div id="tema"> 
					       <p><b><center>Quantidade de Contratos - Obrigado a Preencher</center></b></p>
					  </div>
			


           <p>
			  	<label for="selectncontrato">Total de Contrato(s)<img src= "public/img/check.gif"/></label>
 			    <select id="selectqtdacontrato" name="selectqtdacontrato" style="width:40px" >
				   <option value="1">1</option>
             	   <option value="2">2</option>
    		     </select>

           </p>


					 <div id="tema"> 
					       <p><b><center>Contrato - 1</center></b></p>
					  </div>

					<p>
						<label for="selectcontrato">Regime Jurdico(1)<img src= "public/img/check.gif"/></label>
 			                <select id="selectcontrato1" name="selectcontrato1" style="width:190px" >
              		          <option value="1">ESTATUTARIO</option>
            		          <option value="2">CELETISTA</option>
							  <option value="3">REINTEGRADO</option>
							  <option value="4">CDS</option>							  
							  <option value="5">CDSI</option>							  							  
							  <option value="6">CEDIDO</option>							  							  
							  <option value="7">TERMO COOP TECNICA</option>	
							  <option value="8">ESTATUTARIO CDS</option>								  																					 							 <option value="9">FEDERAL A DISPOSIO DO ESTADO</option>								  													    		               </select>
					</p>

<p>
			  	<label for="selectncontrato">Cargo Comissionado<img src= "public/img/check.gif"/></label>
 				     <select name="txtcargo_comisionado" id="txtcargo_comisionado"  disabled="disabled">
						<option value="">Selecione o CDS</option>
					     <?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM cds
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>

</p>





				    <p>

						<label for="selectadm1">Cedido/Termo Coop Tcnica <img src= "public/img/check.gif"/></label>
 			                <select id="selectcadm1" name="selectcadm1" style="width:300px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
            		          <option value="1">AUTARQUIA</option>
            		          <option value="2">ESTADUAL</option>            		          
            		          <option value="3">FEDERAL</option>
							  <option value="4">FUNDACAO PBLICA</option>							  
              		          <option value="5">MUNICIPAL</option>
    		    	          <option value="6">INSTITUIES CONVENIADAS</option>
				           </select>
					</p>


			      <p>
					<label for="lblcod_cargo">Cargo - Nomeao<img src= "public/img/check.gif"/></label>
 				     <select name="txtcod_cargo" id="txtcod_cargo" style="width:210px" >
						<option value=""></option>
					     <?php
            				include ("conexao_mysql.php");
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          		   <label for="lblcodfuncao0">Funcao<img src= "public/img/check.gif"/></label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="cod_funcao0" id="cod_funcao0" style="width:200px">
			           <option value="">-- Escolha cargo --</option>
            	    </select>
	           </p>		

					<p>
	 
					<label for="lblhabilitacao">Habilitao</label>
						<select name="txthabilitacao" id="txthabilitacao" disabled="disabled">
						<option value="">Selecione Habilitao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>






    <p>		
          <label for="lbllicenca">Servidor de Licena</label>
	
	
		  <label for="lbllicenca">Sim
		       <input name="radiolicenca" type="radio"   value ="S" id="radiolicenca" >
		  </label>
    
	
	      <label for="lbldeficienten">No
		       <input name="radiolicenca" type="radio"  value ="N"  id="radiolicenca"  checked="checked">

		  </label>

  </p>
  <p>
			  	<label for="selectncontrato">Qual Licena<img src= "public/img/check.gif"/></label>
 			    <select id="selectlicenca" name="selectlicenca" style="width:350px" disabled="disabled">
				   <option value="">Selecione a licena</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM licenca
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>



   	 </p>		



				<p>		
						<label for="lblMatricula">Matrcula<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtMatricula1" value="" style="width:90px" maxlength="10" id="txtMatricula1" onKeyPress="return Enum(event)"/>

						<label for="txtDataAdmissao">Data Admisso<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtadmissao1" value="" style="width:70px" id="txtdtadmissao1" 
OnKeyUp="mascaraadmissao1(txtdtadmissao1.value)"/>		

						<label for="selectch1">CH - Contrato<img src= "public/img/check.gif"/></label>
 			                <select id="selectch1" name="selectch1" style="width:40px">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>

					<p>
						<label for="lbldecreto">N Decreto</label>
						<input type="text" name="txtdecreto1" style="width:70px" value="" maxlength="11" id="txtdecreto1"/>

						<label for="lblDataAdmissao">Data</label>
						<input type="text" name="txtdtdecreto1" value="" style="width:70px" id="txtdtdecreto1" OnKeyUp="mascaradecreto1(txtdtdecreto1.value)"/>	

						<label for="txtCPF">Publicado Dirio</label>
						<input type="text" name="txtdiario1" style="width:70px" value="" maxlength="10" id="txtdiario1" />

						<label for="txtDataAdmissao">Data</label>
						<input type="text" name="txtdtdiario1" value="" style="width:70px" id="txtdtdiario1" OnKeyUp="mascaradiario1(txtdtdiario1.value)"/>		

					</p>
					   <p>
	  					<label for="lblqtda">Lotado<img src= "public/img/check.gif"/></label>
 			                <select id="selectlotacao1" name="selectlotacao1" style="width:200px" />	
						    <option value="">...Selecione Lotação...</option>
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
            		          <option value="3">ADMINISTRAO E ESCOLA</option>							  
    		               </select>
    	       		     </p>

			      <p>
					<label for="lblgerencia">Gerencia<img src= "public/img/check.gif" /></label>
						<select name="txtgerencia" id="txtgerencia"  style="width:400px" disabled="disabled" >
						<option value="">...Selecione Administração..</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto">Departamento<img src= "public/img/check.gif"/></label>
	         	<!--	<span class="carregando">Aguarde, carregando...</span>-->
		          <select name="txtdpto" id="txtdpto" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
				 
			
	</p>		

           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "public/img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>

           <p>
				<label for="lblinep1">INEP<img src= "public/img/check.gif"/></label>
				<input type="text" name="txtinep1" value="" style="width:90px" maxlength="8" id="txtinep1" disabled="disabled" onKeyPress="return Enum(event)"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola1" id="txtdescescola1" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>


              <p>
						<label for="txtdtlotacao1">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlota11" value="" style="width:70px" id="txtdtlota11"  disabled="disabled" OnKeyUp="mascaralota1(txtdtlota11.value)"/>		



						<label for="selectcontrato1">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch1lota" name="selectch1lota" style="width:40px"  disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula1">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas1" value="0" style="width:30px" id="txtqdtaaulas1" maxlength="2" disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atuação</label>
						<select name="txtautacao1" id="txtautacao1" disabled="disabled" style="width:300px" >
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep2">INEP<img src= "public/img/check.gif"/></label>
				<input type="text" name="txtinep2" value="" style="width:90px" maxlength="8" id="txtinep2"  disabled="disabled" onKeyPress="return Enum(event)"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola2" id="txtdescescola2" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>



			</p>

              <p>
						<label for="txtdtlotacao2">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlota12" value="" style="width:70px" id="txtdtlota12" disabled="disabled" OnKeyUp="mascaralota2(txtdtlota12.value)"/>		

						<label for="selectcontrato2">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch2lota" name="selectch2lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas2" value="0" style="width:30px" id="txtqdtaaulas2"  disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao2">Area de Atuao</label>
						<select name="txtautacao2" id="txtautacao2" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep3">INEP<img src= "public/img/check.gif"/></label>
				<input type="text" name="txtinep3" value="" style="width:90px" maxlength="8" id="txtinep3"  disabled="disabled" onKeyPress="return Enum(event)"/>

          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola3" id="txtdescescola3" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>

              <p>
						<label for="txtdtlotacao3">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlota13" value="" style="width:70px" id="txtdtlota13" disabled="disabled"/>

						<label for="selectcontrato3">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch3lota" name="selectch3lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula3">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas3" value="0" style="width:30px" id="txtqdtaaulas3"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>
					<label for="lblareaatuacao3">Area de Atuao</label>
						<select name="txtautacao3" id="txtautacao3" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>

           <p>
				<label for="lblinep1">INEP<img src= "public/img/check.gif"/></label>
				<input type="text" name="txtinep4" value="" style="width:90px" maxlength="8" id="txtinep4" disabled="disabled" onKeyPress="return Enum(event)"/>
          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola4" id="txtdescescola4" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
    		</p>

              <p>
						<label for="txtdtlotacao4">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlota14" value="" style="width:70px" id="txtdtlota14" disabled="disabled"/>

						<label for="selectcontrato4">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch4lota" name="selectch4lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula4">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas4" value="0" style="width:30px" id="txtqdtaaulas4"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>
					<label for="lblareaatuacao4">Area de Atuao</label>
						<select name="txtautacao4" id="txtautacao4" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep5">INEP<img src= "public/img/check.gif"/></label>
				<input type="text" name="txtinep5" value="" style="width:90px" maxlength="8" id="txtinep5" disabled="disabled" onKeyPress="return Enum(event)" />

          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola5" id="txtdescescola5" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>

              <p>
						<label for="txtdtlotacao5">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlota15" value="" style="width:70px" id="txtdtlota15" disabled="disabled" OnKeyUp="mascaralota1(mascaralota1.value)"/>

						<label for="selectcontrato5">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch5lota" name="selectch5lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula5">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas5" value="0" style="width:30px" id="txtqdtaaulas5"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atuao</label>
						<select name="txtautacao5" id="txtautacao5" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>



					 <div id="tema"> 
					       <p><b><center>Contrato - 2</center></b></p>
					  </div>


					<p>
						<label for="selectcontrato">Regime Jurdico(1)<img src= "public/img/check.gif"/></label>
 			                <select id="selectcontrato2" name="selectcontrato2" style="width:190px" disabled="disabled" >
              		          <option value="1">ESTATUTARIO</option>
            		          <option value="2">CELETISTA</option>
							  <option value="3">REINTEGRADO</option>
							  <option value="4">CDS</option>							  
							  <option value="5">CDSI</option>							  							  
							  <option value="6">CEDIDO</option>							  							  
							  <option value="7">TERMO COOP TECNICA</option>	
							  <option value="8">ESTATUTARIO CDS</option>								  																					 							 <option value="9">FEDERAL A DISPOSIO DO ESTADO</option>								  													    		               </select>
					</p>

     <p>
			  	<label for="selectncontrato">Cargo Comissionado<img src= "public/img/check.gif"/></label>
 				     <select name="txtcargo_comisionado2" id="txtcargo_comisionado2"  disabled="disabled">
						<option value="">Selecione o CDS</option>
					     <?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM cds
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          </p>


				    <p>
						<label for="selectadm1">Cedido/Termo Coop Tcnica <img src= "public/img/check.gif"/></label>
 			                <select id="selectcadm2" name="selectcadm2" style="width:300px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
            		          <option value="1">AUTARQUIA</option>
            		          <option value="2">ESTADUAL</option>            		          
            		          <option value="3">FEDERAL</option>
							  <option value="4">FUNDACAO PBLICA</option>							  
              		          <option value="5">MUNICIPAL</option>
    		    	          <option value="6">INSTITUIES CONVENIADAS</option>
				           </select>
					</p>


			    <p>
					<label for="lblcargo1">Cargo - Nomeao<img src= "public/img/check.gif"/></label>
						<select name="txtcod_cargo1" id="txtcod_cargo1"  disabled="disabled">
						<option value=""></option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>
          		<label for="lblfuncao1">Funcao<img src= "public/img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao1" id="cod_funcao1" disabled="disabled" >
			           <option value="">-- Escolha cargo --</option>
            	 </select>

	</p>		

						
						
						<p>
						<label for="lblMatricula2">Matrcula<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtMatricula2" value="" style="width:90px" maxlength="9" id="txtMatricula2" disabled="disabled"/>

						<label for="lblDataAdmissao2">Data Admisso<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtadmissao2" value="" style="width:70px" id="txtdtadmissao2" disabled="disabled" OnKeyUp="mascaradtadmissao2(txtdtadmissao2.value)"/>		
						
						
						
						<label for="lblselectch2">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectch2" name="selectch2" style="width:40px" disabled="disabled" />
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>
					</p>


					<p>
						<label for="lbldecreto2">N Decreto</label>
						<input type="text" name="txtdecreto2" style="width:70px" value="" maxlength="11" id="txtdecreto2" disabled="disabled" />

						<label for="txtdtdecreto2">Data</label>
						<input type="text" name="txtdtdecreto2" value="" style="width:70px" id="txtdtdecreto2"  disabled="disabled" OnKeyUp="mascaradtdecreto2(txtdtdecreto2.value)"/>		




						<label for="lbldiario2">Publicado Dirio</label>
						<input type="text" name="txtdiario2" style="width:70px" value="" maxlength="11" id="txtdiario2" disabled="disabled"/>

						<label for="lbldtdiario2">Data</label>
						<input type="text" name="txtdtdiario2" value="" style="width:70px" id="txtdtdiario2" disabled="disabled" OnKeyUp="mascaradtdiario2(txtdtdiario2.value)"/>		
					</p>

                     <p>
	  					<label for="lblqtda">Lotado<img src= "public/img/check.gif"/></label>
 			                <select id="selectlotacao2" name="selectlotacao2" style="width:200px" disabled="disabled">
						    <option value="">...Selecione Lotação...</option>
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
    		               </select>
    	       		     </p>


			      <p>
					<label for="lblgerencia">Gerncia<img src= "public/img/check.gif"/></label>
						<select name="txtgerencia1" id="txtgerencia1"  style="width:400px" disabled="disabled">
						<option value=""></option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto1">Departamento<img src= "public/img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="txtdpto1" id="txtdpto1" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
			
	</p>		


           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "public/img/check.gif"/></label>
 			    <select id="selectqtdaescola2" name="selectqtdaescola2" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>

					<p>
						<label for="lblinep2">INEP<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtinep21" value="" style="width:90px" maxlength="9" id="txtinep21" disabled="disabled"/>

          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola21" id="txtdescescola21" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
					</p>


					<p>
						<label for="lbldtlotacao">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr21" value="" style="width:80px" id="txtdtlotacontr21"  disabled="disabled"OnKeyUp="mascaradtlotacao21(txtdtlotacontr21.value)"/>

						<label for="selectcontrato">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectchcontrato21" name="selectchcontrato21" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas21" value="0" style="width:30px" id="txtqdtaaulas21"  disabled="disabled"/>
                     </p>
                     <p>
					<label for="lblareaatuacao2">Area de Atuao</label>
						<select name="txtautacao21" id="txtautacao21" disabled="disabled" style="width:"300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>




					</p>



					<p>
						<label for="lblinep21">INEP<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtinep22" value="" style="width:90px" maxlength="9" id="txtinep22" disabled="disabled" />


          		   <label for="lbldesescola21">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola22" id="txtdescescola22" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>

					</p>




					<p>
						<label for="lbldtlotacao21">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr22" value="" style="width:80px" id="txtdtlotacontr22" disabled="disabled" OnKeyUp="mascaradtlotacao22(txtdtlotacontr22.value)"/>




						<label for="selectcontrato21">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectchcontrato22" name="selectchcontrato22" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula21">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas22" value="0" style="width:30px" id="txtqdtaaulas22"  disabled="disabled"/>
                    </p> 
                    <p>
					<label for="lblareaatuacao21">Area de Atuao</label>
						<select name="txtautacao22" id="txtautacao22" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>





					<p>
						<label for="lblinep2">INEP<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtinep23" value="" style="width:90px" maxlength="9" id="txtinep23" disabled="disabled"/>

          		   <label for="lbldesescola2">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola23" id="txtdescescola23" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr23" value="" style="width:80px" id="txtdtlotacontr23" disabled="disabled" OnKeyUp="mascaradtlotacao23(txtdtlotacontr23.value)"/>

						<label for="selectcontrato">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectchcontrato23" name="selectchcontrato23" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas23" value="0" style="width:30px" id="txtqdtaaulas23"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao2">Area de Atuao</label>
						<select name="txtautacao23" id="txtautacao23" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>

					<p>
						<label for="lblinep2">INEP<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

          		   <label for="lbldesescola2">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola24" id="txtdescescola24" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>


					</p>




					<p>
						<label for="lbldtlotacao">Data Lotao<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:80px" id="txtdtlotacontr24" disabled="disabled"OnKeyUp="mascaradtlotacao24(txtdtlotacontr24.value)"/>

						<label for="selectcontrato23">CH<img src= "public/img/check.gif"/></label>
 			                <select id="selectchcontrato24" name="selectchcontrato24" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24" disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao23">Area de Atuao</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					<p>
					<label for="lblinep24">INEP<img src= "public/img/check.gif"/></label>
					<input type="text" name="txtinep25" value="" style="width:90px" maxlength="9" id="txtinep25" disabled="disabled"/>

          		   <label for="lbldesescola2">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola25" id="txtdescescola25" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
					</p>


					<p>
					<label for="lbldtlotacao24">Data Lotao<img src= "public/img/check.gif"/></label>
					<input type="text" name="txtdtlotacontr25" value="" style="width:80px" id="txtdtlotacontr25" disabled="disabled" OnKeyUp="mascaradtlotacao25(txtdtlotacontr25.value)"/>

					<label for="selectcontrato24">CH<img src= "public/img/check.gif"/></label>
	                <select id="selectchcontrato25" name="selectchcontrato25" style="width:40px" disabled="disabled">
           		          <option value="0">0</option>
						  <option value="40">40</option>
           		          <option value="25">25</option>
           		          <option value="20">20</option>
  		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "public/img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas25" value="0" style="width:30px" id="txtqdtaaulas25"  disabled="disabled"/>
                    </p>
                    <p>  
					<label for="lblareaatuacao24">Area de Atuao</label>
						<select name="txtautacao25" id="txtautacao25" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuao</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>




					</p>


					 <div id="linha"> 
					       <p><center></center></p>
					  </div>


					  <p>
						  <label for="txtBanco">Banco:<img src= "public/img/check.gif"/></label>
						  <input type="text" name="txtBanco" value= "<? echo $banco; ?>" style="width:50px" id="txtBanco" maxlength="3" onKeyPress="return Enum(event)"/>
						  <label for="txtAgencia" >Agncia:<img src= "public/img/check.gif"/></label>
						  <input type="text" name="txtAgencia" value= "<? echo $agencia; ?>" style="width:60px" id="txtAgencia" maxlength="10" />
						  <label for="txtConta">Conta:<img src= "public/img/check.gif"/></label>
						  <input type="text" name="txtConta" value= "<? echo $cc; ?>" style="width:100px" id="txtConta" maxlength="20"/>
					  </p>

    		<p id="finish">
                  <input type="submit" value="Alterar Dados" />
                  <input type="reset" value="limpar" />
	    	</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<P>Caros servidores,  de sua total responsabilidade as informaes preenchidas neste formulrio eletrnico,<BR> cabendo-lhes as penalidades legais caso haja envio de informaes de comprovada m f, conforme Decreto-lei<BR> no 2.848, de 7 de dezembro de 1940, art. 299.</P>
			<p>Todos direitos reservados/SEDUC-RO Copyright (C) pesv</p>
			<p>Contato:0800-647-5333</p>

   </p>


		</div>
	</div>
</body>


<?
 
/* } 
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Candidato nao localizado .!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"concurso/index.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";

}

mysql_close($conexao);
}*/
?>


