
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />


	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />

	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />




</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>



			<div id="content">

				<form name = "recadastramento" class="form" action="insere_servidor.php" method="post">
				 <div id="tema">
					   <p><center>Dados Pessoais</center></p>
				  </div>

					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="" maxlength="11" id="cpf"  onKeyPress="return Enum(event)"/>

  				        <label for="txtPisPasep">PIS/PASEP:</label>
					    <input type="text" name="pis" value="" id="pis" style="width:110px" value="" maxlength="25" onKeyPress="return Enum(event)"/>

					</p>



					<p>
						<label for="txtRG">RG<img src= "img/check.gif"/></label>
						<input type="text" name="txtRG" style="width:110px" value="" id="txtRG" maxlength="20" />
						<label for="txtOrgaoExp" >Orgão Exp<img src= "img/check.gif"/></label>
						<input type="text" name="txtOrgaoExp" value="" style="width:70px" id="txtOrgaoExp"  maxlength="10"/>
						<label for="txtDataEmissao">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtDataEmissao" value="" style="width:70px" id="txtDataEmissao" maxlength="12" OnKeyUp="mascaradtrg(txtDataEmissao.value)"/>
					</p>





					<p>
						<label for="lblte">Título Eleitor<img src= "img/check.gif"/></label>
						<input type="text" name="txtte" style="width:100px" value="" id="txtte" maxlength="20" onKeyPress="return Enum(event)"/>
						<label for="lblzona" >Zona<img src= "img/check.gif"/></label>
						<input type="text" name="txtzona" value="" style="width:50px" id="txtzona" maxlength="10" onKeyPress="return Enum(event)"/>
						<label for="lblsecao">Seção<img src= "img/check.gif"/></label>
						<input type="text" name="txtsecao" value="" style="width:50px" id="txtsecao" maxlength="5" onKeyPress="return Enum(event)"/>
						<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txttdtte" value="" style="width:65px" id="txttdtte" maxlength="12" OnKeyUp="mascaradtte(txttdtte.value)"/>

					</p>

					<p>
						<label for="txtNome">Nome<img src= "img/check.gif"/></label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value="" id="txtNome" />
					</p>

					<p>
						<label for="lblselectecivil">Estado Civil<img src= "img/check.gif"/></label>
 			               <select id="selectcivil" name="selectcivil" style="width:150px">
              		          <option value="CASADO">CASADO</option>
            		          <option value="SOLTEIRO">SOLTEIRO</option>
              		          <option value="VIUVO">VIUVO</option>
            		          <option value="DESQUITADO">DESQUITADO</option>
              		          <option value="DIVORCIADO">DIVORCIADO</option>
            		          <option value="UNIAOESTAVEL">UNIÃO ESTAVEL</option>
    		               </select>
						<label for="lbldtnascimento">Data Nascimento<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="" style="width:70px" id="txtdtnascimento" OnKeyUp="mascaradtnasc(txtdtnascimento.value)"/>


						<label for="selectsexo">Sexo<img src= "img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo" style="width:140px">
              		          <option value="M">Masculino</option>
            		          <option value="F">Feminino</option>
    		               </select>


					</p>


					<p>
						<label for="lblconjuge">Cônjuge</label>
						<input type="text" name="txtconjuge" style="width:565px" maxlength="60" value="" id="txtconjuge" />
					</p>

					<p>
						<label for="lblmae">Nome Mãe<img src= "img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="" id="txtmae" />
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="" id="txtpai" />
					</p>


					<p>
						<label for="lblEndereco">Endereço<img src= "img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value=""  maxlength="60" size="60" id="txtEndereco" />
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value=""  maxlength="40" size="60" id="txtcomplemento" />
					</p>


					<p>
						<label for="lblBairro">Bairro<img src= "img/check.gif"/></label>
						<input type="text" name="txtBairro" value="" id="txtBairro"  maxlength="40"/>
						<label for="lblBairro">N.<img src= "img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="" id="txtnr" maxlength="5"/>
			            <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" onKeyPress="return Enum(event)"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value="" id="txtFoneSetor"  maxlength="20"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value="" id="txtFoneRes" maxlength="20"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value="" id="txtCelular" maxlength="20"/>
						<label for="txtCelular">Contato<img src= "img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:90px" value="" id="txtcontato" maxlength="25"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="" id="txtEmail" maxlength="80"/>
					</p>


					<p>

					<label for="lblcod_estados">Naturalidade - Estado:</label>
						<select name="cod_estado" id="cod_estado">
						<option value=""></option>
					<?php
		     				include ("conexao_mysql.php");

							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}

					?>
					</select>
          		<label for="lblcod_cidades">Cidade:</label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha um estado --</option>
            	 </select>

		</p>
					<p>

					<label for="lblinstrucao">Grau de Instrução</label>
						<select name="txtinstrucao" id="txtinstrucao">
						<option value="">Grau de Instrução</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM grauinstrucao
									ORDER BY codigo";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>

					</p>
					<p>
					<label for="lblinstrucao">Previsão de Aposentadoria</label>
						  <select name="anoaposentadoria"  id="anoaposentadoria"  onChange= "trava(this)">
						    <option value="">...Selecione Ano...</option>
						    <option value="2011">2011</option>
						    <option value="2012">2012</option>
						    <option value="2013">2013</option>
						    <option value="2014">2014</option>
							<option value="2015">2015</option>
						    <option value="2016">2016</option>
						    <option value="2017">2017</option>
						    <option value="2018">2018</option>
						    <option value="2019">2019</option>
						    <option value="2020">2020</option>
							<option value="2021">2021</option>
						    <option value="2022">2022</option>
						    <option value="2023">2023</option>
						    <option value="2024">2024</option>
						    <option value="2025">2025</option>
							<option value="2026">2026</option>
						    <option value="2027">2027</option>
						    <option value="2028">2028</option>
						    <option value="2029">2029</option>
						    <option value="2030">2030</option>
						    <option value="2031">2031</option>
							<option value="2032">2032</option>
						    <option value="2033">2033</option>
						    <option value="2034">2034</option>
						    <option value="2035">2035</option>
						    <option value="2036">2036</option>
							<option value="2037">2037</option>
						    <option value="2038">2038</option>
						    <option value="2039">2039</option>
						    <option value="2040">2040</option>
						    <option value="2041">2041</option>
						    <option value="2042">2042</option>
						    <option value="2043">2043</option>
						    <option value="2044">2044</option>
						    <option value="2045">2045</option>
						    <option value="2046">2046</option>
						    <option value="2046">2047</option>
						    <option value="2048">2048</option>
						    <option value="2049">2049</option>
						    <option value="2050">2050</option>
						  </select>


					</p>

					 <div id="tema">
					       <p><b><center>Descrição das Últimas Formações</center></b></p>
					  </div>

					<p>
						<label for="txt">Curso</label>
						<input type="text" name="formacurso1" style="width:200px" value="" id="formacurso1" maxlength="60"/>
						<label for="txtFoneRes">Instuição</label>
						<input type="text" name="forminstituicao1" style="width:250px" value="" id="forminstituicao1" maxlength="60"/>
				    </p>
					<p>
						<label for="txtCelular">Ano de Conclusão</label>
						<input type="text" name="anoforma1" style="width:50px" value="" id="anoforma1" maxlength="4" onKeyPress="return Enum(event)"/>
						<label for="txtCelular">C.H</label>
						<input type="text" name="chforma1" style="width:50px" value="" id="chforma1" maxlength="4" onKeyPress="return Enum(event)"/>

					</p>


					<p>
						<label for="txt">Curso</label>
						<input type="text" name="formacurso2" style="width:200px" value="" id="formacurso2" maxlength="60"/>
						<label for="txtFoneRes">Instituição</label>
						<input type="text" name="forminstituicao2" style="width:250px" value="" id="forminstituicao2"  maxlength="60"/>
				    </p>
					<p>
						<label for="txtCelular">Ano de Conclusão</label>
						<input type="text" name="anoforma2" style="width:50px" value="" id="anoforma2" maxlength="4" onKeyPress="return Enum(event)"/>
						<label for="txtCelular">C.H</label>
						<input type="text" name="chforma2" style="width:50px" value="" id="chforma2" maxlength="4" onKeyPress="return Enum(event)"/>

					</p>

					<p>
						<label for="txt">Curso</label>
						<input type="text" name="formacurso3" style="width:200px" value="" id="formacurso3" maxlength="60"/>
						<label for="txtFoneRes">Instituição</label>
						<input type="text" name="forminstituicao3" style="width:250px" value="" id="forminstituicao3" maxlength="60"/>
				    </p>
					<p>
						<label for="txtCelular">Ano de Conclusão</label>
						<input type="text" name="anoforma3" style="width:50px" value="" id="anoform3" maxlength="4" onKeyPress="return Enum(event)"/>
						<label for="txtCelular">C.H</label>
						<input type="text" name="chforma3" style="width:50px" value="" id="chforma3" maxlength="4" onKeyPress="return Enum(event)"/>

					</p>

					<p>
						<label for="txt">Curso</label>
						<input type="text" name="formacurso4" style="width:200px" value="" id="formacurso4" maxlength="60"/>
						<label for="txtFoneRes">Instituição</label>
						<input type="text" name="forminstituicao4" style="width:250px" value="" id="forminstituicao4" maxlength="60"/>
				    </p>
					<p>
						<label for="txtCelular">Ano de Conclusão</label>
						<input type="text" name="anoforma4" style="width:50px" value="" id="anoforma4" maxlength="4" onKeyPress="return Enum(event)"/>
						<label for="txtCelular">C.H</label>
						<input type="text" name="chforma4" style="width:50px" value="" id="chforma4" maxlength="4" onKeyPress="return Enum(event)"/>

					</p>


					 <div id="tema">
					       <p><b><center>Quantidade de Contratos</center></b></p>
					  </div>



           <p>
			  	<label for="selectncontrato">Total de Contrato(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdacontrato" name="selectqtdacontrato" style="width:40px" >
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
    		     </select>

           </p>


					 <div id="tema">
					       <p><b><center>Contrato - 1</center></b></p>
					  </div>

					<p>
						<label for="selectcontrato">Regime Jurídico(1)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato1" name="selectcontrato1" style="width:190px" >
              		          <option value="1">ESTATUTARIO</option>
            		          <option value="2">CELETISTA</option>
							  <option value="3">REINTEGRADO</option>
							  <option value="4">CDS</option>
							  <option value="5">CDSI</option>
							  <option value="6">CEDIDO</option>
							  <option value="7">TERMO COOP TECNICA</option>
							  <option value="8">ESTATUTARIO CDS</option>								  																					 							 <option value="9">FEDERAL A DISPOSIÇÃO DO ESTADO</option>								  													    		               </select>
					</p>

<p>
			  	<label for="selectncontrato">Cargo Comissionado<img src= "img/check.gif"/></label>
 				     <select name="txtcargo_comisionado" id="txtcargo_comisionado"  disabled="disabled">
						<option value="">Selecione o CDS</option>
					     <?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM cds
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>

</p>


				    <p>
						<label for="selectadm1">Cedido/Termo Coop Técnica <img src= "img/check.gif"/></label>
 			                <select id="selectcadm1" name="selectcadm1" style="width:300px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
            		          <option value="1">AUTARQUIA</option>
            		          <option value="2">ESTADUAL</option>
            		          <option value="3">FEDERAL</option>
							  <option value="4">FUNDACAO PÚBLICA</option>
              		          <option value="5">MUNICIPAL</option>
    		    	          <option value="6">INSTITUIÇÕES CONVENIADAS</option>
				           </select>
					</p>


			      <p>
					<label for="lblcod_cargo">Cargo - Nomeação<img src= "img/check.gif"/></label>
 				     <select name="txtcod_cargo" id="txtcod_cargo" style="width:210px" >
						<option value=""></option>
					     <?php
            				include ("conexao_mysql.php");
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          		   <label for="lblcodfuncao0">Funcao<img src= "img/check.gif"/></label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="cod_funcao0" id="cod_funcao0" style="width:200px">
			           <option value="">-- Escolha cargo --</option>
            	    </select>
	           </p>

					<p>

					<label for="lblhabilitacao">Habilitação</label>
						<select name="txthabilitacao" id="txthabilitacao" disabled="disabled">
						<option value="">Selecione Habilitação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>

					</p>






    <p>
          <label for="lbllicenca">Servidor de Licença</label>


		  <label for="lbllicenca">Sim
		       <input name="radiolicenca" type="radio"   value ="S" id="radiolicenca" >
		  </label>


	      <label for="lbldeficienten">Não
		       <input name="radiolicenca" type="radio"  value ="N"  id="radiolicenca"  checked="checked">

		  </label>

  </p>
  <p>
			  	<label for="selectncontrato">Qual Licença<img src= "img/check.gif"/></label>
 			    <select id="selectlicenca" name="selectlicenca" style="width:350px" disabled="disabled">
				   <option value="">Selecione a licença</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM licenca
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>



   	 </p>



				<p>
						<label for="lblMatricula">Matrícula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula1" value="" style="width:90px" maxlength="10" id="txtMatricula1" onKeyPress="return Enum(event)"/>

						<label for="txtDataAdmissao">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao1" value="" style="width:70px" id="txtdtadmissao1"
OnKeyUp="mascaraadmissao1(txtdtadmissao1.value)"/>

						<label for="selectch1">CH - Contrato<img src= "img/check.gif"/></label>
 			                <select id="selectch1" name="selectch1" style="width:40px">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>

					<p>
						<label for="lbldecreto">N Decreto</label>
						<input type="text" name="txtdecreto1" style="width:70px" value="" maxlength="11" id="txtdecreto1"/>

						<label for="lblDataAdmissao">Data</label>
						<input type="text" name="txtdtdecreto1" value="" style="width:70px" id="txtdtdecreto1" OnKeyUp="mascaradecreto1(txtdtdecreto1.value)"/>

						<label for="txtCPF">Publicado Diário</label>
						<input type="text" name="txtdiario1" style="width:70px" value="" maxlength="10" id="txtdiario1" />

						<label for="txtDataAdmissao">Data</label>
						<input type="text" name="txtdtdiario1" value="" style="width:70px" id="txtdtdiario1" OnKeyUp="mascaradiario1(txtdtdiario1.value)"/>

					</p>
					   <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao1" name="selectlotacao1" style="width:200px" />
						    <option value="">...Selecione Lotação...</option>
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
            		          <option value="3">ADMINISTRAÇÃO E ESCOLA</option>
    		               </select>
    	       		     </p>

			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif" /></label>
						<select name="txtgerencia" id="txtgerencia"  style="width:400px" disabled="disabled" >
						<option value="">...Selecione Administração..</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>


			<p>
          		<label for="lbldpto">Departamento<img src= "img/check.gif"/></label>
	         	<!--	<span class="carregando">Aguarde, carregando...</span>-->
		          <select name="txtdpto" id="txtdpto" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>


	</p>

           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep1" value="" style="width:90px" maxlength="8" id="txtinep1" disabled="disabled"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola1" id="txtdescescola1" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>


              <p>
						<label for="txtdtlotacao1">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota11" value="" style="width:70px" id="txtdtlota11"  disabled="disabled" OnKeyUp="mascaralota1(txtdtlota11.value)"/>



						<label for="selectcontrato1">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch1lota" name="selectch1lota" style="width:40px"  disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula1">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas1" value="0" style="width:30px" id="txtqdtaaulas1" maxlength="2" disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atuação</label>
						<select name="txtautacao1" id="txtautacao1" disabled="disabled" style="width:300px" >
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					</p>


           <p>
				<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep2" value="" style="width:90px" maxlength="8" id="txtinep2"  disabled="disabled" onKeyPress="return Enum(event)"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola2" id="txtdescescola2" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>



			</p>

              <p>
						<label for="txtdtlotacao2">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota12" value="" style="width:70px" id="txtdtlota12" disabled="disabled" OnKeyUp="mascaralota2(txtdtlota12.value)"/>

						<label for="selectcontrato2">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch2lota" name="selectch2lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas2" value="0" style="width:30px" id="txtqdtaaulas2"  disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao2" id="txtautacao2" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					</p>


           <p>
				<label for="lblinep3">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep3" value="" style="width:90px" maxlength="8" id="txtinep3"  disabled="disabled" onKeyPress="return Enum(event)"/>

          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola3" id="txtdescescola3" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>

              <p>
						<label for="txtdtlotacao3">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota13" value="" style="width:70px" id="txtdtlota13" disabled="disabled"/>

						<label for="selectcontrato3">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch3lota" name="selectch3lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula3">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas3" value="0" style="width:30px" id="txtqdtaaulas3"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>
					<label for="lblareaatuacao3">Area de Atuação</label>
						<select name="txtautacao3" id="txtautacao3" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					</p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep4" value="" style="width:90px" maxlength="8" id="txtinep4" disabled="disabled" onKeyPress="return Enum(event)"/>
          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola4" id="txtdescescola4" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
    		</p>

              <p>
						<label for="txtdtlotacao4">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota14" value="" style="width:70px" id="txtdtlota14" disabled="disabled"/>

						<label for="selectcontrato4">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch4lota" name="selectch4lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula4">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas4" value="0" style="width:30px" id="txtqdtaaulas4"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>
					<label for="lblareaatuacao4">Area de Atuação</label>
						<select name="txtautacao4" id="txtautacao4" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					</p>


           <p>
				<label for="lblinep5">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep5" value="" style="width:90px" maxlength="8" id="txtinep5" disabled="disabled" onKeyPress="return Enum(event)" />

          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola5" id="txtdescescola5" style="width:350px" >
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>

              <p>
						<label for="txtdtlotacao5">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota15" value="" style="width:70px" id="txtdtlota15" disabled="disabled" OnKeyUp="mascaralota1(mascaralota1.value)"/>

						<label for="selectcontrato5">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch5lota" name="selectch5lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula5">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas5" value="0" style="width:30px" id="txtqdtaaulas5"  disabled="disabled" onKeyPress="return Enum(event)"/>

                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atuação</label>
						<select name="txtautacao5" id="txtautacao5" disabled="disabled" style="width:300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					</p>



					 <div id="tema">
					       <p><b><center>Contrato - 2</center></b></p>
					  </div>


					<p>
						<label for="selectcontrato">Regime Jurídico(1)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato2" name="selectcontrato2" style="width:190px" disabled="disabled" >
              		          <option value="1">ESTATUTARIO</option>
            		          <option value="2">CELETISTA</option>
							  <option value="3">REINTEGRADO</option>
							  <option value="4">CDS</option>
							  <option value="5">CDSI</option>
							  <option value="6">CEDIDO</option>
							  <option value="7">TERMO COOP TECNICA</option>
							  <option value="8">ESTATUTARIO CDS</option>								  																					 							 <option value="9">FEDERAL A DISPOSIÇÃO DO ESTADO</option>								  													    		               </select>
					</p>

     <p>
			  	<label for="selectncontrato">Cargo Comissionado<img src= "img/check.gif"/></label>
 				     <select name="txtcargo_comisionado2" id="txtcargo_comisionado2"  disabled="disabled">
						<option value="">Selecione o CDS</option>
					     <?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM cds
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          </p>


				    <p>
						<label for="selectadm1">Cedido/Termo Coop Técnica <img src= "img/check.gif"/></label>
 			                <select id="selectcadm2" name="selectcadm2" style="width:300px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
            		          <option value="1">AUTARQUIA</option>
            		          <option value="2">ESTADUAL</option>
            		          <option value="3">FEDERAL</option>
							  <option value="4">FUNDACAO PÚBLICA</option>
              		          <option value="5">MUNICIPAL</option>
    		    	          <option value="6">INSTITUIÇÕES CONVENIADAS</option>
				           </select>
					</p>


			    <p>
					<label for="lblcargo1">Cargo - Nomeação<img src= "img/check.gif"/></label>
						<select name="txtcod_cargo1" id="txtcod_cargo1"  disabled="disabled">
						<option value=""></option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>
          		<label for="lblfuncao1">Funcao<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao1" id="cod_funcao1" disabled="disabled" >
			           <option value="">-- Escolha cargo --</option>
            	 </select>

	</p>



						<p>
						<label for="lblMatricula2">Matrícula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula2" value="" style="width:90px" maxlength="9" id="txtMatricula2" disabled="disabled"/>

						<label for="lblDataAdmissao2">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao2" value="" style="width:70px" id="txtdtadmissao2" disabled="disabled" OnKeyUp="mascaradtadmissao2(txtdtadmissao2.value)"/>



						<label for="lblselectch2">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch2" name="selectch2" style="width:40px" disabled="disabled" />
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>
					</p>


					<p>
						<label for="lbldecreto2">N Decreto</label>
						<input type="text" name="txtdecreto2" style="width:70px" value="" maxlength="11" id="txtdecreto2" disabled="disabled" />

						<label for="txtdtdecreto2">Data</label>
						<input type="text" name="txtdtdecreto2" value="" style="width:70px" id="txtdtdecreto2"  disabled="disabled" OnKeyUp="mascaradtdecreto2(txtdtdecreto2.value)"/>




						<label for="lbldiario2">Publicado Diário</label>
						<input type="text" name="txtdiario2" style="width:70px" value="" maxlength="11" id="txtdiario2" disabled="disabled"/>

						<label for="lbldtdiario2">Data</label>
						<input type="text" name="txtdtdiario2" value="" style="width:70px" id="txtdtdiario2" disabled="disabled" OnKeyUp="mascaradtdiario2(txtdtdiario2.value)"/>
					</p>

                     <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao2" name="selectlotacao2" style="width:200px" disabled="disabled">
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
            		          <option value="3">ADMINISTRAÇÃO-ESCOLA</option>
    		               </select>
    	       		     </p>


			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif"/></label>
						<select name="txtgerencia1" id="txtgerencia1"  style="width:400px" disabled="disabled">
						<option value=""></option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>


			<p>
          		<label for="lbldpto1">Departamento<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="txtdpto1" id="txtdpto1" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>

	</p>


           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola2" name="selectqtdaescola2" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>

					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep21" value="" style="width:90px" maxlength="9" id="txtinep21" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola21" value="" style="width:350px" id="txtdescescola21" disabled="disabled" />

					</p>


					<p>
						<label for="lbldtlotacao">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr21" value="" style="width:80px" id="txtdtlotacontr21"  disabled="disabled"OnKeyUp="mascaradtlotacao21(txtdtlotacontr21.value)"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectchcontrato21" name="selectchcontrato21" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas21" value="0" style="width:30px" id="txtqdtaaulas21"  disabled="disabled"/>
                     </p>
                     <p>
					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao21" id="txtautacao21" disabled="disabled" style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>




					</p>



					<p>
						<label for="lblinep21">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep22" value="" style="width:90px" maxlength="9" id="txtinep22" disabled="disabled" />

						<label for="lbldesescola21">Escola</label>
						<input type="text" name="txtdescescola22" value="" style="width:350px" id="txtdescescola22"  disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao21">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr22" value="" style="width:80px" id="txtdtlotacontr22" disabled="disabled" OnKeyUp="mascaradtlotacao22(txtdtlotacontr22.value)"/>




						<label for="selectcontrato21">CH<img src= "img/check.gif"/></label>
 			                <select id="selectchcontrato22" name="selectchcontrato22" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula21">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas22" value="0" style="width:30px" id="txtqdtaaulas22"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao21">Area de Atuação</label>
						<select name="txtautacao22" id="txtautacao22" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>





					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep23" value="" style="width:90px" maxlength="9" id="txtinep23" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola23" value="" style="width:350px" id="txtdescescola23"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr23" value="" style="width:80px" id="txtdtlotacontr23" disabled="disabled" OnKeyUp="mascaradtlotacao23(txtdtlotacontr23.value)"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectchcontrato23" name="selectchcontrato23" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas23" value="0" style="width:30px" id="txtqdtaaulas23"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao23" id="txtautacao23" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>

					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:350px" id="txtdescescola24"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:80px" id="txtdtlotacontr24" disabled="disabled"OnKeyUp="mascaradtlotacao24(txtdtlotacontr24.value)"/>

						<label for="selectcontrato23">CH<img src= "img/check.gif"/></label>
 			                <select id="selectchcontrato24" name="selectchcontrato24" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24" disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao23">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>

					<p>
					<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
					<input type="text" name="txtinep25" value="" style="width:90px" maxlength="9" id="txtinep25" disabled="disabled"/>

					<label for="lbldesescola24">Escola</label>
					<input type="text" name="txtdescescola25" value="" style="width:350px" id="txtdescescola25" disabled="disabled" />

					</p>


					<p>
					<label for="lbldtlotacao24">Data Lotação<img src= "img/check.gif"/></label>
					<input type="text" name="txtdtlotacontr25" value="" style="width:80px" id="txtdtlotacontr25" disabled="disabled" OnKeyUp="mascaradtlotacao25(txtdtlotacontr25.value)"/>

					<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
	                <select id="selectchcontrato25" name="selectchcontrato25" style="width:40px" disabled="disabled">
           		          <option value="0">0</option>
						  <option value="40">40</option>
           		          <option value="25">25</option>
           		          <option value="20">20</option>
  		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas25" value="0" style="width:30px" id="txtqdtaaulas25"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao25" id="txtautacao25" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>




					</p>

					 <div id="tema">
					       <p><b><center>Contrato - 3</center></b></p>
					  </div>



					<p>
						<label for="selectcontrato">Regime Jurídico(1)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato3" name="selectcontrato3" style="width:190px" disabled="disabled">
              		          <option value="1">ESTATUTARIO</option>
            		          <option value="2">CELETISTA</option>
							  <option value="3">REINTEGRADO</option>
							  <option value="4">CDS</option>
							  <option value="5">CDSI</option>
							  <option value="6">CEDIDO</option>
							  <option value="7">TERMO COOP TECNICA</option>
							  <option value="8">ESTATUTARIO CDS</option>								  																					 							 <option value="9">FEDERAL A DISPOSIÇÃO DO ESTADO</option>								  													    		               </select>
					</p>

     <p>
			  	<label for="selectncontrato">Cargo Comissionado<img src= "img/check.gif"/></label>
 				     <select name="txtcargo_comisionado3" id="txtcargo_comisionado3"  disabled="disabled">
						<option value="">Selecione o CDS</option>
					     <?php
							include ("conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM cds
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          </p>


				    <p>
						<label for="selectadm1">Cedido/Termo Coop Técnica <img src= "img/check.gif"/></label>
 			                <select id="selectcadm3" name="selectcadm3" style="width:300px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
            		          <option value="1">AUTARQUIA</option>
            		          <option value="2">ESTADUAL</option>
            		          <option value="3">FEDERAL</option>
							  <option value="4">FUNDACAO PÚBLICA</option>
              		          <option value="5">MUNICIPAL</option>
    		    	          <option value="6">INSTITUIÇÕES CONVENIADAS</option>
				           </select>
					</p>



			<p>
					<label for="cod_estados3">Cargo - Nomeação<img src= "img/check.gif"/></label>
						<select name="cod_cargo2" id="cod_cargo2" disabled="disabled">
						<option value=""></option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>
          		<label for="cod_cidades3">Funcao<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao2" id="cod_funcao2" disabled="disabled">
			           <option value="">-- Escolha cargo --</option>
            	 </select>

	</p>


					<p>
						<label for="lblmatricula3">Matrícula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula3" value="" style="width:90px" maxlength="9" id="txtMatricula3" disabled="disabled"/>

						<label for="lbldtadmisao3">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao3" value="" style="width:70px" id="txtdtadmissao3" disabled="disabled"/>

						<label for="lblch3">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch3" name="selectch3" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>


					<p>

						<label for="lbldecreto3">N Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtdecreto3" style="width:70px" value="" maxlength="11" id="txtdecreto3" disabled="disabled"/>

						<label for="lbldtdecreto3">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdecreto3" value="" style="width:70px" id="txtdtdecreto3" disabled="disabled"/>


						<label for="lbldiario3">Publicado Diário<img src= "img/check.gif"/></label>
						<input type="text" name="txtdiario3" style="width:70px" value="" maxlength="11" id="txtdiario3" disabled="disabled"/>

						<label for="lbldtdiario3">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdiario3" value="" style="width:70px" id="txtdtdiario3" disabled="disabled"/>
					</p>

                     <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao3" name="selectlotaca3" style="width:200px" disabled="disabled">
              		          <option value="ADM">ADMINISTRACAO</option>
            		          <option value="ESCOLA">ESCOLA</option>
            		          <option value="ADM-ESCOLA">ADMINISTRAÇÃO-ESCOLA</option>
    		               </select>
    	       		     </p>



			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif"/></label>
						<select name="txtgerencia2" id="txtgerencia2"  style="width:400px" disabled="disabled">
						<option value=""></option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>


			<p>
          		<label for="lbldpto1">Departamento<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="txtdpto2" id="txtdpto2" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>

	</p>


           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>


					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep22" value="" style="width:90px" maxlength="9" id="txtinep22" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola22" value="" style="width:350px" id="txtdescescola22"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr32" value="" style="width:70px" id="txtdtlotacontr32" disabled="disabled"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato22" name="selectcontrato22" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas22" value="0" style="width:30px" id="txtqdtaaulas22"  disabled="disabled"/>

                     </p>
					<p>
					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao22" id="txtautacao22" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>

					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep23" value="" style="width:90px" maxlength="9" id="txtinep23" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola23" value="" style="width:350px" id="txtdescescola23"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr33" value="" style="width:70px" id="txtdtlotacontr33" disabled="disabled"/>

						<label for="selectcontrato23">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato23" name="selectcontrato23" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas23" value="0" style="width:30px" id="txtqdtaaulas23"  disabled="disabled" disabled="disabled"/>
                     </p>
                     <p>
					<label for="lblareaatuacao23">Area de Atuação</label>
						<select name="txtautacao23" id="txtautacao23" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
            				include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>



					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:350px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr34" value="" style="width:70px" id="txtdtlotacontr34" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>
                   </p>
                   <p>
					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>




					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:350px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr34" value="" style="width:70px" id="txtdtlotacontr34" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>




					</p>


					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:350px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotação<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr34" value="" style="width:70px" id="txtdtlotacontr34" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>
                    </p>
                    <p>
					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled"  style="width:"300px">
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>

					</p>

					 <div id="linha">
					       <p><center></center></p>
					  </div>


					  <p>
						  <label for="txtBanco">Banco:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtBanco" value="" style="width:50px" id="txtBanco" maxlength="3" />
						  <label for="txtAgencia" >Agência:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtAgencia" value="" style="width:60px" id="txtAgencia" maxlength="10" />
						  <label for="txtConta">Conta:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtConta" value="" style="width:100px" id="txtConta" maxlength="20"/>
					  </p>


					 <div id="tema">
					       <p><b><center>Gratificações Recebidas</center></b></p>
					  </div>



        <p>
          <label for="lbldeficientes">Gratificação</label>
		  <label for="lbldeficientes">Especialização
		       <input name="gratificacao1" type="radio"   value ="1" id="gratificacao1">
		  </label>
          <label for="lbldeficienten">Mestrado
		       <input name="gratificacao1" type="radio"  value ="2"  id="gratificacao1"  >
		  </label>
          <label for="lbldeficienten">Doutorado
		      <input name="gratificacao1" type="radio"  value ="3"  id="gratificacao1"  >
		  </label>
       </p>

		<p>
          <label for="lbldeficienten">pelo exercicio de direção escolar
		      <input name="gratificacao4" type="checkbox"  value ="4"  id="gratificacao4" >
		  </label>
		</p>

		<p>

		  <label for="lbldeficienten">vice-direção escolar
		      <input name="gratificacao5" type="checkbox"  value ="5"  id="gratificacao5"  >
		  </label>

		</p>

       <p>
		  <label for="lbldeficienten">pelo exercício da função de representante de ensino
		      <input name="gratificacao6" type="checkbox"  value ="6"  id="gratificacao6"  >
		  </label>
        </p>

<p>
          <label for="lbldeficienten">chefia de secão pedagogica
		      <input name="gratificacao7" type="checkbox"  value ="7"  id="gratificacao7"  >
		  </label>

</p>
<p>
		  <label for="lbldeficienten">chefia de seção administrativa
		      <input name="gratificacao8" type="checkbox"  value ="8"  id="gratificacao8"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">coord de escolar indígena nas representacões de ensino
		      <input name="gratificacao9" type="checkbox"  value ="9"  id="gratificacao9"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">pelo exercício em escola de difícil provimento (dificil acesso)
		      <input name="gratificacao10" type="checkbox"  value ="10"  id="gratificacao10"  >
		  </label>
</p>


<p>
		  <label for="lbldeficienten">pelo efetivo exercício da docência (ensino especial)
		      <input name="gratificacao11" type="checkbox"  value ="11"  id="gratificacao11"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">1º ano do Ensino Fundamental regular
		      <input name="gratificacao12" type="checkbox"  value ="12"  id="gratificacao12"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Classes de Aceleração da Aprendizagem – CAA
		      <input name="gratificacao13" type="checkbox"  value ="13"  id="gratificacao13"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">Ciclo Básico de Aprendizagem – CBA
		      <input name="gratificacao14" type="checkbox"  value ="14"  id="gratificacao14"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">risco de vida 100%
		      <input name="gratificacao15" type="checkbox"  value ="15"  id="gratificacao15"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Gratificação de Efetivo Trabalho Docente em Sala de Aula 20/25 horas
		      <input name="gratificacao16" type="checkbox"  value ="16"  id="gratificacao16"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Gratificação de Efetivo Trabalho Docente em Sala de Aula 40 horas
		      <input name="gratificacao17" type="checkbox"  value ="17"  id="gratificacao17"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">Gratificação de Efetivo Trablho Supervisor/Orientador 20 horas
		      <input name="gratificacao18" type="checkbox"  value ="18"  id="gratificacao18"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">Gratificação de Efetivo Trablho Supervisor/Orientador 40 horas
		      <input name="gratificacao19" type="checkbox"  value ="19"  id="gratificacao19"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Professor de Apoio em Unidade Escolar
		      <input name="gratificacao20" type="checkbox"  value ="20"  id="gratificacao20"  >
		  </label>
</p>

					 <div id="linhagratifica">
					       <p><center></center></p>
					  </div>
<p>
		  <label for="lbldeficienten">Secretaria na unidade escolar
		      <input name="gratificacao21" type="checkbox"  value ="21"  id="gratificacao21"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Chefia de seção administrativa
		      <input name="gratificacao22" type="checkbox"  value ="22"  id="gratificacao22"  >
		  </label>
</p>
<p>
		  <label for="lbldeficienten">Conclusão do ensino médio
		      <input name="gratificacao23" type="checkbox"  value ="23"  id="gratificacao23"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Conclusão do ensino superior
		      <input name="gratificacao24" type="checkbox"  value ="24"  id="gratificacao24"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">De Incentivo à Educação
		      <input name="gratificacao25" type="checkbox"  value ="25"  id="gratificacao25"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">De Atividade Específica
		      <input name="gratificacao26" type="checkbox"  value ="26"  id="gratificacao26"  >
		  </label>
</p>

<p>
		  <label for="lbldeficienten">Técnico de Apoio em Unidade Escolar
		      <input name="gratificacao27" type="checkbox"  value ="27"  id="gratificacao27"  >
		  </label>
</p>







					<p id="finish">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<P>Caros servidores, é de sua total responsabilidade as informações preenchidas neste formulário eletrônico,<BR> cabendo-lhes as penalidades legais caso haja envio de informações de comprovada má fé, conforme Decreto-lei<BR> no 2.848, de 7 de dezembro de 1940, art. 299.</P>
			<p>Todos direitos reservados/SEDUC-RO Copyright (C) pesv</p>
			<p>Contato:0800-647-5333</p>
		<p>

  <div align="center"><span class="style4">Imprimir 2º via do Recadastramento</span> <a href="formsegvia.php"
"target="_blank">
	 <img src="/imagem/bt_imprimir.png" title="Click para imprimir 2º via."></b></em><font size="2" title ="Imprimir 2ºVia"></a></div>
    </p>
	<p>
  <div align="center"><span class="style4">Editar Cadastrado Para Alteração</span> <a href="formsegvia.php"
"target="_blank">
	 <img src="/imagem/bt_modificar.png" title="Click para imprimir 2º via."></b></em><font size="2" title ="Imprimir 2ºVia"></a></div>

   </p>


		</div>
	</div>
</body>

