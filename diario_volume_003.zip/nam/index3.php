<?php
include ("conexao_mysql.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>

</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
      <div id="menu">
        <ul>
          <li>
             <center>
			 </center>
          </li>
       </ul>
      </div>
			<div id="content">

				<form class="form" action="insere_servidor.php" method="post">
				 <div id="tema"> 
					   <p><center>Dados Pessoais</center></p>
				  </div>

					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="" maxlength="11" id="cpf" />

  				    <label for="txtPisPasep">PIS/PASEP:</label>
					    <input type="text" name="pis" value="" id="pis" style="width:110px" value=""/>

					</p>



					<p>

						<label for="txtRG">RG<img src= "img/check.gif"/></label>
						<input type="text" name="txtRG" style="width:110px" value="" id="txtRG" />
						<label for="txtOrgaoExp" >Orgão Exp<img src= "img/check.gif"/></label>
						<input type="text" name="txtOrgaoExp" value="" style="width:70px" id="txtOrgaoExp" />
						<label for="txtDataEmissao">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtDataEmissao" value="" style="width:70px" id="txtDataEmissao" />
					</p>
					




					<p>

						<label for="lblte">Título Eleitor<img src= "img/check.gif"/></label>
						<input type="text" name="txtte" style="width:110px" value="" id="txtte" />
						<label for="lblzona" >Zona<img src= "img/check.gif"/></label>
						<input type="text" name="txtzona" value="" style="width:70px" id="txtzona" />
						<label for="lblsecao">Seção<img src= "img/check.gif"/></label>
						<input type="text" name="txtsecao" value="" style="width:70px" id="txtsecao" />
						<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txttdtte" value="" style="width:70px" id="txttdtte" />

					</p>
					



					<p>
						<label for="txtNome">Nome<img src= "img/check.gif"/></label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value="" id="txtNome" />
					</p>

					<p>
						<label for="selectsexo">Estado Civil<img src= "img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo" style="width:150px">
              		          <option value="CASADO">CASADO</option>
            		          <option value="SOLTEIRO">SOLTEIRO</option>
              		          <option value="VIUVO">VIUVO</option>
            		          <option value="DESQUITADO">DESQUITADO</option>
              		          <option value="DIVORCIADO">DIVORCIADO</option>
            		          <option value="OUTROS">OUTROS</option>
    		               </select>
						<label for="lbldtnascimento">Data Nascimento<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="" style="width:70px" id="txtdtnascimento" />

 	    		        
						<label for="selectsexo">Sexo<img src= "img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo" style="width:140px">
              		          <option value="M">Masculino</option>
            		          <option value="F">Femenino</option>
    		               </select>


					</p>


					<p>
						<label for="lblconjuge">Conjuge</label>
						<input type="text" name="txtconjuge" style="width:565px" maxlength="60" value="" id="txtconjuge" />
					</p>

					<p>
						<label for="lblmae">Nome Mãe<img src= "img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="" id="txtmae" />
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="" id="txtpai" />
					</p>


					<p>


						<label for="lblEndereco">Endereço<img src= "img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:298px" value=""  maxlength="60" size="60" id="txtEndereco" />
					</p>
					<p>
						<label for="lblBairro">Bairro<img src= "img/check.gif"/></label>
						<input type="text" name="txtBairro" value="" id="txtBairro" />
						<label for="lblBairro">Nr<img src= "img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="" id="txtnr" />
			            <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" />
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Trabalho</label>
						<input type="text" name="txtFoneSetor" style="width:110px" value="" id="txtFoneSetor" />
						<label for="txtFoneRes">Telefone Residencial<img src= "img/check.gif"/></label>
						<input type="text" name="txtFoneRes" style="width:110px" value="" id="txtFoneRes" />
						<label for="txtCelular">Telefone Celular<img src= "img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:110px" value="" id="txtCelular" />
					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="" id="txtEmail" />
					</p>


					<p>
	 
					<label for="cod_estados">Naturalidade - Estado:</label>
						<select name="cod_estado" id="cod_estado">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}
	
					?>
					</select>
          		<label for="cod_cidades">Cidade:</label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha um estado --</option>
            	 </select>

		</p>
					<p>
	 
					<label for="lblinstrucao">Grau de Instrução</label>
						<select name="txtinstrucao" id="txtinstrucao">
						<option value="">Selecione Grau de Instrução</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM grauinstrucao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>



					<p>
	 
					<label for="lblhabilitacao">Habilitação</label>
						<select name="txthabilitacao" id="txthabilitacao">
						<option value="">Selecione Habilitação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>

					 <div id="tema"> 
					       <p><center>Contrato(s) SEDUC/RO</center></p>
					  </div>
					
           <p>
			  	<label for="selectncontrato"><b>Número de Contrato</b><img src= "img/check.gif"/></label>
 			    <select id="selectqtdacontrato" name="selectqtdacontrato" style="width:40px" >
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
    		     </select>

           </p>


                     			
			      <p>
					<label for="lblcod_cargo">Cargo - Nomeacao<img src= "img/check.gif"/></label>
 				     <select name="txtcod_cargo" id="txtcod_cargo" >
						<option value=""></option>
					     <?php
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
				       ?>
					  </select>
          		<label for="lblcodfuncao0">Funcao<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao0" id="cod_funcao0">
			           <option value="">-- Escolha cargo --</option>
            	 </select>
	</p>		


					<p>
						<label for="selectcontrato">Regime Jurídico(1)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato1" name="selectcontrato1" style="width:190px">
              		          <option value="ESTATUTARIO">ESTATUTARIO</option>
            		          <option value="CLT">CELETISTA</option>
							  <option value="REINTEGRADO">REINTEGRADO</option>
							  <option value="CDS">CDS</option>							  
							  <option value="CDSI">CDSI</option>							  							  
							  <option value="CEDIDO">CEDIDO</option>							  							  
							  <option value="PERMUTA">TERMO COOP TECNICA</option>							  							    		               </select>

						<label for="selectadm1">Cedido/Permuta Adm <img src= "img/check.gif"/></label>
 			                <select id="selectcadm1" name="selectcadm1" style="width:200px" disabled="disabled">
              		          <option value="">Selecione a Adm</option>
              		          <option value="MUNICIPAL">MUNICIPAL</option>
            		          <option value="FEDERAL">FEDERAL</option>
            		          <option value="AUTARQUIA">AUTARQUIA</option>
            		          <option value="FUNDACAO">FUNDACAO PÚBLICA</option>							  
    		               </select>
					</p>

				<p>		
						<label for="txtMatricula">Matricula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula1" value="" style="width:90px" maxlength="9" id="txtMatricula1" />

						<label for="txtDataAdmissao">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao1" value="" style="width:70px" id="txtdtadmissao1" />

						<label for="selectch1">CH - Contrato<img src= "img/check.gif"/></label>
 			                <select id="selectch1" name="selectch1" style="width:40px">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>

					<p>
						<label for="lbldecreto">N Decreto</label>
						<input type="text" name="txtdecreto1" style="width:70px" value="" maxlength="11" id="txtdecreto1"/>

						<label for="lblDataAdmissao">Data</label>
						<input type="text" name="txtdtdecreto1" value="" style="width:70px" id="txtdtdecreto1" />


						<label for="txtCPF">Publicado Diário</label>
						<input type="text" name="txtdiario1" style="width:70px" value="" maxlength="11" id="txtdiario1" />

						<label for="txtDataAdmissao">Data</label>
						<input type="text" name="txtdtdiario1" value="" style="width:70px" id="txtdtdiario1" />

					</p>
					   <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao1" name="selectlotacao1" style="width:200px">
              		          <option value="ADM">ADMINISTRACAO</option>
            		          <option value="ESCOLA">ESCOLA</option>
            		          <option value="ADM-ESCOLA">ADMINISTRAÇÃO-ESCOLA</option>							  
    		               </select>
    	       		     </p>

			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif" /></label>
						<select name="txtgerencia" id="txtgerencia"  style="width:400px" disabled="disabled" >
						<option value=""></option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto">Departamento<img src= "img/check.gif"/></label>
	         	<!--	<span class="carregando">Aguarde, carregando...</span>-->
		          <select name="txtdpto" id="txtdpto" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
				 
			
	</p>		

           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep1" value="" style="width:90px" maxlength="8" id="txtinep1" disabled="disabled"/>

				<label for="lbldesescola">Escola</label>
						<input type="text" name="txtdescescola1" value="" style="width:450px" id="txtdescescola1"  disabled="disabled"/>
			</p>
              <p>
						<label for="txtdtlotacao1">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota11" value="" style="width:70px" id="txtdtlota11"  disabled="disabled"/>

						<label for="selectcontrato1">CH-Lotacao<img src= "img/check.gif"/></label>
 			                <select id="selectch1lota" name="selectch1lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula1">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas1" value="0" style="width:30px" id="txtqdtaaulas1"  disabled="disabled" />



					<label for="lblareaatuacao1">Area de Atuação</label>
						<select name="txtautacao1" id="txtautacao1" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep2" value="" style="width:90px" maxlength="8" id="txtinep2"  disabled="disabled"/>

				<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola2" value="" style="width:450px" id="txtdescescola2"  disabled="disabled"/>
			</p>

              <p>
						<label for="txtdtlotacao2">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota12" value="" style="width:70px" id="txtdtlota12" disabled="disabled"/>

						<label for="selectcontrato2">CH - Lotacao<img src= "img/check.gif"/></label>
 			                <select id="selectch2lota" name="selectch2lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas2" value="0" style="width:30px" id="txtqdtaaulas2"  disabled="disabled" />



					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao2" id="txtautacao2" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep3">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep3" value="" style="width:90px" maxlength="8" id="txtinep3"  disabled="disabled"/>

				<label for="lbldesescola3">Escola</label>
						<input type="text" name="txtdescescola3" value="" style="width:450px" id="txtdescescola3"  disabled="disabled"/>
			</p>

              <p>
						<label for="txtdtlotacao3">Data Lotacao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota13" value="" style="width:70px" id="txtdtlota13" disabled="disabled"/>

						<label for="selectcontrato3">CH - Lotacao<img src= "img/check.gif"/></label>
 			                <select id="selectch3lota" name="selectch3lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
							  <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula3">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas3" value="0" style="width:30px" id="txtqdtaaulas3"  disabled="disabled" />



					<label for="lblareaatuacao3">Area de Atuação</label>
						<select name="txtautacao3" id="txtautacao3" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep4" value="" style="width:90px" maxlength="8" id="txtinep4" disabled="disabled"/>

				<label for="lbldesescola4">Escola</label>
						<input type="text" name="txtdescescola4" value="" style="width:450px" id="txtdescescola4"  disabled="disabled"/>
    		</p>

              <p>
						<label for="txtdtlotacao4">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota14" value="" style="width:70px" id="txtdtlota14" disabled="disabled"/>

						<label for="selectcontrato4">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch4lota" name="selectch4lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula4">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas4" value="0" style="width:30px" id="txtqdtaaulas4"  disabled="disabled" />



					<label for="lblareaatuacao4">Area de Atuação</label>
						<select name="txtautacao4" id="txtautacao4" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>


           <p>
				<label for="lblinep5">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep5" value="" style="width:90px" maxlength="8" id="txtinep5" disabled="disabled" />

				<label for="lbldesescola5">Escola</label>
						<input type="text" name="txtdescescola5" value="" style="width:450px" id="txtdescescola5"  disabled="disabled"/>
			</p>

              <p>
						<label for="txtdtlotacao5">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota15" value="" style="width:70px" id="txtdtlota15" disabled="disabled"/>

						<label for="selectcontrato5">CH - Lotação<img src= "img/check.gif"/></label>
 			                <select id="selectch5lota" name="selectch5lota" style="width:40px" disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula5">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas5" value="0" style="width:30px" id="txtqdtaaulas5"  disabled="disabled" />



					<label for="lblareaatuacao1">Area de Atuação</label>
						<select name="txtautacao5" id="txtautacao5" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					</p>




					 <div id="linha"> 
					       <p><center></center></p>
					  </div>



			    <p>
					<label for="lblcargo1">Cargo - Nomeacao<img src= "img/check.gif"/></label>
						<select name="txtcod_cargo1" id="txtcod_cargo1"  disabled="disabled">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>
          		<label for="lblfuncao1">Funcao<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao1" id="cod_funcao1" disabled="disabled" >
			           <option value="">-- Escolha cargo --</option>
            	 </select>

	</p>		

					<p>
						<label for="lblcontrato2">Regime Jurídico(2)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato2" name="selectcontrato2" style="width:200px"  disabled="disabled">
              		          <option value="ESTATUTARIO">ESTATUTARIO</option>
            		          <option value="CLT">CELETISTA</option>
							  <option value="REINTEGRADO">REINTEGRADO</option>
							  <option value="CDS">CDS</option>							  
							  <option value="CDSI">CDSI</option>							  							  
							  <option value="CEDIDO">CEDIDO</option>							  							  
							  <option value="PERMUTA">TERMO COOP TECNICA</option>							  							    		               </select>

						<label for="selectadm2">Cedido/Permuta Adm <img src= "img/check.gif"/></label>
 			                <select id="selectcadm2" name="selectcadm2" style="width:200px" disabled="disabled">
              		          <option value="">Selecione a Administracao</option>
              		          <option value="MUNICIPAL">MUNICIPAL</option>
            		          <option value="FEDERAL">FEDERAL</option>
            		          <option value="AUTARQUIA">AUTARQUIA</option>
            		          <option value="FUNDACAO">FUNDACAO PÚBLICA</option>							  
    		               </select>
					</p>
						
						
						
						
						
						<p>
						<label for="lblMatricula2">Matricula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula2" value="" style="width:90px" maxlength="9" id="txtMatricula2" disabled="disabled"/>

						<label for="lblDataAdmissao2">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao2" value="" style="width:70px" id="txtdtadmissao2" disabled="disabled"/>
						<label for="lblselectch2">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch2" name="selectch2" style="width:40px" disabled="disabled" />
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>
					</p>


					<p>
						<label for="lbldecreto2">N Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtdecreto2" style="width:70px" value="" maxlength="11" id="txtdecreto3" disabled="disabled"/>

						<label for="txtdtdecreto2">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdecreto2" value="" style="width:70px" id="txtdtdecreto2"  disabled="disabled"/>


						<label for="lbldiario2">Publicado Diário<img src= "img/check.gif"/></label>
						<input type="text" name="txtdiario2" style="width:70px" value="" maxlength="11" id="txtdiario3" disabled="disabled"/>

						<label for="lbldtdiario2">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdiario2" value="" style="width:70px" id="txtdtdiario2" disabled="disabled"/>
					</p>

                     <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao2" name="selectlotacao2" style="width:200px" disabled="disabled">
              		          <option value="ADM">ADMINISTRACAO</option>
            		          <option value="ESCOLA">ESCOLA</option>
            		          <option value="ADM-ESCOLA">ADMINISTRAÇÃO-ESCOLA</option>							  
    		               </select>
    	       		     </p>


			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif"/></label>
						<select name="txtgerencia1" id="txtgerencia1"  style="width:400px" disabled="disabled">
						<option value=""></option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto1">Departamento<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="txtdpto1" id="txtdpto1" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
			
	</p>		


           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>



					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep2" value="" style="width:90px" maxlength="9" id="txtinep2" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola2" value="" style="width:450px" id="txtdescescola2" disabled="disabled" />

					</p>


					<p>
						<label for="lbldtlotacao">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr21" value="" style="width:70px" id="txtdtlotacontr21"  disabled="disabled"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato21" name="selectcontrato21" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas2" value="0" style="width:30px" id="txtqdtaaulas2"  disabled="disabled"/>


					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao2" id="txtautacao2" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>



					<p>
						<label for="lblinep21">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep21" value="" style="width:90px" maxlength="9" id="txtinep21" disabled="disabled" />

						<label for="lbldesescola21">Escola</label>
						<input type="text" name="txtdescescola21" value="" style="width:450px" id="txtdescescola21"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao21">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr21" value="" style="width:70px" id="txtdtlotacontr21" disabled="disabled" />

						<label for="selectcontrato21">CH<img src= "img/check.gif"/></label>
 			                <select id="select" name="selectcontrato21" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula21">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas21" value="0" style="width:30px" id="txtqdtaaulas21"  disabled="disabled"/>


					<label for="lblareaatuacao21">Area de Atuação</label>
						<select name="txtautacao21" id="txtautacao21" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>





					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep22" value="" style="width:90px" maxlength="9" id="txtinep22" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola22" value="" style="width:450px" id="txtdescescola22"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr22" value="" style="width:70px" id="txtdtlotacontr22" disabled="disabled"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato22" name="selectcontrato22" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas22" value="0" style="width:30px" id="txtqdtaaulas22"  disabled="disabled"/>


					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao22" id="txtautacao22" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>

					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep23" value="" style="width:90px" maxlength="9" id="txtinep23" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola23" value="" style="width:450px" id="txtdescescola23"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr23" value="" style="width:70px" id="txtdtlotacontr23" disabled="disabled"/>

						<label for="selectcontrato23">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato23" name="selectcontrato23" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas23" value="0" style="width:30px" id="txtqdtaaulas23"  disabled="disabled" disabled="disabled"/>


					<label for="lblareaatuacao23">Area de Atuação</label>
						<select name="txtautacao23" id="txtautacao23" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:450px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:70px" id="txtdtlotacontr24" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>


					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>




					</p>

					 <div id="linha"> 
					       <p><center></center></p>
					  </div>

			<p>
					<label for="cod_estados3">Cargo - Nomeacao<img src= "img/check.gif"/></label>
						<select name="cod_cargo2" id="cod_cargo2">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_cargo, descricao
									FROM cargo
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_cargo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>
          		<label for="cod_cidades3">Funcao<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_funcao2" id="cod_funcao2">
			           <option value="">-- Escolha cargo --</option>
            	 </select>
			
	</p>		


					<p>
						<label for="lblrj3">Regime Jurídico(3)<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato3" name="selectcontrato3" style="width:200px">
              		          <option value="ESTATUTARIO">ESTATUTARIO</option>
            		          <option value="CLT">CELETISTA</option>
							  <option value="REINTEGRADO">REINTEGRADO</option>
							  <option value="CDS">CDS</option>							  
							  <option value="CDSI">CDSI</option>							  							  
							  <option value="CEDIDO">CEDIDO</option>							  							  
							  <option value="PERMUTA">TERMO COOP TECNICA</option>							  							    		               </select>

						<label for="selectadm3">Cedido Para Adminstração <img src= "img/check.gif"/></label>
 			                <select id="selectcadm3" name="selectcadm3" style="width:200px" disabled="disabled">
              		          <option value="">Selecione a Administracao</option>
              		          <option value="MUNICIPAL">MUNICIPAL</option>
            		          <option value="FEDERAL">FEDERAL</option>
            		          <option value="AUTARQUIA">AUTARQUIA</option>
            		          <option value="FUNDACAO">FUNDACAO PÚBLICA</option>							  
    		               </select>
					</p>
                    
					
					
					
					<p>
						<label for="lblmatricula3">Matricula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula3" value="" style="width:90px" maxlength="9" id="txtMatricula3" />

						<label for="lbldtadmisao3">Data Admissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao3" value="" style="width:70px" id="txtdtadmissao3" />

						<label for="lblch3">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch3" name="selectch3" style="width:40px">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>


					<p>

						<label for="lbldecreto3">N Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtdecreto3" style="width:70px" value="" maxlength="11" id="txtdecreto3" />

						<label for="lbldtdecreto3">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdecreto3" value="" style="width:70px" id="txtdtdecreto3" />


						<label for="lbldiario3">Publicado Diário<img src= "img/check.gif"/></label>
						<input type="text" name="txtdiario3" style="width:70px" value="" maxlength="11" id="txtdiario3" />

						<label for="lbldtdiario3">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdiario3" value="" style="width:70px" id="txtdtdiario3" />
					</p>

                     <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao3" name="selectlotaca3" style="width:200px">
              		          <option value="ADM">ADMINISTRACAO</option>
            		          <option value="ESCOLA">ESCOLA</option>
            		          <option value="ADM-ESCOLA">ADMINISTRAÇÃO-ESCOLA</option>							  
    		               </select>
    	       		     </p>



			      <p>
					<label for="lblgerencia">Gerência<img src= "img/check.gif"/></label>
						<select name="txtgerencia2" id="txtgerencia2"  style="width:400px" disabled="disabled">
						<option value=""></option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto1">Departamento<img src= "img/check.gif"/></label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="txtdpto2" id="txtdpto2" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
			
	</p>		


           <p>
			  	<label for="selectcontrato3">Total de Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
				   <option value="1">1</option>
             	   <option value="2">2</option>
            	   <option value="3">3</option>
             	   <option value="4">4</option>
            	   <option value="5">5</option>

    		     </select>

           </p>


					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep22" value="" style="width:90px" maxlength="9" id="txtinep22" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola22" value="" style="width:450px" id="txtdescescola22"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr22" value="" style="width:70px" id="txtdtlotacontr22" disabled="disabled"/>

						<label for="selectcontrato">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato22" name="selectcontrato22" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas22" value="0" style="width:30px" id="txtqdtaaulas22"  disabled="disabled"/>


					<label for="lblareaatuacao2">Area de Atuação</label>
						<select name="txtautacao22" id="txtautacao22" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>

					<p>
						<label for="lblinep2">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep23" value="" style="width:90px" maxlength="9" id="txtinep23" disabled="disabled"/>

						<label for="lbldesescola2">Escola</label>
						<input type="text" name="txtdescescola23" value="" style="width:450px" id="txtdescescola23"  disabled="disabled"/>

					</p>




					<p>
						<label for="lbldtlotacao">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr23" value="" style="width:70px" id="txtdtlotacontr23" disabled="disabled"/>

						<label for="selectcontrato23">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato23" name="selectcontrato23" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula2">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas23" value="0" style="width:30px" id="txtqdtaaulas23"  disabled="disabled" disabled="disabled"/>


					<label for="lblareaatuacao23">Area de Atuação</label>
						<select name="txtautacao23" id="txtautacao23" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>



					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:450px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:70px" id="txtdtlotacontr24" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>


					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>




					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:450px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:70px" id="txtdtlotacontr24" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>


					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>




					</p>


					<p>
						<label for="lblinep24">INEP<img src= "img/check.gif"/></label>
						<input type="text" name="txtinep24" value="" style="width:90px" maxlength="9" id="txtinep24" disabled="disabled"/>

						<label for="lbldesescola24">Escola</label>
						<input type="text" name="txtdescescola24" value="" style="width:450px" id="txtdescescola24" disabled="disabled" />

					</p>




					<p>
						<label for="lbldtlotacao24">Data Lotaçao<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlotacontr24" value="" style="width:70px" id="txtdtlotacontr24" disabled="disabled"/>

						<label for="selectcontrato24">CH<img src= "img/check.gif"/></label>
 			                <select id="selectcontrato24" name="selectcontrato24" style="width:40px" disabled="disabled">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula24">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas24" value="0" style="width:30px" id="txtqdtaaulas24"  disabled="disabled"/>


					<label for="lblareaatuacao24">Area de Atuação</label>
						<select name="txtautacao24" id="txtautacao24" disabled="disabled">
						<option value="">Selecione Area de Atuação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>

					 <div id="linha"> 
					       <p><center></center></p>
					  </div>


					  <p>
						  <label for="txtBanco">Banco:</label>
						  <input type="text" name="txtBanco" value="" style="width:50px" id="txtBanco" />
						  <label for="txtAgencia" >Agência:</label>
						  <input type="text" name="txtAgencia" value="" style="width:60px" id="txtAgencia" />
						  <label for="txtConta">Conta:</label>
						  <input type="text" name="txtConta" value="" style="width:100px" id="txtConta" />
					  </p>




					<p id="finish">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados</p>
		</div>
	</div>
</body>

