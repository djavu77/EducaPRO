/**
 * Autor : Paulo Eduardo
 * Data  : 27.08.2009 
 * Analista : Paulo Eduardo
 * Programador : Paulo Eduardo
 
 
 *    NTE
 **/


function DoPrinting()
{
    if (!window.print)
    {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}


function cor_tabela(id)
{
    var cor1 = "#dae5e3";
    var cor2 = "#fff";
    var x = document.getElementById(id).getElementsByTagName('tr');
    for (i = 0; i < x.length; i++)
        x[i].style.backgroundColor = (i % 2 == 0) ? cor1 : cor2;
}

function pesquisacombo()
{
    var texto
    texto = "O n�mero de op��es do select: " + document.formul.minhaSelect.length
    var indice = document.formul.minhaSelect.selectedIndex
    texto += "\nIndice da op��o escolhida: " + indice
    var valor = document.formul.minhaSelect.options[indice].value
    texto += "\nValor da op��o escolhida: " + valor
    var textoEscolhido = document.formul.minhaSelect.options[indice].text
    texto += "\nTexto da op��o escolhida: " + textoEscolhido
    alert(texto)
}

function valida_cpf(cpf)
{
    var numeros, digitos, soma, i, resultado, digitos_iguais;
    digitos_iguais = 1;

    if (cpf == '' || cpf.length < 11)
    {
        return false;
    }

    for (i = 0; i < cpf.length - 1; i++)
    {
        if (cpf.charAt(i) != cpf.charAt(i + 1))
        {
            digitos_iguais = 0;
            break;
        }
    }

    if (!digitos_iguais)
    {
        numeros = cpf.substring(0, 9);
        digitos = cpf.substring(9);
        soma = 0;
        for (i = 10; i > 1; i--)
            soma += numeros.charAt(10 - i) * i;

        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;

        if (resultado != digitos.charAt(0))
        {
            alert("CPF inv�lido.");
            document.self.cpf.focus();
            return false;
        }
        else
        {
            numeros = cpf.substring(0, 10);
            soma = 0;
            for (i = 11; i > 1; i--)
                soma += numeros.charAt(11 - i) * i;

            resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;

            if (resultado != digitos.charAt(1))
            {
                alert("CPF inv�lido.");
                document.self.cpf.focus();
                return false;
            }
            else
            {
                return true;
            }
        }
    }
    else
    {
        alert("CPF inv�lido.");
        document.self.cpf.focus();
        return false;
    }

    return false;
}

//form altera_Escola

function maiusculalteracadescola()
{
    document.formalteraescola.descricao.value = document.formalteraescola.descricao.value.toUpperCase();
    document.formalteraescola.endereco.value = document.formalteraescola.endereco.value.toUpperCase();
    document.formalteraescola.bairro.value = document.formalteraescola.bairro.value.toUpperCase();
}


function maiusculadiagnostico()
{

    document.formdiagnostico.siteblog.value = document.formdiagnostico.siteblog.value.toLowerCase();
    document.formdiagnostico.emailescola.value = document.formdiagnostico.emailescola.value.toLowerCase();
    document.formdiagnostico.nomediretor.value = document.formdiagnostico.nomediretor.value.toUpperCase();
    document.formdiagnostico.vicediretor.value = document.formdiagnostico.vicediretor.value.toUpperCase();
    document.formdiagnostico.liescoord1.value = document.formdiagnostico.liescoord1.value.toUpperCase();
    document.formdiagnostico.liescoord2.value = document.formdiagnostico.liescoord2.value.toUpperCase();
    document.formdiagnostico.liescoord3.value = document.formdiagnostico.liescoord3.value.toUpperCase();
    document.formdiagnostico.tvecoord1.value = document.formdiagnostico.tvecoord1.value.toUpperCase();
    document.formdiagnostico.tvecoord2.value = document.formdiagnostico.tvecoord2.value.toUpperCase();
    document.formdiagnostico.tvecoord3.value = document.formdiagnostico.tvecoord3.value.toUpperCase();
    document.formdiagnostico.prooutros.value = document.formdiagnostico.prooutros.value.toUpperCase();
    document.formdiagnostico.codifisicalie.value = document.formdiagnostico.codifisicalie.value.toUpperCase();
    document.formdiagnostico.codifisicatv.value = document.formdiagnostico.codifisicatv.value.toUpperCase();



}

function maiusculaltrecho()
{
    document.form.trecho.value = document.form.trecho.value.toUpperCase();
}

function maiusculalterachamado()
{
    document.alterachamado.tecnico.value = document.alterachamado.tecnico.value.toUpperCase();
    document.alterachamado.laudo.value = document.alterachamado.laudo.value.toUpperCase();
}


function maiusculacancelachamdo()
{
    document.alterachamado.laudo.value = document.alterachamado.laudo.value.toUpperCase();
}

function validacancelachamado()
{

    if (document.alterachamado.laudo.value == "")
    {
        alert("Campo obrigat�rio. Descreva o Motivo do Cancelamento.");
        document.alterachamado.problema.focus();
        return false;

    }

    if (confirm("Confirma o Cancelamento do Chamado ? "))
    {
        return true;
    }
    else
    {
        document.alterachamado.laudo.focus();
        return false;
    }

}

function validaequipamento()
{
    if (document.formregchamado.tsala.value == "")
    {
        alert("Campo obrigat�rio. Informe o total de salas existentes na escola.");
        document.formregchamado.tsala.focus();
        return false;

    }



    if (document.formregchamado.txtextintor.value == "")
    {
        alert("Campo obrigat�rio. Informe o total de extintores na escola.");
        document.formregchamado.txtextintor.focus();
        return false;

    }

    if (document.formregchamado.txthidrantes.value == "")
    {
        alert("Campo obrigat�rio. Informe o total de hidrantes na escola.");
        document.formregchamado.txthidrantes.focus();
        return false;

    }


    if (document.formregchamado.txttsar.value == "")
    {
        alert("Campo obrigat�rio. Informe o total de sala de aula sem ar-condicionado.");
        document.formregchamado.txttsar.focus();
        return false;

    }

    if (document.formregchamado.edificacao.value == "")
    {
        alert("Campo obrigat�rio. Informe a situa��o da escola.");
        document.formregchamado.edificacao.focus();
        return false;

    }




    if (confirm("Confirma a Grava��o dos Dados ? "))
    {
        return true;
    }
    else
    {
        document.formregchamado.tsala.focus();
        return false;
    }

}


function validacampobaixa()
{


    if (document.alterachamado.tecnico.value == "")
    {
        alert("Campo obrigat�rio. Identifique o(s) T�cnico(s).");
        document.alterachamado.tecnico.focus();
        return false;

    }

    if (document.alterachamado.laudo.value == "")
    {
        alert("Campo obrigat�rio. Descreva a a��o executada.");
        document.alterachamado.problema.focus();
        return false;

    }


    if (document.alterachamado.npessoas.value <= 0)
    {
        alert("Campo obrigat�rio. Informe o n� de participante(s) da a��o.");
        document.alterachamado.npessoas.focus();
        return false;

    }


    if (document.alterachamado.situacao.value == "")
    {
        alert("Campo obrigat�rio. Selecione a situa��o Atual.");
        document.alterachamado.situacao.focus();
        return false;

    }


    if (confirm("...Confirma dados para grava��o  ? "))
    {
        return true;
    }
    else
    {
        document.alterachamado.laudo.focus();
        return false;
    }

}


function validaagenda()
{


    if (document.formagenda.local.value == "")
    {
        alert("Campo obrigat�rio. Informe o destino.");
        document.formagenda.local.focus();
        return false;

    }

    if (document.formagenda.dtagenda.value == "")
    {
        alert("Campo obrigat�rio. Informe a data do compromisso.");
        document.formagenda.dtagenda.focus();
        return false;
    }
    if (document.formagenda.atividade.value == "")
    {
        alert("Campo obrigat�rio. Descreva a Atividade.");
        document.formagenda.atividade.focus();
        return false;
    }

    if (document.formagenda.turno.value == "")
    {
        alert("Campo obrigat�rio. Selecione o Turno.");
        document.formagenda.turno.focus();
        return false;
    }

    if (confirm("...Confirma dados para grava��o  ? "))
    {
        return true;
    }
    else
    {
        document.formagenda.local.focus();
        return false;
    }

}

function maiusculadiarias()
{
    document.form1.cronograma.value = document.form1.cronograma.value.toUpperCase();
    document.form1.destino.value = document.form1.destino.value.toUpperCase();

}

function maiusculaalteramunicipio()
{
    document.formaltmunicipio.descricao.value = document.formaltmunicipio.descricao.value.toUpperCase();
}

function alterante(caractere)
{
    window.document.formaltmunicipio.nte.value = caractere;
}

function alterazona(caractere)
{
    window.document.formalteraescola.zona.value = caractere;
}

function alteraurnoagenda(caractere)
{
    window.document.formagenda.turno.value = caractere;
}

function alteranivelusuario(caractere)
{
    window.document.formaltusuario.nivel.value = caractere;
}

function alteramuni(caractere)
{
    var texto
    texto = "O n�mero de op��es do select: "
    texto = "O n�mero de op��es do select: " + document.formalteraescola.municipio.length
    var indice = document.formalteraescola.municipio.selectedIndex
    texto += "\nIndice da op��o escolhida: " + indice
    var valor = document.formalteraescola.municipio.options[indice].value
    texto += "\nValor da op��o escolhida: " + valor
    var textoEscolhido = document.formalteraescola.municipio.options[indice].text
    texto += "\nTexto da op��o escolhida: " + textoEscolhido
//    alert(texto)

    window.document.formalteraescola.municipio1.value = textoEscolhido;
    window.document.formalteraescola.municodigo.value = valor;


}

//form altera_Escola fim
function vai(numero)
{
    var urls = new Array()
    urls[0] = "http://www.hardmob.com.br";
    urls[1] = "http://www.google.com";
    var m_site = "";
    m_site = urls[numero];
    if ((m_site != null) && (m_site != ""))
        window.location = m_site;
}

function validalogin()
{
    if (document.login.cpf.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a seu login.");
        document.login.cpf.focus();
        return false;
    }


    if (document.login.password.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a sua senha.");
        document.login.password.focus();
        return false;
    }



}

function Direciona(botao)
{

    var pagina;

    if (botao == 1)
        pagina = "login.php"
    else if (botao == 5)
        pagina = "formcadprograma.php"
    else if (botao == 3)
        pagina = "exclui.html"
    else if (botao == 4)
        pagina = "mnescola.php"
    else if (botao == 6)
        pagina = "mngti.php"
    else if (botao == 7)
        pagina = "/cursodiretor/index.php"




    document.getElementById("resposta").action = pagina;
    document.getElementById("resposta").submit();
}

//cadastro de usuario
function validacadusuario()
{
    if (document.formusuario.cpf.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o seu CPF.");
        document.formusuario.cpf.focus();
        return false;
    }


    if (document.formusuario.nome.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe seu nome.");
        document.formusuario.nome.focus();
        return false;
    }


    if (document.formusuario.senha.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a sua senha.");
        document.formusuario.senha.focus();
        return false;
    }


    if (document.formusuario.nivel.value == "")
    {
        alert("Adm, Selecione o n�vel de acesso do usu�rio.");
        document.formusuario.nivel.focus();
        return false;
    }


    if (document.formusuario.nivel.value == "ADME")
    {
        if (document.formusuario.inep.value == "")
        {
            alert("Informe o INEP da escola..");
            document.formusuario.inep.focus();
            return false;
        }
    }




    if (document.formusuario.senha.value != document.formusuario.password.value)
    {
        alert("Usu�rio, Senha n�o confere digite novamente.");
        document.formusuario.senha.focus();
        return false;
    }


    if (confirm("....Confirma a Inclus�o "))
    {
        return true;
    }
    else
    {
        document.formaltusuario.nome.focus();
        return false;
    }


}

function validaaltusuario()
{

// if document.formaltusuario.chkaltera. 	
//alert(document.formaltusuario.alterasenha.checked);

    if (document.formaltusuario.cpf.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o seu CPF.");
        document.formaltusuario.cpf.focus();
        return false;
    }


    if (document.formaltusuario.nome.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe seu nome.");
        document.formaltusuario.nome.focus();
        return false;
    }


    if (document.formaltusuario.senha.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a sua senha.");
        document.formusuario.senha.focus();
        return false;
    }


    if (document.formaltusuario.nivel.value == "")
    {
        alert("Adm, Selecione o n�vel de acesso do usu�rio.");
        document.formaltusuario.nivel.focus();
        return false;
    }




    if (document.formaltusuario.alterasenha.checked == true)
    {
        if (document.formaltusuario.senha.value != document.formaltusuario.password.value)
        {
            alert("Usu�rio, Senha n�o confere digite novamente.");
            document.formaltusuario.senha.focus();
            return false;
        }
    }




    if (document.formusuario.nivel.value == "ADME")
    {
        if (document.formusuario.inep.value == "")
        {
            alert("Informe o INEP da escola..");
            document.formusuario.inep.focus();
            return false;
        }
    }






    if (confirm("....Confirma Altera��o "))
    {
        return true;
    }
    else
    {
        document.formaltusuario.nome.focus();
        return false;
    }



}

function mascaraDTinicio(campoData) {


    var data = campoData;

    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.form1.dtinicio.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.form1.dtinicio.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.form1.dtinicio.value.substring(0, 2));
        mes = (document.form1.dtinicio.value.substring(3, 5));
        ano = (document.form1.dtinicio.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.form1.dtinicio.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.form1.dtinicio.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.form1.dtinicio.sefocus();
            situacao = "falsa";
        }


        dia = (document.form1.dtinicio.value.substring(0, 2));
        mes = (document.form1.dtinicio.value.substring(3, 5));
        ano = (document.form1.dtinicio.value.substring(6, 10));

        return true;
    }

}

function mascaraDTfim(campoData) {


    var data = campoData;
    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.form1.dtfim.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.form1.dtfim.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.form1.dtfim.value.substring(0, 2));
        mes = (document.form1.dtfim.value.substring(3, 5));
        ano = (document.form1.dtfim.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.form1.dtfim.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.form1.dtfim.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.form1.dtfim.sefocus();
            situacao = "falsa";
        }


        dia = (document.form1.dtfim.value.substring(0, 2));
        mes = (document.form1.dtfim.value.substring(3, 5));
        ano = (document.form1.dtfim.value.substring(6, 10));

        return true;
    }

}

function maiusculacadusuario()
{
    document.formusuario.nome.value = document.formusuario.nome.value.toUpperCase();

}
//fim cadastro de usuario

//cadastro de escola
function validacadescola()
{


    if (document.formescola.inep.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o c�digo do INEP.");
        document.formescola.inep.focus();
        return false;
    }

    if (document.formescola.descricao.value == 0)
    {
        alert("Campo Obrigat�rio, Selecione o de localiza��o da escola.");
        document.formescola.descricao.focus();
        return false;
    }


    if (document.formescola.tipo.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o de localiza��o da escola.");
        document.formescola.tipo.focus();
        return false;
    }

}

function validapatrimonio()
{


    if (document.formregpatrimonio.opcao.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o Tipo de Movimento.");
        document.formregpatrimonio.opcao.focus();
        return false;
    }


    if (document.formregpatrimonio.programa.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o Programa.");
        document.formregpatrimonio.programa.focus();
        return false;
    }

    if (document.formregpatrimonio.ativo.value == 0)
    {
        alert("Campo Obrigat�rio, Selecione o Mobili�rio.");
        document.formescola.ativo.focus();
        return false;
    }

    if (document.formregpatrimonio.ativo.value == "INTERNET")
    {

        if (document.formregpatrimonio.conexao.value == "")
        {
            alert("Campo Obrigat�rio, Informe o tipo de conex�o.");
            document.formregpatrimonio.conexao.focus();
            return false;
        }


        if (document.formregpatrimonio.tronco.value == "")
        {
            alert("Campo Obrigat�rio, Informe o n� do tronco.");
            document.formregpatrimonio.tronco.focus();
            return false;
        }
    }


    if (document.formregpatrimonio.anomovimento.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o Ano da Movimenta��o.");
        document.formregpatrimonio.anomovimento.focus();
        return false;
    }


    if (document.formregpatrimonio.anoprograma.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o Ano do Programa.");
        document.formregpatrimonio.anoprograma.focus();
        return false;
    }


    if (document.formregpatrimonio.qtda.value <= 0)
    {
        alert("Campo Obrigat�rio, Quantidade Informada Inv�lida.");
        document.formregpatrimonio.qtda.focus();
        return false;
    }

    if (confirm("....Confirma registro do patrim�nio "))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }
}

function validadiagnostico()
{



    if (document.formdiagnostico.fone.value == "")
    {
        alert("Campo Obrigat�rio, Informe telefone para contato.");
        document.formdiagnostico.fone.focus();
        return false;
    }


    if (document.formdiagnostico.nalunos.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o numero de alunos matriculados.");
        document.formdiagnostico.nalunos.focus();
        return false;
    }


    if (document.formdiagnostico.ndocentes.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o numero de professores pertencente ao quadro da escola .");
        document.formdiagnostico.ndocentes.focus();
        return false;
    }


    if (document.formdiagnostico.nsala.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o numero de sala de aula .");
        document.formdiagnostico.nsala.focus();
        return false;
    }





    if (document.formdiagnostico.ntmanha.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o  numero de turma pela manha.");
        document.formdiagnostico.ntmanha.focus();
        return false;
    }

    if (document.formdiagnostico.nttarde.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o  numero de turma pela tarde");
        document.formdiagnostico.nttarde.focus();
        return false;
    }

    if (document.formdiagnostico.ntnoite.value == 0)
    {
        alert("Campo Obrigat�rio, Informe o  numero de turma pela noite.");
        document.formdiagnostico.ntnoite.focus();
        return false;
    }




    if (document.formdiagnostico.nomediretor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome do diretor(a).");
        document.formdiagnostico.nomediretor.focus();
        return false;
    }

    if (document.formdiagnostico.fonediretor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe telefone de contato do diretor(a).");
        document.formdiagnostico.fonediretor.focus();
        return false;
    }

    if (document.formdiagnostico.fonevice.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe telefone de contato do vice diretor(a).");
        document.formdiagnostico.fonevice.focus();
        return false;
    }



    if (document.formdiagnostico.vicediretor.value == "")
    {
        alert("Campo Obrigat�rio, Informe o nome do vice diretor(a).");
        document.formdiagnostico.vicediretor.focus();
        return false;
    }

    if (document.formdiagnostico.liescoord1.value != "")
    {
        if ((document.formdiagnostico.liescoord1m.checked == false) && (document.formdiagnostico.liescoord1t.checked == false) && (document.formdiagnostico.liescoord1n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador de LIE.");
            document.formdiagnostico.liescoord1.focus();
            return false;
        }
    }

    if (document.formdiagnostico.liescoord2.value != "")
    {
        if ((document.formdiagnostico.liescoord2m.checked == false) && (document.formdiagnostico.liescoord2t.checked == false) && (document.formdiagnostico.liescoord2n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador de LIE.");
            document.formdiagnostico.liescoord1.focus();
            return false;
        }
    }

    if (document.formdiagnostico.liescoord3.value != "")
    {
        if ((document.formdiagnostico.liescoord3m.checked == false) && (document.formdiagnostico.liescoord3t.checked == false) && (document.formdiagnostico.liescoord3n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador de LIE.");
            document.formdiagnostico.liescoord3.focus();
            return false;
        }
    }



    if (document.formdiagnostico.tvecoord1.value != "")
    {
        if ((document.formdiagnostico.tvecoord1m.checked == false) && (document.formdiagnostico.tvecoord1t.checked == false) && (document.formdiagnostico.tvecoord1n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador da Telessala.");
            document.formdiagnostico.tvecoord1.focus();
            return false;
        }
    }


    if (document.formdiagnostico.tvecoord2.value != "")
    {
        if ((document.formdiagnostico.tvecoord2m.checked == false) && (document.formdiagnostico.tvecoord2t.checked == false) && (document.formdiagnostico.tvecoord2n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador da Telessala.");
            document.formdiagnostico.tvecoord2.focus();
            return false;
        }
    }

    if (document.formdiagnostico.tvecoord3.value != "")
    {
        if ((document.formdiagnostico.tvecoord3m.checked == false) && (document.formdiagnostico.tvecoord3t.checked == false) && (document.formdiagnostico.tvecoord2n.checked == false))
        {
            alert("Campo Obrigat�rio, Informe o Turno de Atividade do Coordenador da Telessala.");
            document.formdiagnostico.tvecoord3.focus();
            return false;
        }
    }



    if ((document.formdiagnostico.merf.checked == false) && (document.formdiagnostico.merm.checked == false))
    {
        alert("Campo Obrigat�rio, Informe a modalidade de ensino regular.");
        document.formdiagnostico.merf.focus();
        return false;
    }




    if (confirm("....Essas informa��es serviram para tomadas de decis�es. Confirma  a grava��o desses dados. "))
    {
        return true;
    }
    else
    {
        document.formdiagnostico.fone.focus();
        return false;
    }
}

function disabilitainternet()
{
    if (document.formregpatrimonio.ativo.value == "INTERNET")
    {
        document.formregpatrimonio.conexao.disabled = false;
        document.formregpatrimonio.tronco.disabled = false;
        document.formregpatrimonio.conexao.focus();
        return true;
    }
    else
    {

        document.formregpatrimonio.conexao.value = "";
        document.formregpatrimonio.tronco.value = "";

        document.formregpatrimonio.conexao.disabled = true;
        document.formregpatrimonio.tronco.disabled = true;
        return true;
    }


}

//---------------Form-----------------------------------------
function habilitaequipamentogti()
{
    if (document.form1.origem.value != "ESCOLA")
    {
        document.form1.inep.disabled = true;
        document.form1.departamento.text = "";
        document.form1.departamento.disabled = false;
        document.form1.inep.focus();
        return true;
    }
    else if (document.form1.origem.value != "SECRETARIA")
    {

        document.form1.departamento.disabled = true;
        document.form1.inep.text = "";
        document.form1.inep.disabled = false;
        document.form1.departamento.focus();
        return true;
    }
}

function habilitaequipamentogti2()
{
    if (document.form1.tptecnico.value == "EFETIVO")
    {
        document.form1.empresa.disabled = true;
        document.form1.empresa.focus();
        return true;
    }
    else if (document.form1.tptecnico.value == "TERCERIZADO")
    {
        document.form1.empresa.disabled = false;
        document.form1.empresa.focus();
        return true;
    }
}

function maiusculacadescola()
{
    document.formescola.descricao.value = document.formescola.descricao.value.toUpperCase();
    document.formescola.endereco.value = document.formescola.endereco.value.toUpperCase();
    document.formescola.bairro.value = document.formescola.bairro.value.toUpperCase();
}

function maiusculatecnico()
{
    document.formtecnico.nome.value = document.formtecnico.nome.value.toUpperCase();
    document.formtecnico.endereco.value = document.formtecnico.endereco.value.toUpperCase();
    document.formtecnico.bairro.value = document.formtecnico.bairro.value.toUpperCase();
    document.formtecnico.rg.value = document.formtecnico.rg.value.toUpperCase();
    document.formtecnico.orgaoexp.value = document.formtecnico.orgaoexp.value.toUpperCase();

}

function maiusculaconcurso()
{
    document.formconcurso.nome.value = document.formconcurso.nome.value.toUpperCase();
    document.formconcurso.endereco.value = document.formconcurso.endereco.value.toUpperCase();
    document.formconcurso.bairro.value = document.formconcurso.bairro.value.toUpperCase();
    document.formconcurso.rg.value = document.formconcurso.rg.value.toUpperCase();
    document.formconcurso.orgaoexp.value = document.formconcurso.orgaoexp.value.toUpperCase();
    document.formconcurso.complemento.value = document.formconcurso.complemento.value.toUpperCase();

}

function maiusculaentregapassagem()
{
    document.form.nome.value = document.form.nome.value.toUpperCase();
    document.form.objetivo.value = document.form.objetivo.value.toUpperCase();

}

function maiusculaentregapassagemscpf()
{
    document.form.observacao.value = document.form.observacao.value.toUpperCase();


}

function maiusculainscricao()
{
    document.form1.nome.value = document.form1.nome.value.toUpperCase();

}

//fim cadastro de escola

//Ininio registro de aula
function validaregaula()
{


    if (document.formregistroaula.nivel.value == "")
    {
        alert("Campo obrigat�rio, Selecione o n�vel.");
        document.formregistroaula.nivel.focus();
        return false;
    }

    if (document.formregistroaula.serie.value == "")
    {
        alert("Campo obrigat�rio, Selecione a s�rie.");
        document.formregistroaula.serie.focus();
        return false;
    }
    if (document.formregistroaula.turma.value == "")
    {
        alert("Campo obrigat�rio, Selecione a turma.");
        document.formregistroaula.turma.focus();
        return false;
    }

    if (document.formregistroaula.turno.value == "")
    {
        alert("Campo obrigat�rio, Selecione o turno.");
        document.formregistroaula.turno.focus();
        return false;
    }

    if (document.formregistroaula.disciplina.value == "")
    {
        alert("Campo obrigat�rio, Selecione a disciplina.");
        document.formregistroaula.disciplina.focus();
        return false;
    }

    if (document.formregistroaula.recurso.value == "")
    {
        alert("Campo obrigat�rio, Selecione o recurso pedagogico utilizado.");
        document.formregistroaula.recurso.focus();
        return false;
    }


    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o conteudo trabalhado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }


    if (document.formregistroaula.professor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome o professor.");
        document.formregistroaula.professor.focus();
        return false;
    }

    if (document.formregistroaula.tipo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o qual o tipo de software.");
        document.formregistroaula.tipo.focus();
        return false;
    }

    if (document.formregistroaula.qual.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o qual o tipo de software.");
        document.formregistroaula.qual.focus();
        return false;
    }

    if (document.formregistroaula.descrecurso.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a descri��o do recurso utilizado.");
        document.formregistroaula.descrecurso.focus();
        return false;
    }



    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Descreva o conte�do ministrado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }

    if (document.formregistroaula.nalunos.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o total de alunos presentes.");
        document.formregistroaula.nalunos.focus();
        return false;
    }



    if (confirm("....Confirma registro de aula "))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }

}

function validaregaulatvescola()
{

    if (document.formregistroaula.nivel.value == "")
    {
        alert("Campo obrigat�rio, Selecione o n�vel.");
        document.formregistroaula.nivel.focus();
        return false;
    }

    if (document.formregistroaula.serie.value == "")
    {
        alert("Campo obrigat�rio, Selecione a s�rie.");
        document.formregistroaula.serie.focus();
        return false;
    }
    if (document.formregistroaula.turma.value == "")
    {
        alert("Campo obrigat�rio, Selecione a turma.");
        document.formregistroaula.turma.focus();
        return false;
    }

    if (document.formregistroaula.turno.value == "")
    {
        alert("Campo obrigat�rio, Selecione o turno.");
        document.formregistroaula.turno.focus();
        return false;
    }

    if (document.formregistroaula.disciplina.value == "")
    {
        alert("Campo obrigat�rio, Selecione a disciplina.");
        document.formregistroaula.disciplina.focus();
        return false;
    }

    if (document.formregistroaula.recurso.value == "")
    {
        alert("Campo obrigat�rio, Selecione o recurso pedagogico utilizado.");
        document.formregistroaula.recurso.focus();
        return false;
    }


    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o conteudo trabalhado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }


    if (document.formregistroaula.professor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome o professor.");
        document.formregistroaula.professor.focus();
        return false;
    }

    if (document.formregistroaula.tipo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o qual o tipo de software.");
        document.formregistroaula.tipo.focus();
        return false;
    }


    if (document.formregistroaula.descrecurso.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a descri��o do recurso utilizado.");
        document.formregistroaula.descrecurso.focus();
        return false;
    }

    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Descreva o conte�do ministrado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }

    if (document.formregistroaula.nalunos.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o total de alunos presentes.");
        document.formregistroaula.nalunos.focus();
        return false;
    }



    if (confirm("....Confirma registro de aula "))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }

}

function validaregaulaextra()
{

    if (document.formregistroaula.recurso.value == "")
    {
        alert("Campo obrigat�rio, Selecione o recurso pedagogico utilizado.");
        document.formregistroaula.recurso.focus();
        return false;
    }



    if (document.formregistroaula.nivel.value == "")
    {
        alert("Campo obrigat�rio, Selecione o n�vel.");
        document.formregistroaula.nivel.focus();
        return false;
    }


    if (document.formregistroaula.turno.value == "")
    {
        alert("Campo obrigat�rio, Selecione o turno.");
        document.formregistroaula.turno.focus();
        return false;
    }

    if (document.formregistroaula.disciplina.value == "")
    {
        alert("Campo obrigat�rio, Selecione a disciplina.");
        document.formregistroaula.disciplina.focus();
        return false;
    }


    if (document.formregistroaula.descrecurso.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a descri��o do recurso utilizado.");
        document.formregistroaula.descrecurso.focus();
        return false;
    }


    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o conteudo trabalhado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }





    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Descreva o conte�do ministrado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }

    if (document.formregistroaula.nalunos.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o total de alunos presentes.");
        document.formregistroaula.nalunos.focus();
        return false;
    }



    if (confirm("....Confirma registro da aula "))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }

}

function validacadescola()
{


    if (document.formescola.inep.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o c�digo do INEP.");
        document.formescola.inep.focus();
        return false;
    }

    if (document.formescola.descricao.value == 0)
    {
        alert("Campo Obrigat�rio, Selecione o de localiza��o da escola.");
        document.formescola.descricao.focus();
        return false;
    }


    if (document.formescola.tipo.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o de localiza��o da escola.");
        document.formescola.tipo.focus();
        return false;
    }

}

function maiusculacadescola()
{
    document.formescola.descricao.value = document.formescola.descricao.value.toUpperCase();
    document.formescola.endereco.value = document.formescola.endereco.value.toUpperCase();
    document.formescola.bairro.value = document.formescola.bairro.value.toUpperCase();
}
//fim cadastro de escola


//Ininio registro de aula
function validatecnico()
{

    if (document.formtecnico.cpf.value == "")
    {
        alert("Campo obrigat�rio, Informe o CPF.");
        document.formtecnico.cpf.focus();
        return false;
    }

    if (document.formtecnico.rg.value == "")
    {
        alert("Campo obrigat�rio, Informe o RG.");
        document.formtecnico.rg.focus();
        return false;
    }

    if (document.formtecnico.matricula.value == "")
    {
        alert("Campo obrigat�rio, sua Matricula.");
        document.formtecnico.matricula.focus();
        return false;
    }

    if (document.formtecnico.orgaoexp.value == "")
    {
        alert("Campo obrigat�rio, Informe o Org�o de Expedi��o da Carteira Identidade.");
        document.formtecnico.orgaoexp.focus();
        return false;
    }



    if (document.formtecnico.nome.value == "")
    {
        alert("Campo obrigat�rio, Informe seu nome.");
        document.formtecnico.nome.focus();
        return false;
    }

    if (document.formtecnico.endereco.value == "")
    {
        alert("Campo obrigat�rio, Informe o seu endere�o.");
        document.formtecnico.endereco.focus();
        return false;
    }
    if (document.formtecnico.bairro.value == "")
    {
        alert("Campo obrigat�rio, Informe o bairro.");
        document.formtecnico.bairro.focus();
        return false;
    }

    if (document.formtecnico.nr.value == "")
    {
        alert("Campo obrigat�rio, Informe o n�mero.");
        document.formtecnico.nr.focus();
        return false;
    }

    if (document.formtecnico.escolaridade.value == "")
    {
        alert("Campo obrigat�rio, Selecione sua escolaridade.");
        document.formtecnico.escolaridade.focus();
        return false;
    }

    if (document.formtecnico.habilitacao.value == "")
    {
        alert("Campo obrigat�rio, Selecione sua escolaridade.");
        document.formtecnico.habilitacao.focus();
        return false;
    }


    if (document.formtecnico.dia.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o dia do seu nascimento.");
        document.formtecnico.dia.focus();
        return false;
    }

    if (document.formtecnico.mes.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o m�s de nascimento.");
        document.formtecnico.mes.focus();
        return false;
    }

    if (document.formtecnico.funcao.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a sua fun��o.");
        document.formtecnico.funcao.focus();
        return false;
    }


    /*  if (document.formtecnico.banco.value=="")
     {
     alert("Campo obrigat�rio, Informe o Banco.");   
     document.formtecnico.banco.focus();
     return false;
     }     
     
     if (document.formtecnico.agencia.value=="")
     {
     alert("Campo obrigat�rio, Informe a  Ag�ncia.");   
     document.formtecnico.agencia.focus();
     return false;
     }     
     
     
     if (document.formtecnico.cc.value=="")
     {
     alert("Campo obrigat�rio, Informe a  Conta Corrente.");   
     document.formtecnico.cc.focus();
     return false;
     }     
     
     if (document.formtecnico.titulo.value=="")
     {
     alert("Campo obrigat�rio, Informe T�tulo.");   
     document.formtecnico.titulo.focus();
     return false;
     }     
     
     
     if (document.formtecnico.zona.value=="")
     {
     alert("Campo obrigat�rio, Informe T�tulo.");   
     document.formtecnico.zona.focus();
     return false;
     }     
     
     
     if (document.formtecnico.sessao.value=="")
     {
     alert("Campo obrigat�rio, Informe a Sess�o.");   
     document.formtecnico.sessao.focus();
     return false;
     }     
     
     
     if (document.formtecnico.pis.value=="")
     {
     alert("Campo obrigat�rio, Informe o seu PIS.");   
     document.formtecnico.pis.focus();
     return false;
     }     
     */

    if (confirm("....Confirma dados para grava��o."))
    {
        return true;
    }
    else
    {
        document.formtecnico.cpf.focus();
        return false;
    }

}

function validaregformcao()
{
    if (document.formregistroaula.nivel.value == "")
    {
        alert("Campo obrigat�rio, Selecione o Curso.");
        document.formregistroaula.nivel.focus();
        return false;
    }



    if (document.formregistroaula.turno.value == "")
    {
        alert("Campo obrigat�rio, Selecione o turno.");
        document.formregistroaula.turno.focus();
        return false;
    }


    if (document.formregistroaula.recurso.value == "")
    {
        alert("Campo obrigat�rio, Selecione o recurso pedagogico utilizado.");
        document.formregistroaula.recurso.focus();
        return false;
    }


    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o conteudo trabalhado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }

    if (document.formregistroaula.professor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome o professor.");
        document.formregistroaula.professor.focus();
        return false;
    }


    if (document.formregistroaula.descrecurso.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a descri��o do recurso utilizado.");
        document.formregistroaula.descrecurso.focus();
        return false;
    }


    if (document.formregistroaula.nalunos.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o total de alunos presentes.");
        document.formregistroaula.nalunos.focus();
        return false;
    }


    if (confirm("....Confirma registro da aula do curso de forma�ao"))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }

}

function validaregassessoria()
{



    if (document.formregistroaula.nivel.value == "")
    {
        alert("Campo obrigat�rio, Selecione a Assessoria.");
        document.formregistroaula.nivel.focus();
        return false;
    }



    if (document.formregistroaula.turno.value == "")
    {
        alert("Campo obrigat�rio, Selecione o turno.");
        document.formregistroaula.turno.focus();
        return false;
    }


    if (document.formregistroaula.recurso.value == "")
    {
        alert("Campo obrigat�rio, Selecione o recurso pedagogico utilizado.");
        document.formregistroaula.recurso.focus();
        return false;
    }


    if (document.formregistroaula.conteudo.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o conteudo trabalhado.");
        document.formregistroaula.conteudo.focus();
        return false;
    }

    if (document.formregistroaula.professor.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome o professor.");
        document.formregistroaula.professor.focus();
        return false;
    }


    if (document.formregistroaula.descrecurso.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a descri��o do recurso utilizado.");
        document.formregistroaula.descrecurso.focus();
        return false;
    }


    if (document.formregistroaula.nalunos.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o total de alunos presentes.");
        document.formregistroaula.nalunos.focus();
        return false;
    }


    if (confirm("....Confirma registro da Assessoria ?"))
    {
        return true;
    }
    else
    {
        document.formregistroaula.escola.focus();
        return false;
    }

}

function maiuscularegaula()
{
    document.formregistroaula.descrecurso.value = document.formregistroaula.descrecurso.value.toUpperCase();
    document.formregistroaula.professor.value = document.formregistroaula.professor.value.toUpperCase();
    document.formregistroaula.conteudo.value = document.formregistroaula.conteudo.value.toUpperCase();
    document.formregistroaula.obs.value = document.formregistroaula.obs.value.toUpperCase();

//item nao existe em registro de formacao por isso vem por ultimo
    document.formregistroaula.qual.value = document.formregistroaula.qual.value.toUpperCase();
}
//fim registro de aula

function maiusculaagenda()
{

    document.formagenda.local.value = document.formagenda.local.value.toUpperCase();
    document.formagenda.atividade.value = document.formagenda.atividade.value.toUpperCase();
    document.formagenda.observacao.value = document.formagenda.observacao.value.toUpperCase();
}
//fim registro 

//cadastro de municipio
function validacadmunicipio()
{


    if (document.formunicipio.descricao.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o nome do munic�pio.");
        document.formunicipio.descricao.focus();
        return false;
    }

    if (document.formunicipio.nte.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o NTE respons�vel.");
        document.formunicipio.nte.focus();
        return false;
    }

    if (document.formunicipio.nte.value == "")
    {
        alert("Campo Obrigat�rio, Selecione o NTE respons�vel.");
        document.formunicipio.nte.focus();
        return false;
    }



}

function maiusculacadmunicipio()
{
    document.formunicipio.descricao.value = document.formunicipio.descricao.value.toUpperCase();

}
//fim cadastro de municipio

//inicio registra chamado
function validacampo()
{
    if (document.formregchamado.tpchamado.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe  tipo de  chamado.");
        document.formregchamado.tpchamado.focus();
        return false;
    }

    if (document.formregchamado.programa.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe  o programa para atendimento.");
        document.formregchamado.programa.focus();
        return false;
    }

    if (document.formregchamado.problema.value == "")
    {
        alert("Campo obrigat�rio. Descreva o defeito verificado.");
        document.formregchamado.problema.focus();
        return false;

    }

    if (document.formregchamado.respabertura.value == "")
    {
        alert("Campo obrigat�rio. Descreva o nome do respos�vel pela abertura do chamado.");
        document.formregchamado.respabertura.focus();
        return false;
    }


    if (confirm("Confirma Abertura do Achamado ? "))
    {
        return true;
    }
    else
    {
        document.formregchamado.escola.focus();
        return false;
    }

}

function validacampoequipamento()
{

    if (document.form1.origem.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o Tipo da Entrada.");
        document.form1.origem.focus();
        return false;
    }


    if (document.form1.origem.value == "SECRETARIA")
    {
        if (document.form1.departamento.value.length == 0)
        {
            alert("Campo Obrigat�rio. Informe a Ger�ncia ou Departamento de Origem.");
            document.form1.departamento.focus();
            return false;
        }
    }

    else if (document.form1.origem.value == "ESCOLA")
    {
        if (document.form1.inep.value == "")
        {
            alert("Campo obrigat�rio. Informe o INEP da Escola.");
            document.form1.inep.focus();
            return false;
        }
    }


    if (document.form1.tptecnico.value == "")
    {
        alert("Campo obrigat�rio. Informe o tipo do t�cnico .");
        document.form1.tptecnico.focus();
        return false;

    }



    if (document.form1.tptecnico.value == "TERCERIZADO")
    {
        if (document.form1.empresa.value == "")
        {
            alert("Campo obrigat�rio. Informe o nome da Empresa.");
            document.form1.empresa.focus();
            return false;
        }
    }




    if (document.form1.equipamento.value == "")
    {
        alert("Campo obrigat�rio. Informe a Descri��o do equipamento.");
        document.form1.equipamento.focus();
        return false;

    }

    if (document.form1.patrimonio.value == "")
    {
        alert("Campo obrigat�rio. Informe o patrim�nio ou a s�rie do equipamento.");
        document.form1.patrimonio.focus();
        return false;

    }


    if (document.form1.problema.value == "")
    {
        alert("Campo obrigat�rio. Descreva o poss�vel problema.");
        document.form1.problema.focus();
        return false;

    }


    if (document.form1.respabertura.value == "")
    {
        alert("Campo obrigat�rio. Informe o nome do respons�vel pela entraga do equipamento.");
        document.form1.respabertura.focus();
        return false;

    }


    if (document.form1.tecnico.value == "")
    {
        alert("Campo obrigat�rio. Descreva o nome do t�cnico para atender o chamado.");
        document.form1.tecnico.focus();
        return false;
    }


    if (confirm("Confirma Abertura da Ordem de Servi�o ? "))
    {
        return true;
    }
    else
    {
        document.form1.origem.focus();
        return false;
    }

}

function validaproinfo2010()
{
    if (document.form1.cpf.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o seu CPF.");
        document.form1.cpf.focus();
        return false;
    }
    else if (document.form1.nome.value == "")
    {
        alert("Campo obrigat�rio. Informe o nome .");
        document.form1.nome.focus();
        return false;

    }

    else if (document.form1.fone1.value == "")
    {
        alert("Campo obrigat�rio. Informe telefone para contato.");
        document.form1.fone1.focus();
        return false;

    }

    else if (document.form1.fone2.value == "")
    {
        alert("Campo obrigat�rio. Informe telefone para contato.");
        document.form1.fone2.focus();
        return false;

    }
    else if (document.form1.fone3.value == "")
    {
        alert("Campo obrigat�rio. Informe telefone para contato.");
        document.form1.fone3.focus();
        return false;

    }
    else if (document.form1.oficina.value == "")
    {
        alert("Campo obrigat�rio. Informe a oficina.");
        document.form1.oficina.focus();
        return false;
    }

    else if (document.form1.municipio.value == "")
    {
        alert("Campo obrigat�rio. Informe o munic�pio de origem da sua inscri��o.");
        document.form1.municipio.focus();
        return false;

    }

    else if (document.form1.funcao.value == "")
    {
        alert("Campo obrigat�rio. Informe a sua fun��o.");
        document.form1.funcao.focus();
        return false;
    }
    else if (document.form1.formacao.value == "")
    {
        alert("Campo obrigat�rio. Selecione a sua forma��o.");
        document.form1.formacao.focus();
        return false;
    }

    else if (document.form1.fezcurso.value == "")
    {
        alert("Campo obrigat�rio. Selecione <SIM>Caso tenho feito qualquer curso de inform�tica <N>Nunca Fez curso de inform�tica");
        document.form1.fezcurso.focus();
        return false;
    }

    if (confirm("Confirma sua inscri��o ? "))
    {
        return true;
    }
    else
    {
        document.form1.cpf.focus();
        return false;
    }

}

function validacamposecretariagti()
{

    if (document.formregchamado.departamento.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o departamento.");
        document.formregchamado.departamento.focus();
        return false;
    }

    if (document.formregchamado.tptecnico.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe o V�nculo T�cnico.");
        document.formregchamado.tptecnico.focus();
        return false;
    }

    if (document.formregchamado.empresa.value == "")
    {
        alert("Campo obrigat�rio. Informe a empresa.");
        document.formregchamado.empresa.focus();
        return false;

    }


    if (document.formregchamado.problema.value == "")
    {
        alert("Campo obrigat�rio. Informe poss�vel problema.");
        document.formregchamado.problema.focus();
        return false;

    }



    if (document.formregchamado.respabertura.value == "")
    {
        alert("Campo obrigat�rio. Informe o nome do respos�vel para atender o chamado.");
        document.formregchamado.respabertura.focus();
        return false;
    }


    if (document.formregchamado.nometecnico.value == "")
    {
        alert("Campo obrigat�rio. Informe o nome do t�cnico respons�vel pela chamado.");
        document.formregchamado.nometecnico.focus();
        return false;
    }


    if (confirm("Confirma Abertura do Achamado ? "))
    {
        return true;
    }
    else
    {
        document.formregchamado.departamento.focus();
        return false;
    }

}

function validacampochescolagti()
{
    if (document.formregchamado.programa.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe  tipo de  chamado.");
        document.formregchamado.programa.focus();
        return false;
    }

    if (document.formregchamado.circuito.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe  o N� do Circuito.");
        document.formregchamado.circuito.focus();
        return false;
    }


    if (document.formregchamado.problema.value == "")
    {
        alert("Campo obrigat�rio. Descreva o poss�vel problema.");
        document.formregchamado.problema.focus();
        return false;

    }

    if (document.formregchamado.respabertura.value == "")
    {
        alert("Campo obrigat�rio. Descreva o nome do respos�vel pela abertura do chamado.");
        document.formregchamado.respabertura.focus();
        return false;
    }


    if (document.formregchamado.nometecnico.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe  o nome do t�cnico respons�vel para atender o chamado.");
        document.formregchamado.nometecnico.focus();
        return false;
    }


    if (confirm("Confirma Abertura do Achamado ? "))
    {
        return true;
    }
    else
    {
        document.formregchamado.programa.focus();
        return false;
    }

}

function validaformpequisante()
{

    if (document.form2.dtinicial.value == "")
    {
        alert("Campo Obrigat�rio. Informe a Data Inicial.");
        document.form2.dtinicial.focus();
        return false;
    }


    if (document.form2.dtfinal.value == "")
    {
        alert("Campo Obrigat�rio. Informe Data Final.");
        document.form2.dtfinal.focus();
        return false;
    }


    if (confirm("Confirma Gera��o do Relat�rio ? "))
    {
        return true;
    }
    else
    {
        document.form2.dtinicial.focus();
        return false;
    }

}

function validaformpequisapassagem()
{
    if (document.form2.dtinicial.value == "")
    {
        alert("Campo Obrigat�rio. Informe a Data Inicial.");
        document.form2.dtinicial.focus();
        return false;
    }


    if (document.form2.dtfinal.value == "")
    {
        alert("Campo Obrigat�rio. Informe Data Final.");
        document.form2.dtfinal.focus();
        return false;
    }

    /*if (document.form2.opcao.value=="4")   
     {  
     alert("oi");
     if (document.form2.tecnico.value=="") 
     { 
     alert("Campo Obrigat�rio. Informe o nome do benefici�rio.");   
     document.form2.tecnico.focus();
     return false;
     }
     }
     */


    if (confirm("Confirma Gera��o do Relat�rio ? "))
    {
        return true;
    }
    else
    {
        document.form2.dtinicial.focus();
        return false;
    }

}

function maiuscula()
{
    document.formregchamado.respabertura.value = document.formregchamado.respabertura.value.toUpperCase();
    document.formregchamado.problema.value = document.formregchamado.problema.value.toUpperCase();
}

function maiusculaequipamento()
{
    document.form1.equipamento.value = document.form1.equipamento.value.toUpperCase();
    document.form1.patrimonio.value = document.form1.patrimonio.value.toUpperCase();
    document.form1.problema.value = document.form1.problema.value.toUpperCase();
    document.form1.tecnico.value = document.form1.tecnico.value.toUpperCase();
    document.form1.obs.value = document.form1.obs.value.toUpperCase();
    document.form1.respabertura.value = document.form1.respabertura.value.toUpperCase();
    document.form1.problema.value = document.form1.problema.value.toUpperCase();
}


function maiusculasecretagti()
{
    document.formregchamado.respabertura.value = document.formregchamado.respabertura.value.toUpperCase();
    document.formregchamado.problema.value = document.formregchamado.problema.value.toUpperCase();
    document.formregchamado.observacao.value = document.formregchamado.observacao.value.toUpperCase();
    document.formregchamado.nometecnico.value = document.formregchamado.nometecnico.value.toUpperCase();
}

function maiusculaescolagti()
{
    document.formregchamado.respabertura.value = document.formregchamado.respabertura.value.toUpperCase();
    document.formregchamado.problema.value = document.formregchamado.problema.value.toUpperCase();
    document.formregchamado.circuito.value = document.formregchamado.circuito.value.toUpperCase();
    document.formregchamado.nometecnico.value = document.formregchamado.nometecnico.value.toUpperCase();
}


//fim registro  chamada
function entrada()
{
    window.location = "bem vindo.html";
}

function formatar(src, mask)
{
    var i = src.value.length;
    var saida = mask.substring(0, 1);
    var texto = mask.substring(i)
    if (texto.substring(0, 1) != saida)
    {
        src.value += texto.substring(0, 1);
    }
}

function Enum(num) {

    var tecla = num.which;
//alert(tecla);
    if (document.all)
        var tecla = event.keyCode;
    else if (document.layers)
        var tecla = num.which;

//alert(tecla);
    if (((tecla > 47) && (tecla < 58)) || (tecla == 0))
    {
        return true;
    }
    else
    {
        if (tecla == 8)
            return true
        if (tecla != 8)
            return false
        else
            return false;
    }
}

function Hoje() {
    ContrRelogio = setTimeout("Hoje()", 1000)
    Hr = new Date()
    dd = Hr.getDate()
    mm = Hr.getMonth() + 1
    aa = Hr.getYear()
    if (aa < 1000)
        aa += 1900


    hh = Hr.getHours()
    min = Hr.getMinutes()
    seg = Hr.getSeconds()
    DataAtual = ((dd < 10) ? "0" + dd + "/" : dd + "/")
    DataAtual += ((mm < 10) ? "0" + mm + "/" + aa : mm + "/" + aa)
    HoraAtual = ((hh < 10) ? "0" + hh + ":" : hh + ":")
    HoraAtual += ((min < 10) ? "0" + min + ":" : min + ":")
    HoraAtual += ((seg < 10) ? "0" + seg : seg)
    document.cadastro.data.value = DataAtual
    document.cadastro.hora.value = HoraAtual
    return true;
}

var dayarray = new Array("Domingo", "Segunda", "Ter�a", "Quarta", "Quinta", "Sexta", "S�bado")
var montharray = new Array("Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "agosto", "Setembro", "Outubro", "Novembro", "Dezembro")

function getthedate() {
    var mydate = new Date()
    var year = mydate.getYear()
    if (year < 1000)
        year += 1900
    var day = mydate.getDay()
    var month = mydate.getMonth()
    var daym = mydate.getDate()
    if (daym < 10)
        daym = "0" + daym
    var hours = mydate.getHours()
    var minutes = mydate.getMinutes()
    var seconds = mydate.getSeconds()
    var dn = "AM"
    if (hours >= 12)
        dn = "PM"
    if (hours > 12) {
        hours = hours - 12
    }
    if (hours == 0)
        hours = 12
    if (minutes <= 9)
        minutes = "0" + minutes
    if (seconds <= 9)
        seconds = "0" + seconds
//change font size here
    var cdate = "<small><font color='000000' face='Verdana'>" + dayarray[day] + " -  " + montharray[month] + " " + daym + ", " + year + " " + hours + ":" + minutes + ":" + seconds + " " + dn
            + "</font></small>"
    if (document.all)
        document.all.clock.innerHTML = cdate
    else if (document.getElementById)
        document.getElementById("clock").innerHTML = cdate
    else
        document.write(cdate)
}
if (!document.all && !document.getElementById)
    getthedate()
function goforit() {
    if (document.all || document.getElementById)
        setInterval("getthedate()", 1000)
}

function mascaraData(campoData) {
    var data = campoData;

    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formtecnico.dtemissaorg.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formtecnico.dtemissaorg.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formtecnico.dtemissaorg.value.substring(0, 2));
        mes = (document.formtecnico.dtemissaorg.value.substring(3, 5));
        ano = (document.formtecnico.dtemissaorg.value.substring(6, 10));
        document.formtecnico.dtemissaorg1.value = (ano + "." + mes + "." + dia);


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formtecnico.dtemissaorg.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formtecnico.dtemissaorg.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formtecnico.dtemissaorg.sefocus();
            situacao = "falsa";
        }


        dia = (document.formtecnico.dtemissaorg.value.substring(0, 2));
        mes = (document.formtecnico.dtemissaorg.value.substring(3, 5));
        ano = (document.formtecnico.dtemissaorg.value.substring(6, 10));
        document.formtecnico.dtemissaorg1.value = (ano + "." + mes + "." + dia);
        return true;
    }




}//fim

function MascaraDatainicial(campoData) {
    var data = campoData;

    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formpesquisachamdo.dtinicial.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formpesquisachamdo.dtinicial.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formpesquisachamdo.dtinicial.value.substring(0, 2));
        mes = (document.formpesquisachamdo.dtinicial.value.substring(3, 5));
        ano = (document.formulario.dtinicial.value.substring(6, 10));

        document.formpesquisachamdo.dtinicial.value = (ano + "." + mes + "." + dia);


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formpesquisachamdo.dtinicial.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formpesquisachamdo.dtinicial.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formpesquisachamdo.dtinicial.sefocus();
            situacao = "falsa";
        }


        dia = (document.formpesquisachamdo.dtinicial.value.substring(0, 2));
        mes = (document.formpesquisachamdo.dtinicial.value.substring(3, 5));
        ano = (document.formpesquisachamdo.dtinicial.value.substring(6, 10));
        document.formpesquisachamdo.dtinicial.value = (ano + "." + mes + "." + dia);
        return true;
    }

}//fim

function verifica_data() {

    dia = (document.forms[0].data.value.substring(0, 2));
    mes = (document.forms[0].data.value.substring(3, 5));
    ano = (document.forms[0].data.value.substring(6, 10));

    situacao = "";
    // verifica o dia valido para cada mes 
    if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31) {
        situacao = "falsa";
    }

    // verifica se o mes e valido 
    if (mes < 01 || mes > 12) {
        situacao = "falsa";
    }

    // verifica se e ano bissexto 
    if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4)))) {
        situacao = "falsa";
    }

    if (document.forms[0].data.value == "") {
        situacao = "falsa";
    }

    if (situacao == "falsa") {
        alert("Data inv�lida!");
        document.forms[0].data.focus();
    }
}

function mascara_hora(hora) {
    var myhora = '';
    myhora = myhora + hora;
    if (myhora.length == 2) {
        myhora = myhora + ':';
        document.forms[0].hora.value = myhora;
    }
    if (myhora.length == 5) {
        verifica_hora();
    }
}

function verifica_hora() {
    hrs = (document.forms[0].hora.value.substring(0, 2));
    min = (document.forms[0].hora.value.substring(3, 5));

    alert('hrs ' + hrs);
    alert('min ' + min);

    situacao = "";
    // verifica data e hora 
    if ((hrs < 00) || (hrs > 23) || (min < 00) || (min > 59)) {
        situacao = "falsa";
    }

    if (document.forms[0].hora.value == "") {
        situacao = "falsa";
    }

    if (situacao == "falsa") {
        alert("Hora inv�lida!");
        document.forms[0].hora.focus();
    }
}

function FormataValor(campo, tammax, teclapres) {
    var tecla = teclapres.keyCode;
    vr = document.form[campo].value;
    vr = vr.replace("/", "");
    vr = vr.replace("/", "");
    vr = vr.replace(",", "");
    vr = vr.replace(".", "");
    vr = vr.replace(".", "");
    vr = vr.replace(".", "");
    vr = vr.replace(".", "");
    tam = vr.length;
    if (tam < tammax && tecla != 8) {
        tam = vr.length;
    }
    if (tecla == 8) {
        tam = tam - 1;
    }
    if (tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105) {
        if (tam <= 2) {
            document.form[campo].value = vr;
        }
        if ((tam > 2) && (tam <= 5)) {
            document.form[campo].value = vr.substr(0, tam - 2) + ',' + vr.substr(tam - 2, tam);
        }
        if ((tam >= 6) && (tam <= 8)) {
            document.form[campo].value = vr.substr(0, tam - 5) + '.' + vr.substr(tam - 5, 3) + ',' + vr.substr(tam - 2, tam);
        }
        if ((tam >= 9) && (tam <= 11)) {
            document.form[campo].value = vr.substr(0, tam - 8) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) + ',' + vr.substr(tam - 2, tam);
        }
        if ((tam >= 12) && (tam <= 14)) {
            document.form[campo].value = vr.substr(0, tam - 11) + '.' + vr.substr(tam - 11, 3) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) + ',' + vr.substr(tam - 2, tam);
        }
        if ((tam >= 15) && (tam <= 17)) {
            document.form[campo].value = vr.substr(0, tam - 14) + '.' + vr.substr(tam - 14, 3) + '.' + vr.substr(tam - 11, 3) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) + ',' + vr.substr(tam - 2, tam);
        }
    }
}

function mascdtinicio(campoData)
{
    var data = campoData;



    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.form2.dtinicial.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.form2.dtinicial.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.form2.dtinicial.value.substring(0, 2));
        mes = (document.form2.dtinicial.value.substring(3, 5));
        ano = (document.form2.dtinicial.value.substring(6, 10));

//		 document.form2.dtinicial.value  = (ano+ "."+mes + "." +dia);

        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.form2.dtinicial.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.form2.dtinicial.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.form2.dtinicial.sefocus();
            situacao = "falsa";
        }


        dia = (document.form2.dtinicial.value.substring(0, 2));
        mes = (document.form2.dtinicial.value.substring(3, 5));
        ano = (document.form2.dtinicial.value.substring(6, 10));
        // document.form2.dtinicial.value  = (ano+ "."+mes + "." +dia);
        return true;
    }

}

function mascdtfinal(campoData)
{
    var data = campoData;



    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.form2.dtfinal.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.form2.dtfinal.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.form2.dtfinal.value.substring(0, 2));
        mes = (document.form2.dtfinal.value.substring(3, 5));
        ano = (document.form2.dtfinal.value.substring(6, 10));

//		 document.form2.dtinicial.value  = (ano+ "."+mes + "." +dia);

        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.form2.dtfinal.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.form2.dtfinal.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.form2.dtfinal.sefocus();
            situacao = "falsa";
        }


        dia = (document.form2.dtfinal.value.substring(0, 2));
        mes = (document.form2.dtfinal.value.substring(3, 5));
        ano = (document.form2.dtfinal.value.substring(6, 10));
        return true;
    }

}

function mascdtinicioregaula(campoData)
{
    var data = campoData;



    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formregistroaula.dtinicial.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formregistroaula.dtinicial.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formregistroaula.dtinicial.value.substring(0, 2));
        mes = (document.formregistroaula.dtinicial.value.substring(3, 5));
        ano = (document.formregistroaula.dtinicial.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formregistroaula.dtinicial.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formregistroaula.dtinicial.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formregistroaula.dtinicial.sefocus();
            situacao = "falsa";
        }


        dia = (document.formregistroaula.dtinicial.value.substring(0, 2));
        mes = (document.formregistroaula.dtinicial.value.substring(3, 5));
        ano = (document.formregistroaula.dtinicial.value.substring(6, 10));
        // document.form2.dtinicial.value  = (ano+ "."+mes + "." +dia);
        return true;
    }

}

function mascdtfinalregaula(campoData)
{
    var data = campoData;



    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formregistroaula.dtfinal.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formregistroaula.dtfinal.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formregistroaula.dtfinal.value.substring(0, 2));
        mes = (document.formregistroaula.dtfinal.value.substring(3, 5));
        ano = (document.formregistroaula.dtfinal.value.substring(6, 10));

//		 document.form2.dtinicial.value  = (ano+ "."+mes + "." +dia);

        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formregistroaula.dtfinal.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formregistroaula.dtfinal.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formregistroaula.dtfinal.sefocus();
            situacao = "falsa";
        }


        dia = (document.formregistroaula.dtfinal.value.substring(0, 2));
        mes = (document.formregistroaula.dtfinal.value.substring(3, 5));
        ano = (document.formregistroaula.dtfinal.value.substring(6, 10));
        return true;
    }

}

function mascaraDTgenda(campoData) {

    var data = campoData;
    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formagenda.dtagenda.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formagenda.dtagenda.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formagenda.dtagenda.value.substring(0, 2));
        mes = (document.formagenda.dtagenda.value.substring(3, 5));
        ano = (document.formagenda.dtagenda.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formagenda.dtagenda.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formagenda.dtagenda.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formagenda.dtagenda.sefocus();
            situacao = "falsa";
        }


        dia = (document.formagenda.dtagenda.value.substring(0, 2));
        mes = (document.formagenda.dtagenda.value.substring(3, 5));
        ano = (document.formagenda.dtagenda.value.substring(6, 10));

        return true;
    }

}

function mascaraDTpassagem(campoData) {

    var data = campoData;
    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.form.dtagenda.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.form.dtagenda.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.form.dtagenda.value.substring(0, 2));
        mes = (document.form.dtagenda.value.substring(3, 5));
        ano = (document.form.dtagenda.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.form.dtagenda.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.form.dtagenda.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.form.dtagenda.sefocus();
            situacao = "falsa";
        }


        dia = (document.form.dtagenda.value.substring(0, 2));
        mes = (document.form.dtagenda.value.substring(3, 5));
        ano = (document.form.dtagenda.value.substring(6, 10));

        return true;
    }

}

function mascaraDTBxAgenda(campoData) {

    var data = campoData;
    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.baixaagenda.dtagenda1.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.baixaagenda.dtagenda1.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.baixaagenda.dtagenda1.value.substring(0, 2));
        mes = (document.baixaagenda.dtagenda1.value.substring(3, 5));
        ano = (document.baixaagenda.dtagenda1.value.substring(6, 10));


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.baixaagenda.dtagenda1.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.baixaagenda.dtagenda1.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.baixaagenda.dtagenda1.sefocus();
            situacao = "falsa";
        }


        dia = (document.baixaagenda.dtagenda1.value.substring(0, 2));
        mes = (document.baixaagenda.dtagenda1.value.substring(3, 5));
        ano = (document.baixaagenda.dtagenda1.value.substring(6, 10));

        return true;
    }

}

function validatrecho()
{

    if (document.form.descricao.value == "")
    {
        alert("Campo obrigat�rio. Informe o trecho.");
        document.form.descricao.focus();
        return false;

    }

    if ((document.form.saldo.value == "") || (document.form.saldo.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o saldo de passagens.");
        document.form.saldo.focus();
        return false;

    }

    if ((document.form.ano.value == ""))
    {
        alert("Campo obrigat�rio. Informe o a.");
        document.form.ano.focus();
        return false;
    }


    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.descricao.focus();
        return false;
    }

}

function validatrecho()
{

    if (document.form.descricao.value == "")
    {
        alert("Campo obrigat�rio. Informe o trecho.");
        document.form.descricao.focus();
        return false;

    }

    if ((document.form.saldo.value == "") || (document.form.saldo.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o saldo de passagens.");
        document.form.saldo.focus();
        return false;

    }

    if ((document.form.ano.value == ""))
    {
        alert("Campo obrigat�rio. Informe o a.");
        document.form.ano.focus();
        return false;
    }


    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.descricao.focus();
        return false;
    }

}

function validaprocessopassagem()
{

    if (document.form.processo.value == "")
    {
        alert("Campo obrigat�rio. Informe o N� do Processo.");
        document.form.processo.focus();
        return false;

    }

    if ((document.form.ne.value == "") || (document.form.ne.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o N� da Nota de Empenho.");
        document.form.ne.focus();
        return false;

    }



    if ((document.form.dtprocesso.value == "") || (document.form.dtprocesso.value == "0"))
    {
        alert("Campo obrigat�rio. Informe a Data do Processo.");
        document.form.dtprocesso.focus();
        return false;

    }



    if ((document.form.saldo.value == "") || (document.form.saldo.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o saldo de passagens.");
        document.form.saldo.focus();
        return false;

    }

    if ((document.form.ano.value == "") || (document.form.ano.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o ano do processo.");
        document.form.ano.focus();
        return false;

    }


    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.processo.focus();
        return false;
    }

}

function validatrechopassagem()
{

    if (document.form.trecho.value == "")
    {
        alert("Campo obrigat�rio. Informe o trecho.");
        document.form.trecho.focus();
        return false;

    }

    if ((document.form.saldo.value == "") || (document.form.saldo.value == "0"))
    {
        alert("Campo obrigat�rio. Informe o saldo de passagens.");
        document.form.saldo.focus();
        return false;

    }


    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.descricao.focus();
        return false;
    }

}

function validaentregapassagem()
{

    if (document.form.cpf.value == "")
    {
        alert("Campo obrigat�rio. Informe o CPF.");
        document.form.cpf.focus();
        return false;

    }

    if ((document.form.nome.value == ""))
    {
        alert("Campo obrigat�rio. Informe o Nome do Benefici�rio.");
        document.form.nome.focus();
        return false;
    }


    if ((document.form.trecho.value == ""))
    {
        alert("Campo obrigat�rio. Informe o Nome do Benefici�rio.");
        document.form.trecho.focus();
        return false;
    }

    if ((document.form.objetivo.value == ""))
    {
        alert("Campo obrigat�rio. Descreva o objetivo.");
        document.form.objetivo.focus();
        return false;
    }
    if ((document.form.qtda.value == "") || (document.form.qtda.value == "0"))
    {
        alert("Campo obrigat�rio. Informe a Quantidade de passagens.");
        document.form.qtda.focus();
        return false;
    }

    if (document.form.dtagenda.value == "")
    {
        alert("Campo obrigat�rio. Informe data de entrega.");
        document.form.dtagenda.focus();
        return false;
    }





    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.descricao.focus();
        return false;
    }

}

function validaentregapassagemsemcpf()
{


    if ((document.form.nome.value == ""))
    {
        alert("Campo obrigat�rio. Informe o Nome do Benefici�rio.");
        document.form.nome.focus();
        return false;
    }


    if ((document.form.trecho.value == ""))
    {
        alert("Campo obrigat�rio. Informe o Nome do Benefici�rio.");
        document.form.trecho.focus();
        return false;
    }

    if ((document.form.objetivo.value == ""))
    {
        alert("Campo obrigat�rio. Descreva o objetivo.");
        document.form.objetivo.focus();
        return false;
    }

    if ((document.form.observacao.value == ""))
    {
        alert("Campo obrigat�rio. Justifique o motivo que o benefici�rio n�o possui Documento Oficial.");
        document.form.observacao.focus();
        return false;
    }

    if ((document.form.qtda.value == "") || (document.form.qtda.value == "0"))
    {
        alert("Campo obrigat�rio. Informe a Quantidade de passagens.");
        document.form.qtda.focus();
        return false;
    }

    if (document.form.dtagenda.value == "")
    {
        alert("Campo obrigat�rio. Informe data de entrega.");
        document.form.dtagenda.focus();
        return false;
    }





    if (confirm("Confirma os dados ? "))
    {
        return true;
    }
    else
    {
        document.form.descricao.focus();
        return false;
    }

}

function calculodiarias()
{
    var num1 = (document.form1.qtdadiarias.value);
    var num2 = (document.form1.vlrunit.value);

    var vltotal = new Number();


    vltotal = (num1.replace(",", ".")) * (num2.replace(",", "."))

    document.form1.vlrtotal.value = vltotal.toFixed(2);

}

function validacaddiarias()
{



    if (document.form1.cpf.value == "")
    {
        alert("Campo Obrigat�rio. Informe o seu CPF.");
        document.form1.cpf.focus();
        return false;
    }



    else if (document.form1.departamento.value == "")
    {
        alert("Campo obrigat�rio. Informe o Departamento Solicitante.");
        document.form1.departamento.focus();
        return false;

    }

    else if (document.form1.processo.value == "")
    {
        alert("Campo obrigat�rio. Informe o nr do processor.");
        document.form1.processo.focus();
        return false;

    }

    else if (document.form1.ano.value == "")
    {
        alert("Campo obrigat�rio. Informe o ano do processor.");
        document.form1.ano.focus();
        return false;

    }

    else if (document.form1.destino.value == "")
    {
        alert("Campo obrigat�rio. Informe o destino.");
        document.form1.destino.focus();
        return false;

    }

    else if ((document.form1.chkaereo.checked == false) && (document.form1.chkfluvial.checked == false) && (document.form1.chkterrestre.checked == false))
    {
        {
            alert("Usu�rio, Informe pelo menos um meio de transporte.");
            document.form1.destino.focus();
            return false;
        }
    }



    else if (document.form1.dtinicio.value == "")
    {
        alert("Campo obrigat�rio. Informe a data inicial da viagem.");
        document.form1.dtinicio.focus();
        return false;
    }


    else if (document.form1.dtfim.value == "")
    {
        alert("Campo obrigat�rio. Informe a data final da viagem.");
        document.form1.dtfim.focus();
        return false;

    }

    else if (document.form1.qtdadiarias.value == "0,00")
    {
        alert("Campo obrigat�rio. Informe a quantidade de dias que o servidor passara viajando.");
        document.form1.dtfim.focus();
        return false;

    }

    else if (document.form1.vlrunit.value == "0,00")
    {
        alert("Campo obrigat�rio. Informe o valor unit�ria.");
        document.form1.vlrunit.focus();
        return false;

    }


    /*
     else  if (document.form1.cronograma.value=="")
     
     alert("Campo obrigat�rio. Informe Cronograma da Viagem.");   
     document.form1.cronograma.focus();
     return false;
     }     
     */
    if (confirm("Confirma a concess�o ? "))
    {
        return true;
    }
    else
    {
        document.form1.cpf.focus();
        return false;
    }

}

function validaindexconcurso()
{


    if (document.formconcurso.habilitacao.value == "")
    {
        alert("Campo obrigat�rio, Selecione sua habilita��o.");
        document.formconcurso.habilitacao.focus();
        return false;
    }

}

function validaconcurso()
{

    if (document.formconcurso.localvaga.value == "")
    {
        alert("Campo obrigat�rio, Selecione o local de vaga.");
        document.formconcurso.localvaga.focus();
        return false;
    }

    if (document.formconcurso.habilitacao.value == "")
    {
        alert("Campo obrigat�rio, Selecione sua habilita��o.");
        document.formconcurso.habilitacao.focus();
        return false;
    }

    if (document.formconcurso.nome.value == "")
    {
        alert("Campo obrigat�rio, Informe seu nome.");
        document.formconcurso.nome.focus();
        return false;
    }

    if (document.formconcurso.dtnascimento.value.length == 0)
    {
        alert("Campo Obrigat�rio. Informe a data de nascimento.");
        document.formconcurso.dtnascimento.focus();
        return false;
    }


    if (document.formconcurso.cpf.value == "")
    {
        alert("Campo obrigat�rio, Informe o CPF.");
        document.formconcurso.cpf.focus();
        return false;
    }

    if (document.formconcurso.rg.value == "")
    {
        alert("Campo obrigat�rio, Informe o RG.");
        document.formconcurso.rg.focus();
        return false;
    }


    if (document.formconcurso.orgaoexp.value == "")
    {
        alert("Campo obrigat�rio, Informe o Org�o de Expedi��o da Carteira Identidade.");
        document.formconcurso.orgaoexp.focus();
        return false;
    }


    if (document.formconcurso.endereco.value == "")
    {
        alert("Campo obrigat�rio, Informe o seu endere�o.");
        document.formconcurso.endereco.focus();
        return false;
    }
    if (document.formconcurso.bairro.value == "")
    {
        alert("Campo obrigat�rio, Informe o bairro.");
        document.formconcurso.bairro.focus();
        return false;
    }

    if (document.formconcurso.nr.value == "")
    {
        alert("Campo obrigat�rio, Informe o n�mero.");
        document.formconcurso.nr.focus();
        return false;
    }

    if (document.formconcurso.cep.value == "")
    {
        alert("Campo obrigat�rio, Informe o CEP.");
        document.formconcurso.cep.focus();
        return false;
    }


    if (confirm("....Confirma dados para grava��o."))
    {
        return true;
    }
    else
    {
        document.formconcurso.localvaga.focus();
        return false;
    }

}


function mascaraDataconcurso(campoData) {
    var data = campoData;

    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formconcurso.dtemissaorg.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formconcurso.dtemissaorg.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formconcurso.dtemissaorg.value.substring(0, 2));
        mes = (document.formconcurso.dtemissaorg.value.substring(3, 5));
        ano = (document.formconcurso.dtemissaorg.value.substring(6, 10));
        document.formconcurso.dtemissaorg1.value = (ano + "." + mes + "." + dia);


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formconcurso.dtemissaorg.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formconcurso.dtemissaorg.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formconcurso.dtemissaorg.sefocus();
            situacao = "falsa";
        }


        dia = (document.formconcurso.dtemissaorg.value.substring(0, 2));
        mes = (document.formconcurso.dtemissaorg.value.substring(3, 5));
        ano = (document.formconcurso.dtemissaorg.value.substring(6, 10));
        document.formconcurso.dtemissaorg1.value = (ano + "." + mes + "." + dia);
        return true;
    }




}//fim

function mascaraDataconcurso1(campoData) {
    var data = campoData;

    if (data.length == 2) {
        dia = data;
        data = data + '/';
        document.formconcurso.dtnascimento.value = data;

        return true;
    }
    if (data.length == 5)
    {
        data = data + '/';
        document.formconcurso.dtnascimento.value = data;

        return true;
    }

    if (data.length > 5)
    {

        dia = (document.formconcurso.dtnascimento.value.substring(0, 2));
        mes = (document.formconcurso.dtnascimento.value.substring(3, 5));
        ano = (document.formconcurso.dtnascimento.value.substring(6, 10));
        document.formconcurso.dtemissaorg1.value = (ano + "." + mes + "." + dia);


        situacao = "";
        // verifica o dia valido para cada mes 
        if ((dia < 01) || (dia < 01 || dia > 30) && (mes == 04 || mes == 06 || mes == 09 || mes == 11) || dia > 31)
        {
            alert("Dia Inv�lido.");
            document.formconcurso.dtnascimento.sefocus();
            situacao = "falsa";
        }


        // verifica se o mes e valido 
        if (mes < 01 || mes > 12)
        {
            alert("Dia Inv�lido.");
            document.formconcurso.dtnascimento.sefocus();
            situacao = "falsa";
        }

        if (mes == 2 && (dia < 01 || dia > 29 || (dia > 28 && (parseInt(ano / 4) != ano / 4))))
        {
            alert("M�s Inv�lido.");
            document.formconcurso.dtnascimento.sefocus();
            situacao = "falsa";
        }


        dia = (document.formconcurso.dtnascimento.value.substring(0, 2));
        mes = (document.formconcurso.dtnascimento.value.substring(3, 5));
        ano = (document.formconcurso.dtnascimento.value.substring(6, 10));
        document.formconcurso.dtemissaorg1.value = (ano + "." + mes + "." + dia);
        return true;
    }




}//fim