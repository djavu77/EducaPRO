<?

session_start();
if (isset($_SESSION["login_usuario"]))
  {
      $login =  $_SESSION["login_usuario"];
      $nte   =  $_SESSION["nivel_usuario"];
  	  $inep  =  $_SESSION["inep_usuario"] ;   
	
	  include ("funcoes.php");
      include ("../conexao_mysql.php");
 
 
 
  mysql_query("SET NAMES 'utf8'");
//ini_set('default_charset','UTF-8');	


      echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: login.php");
  }  	 




 

$id = $inep;
$sql = "select * from escola where inep = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta ))
 {
$codmuni=$linha["MUNICIPIO"];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>SEDUC-RO</title>


	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />	
	<link rel="stylesheet" href="tablecloth/tablecloth.css" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
    <script src="generic2.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>
    <script src="../script.js"></script>


<script>
</script>



</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>

<div id="content">
    <form name ="form" id="form" class="form" action="insere_escola_gestao.php" method="post" >

<div id="tabs">
			<ul>
				<li><a href="#tabs-1">Dados Escola</a></li>
				<li><a href="#tabs-2">Conselho Escolar</a></li>
			</ul>
<div id="tabs-1">
<p>
		<label for="lbldtemissaote">C�digo<img src= "img/check.gif"/></label>
         <input readonly="true"  name="codigo" id="codigo"  type="text" value="<?echo $id?>">
</p>


<p>
		<label for="lbldtemissaote">INEP<img src= "img/check.gif"/></label>
         <input  name="inep"  id="inep" readonly="true" size="10" maxlength="10" type="text" value = "<?echo $linha["INEP"];?>" onKeyPress="return Enum(event)"/>
</p>

 <p>
		<label for="lbldtemissaote">Descri��o<img src= "img/check.gif"/></label>
        <input  name="descricao" id="descricao" size="60" maxlength="60" type="text" value="<?echo $linha["DESCRICAO"];?>" />
</p>

 <p>
 <label for="lbldtemissaote">Endere�o<img src= "img/check.gif"/></label>
 <input name="endereco" type="text" id="endereco" size="60" MAXLENGTH="60"  value="<?echo $linha["ENDERECO"];?>" />
 </p>


 <p>
 <label for="lbldtemissaote">Bairro<img src= "img/check.gif"/></label>
        <input name="bairro" type="text" id="bairro" size="40" MAXLENGTH="40" value="<?echo $linha["BAIRRO"];?>" />
 <label for="lbldtemissaote">N<img src= "img/check.gif"/></label>
  <input name="nr" type="text" id="nr" size="10" MAXLENGTH="4" value="<?echo $linha["NUMERO"];?>" onKeyPress="return Enum(event)" >

    <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
	<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" value="<?echo $linha["CEP"];?>" onKeyPress="return Enum(event)"/>


</p>

<p>
 <label for="lbldtemissaote">FONE<img src= "img/check.gif"/></label>
 <input name="fone" type="text" id="fone" size="20" MAXLENGTH="20" value="<?echo $linha["FONE"];?>" >
</p>



	   <p>
         <label for="lblcod_cpf">Diretor<img src= "img/check.gif"/></label>
         <input name="diretor" type="text" id="diretor" size="60" MAXLENGTH="60" value= "<?echo $linha["DIRETOR"];?>">
       </p>


	   <p>
         <label for="lblcod_cpf">Vice Diretor<img src= "img/check.gif"/></label>
		 <input name="vicediretor" type="text" id="vicediretor" size="60" maxlength="60" value= "<?echo $linha["VICEDIRETOR"];?>">
       </p>


 <p>		
  <label for="lbldeficienten">Fundamental Regular 1 a 5 </label>

<?
if ($linha["MODALIDADE1"]=='1')
{
?>
<label for="lbldeficienten"><input name="modalidade1" type="checkbox"  value ="1"  id="modalidade1" checked="checked"/> 
<?
}
else
{
?>
<input name="modalidade1" type="checkbox"  value ="1"  id="modalidade1" /> 
<?
}
?>


Fundamental Regular 6 a 9
<?
if ($linha["MODALIDADE2"]=='1')
{
?>
<input name="modalidade2" type="checkbox"     value ="1"  id="modalidade2" checked="checked"/></label>
<?
}
else
{
?>
<input name="modalidade2" type="checkbox"     value ="1"  id="modalidade2" /></label>
<?
}
?>
   



Fundamental Regular 1 a 9
<?
if ($linha["MODALIDADE3"]=='1')
{
?>
<input name="modalidade3" type="checkbox"     value ="1"  id="modalidade3" checked="checked"/>
<?
}
else
{
?>
<input name="modalidade3" type="checkbox"     value ="1"  id="modalidade3" /></label>
<?
}
?>
 		   


Fundamental EJA
<?
if ($linha["MODALIDADE3"]=='1')
{
?>
<input name="modalidade4" type="checkbox"     value ="1"  id="modalidade4" checked="checked"/>
<?
}
else
{
?>
<input name="modalidade4" type="checkbox"     value ="1"  id="modalidade4" /></label>
<?
}
?>
</p>



<p>		
 <label for="lbldeficienten">Ensino M�dio Regular</label>
<label for="lbldeficienten">
<?
if ($linha["MODALIDADE5"]=='1')
{
?>

  <input name="modalidade5" type="checkbox"  value ="1"  id="modalidade5" checked="checked"/>
  
<?
}
else
{
?>
  <input name="modalidade5" type="checkbox"  value ="1"  id="modalidade5" > 

<?
}
?>
 
</label> 
Ensino M�dio EJA

<?
if ($linha["MODALIDADE6"]=='1')
{
?>
  <input name="modalidade6" type="checkbox"  value ="1"  id="modalidade6" checked="checked"/>
<?
}
else
{
?>
  <input name="modalidade6" type="checkbox"  value ="1"  id="modalidade6" />

<?
}
?>




<label for="lbldeficienten">Educa��o Especial  

<?
if ($linha["MODALIDADE7"]=='1')
{
?>
<input name="modalidade7" type="checkbox"  value ="1"  id="modalidade7" checked="checked"/>
<?
}
else
{
?>
<input name="modalidade7" type="checkbox"  value ="1"  id="modalidade7" />
</label>
<?
}
?>


  </p>

<p>

					<label for="lblcod_estados">Munic�pio:</label>
					   <select name="cod_estado" id="cod_estado" >
					   <option value=""></option>
  					  <?php
						   $sql = "select codigo, descricao FROM municipio order by descricao"; 
						   $res = mysql_query($sql); 
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){ 
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $codmuni){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php 
							      } }
						        ?>
					   </select>
					</p>

<p>
 <label for="lbldtemissaote">Altera Zona<img src= "img/check.gif"/></label>
          <select name="tipo"/>
  	      	  
<?
if ($linha["TIPO"]=='RURAL')
{
?>
              <option value="RURAL">RURAL</option>
              <option value="URBANA">URBANA</option>
<?
}
else
{
?>
	          <option value="URBANA">URBANA</option>
			  <option value="RURAL">RURAL</option>
  
 <?
}
?>
 
  
            </select>



</p>








<p><br><font size="4">::Transi��o::</font> </p>			




		<p>
						 <label for="regularizacao">Ato Regulariza��o<img src= "img/check.gif"/></label>
 			               <select id="selectregularizacao" name="selectregularizacao" style="width:80px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>

						 <label for="regularizacao">Situa��o<img src= "img/check.gif"/></label>
 			               <select id="selectsituacao" name="selectsituacao" style="width:105px">
              		          <option value=""></option>
							  <option value="A">Autorizada</option>
            		          <option value="R">Reconhecida</option>
            		          <option value="I">Irregular</option>
    		               </select>



						<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtportaria"  style="width:140px" id="txtportaria" value="<?echo $linha["PORTARIA"];?>" maxlength="12" />
         </P>  


<P>
<label for="lbldtemissaote">Data Emiss�o<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemissao" id="txtdtemissao"  value="<? $data = date("d/m/Y",strtotime($linha["DTPORTARIA"]));   

 if ($data=='31/12/1969')
  {
	$data="";
	echo $data;
  }
else
{
 echo $data;
 }
 ?>" >


<label for="lbldtemissaote1">Data Validade<img src= "img/check.gif"/></label>
 <input name= "txtdtvalidade" type="text" id="txtdtvalidade" value="<? $data1 = date("d/m/Y",strtotime($linha["DTVALIDADE"]));

 if ($data1=='31/12/1969')
  {
	$data1="";
  }
 else
{
 echo $data1;
 }
 ?>" >

</p>	





<P>
 <label for="lbldtemissaote">Prof Estatut�rio<img src="img/check.gif"/></label>
 <input name="nprofessores" type="text" id="nprofessores" size="5" MAXLENGTH="5" value="<?echo $linha["NPROFESSORES"];?>" onKeyPress="return Enum(event)">


<label for="lbldtemissaote">Prof Emerg�ncial<img src=

"img/check.gif"/></label>
 <input name="nemergencial" type="text" id="nemergencial" size="5" MAXLENGTH="5" value="<?echo $linha["NEMERGENCIAL"];?>" onKeyPress="return Enum(event)">


 <label for="lbldtemissaote">T�c Administrativo<img src="img/check.gif"/></label>
 <input name="nadm" type="text" id="nadm" size="5" MAXLENGTH="5" value="<?echo $linha["NADMINISTRATIVO"];?>" onKeyPress="return Enum(event)">

 <label for="lbldtemissaote">Alunos<img src= "img/check.gif"/></label>
  <input name="nalunos" type="text" id="nalunos" size="5" MAXLENGTH="5" value="<?echo $linha["NALUNOS"];?>" onKeyPress="return Enum(event)">

</p>


 			     	<p>
						<label for="regularizacao">Patrim�nio<img src= "img/check.gif"/></label>
 			               <select id="selectpatrimonio" name="selectpatrimonio" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>

						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatuspatri" name="selectstatuspatri" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
            		          <option value="B">Bom</option>
            		          <option value="O">Otimo</option>
    		               </select>


					</p>


		     	 <p>

					<label for="regularizacao">Sala de Aula<img src= "img/check.gif"/></label>
				  <input type="text" name="txtqdtasala" value="0" style="width:30px" id="txtqdtasala" onKeyPress="return Enum(event)"/>
					</p>

  			     	<p>
						<label for="regularizacao">Sala de Leitura<img src= "img/check.gif"/></label>
 			               <select id="selectleitura" name="selectleitura" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>

					</p>

  			     	<p>
						<label for="regularizacao">Laborat�rio Inform�tica<img src= "img/check.gif"/></label>
 			               <select id="selectlie" name="selectlie" style="width:140px"/>
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>
					</p>

  			     	<p>
						<label for="regularizacao">Quadra de Esporte<img src= "img/check.gif"/></label>
 			               <select id="selectquadra" name="selectquadra" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>

						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatusqd" name="selectstatusqd" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
             		                 <option value="B">Bom</option>
            		                 <option value="O">Otimo</option>
                                      <option value="V">N�o Existe</option>

    		               </select>



						<label for="regularizacao">Coberta<img src= "img/check.gif"/></label>
 			               <select id="selectcoberta" name="selectcoberta" style="width:140px">
              		          <option value=""></option>
              		          <option value="S">Sim</option>
            		                 <option value="N">N�o</option>
    		                        <option value="V">N�o Existe</option>


					</select>




					</p>
  			     	<p>
						<label for="regularizacao">PDE<img src= "img/check.gif"/></label>
 			               <select id="selectpde" name="selectpde" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>
					</p>

  			     	<p>
						<label for="regularizacao">Programas<img src= "img/check.gif"/></label>
 			               <select id="selectprogramas" name="selectprogramas" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>
					<label for="regularizacao">Quantidade<img src= "img/check.gif"/></label>
				  <input type="text" name="txtqdtaprograma" value="0" style="width:30px" id="txtqdtaprograma" maxlength="4" onKeyPress="return Enum(event)"/>



					</p>



  			     	<p>
						<label for="regularizacao">Acervo Bibliografico<img src= "img/check.gif"/></label>
 			               <select id="selectacervo" name="selectacervo" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>


						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatus" name="selectstatus" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
            		          <option value="B">Bom</option>
            		          <option value="O">Otimo</option>
    		               </select>


					</p>

			 <p>  
			  <label for="lbldeficienten">IDEB<img src= "img/check.gif"/></label>
			  <input type="text" name="txtideb"  style="width:30px" id="txtideb" maxlength="3" value="<?echo $linha["IDEB"];?>" onKeyPress="return Enum(event)"/>
			  <label for="lbldeficienten">ENEM<img src= "img/check.gif"/></label>
			  <input type="text" name="txtenem"  style="width:30px" id="txtenem" maxlength="3" value="<?echo $linha["ENEM"];?>" onKeyPress="return Enum(event)"/>	
			  <label for="lbldeficienten">Prova Brasil<img src= "img/check.gif"/></label>
			  <input type="text" name="txtprasil"  style="width:30px" id="txtprasil" maxlength="3" value="<?echo $linha["PBRASIL"];?>" onKeyPress="return Enum(event)"/>
			 <label for="lbldeficienten">Provinha Brasil<img src= "img/check.gif"/></label>
			 <input type="text" name="txtprovlhabr"  style="width:30px" id="txtprovlhabr" maxlength="3" value="<?echo $linha["PROVINHABR"];?>" onKeyPress="return Enum(event)"/>

			 </p>  





  			     	<p>
						<label for="regularizacao">Fonte de Recurso<img src= "img/check.gif"/></label>
 			               <select id="selectfonte" name="selectfonte" style="width:140px">
              		          <option value="FNDE">FNDE</option>
            		          <option value="ESTADO">ESTADO</option>
							  <option value="OUTROS">OUTROS</option>
              		          <option value="FNDEESTADO">FNDE/ESTADO</option>
							  <option value="FNESOUTROS">FNDE/ESTADO/OUTROS</option>
    		               </select>

     	  			</p>

  			     	<p>
						<label for="regularizacao">Cantina Alugado<img src= "img/check.gif"/></label>
 			               <select id="selectcantina" name="selectcantina" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

     	  			</p>


  			     	<p>
						<label for="regularizacao">Mais Educa��o<img src= "img/check.gif"/></label>
 			               <select id="selectmais" name="selectmais" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

     	  			</p>




<p><br><font size="4">::Regularidade Fiscal::</font> </p>			


  			     	<p>
						<label for="regularizacao">Municipio<img src= "img/check.gif"/></label>
 			               <select id="fiscalmuni" name="fiscalmuni" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

						<label for="regularizacao" style="width:58px">Estado<img src= "img/check.gif"/></label>
 			                <select id="fiscalestado" name="fiscalestado" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

						<label for="regularizacao">Federal<img src= "img/check.gif"/></label>
 			               <select id="fiscalfedera" name="fiscalfedera" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>



     	  			</p>


  			     	<p>
						  <label for="regularizacao" style="width:49px">FGTS<img src= "img/check.gif"/></label>
 			              <select id="fiscalfgts" name="fiscalfgts" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>
     	  			
						<label for="regularizacao">Contabil<img src= "img/check.gif"/></label>
 			               <select id="contabil" name="contabil" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

						<label for="regularizacao" style="width:55px">INSS<img src= "img/check.gif"/></label>
 			               <select id="inss" name="inss" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>



					</p>


<p><br><font size="4">::Presta��o Contas 2010/2011::</font> </p>			

  			     	<p>
						<label for="regularizacao">PROAFI<img src= "img/check.gif"/></label>
 			               <select id="proafi" name="proafi" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

						<label for="regularizacao" style="width:60px">PNAE<img src= "img/check.gif"/></label>
 			               <select id="penai" name="penai" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>



     	  			</p>


  			     	<p>
						<label for="regularizacao">PROFIPES<img src= "img/check.gif"/></label>
 			               <select id="profipes" name="profipes" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>

						<label for="regularizacao" style="width:60px">PDE<img src= "img/check.gif"/></label>
 			               <select id="pde" name="pde" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">N�O</option>
    		               </select>


     	  			</p>





.</div>


<!--- Conselho de Educacao--> 
<div id="tabs-2">
<?
$id = $inep;




$sqlconselho = "select * from conselhoe where inep = $id";
$respostaconselho = mysql_query( $sqlconselho );
while ( $linhaconselho = mysql_fetch_array( $respostaconselho ))
   {

     $dtregistro    		   = date("d/m/Y",strtotime($linhaconselho["DTREGISTRO"]));
	 $dtinicio      		   = date("d/m/Y",strtotime($linhaconselho["DTINICIO"]));
	 $dtfim         		   = date("d/m/Y",strtotime($linhaconselho["DTFIM"]));



     $cnpj                     =$linhaconselho["CNPJ"]; 
     $presidente               =$linhaconselho["PRESIDENTE"];
     $suplente_pres            =$linhaconselho["SUPLENTE_PRES"];
     $secretariode             =$linhaconselho["SECRETARIO1DE"];	 
	 $suplente_secr1		   =$linhaconselho["SUPLENTE_SECR1"];
     $secretario2de            =$linhaconselho["SECRETARIO2DE"];
  	 $suplente_secr2		   =$linhaconselho["SUPLENTE_SECR2"];
 	 $conselhe1cap			   =$linhaconselho["CONSELHE1CAP"];
	 $suplente1cap			   =$linhaconselho["SUPLENTE1CAP"];
	 $conselhe2cap			   =$linhaconselho["CONSELHE2CAP"];
	 $suplente2cap			   =$linhaconselho["SUPLENTE2CAP"];
	 $conselhe3cap			   =$linhaconselho["CONSELHE3CAP"];
	 $suplente3cap			   =$linhaconselho["SUPLENTE3CAP"];
	 $conselhe4cap			   =$linhaconselho["CONSELHE4CAP"];
	 $suplente4cap			   =$linhaconselho["SUPLENTE4CAP"];
	 $tesoureiro			   =$linhaconselho["TESOUREIRO"];
	 $suplentetesoureiro	   =$linhaconselho["SUPLENTETESOURO"];
	 $conselhe1cef	   	       =$linhaconselho["CONSELHE1CEF"];
	 $suplente1cef			   =$linhaconselho["SUPLENTE1CEF"];
	 $conselhe2cef			   =$linhaconselho["CONSELHE2CEF"];
	 $suplente2cef			   =$linhaconselho["SUPLENTE2CEF"];
	 $conselhe3cef			   =$linhaconselho["CONSELHE3CEF"];
	 $suplente3cef			   =$linhaconselho["SUPLENTE3CEF"];
	 $conselhe1cf			   =$linhaconselho["CONSELHE1CF"];
	 $suplente1cf              =$linhaconselho["SUPLENTE1CF"];
	 $conselhe2cf			   =$linhaconselho["CONSELHE2CF"];
	 $suplente2cf			   =$linhaconselho["SUPLENTE2CF"];
	 $conselhe3cf			   =$linhaconselho["CONSELHE3CF"];
	 $suplente3cf			   =$linhaconselho["SUPLENTE3CF"];
	 $conselhe4cf			   =$linhaconselho["CONSELHE4CF"];
	 $suplente4cf			   =$linhaconselho["SUPLENTE4CF"];

   }
?>




  <p>
 <label for="lblcod_cpf">CNPJ<img src= "img/check.gif"/></label>
  <input name="cnpj" type="text" id="cnpj" size="20" MAXLENGTH="18" value= "<?echo $cnpj;?>">
 </p>

<P>
<label for="lbldtemissaote">Data de Registro<img src= "img/check.gif"/></label>
<input type="text" name="txtdtregistro" id="txtdtregistro"  value="<? 

 if ($dtregistro=='31/12/1969')
   {
	$dtregistro="";
	echo $dtregistro;
    }
else
   {
    echo $dtregistro;
   }
 ?>" >
</P>
<p>
 
 <label for="lbldtemissaote">Tipo de Elei��o<img src= "img/check.gif"/></label>
	          <select name="tipoe" id="tipoe" value="<?echo $linhaconselho["TPELEICAO"];?>">
              <option value="">...Selecione Tipo...</option>
              <option value="A">ACLAMA��O</option>
              <option value="D">DIRETA</option>
            </select>
</p>
			

<P>
<label for="lbldtemissaote">Per�odo de Mandato Inicio<img src= "img/check.gif"/></label>
<input type="text" name="txtdtmandatoi" id="txtdtmandatoi"  value="
<? 
 if ($dtinicio=='31/12/1969')
   {
	$dtinicio="";
	echo $dtinicio;
    }
else
   {
   echo "qqqqqqqqqqqqqqqqqqq";
    echo $dtinicio;
   }
 ?>" >


<label for="lbldtemissaote">Fim<img src= "img/check.gif"/></label>
<input type="text" name="txtdtmandatof" id="txtdtmandatof"  value="<?    
 if ($dtfim=='31/12/1969')
  {
	$dtfim="";
	echo $dtfim;
  }
else
  {
   echo $dtfim;
   }
 ?>" >
</P>





<p><br><font size="4">Menmbros da Composi��o Atual: </font> </p>			
<p><br><font size="4">Diretoria Executiva: </font> </p>						

	   <p>

		 <label for="lblcod_cpf">Presidente<img src= "img/check.gif"/></label>
         <input name="txtpresidente" type="text" id="txtpresidente" size="50" MAXLENGTH="60" value= "<?echo   $presidente;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente" type="text" id="txtsuplente" size="50" MAXLENGTH="60" value= "<?echo $suplente_pres;?>">
	   </p>
	   

	   <p>

          <label for="lbldtemissaote">Segmento<img src= "img/check.gif"/></label>
	          <select name="txtsegmento1_de" id="txtsegmento1_de" >
              <option value="">Segmento</option>
              <option value="PAI">PAI</option>
              <option value="ALUNO">ALUNO</option>
              <option value="PROF">PROFESSOR</option>
              <option value="FUNC">FUNCIONARIO</option>
            </select>

         <label for="lblcod_cpf">1 Secretario<img src= "img/check.gif"/></label>
         <input name="txtsecretario1_de" type="text" id="txtsecretario1_de" size="30" MAXLENGTH="60" value= "<?echo $secretariode;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente1_de" type="text" id="txtsuplente1_de" size="30" MAXLENGTH="60" value= "<?echo $suplente_secr1;?>">

       </p>


	   <p>
          <label for="lbldtemissaote">Segmento<img src= "img/check.gif"/></label>
	          <select name="txtsegmento2_de" id="txtsegmento2_de" >
              <option value="">Segmento</option>
              <option value="PAI">PAI</option>
              <option value="ALUNO">ALUNO</option>
              <option value="PROF">PROFESSOR</option>
              <option value="FUNC">FUNCIONARIO</option>
            </select>

         <label for="lblcod_cpf">2 Secretario<img src= "img/check.gif"/></label>
         <input name="txtsecretario2_de" type="text" id="txtsecretario2_de" size="30" MAXLENGTH="40" value= "<?echo $secretario2de;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente2_de" type="text" id="txtsuplente2_de" size="30" MAXLENGTH="40" value= "<?echo $suplente_secr2;?>">

       </p>

<p><br><font size="4">Comiss�o de Articula��o Pedag�gica: </font> </p>						
	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro1_cap" type="text" id="txtconselheiro1_cap" size="40" MAXLENGTH="40" value= "<?echo $conselhe1cap;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente1_cap" type="text" id="txtsuplente1_cap" size="40" MAXLENGTH="40" value= "<?echo $suplente1cap;?>">

       </p>

	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro2_cap" type="text" id="txtconselheiro2_cap" size="40" MAXLENGTH="40" value= "<?echo $conselhe2cap;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente2_cap" type="text" id="txtsuplente2_cap" size="40" MAXLENGTH="40" value= "<?echo $suplente2cap;?>">
       </p>

	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro3_cap" type="text" id="txtconselheiro3_cap" size="40" MAXLENGTH="40" value= "<?echo $conselhe3cap;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente3_cap" type="text" id="txtsuplente3_cap" size="40" MAXLENGTH="40" value= "<?echo $suplente3cap;?>">

       </p>

	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro4_cap" type="text" id="conselheiro4_cap" size="40" MAXLENGTH="40" value= "<?echo $conselhe4cap;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente4_cap" type="text" id="txtsuplente4_cap" size="40" MAXLENGTH="40" value= "<?echo $suplente4cap;?>">

       </p>


<p><br><font size="4">Comiss�o de Execu��o Financeira : </font> </p>						
	   <p>
         <label for="lblcod_cpf">Tesoureiro<img src= "img/check.gif"/></label>
         <input name="txttesoureiro1_cef" type="text" id="txttesoureiro1_cef" size="40" MAXLENGTH="40" value= "<?echo $tesoureiro;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplentetesouro" type="text" id="txtsuplentetesouro" size="40" MAXLENGTH="40" value= "<?echo $suplentetesoureiro;?>">
       </p>


	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro1_cef" type="text" id="txtconselheiro1_cef" size="40" MAXLENGTH="40" value= "<?echo $conselhe1cef;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente1_cef" type="text" id="txtsuplente1_cef" size="40" MAXLENGTH="40" value= "<?echo $suplente1cef;?>">

       </p>




	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro2_cef" type="text" id="txtconselheiro2_cef" size="40" MAXLENGTH="40" value= "<?echo $conselhe2cef;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente2_cef" type="text" id="txtsuplente2_cef" size="40" MAXLENGTH="40" value= "<?echo $suplente2cef;?>">

       </p>




	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro3_cef" type="text" id="txtconselheiro3_cef" size="40" MAXLENGTH="40" value= "<?echo $conselhe3cef;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente3_cef" type="text" id="txtsuplente3_cef" size="40" MAXLENGTH="40" value= "<?echo $suplente3cef;?>">

       </p>

<p><br><font size="4">Conselho Fiscal : </font> </p>						

	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro1_cf" type="text" id="txtconselheiro1_cf" size="40" MAXLENGTH="40" value= "<?echo $conselhe1cf;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente1_cf" type="text" id="txtsuplente1_cf" size="40" MAXLENGTH="40" value= "<?echo $suplente1cf;?>">

       </p>
	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro2_cf" type="text" id="txtconselheiro2_cf" size="40" MAXLENGTH="40" value= "<?echo $conselhe2cf;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente2_cf" type="text" id="txtsuplente2_cf" size="40" MAXLENGTH="40" value= "<?echo $suplente2cf;?>">

       </p>


	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro3_cf" type="text" id="txtconselheiro3_cf" size="40" MAXLENGTH="40" value= "<?echo $conselhe3cf;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente3_cf" type="text" id="txtsuplente3_cf" size="40" MAXLENGTH="40" value= "<?echo $suplente3cf;?>">

       </p>

	   <p>
         <label for="lblcod_cpf">Conselheiro<img src= "img/check.gif"/></label>
         <input name="txtconselheiro4_cf" type="text" id="txtconselheiro4_cf" size="40" MAXLENGTH="40" value= "<?echo $conselhe4cf;?>">
         <label for="lblcod_cpf">Suplente<img src= "img/check.gif"/></label>
         <input name="txtsuplente4_cf" type="text" id="txtsuplente4_cf" size="40" MAXLENGTH="40" value= "<?echo $suplente4cf;?>">

       </p>


.</div>

 



<?
}
?>
					<p id="finish">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
	</div>
</body>
</html>