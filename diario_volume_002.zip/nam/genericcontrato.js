$(document).ready(function() {
	$('#toggle').click(function() {
		$('#hidden').toggle(400);
  	return false;
	});



$(".form").validate({
	        rules:{
 
              txtNome:{
	               required: true, 
	            },
               
			   cpf:  {cpf: true},		 


             txtRG:{
	               required: true, 

	            },

         	txtOrgaoExp:{
	               required: true, 

	            },


            txtte:{
	               required: true, 

	            },

         	txtzona:{
	               required: true, 

	            },

        	txtsecao:{
	               required: true, 

	            },


    selectcivil:{
	               required: true, 

	            },
    selectsexo:{
	               required: true, 

	            },
   txtEndereco:{
	               required: true, 

	            },
    txtBairro:{
	               required: true, 

	            },
    txtnr:{
	               required: true, 

	            },

   txtcontato:{
	               required: true, 

	            },

  cod_estado:{
	               required: true, 
	            },

 cod_cidades:{
	               required: true, 
	            },


 txtinstrucao:{
	               required: true, 
	            },

 anoaposentadoria:{
	               required: true, 
	            },


  txtBanco:
				{
                  required: true,

	            },

   txtAgencia:
				{
                  required: true,

	            },
   txtConta:
				{
                  required: true,

	            },


   txtmae:{
	               required: true, 

	            },





  selectcontrato1:
	            {
	               required: true, 
	            },

     txtcod_cargo:{
	               required: true, 

	            },

    cod_funcao0:{
	               required: true, 

	            },


  selectlicenca:{
	               required: true, 
                   disabled: false,
	            },

  
  txtMatricula1:{
	               required: true, 

	            },
    selectch1:{
	               required: true, 

	            },

    selectlotacao1:{
	               required: true, 

	            },
				
    txtDataEmissao:{
	               required: true, 

	            },
         txttdtte:{
	               required: true, 

	            },
	txtdtnascimento:{
	               required: true, 

	            },			

	txtdtadmissao1:{
	               required: true, 

	            },			

	txtdtdiario1:{
	               required: true, 

	            },			

	txtdtdecreto1:{
	               required: true, 

	            },			


txtgerencia:
	       {
             required: true, 
             disabled: false,
		   },

     txtdpto:
	       {
             required: true, 
             disabled: false,
		   },

     selectqtdaescola:
	       {
             required: true, 
             disabled: false,
		   },

     txtinep1:
	       {
             required: true, 
             disabled: false,
		   },
     txtdtlota11:
	       {
             required: true, 
             disabled: false,
		   },
    selectch1lota:
	       {
             required: true, 
             disabled: false,
		   },

     txtqdtaaulas1:
	       {
             required: true, 
             disabled: false,
		   },

     txtautacao1:
	       {
             required: true, 
             disabled: false,
		   },




     txtinep2:
	       {
             required: true, 
             disabled: false,
		   },
     txtdtlota12:
	       {
             required: true, 
             disabled: false,
		   },
    selectch2lota:
	       {
             required: true, 
             disabled: false,
		   },

     txtqdtaaulas2:
	       {
             required: true, 
             disabled: false,
		   },

     txtautacao2:
	       {
             required: true, 
             disabled: false,
		   },




     txtinep3:
	       {
             required: true, 
             disabled: false,
		   },
     txtdtlota13:
	       {
             required: true, 
             disabled: false,
		   },
    selectch3lota:
	       {
             required: true, 
             disabled: false,
		   },

     txtqdtaaulas3:
	       {
             required: true, 
             disabled: false,
		   },

     txtautacao3:
	       {
             required: true, 
             disabled: false,
		   },




     txtinep4:
	       {
             required: true, 
             disabled: false,
		   },
     txtdtlota14:
	       {
             required: true, 
             disabled: false,
		   },
    selectch4lota:
	       {
             required: true, 
             disabled: false,
		   },

     txtqdtaaulas4:
	       {
             required: true, 
             disabled: false,
		   },

     txtautacao4:
	       {
             required: true, 
             disabled: false,
		   },



     txtinep5:
	       {
             required: true, 
             disabled: false,
		   },
     txtdtlota15:
	       {
             required: true, 
             disabled: false,
		   },
    selectch5lota:
	       {
             required: true, 
             disabled: false,
		   },

     txtqdtaaulas5:
	       {
             required: true, 
             disabled: false,
		   },

     txtautacao5:
	       {
             required: true, 
             disabled: false,
		   },






selectcontrato2:
	       {
             required:true, 
             disabled: false,
		   },
txtcargo_comisionado2:
	       {
             required: true, 
             disabled: false,
		   },
selectcadm2:
	       {
             required: true, 
             disabled: false,
		   },
txtcod_cargo1:
	       {
             required: true, 
             disabled: false,
		   },
cod_funcao1:
	       {
             required: true, 
             disabled: false,
		   },
txtMatricula2:
	       {
             required: true, 
             disabled: false,
		   },
txtdtadmissao2:
	       {
             required: true, 
             disabled: false,
		   },
selectch2:
	       {
             required: true, 
             disabled: false,
		   },
selectlotacao2:
	       {
             required: true, 
             disabled: false,
		   },
txtgerencia1:
	       {
             required: true, 
             disabled: false,
		   },
txtdpto1:
	       {
             required: true,
             disabled: false,
		   },
selectqtdaescola2:
	       {
             required: true,
             disabled: false,
		   },

txtinep21:
	       {
             required: true,
             disabled: false,
		   },
txtdtlotacontr21:
	       {
             required: true,
             disabled: false,
		   },
selectchcontrato21:
	       {
             required: true, 
             disabled: false,
		   },
txtqdtaaulas21:
	       {
             required: true, 
             disabled: false,
		   },
txtautacao21:
	       {
             required: true, 
             disabled: false,
		   },


txtinep22:
	       {
             required: true, 
             disabled: false,
		   },
txtdtlotacontr22:
	       {
             required: true, 
             disabled: false,
		   },
selectchcontrato22:
	       {
             required: true, 
             disabled: false,
		   },
txtqdtaaulas22:
	       {
             required: true, 
             disabled: false,
		   },
txtautacao22:
	       {
             required: true, 
             disabled: false,
		   },


   txtdecreto1:{
	               required: true, 

	            },


   txtdiario1:{
	               required: true, 

	            },

   txthabilitacao :{
	               required: true, 

	            },





},


           messages:{
	            txtNome:{
	                required: "Informe o seu nome",
                       },
	            cpf:  
				  {  cpf: 'CPF inv�lido'},
				  
              
	            txtRG:{
	                required: "Informe o seu RG",
                       },

	            txtOrgaoExp:{
	                required: "Informe o org�o expedidor",
                       },
            txtte:{
	                required: "Informe o T�tulo de Eleitor",
                       },

         	txtzona:{
	                required: "Informe a zona",
                       },

        	txtsecao:{
	                required: "Informe a sessao",
                       },

         selectcivil	:{
	                required: "Informe o seu estado civil",
                       },

         selectsexo:{
	                required: "Informe o sexo",
                    },

	            txtEndereco:{
	                required: "Informe o seu endere�o",
	
                       },


	            txtBairro:{
	                required: "Informe o bairro onde mora",
	
                       },

	            txtnr:{
	                required: "Informe o número de sua residencia",
	
                       },

	            txtcontato:{
	                required: "Informe um telefone para contato",
	
                       },

 	            cod_estado:{
	                required: "Informe o estado onde nasceu",
	                maxLength: 60
                       },

	            cod_cidades:{
	                required: "Informe a cidade",

                       },

	            txtinstrucao:{
	                required: "Informe o seu grau de instru��o",

                       },

	            anoaposentadoria:{
	                required: "Informe o ano provável de sua aposentadoria",
                       },

	            txtBanco:{
	                required: "Informe o Banco Oficial do Seu Pagamento",

                       },

	            txtAgencia:{
	                required: "Informe a Agencia do Seu Pagamento",

                       },
			 
	            txtConta:{
	                required: "Informe Conta Corrente do Seu Pagamento",

                       },

                txtmae:{
	                required: "Informe o nome da sua m�e",

                       },
        selectcontrato1:{
	                   required: "Informe o tipo de contrato",
          	            },
        txtcod_cargo:{
	                required: "Informe o cargo para o qual foi nomeado",
	                   },

        cod_funcao0:{
	                required: "Informe a fun��o que exerce",
	                },
		  
       selectlicenca:{
	               required: "Informe o tipo de licen�a",
                   disabled: false,
	                 },


       txtMatricula1:{
	                required: "Informe sua matricula",
     	            },
          selectch1:{
   	                 required: "Informe a carga hor�ria docontrato",
	                 },

              selectlotacao1:{
	                required: "Selecione o local de sua lota��o",

	            },

              txtDataEmissao:{
	                required: "Informe a data de emiss�o de sua RG",

	            },


              txttdtte:{
	                required: "Informe a data de emiss�o de seu T�tulo de Eleitor",
					},

              txtdtnascimento:{
	                required: "Informe a data de Nascimento",
					},

              txtdtadmissao1:{
	                required: "Informe a Data da Posse",
					},

              txtdtdiario1:{
	                required: "Informe a Data do diario oficial",
					},

              txtdtdecreto1:{
	                required: "Informe a Data do decreto",
					},




       txtgerencia:
	          {
                required: "Informe a Administração que você está lotado", 
                disabled: false,
		      },

          txtdpto:
	          {
                required: "Informe o Departamento que você está lotado", 
                disabled: false,
		      },


     selectqtdaescola:
	       {
             required: "Informe as Escolas de Lotação",  
             disabled: false,
		   },

     txtinep1:
	       {
             required: "Informe o INEP da Escola de Lotação", 
             disabled: false,
		   },
     txtdtlota11:
	       {
             required: "Informe a Data da Lotação", 
             disabled: false,
		   },
     selectch1lota:
	       {
             required: "Informe a C.H. de Lotação Nesta Escola", 
             disabled: false,
		   },

     txtqdtaaulas1:
	       {
             required: "Informe a Quantidade de Aulas ", 
             disabled: false,
		   },

     txtautacao1:
	       {
             required: "Informe a Disciplina de Ministra.", 
             disabled: false,
		   },




     txtinep2:
	       {
             required: "Informe o INEP da Escola de Lotação", 
             disabled: false,
		   },
     txtdtlota12:
	       {
             required: "Informe a Data da Lotação",
             disabled: false,
		   },
    selectch2lota:
	       {
             required: "Informe a C.H. de Lotação Nesta Escola", 
             disabled: false,
		   },

     txtqdtaaulas2:
	       {
             required: "Informe a Quantidade de Aulas ", 
             disabled: false,
		   },

     txtautacao2:
	       {
             required: "Informe a Disciplina de Ministra.", 
             disabled: false,
		   },


     txtinep3:
	       {
             required: "Informe o INEP da Escola de Lotação", 
             disabled: false,
		   },
     txtdtlota13:
	       {
             required: "Informe a Data da Lotação",
             disabled: false,
		   },
    selectch3lota:
	       {
             required: "Informe a C.H. de Lotação Nesta Escola", 
             disabled: false,
		   },

     txtqdtaaulas3:
	       {
             required: "Informe a Quantidade de Aulas ", 
             disabled: false,
		   },

     txtautacao3:
	       {
             required: "Informe a Disciplina de Ministra.", 
             disabled: false,
		   },





     txtinep4:
	       {
             required: "Informe o INEP da Escola de Lotação", 
             disabled: false,
		   },
     txtdtlota14:
	       {
             required: "Informe a Data da Lotação",
             disabled: false,
		   },
    selectch4lota:
	       {
             required: "Informe a C.H. de Lotação Nesta Escola", 
             disabled: false,
		   },

     txtqdtaaulas4:
	       {
             required: "Informe a Quantidade de Aulas ", 
             disabled: false,
		   },

     txtautacao4:
	       {
             required: "Informe a Disciplina de Ministra.", 
             disabled: false,
		   },



     txtinep5:
	       {
             required: "Informe o INEP da Escola de Lotação", 
             disabled: false,
		   },
     txtdtlota15:
	       {
             required: "Informe a Data da Lotação",
             disabled: false,
		   },
    selectch5lota:
	       {
             required: "Informe a C.H. de Lotação Nesta Escola", 
             disabled: false,
		   },

     txtqdtaaulas5:
	       {
             required: "Informe a Quantidade de Aulas ", 
             disabled: false,
		   },

     txtautacao5:
	       {
             required: "Informe a Disciplina de Ministra.", 
             disabled: false,
		   },



selectcontrato2:
	       {
             required: "Informe a quantidade de escola(s).", 
             disabled: false,
		   },
txtcargo_comisionado2:
	       {
             required: "Informe qual o cargo comissionado.", 
             disabled: false,
		   },
selectcadm2:
	       {
             required: "Informe a local de lotação.", 
             disabled: false,
		   },
txtcod_cargo1:
	       {
             required: "Informe o cargo de posse", 
             disabled: false,
		   },
cod_funcao1:
	       {

             required: "Informe a função exercicida", 
             disabled: false,
		   },
txtMatricula2:
	       {
             required: "Informe a matricula.", 
             disabled: false,
		   },
txtdtadmissao2:
	       {
             required: "Informe a data da posse.", 
             disabled: false,
		   },
selectch2:
	       {
             required: "Informe a carga horária do seu contrato.", 
             disabled: false,
		   },
selectlotacao2:
	       {
             required: "Informe onde está lotado.", 
             disabled: false,
		   },
txtgerencia1:
	       {
             required: "Informe a sua lotação.", 
             disabled: false,
		   },
txtdpto1:
	       {
             required: "Informe o departamento de sua lotação.", 
             disabled: false,
		   },

selectqtdaescola2:
	       {
             required: "Informe a quantidade de escolas.", 
             disabled: false,
		   },
txtinep21:
	       {
             required: "Informe o INEP da escola que está lotado.", 
             disabled: false,
		   },
txtdtlotacontr21:
	       {
             required: "Informe a data da posse.", 
             disabled: false,
		   },
selectchcontrato21:
	       {
             required: "Informe a sua C.H. ", 
             disabled: false,
		   },
txtqdtaaulas21:
	       {
             required: "Informe a quantidade de aula(s).", 
             disabled: false,
		   },
txtautacao21:
	       {
             required: "Informe a disciplina que ministra.", 
             disabled: false,
		   },


txtinep22:
	       {
             required: "Informe o INEP.", 
             disabled: false,
		   },
txtdtlotacontr22:
	       {
             required: "Informe a data da posse.", 
             disabled: false,
		   },
selectchcontrato22:
	       {
             required: "Informe a C.H. do contrato.", 
             disabled: false,
		   },
txtqdtaaulas22:
	       {
             required: "Informe a quantidade de aulas Ministradas.", 
             disabled: false,
		   },
txtautacao22:
	       {
             required: "Informe a Disciplina que Ministra.", 
             disabled: false,
		   },


   txtdecreto1:{
	               required: "Informe o Decreto que deu posse ao servidor.", 

	            },


   txtdiario1:{
	               required: "Informe o Número do Diário Oficial.", 

	            },


   txthabilitacao :{
                     required: "Informe a habilita��o.", 

	            },




}

      
	    });
});



$(document).change(function(){
  if ($("input[@name='radiolicenca']:checked").val()=='S')
    { 
        $("#selectlicenca").attr("disabled", '');
    }	 
  else
     {
        $("#selectlicenca").attr("disabled", true);
        $("#selectlicenca").attr("value",'' );
}
  })











$(document).ready(function(){
//********Contrato 1*************************************************




   	    var txtcod_cargo = $("#txtcod_cargo");
				
         $("#txtcod_cargo").click(function(){

         if((txtcod_cargo.val() == "1"))
		      {
				 $("#txthabilitacao").attr("disabled", '');
			  }
          else
              {
				  $("#txthabilitacao").attr("disabled", true);			 
			      $("#txthabilitacao").attr("value", '');			 
			  }



     });



    var adm1 = $("#selectcontrato1");
				
         $("#selectcontrato1").click(function(){
	     

		  if((adm1.val() == "6") || (adm1.val() == "7"))
		      {
				 $("#selectcadm1").attr("disabled", '');
			  }
          else
              {
				  $("#selectcadm1").attr("disabled", true);			 
			      $("#selectcadm1").attr("value", '');			 
			  }

          });


   	    var adm2 = $("#selectcontrato2");
				
         $("#selectcontrato2").click(function(){
	     

		  if((adm2.val() == "6") || (adm2.val() == "7"))
		      {
				 $("#selectcadm2").attr("disabled", '');
			  }
          else
              {
				  $("#selectcadm2").attr("disabled", true);			 
			      $("#selectcadm2").attr("value", '');			 
			  }

          });

   	    var adm3 = $("#selectcontrato3");
				
         $("#selectcontrato3").click(function(){
		  if((adm3.val() == "6") || (adm3.val() == "7"))
		      {
				 $("#selectcadm3").attr("disabled", '');
			  }
          else
              {
				  $("#selectcadm3").attr("disabled", true);			 
			      $("#selectcadm3").attr("value", '');			 
			  }

          });

// Quantidades Contratos
         var qtdacontrato = $("#selectqtdacontrato");
          $("#selectqtdacontrato").click(function(){
		  if (qtdacontrato.val() == "2")
		      {
				  $("#selectcontrato2").attr("disabled", '');
				  $("#txtcod_cargo1").attr("disabled", '');
				  $("#cod_funcao1").attr("disabled", '');
				  $("#selectcontrato2").attr("disabled", '');
				  $("#selectcadm2").attr("disabled", '');
				  $("#txtMatricula2").attr("disabled", '');
				  $("#txtdtadmissao2").attr("disabled", '');				 
				  $("#selectch2").attr("disabled", '');
				  $("#txtdecreto2").attr("disabled", '');
				  $("#txtdtdecreto2").attr("disabled", '');				 
				  $("#txtdiario2").attr("disabled", '');
				  $("#txtdtdiario2").attr("disabled", '');
				  $("#selectlotacao2").attr("disabled", '');				 
 			      //$("#txtgerencia1").attr("disabled", '');				 
				  //$("#txtdpto1").attr("disabled", '');				 
//				  $("#selectqtdaescola2").attr("disabled", '');				                 

              }
		 else if (qtdacontrato.val() == "3")
              {
				  $("#qtdacontrato").attr("disabled", true);			 
			      $("#qtdacontrato").attr("value", '');			 
			  }

           else
		     {
   				  $("#txtcod_cargo1").attr("disabled", true);
				  $("#cod_funcao1").attr("disabled", true);
				  $("#selectcontrato2").attr("disabled", true);
				  $("#selectcadm2").attr("disabled", true);
				  $("#txtMatricula2").attr("disabled", true);
				  $("#txtdtadmissao2").attr("disabled", true);				 
				  $("#selectch2").attr("disabled", true);
				  $("#txtdecreto2").attr("disabled", true);
				  $("#txtdtdecreto2").attr("disabled", true);				 
				  $("#txtdtdiario2").attr("disabled", '');
				  $("#txtdiario2").attr("disabled", true);
				  $("#selectlotacao2").attr("disabled", true);				 
 			    //  $("#txtgerencia1").attr("disabled", true);				 
				 // $("#txtdpto1").attr("disabled", true);				 
				 // $("#selectqtdaescola2").attr("disabled", true);				                 
			 
			 

   				  $("#txtcod_cargo1").attr("value", '');			 
				  $("#cod_funcao1").attr("value", '');			 

                  $("#selectcontrato2").attr("value", '');			 
				  $("#selectcadm2").attr("value", '');			 
				  $("#txtMatricula2").attr("value", '');			 
				  $("#txtdtadmissao2").attr("value", '');			 
				  $("#selectch2").attr("value", '');			 
				  $("#txtdecreto2").attr("value", '');			 
				  $("#txtdtdecreto2").attr("value", '');			 
				  $("#txtdiario2").attr("value", '');			 
				  $("#selectlotacao2").attr("value", '');			 
     }
   
 });





// Selecao de contrato
        var selectcontrato1 = $("#selectcontrato1");
          $("#selectcontrato1").click(function(){
		  if ((selectcontrato1.val() == "4") || (selectcontrato1.val() == "5") || (selectcontrato1.val() == "8"))
		      {
				  $("#txtcargo_comisionado").attr("readonly", '');				 
              }
		 else  
              {
				  $("#txtcargo_comisionado").attr("readonly", true);			 
			      $("#txtcargo_comisionado").attr("value", '');			 
			  }

          });




// Selecao de contrato
        var selectcontrato2 = $("#selectcontrato2");
          $("#selectcontrato2").click(function(){
		  if ((selectcontrato2.val() == "4") || (selectcontrato2.val() == "5") || (selectcontrato2.val() == "8"))
		      {
				  $("#txtcargo_comisionado2").attr("disabled", '');				 
              }
		 else  
              {
				  $("#txtcargo_comisionado2").attr("disabled", true);			 
			      $("#txtcargo_comisionado2").attr("value", '');			 
			  }

          });

//*********************************
//Seleciona lotacao 1
//
//********************************

   	    var texto = $("#selectlotacao1");

          $("#selectlotacao1").click(function(){
		  if(texto.val() == "1") {
	         $("#txtgerencia").attr("disabled", '');
	         $("#txtdpto").attr("disabled", '');			 
			 $("#txtinep1").attr("disabled", true);			 
			 $("#txtinep1").attr("value", '');			 
			 $("#txtqdtaaulas1").attr("disabled", true);			 
			 $("#txtqdtaaulas1").attr("value", '0');			 
			 $("#txtautacao1").attr("disabled", true);			 	
			 $("#txtautacao1").attr("value", '');			 
			 

	          $("#txtinep1").attr("disabled",true);			 
	          $("#txtinep2").attr("disabled",true);			 
	          $("#txtinep3").attr("disabled",true);			 
	          $("#txtinep4").attr("disabled",true);			 
	          $("#txtinep5").attr("disabled",true);			 			  			     	


			 $("#txtqdtaaulas1").attr("disabled", true);			 
			 $("#txtqdtaaulas2").attr("disabled", true);			 
			 $("#txtqdtaaulas3").attr("disabled", true);			 
			 $("#txtqdtaaulas4").attr("disabled", true);			 
			 $("#txtqdtaaulas5").attr("disabled", true);			 

			 $("#txtqdtaaulas1").attr("value", '0');			 
			 $("#txtqdtaaulas2").attr("value", '0');			 
			 $("#txtqdtaaulas3").attr("value", '0');			 
			 $("#txtqdtaaulas4").attr("value", '0');			 
			 $("#txtqdtaaulas5").attr("value", '0');			 			 			 			 

			 $("#txtautacao1").attr("disabled", true);			 	
			 $("#txtautacao2").attr("disabled", true);			 	
			 $("#txtautacao3").attr("disabled", true);			 	
			 $("#txtautacao4").attr("disabled", true);			 	
			 $("#txtautacao5").attr("disabled", true);			 				 			 			 


			 $("#txtautacao1").attr("value", '');			 
			 $("#txtautacao2").attr("value", '');			 
			 $("#txtautacao3").attr("value", '');			 
			 $("#txtautacao4").attr("value", '');			 
			 $("#txtautacao5").attr("value", '');		
			 
			 
			 $("#txtdtlota11").attr("disabled", true);			 	
			 $("#txtdtlota12").attr("disabled", true);			 	
			 $("#txtdtlota13").attr("disabled", true);			 	
			 $("#txtdtlota14").attr("disabled", true);			 	
			 $("#txtdtlota15").attr("disabled", true);			 				 			 			 
			 

			 $("#txtdtlota11").attr("value", '');			 
			 $("#txtdtlota12").attr("value", '');			 
			 $("#txtdtlota13").attr("value", '');			 
			 $("#txtdtlota14").attr("value", '');			 
			 $("#txtdtlota15").attr("value", '');		



			 $("#selectch1lota").attr("disabled", true);			 	
			 $("#selectch2lota").attr("disabled", true);			 	
			 $("#selectch3lota").attr("disabled", true);			 	
			 $("#selectch4lota").attr("disabled", true);			 	
			 $("#selectch5lota").attr("disabled", true);			 				 			 			 

			 $("#selectqtdaescola").attr("disabled", true);			 				 			 			 
             $("#selectqtdaescola").attr("value", '0');			 

	      }
		  
		 else if (texto.val() == "3")
		  {

	          $("#txtdpto").attr("disabled",'');
	          $("#txtgerencia").attr("disabled",'');

			 $("#selectqtdaescola").attr("disabled", '');			 
   			 $("#selectqtdaescola").attr("value", '0');			 


             var qtdaescola = $("#selectqtdaescola");
             $("#selectqtdaescola").click(function(){
	         if(qtdaescola.val() == "1") 
			    {

     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	


				  $("#txtinep2").attr("disabled",true);			 
                  $("#txtqdtaaulas2").attr("disabled", true);			 	          
       			  $("#txtautacao2").attr("disabled", true);			 				  
      			  $("#txtdtlota12").attr("disabled", true);			 	
     			  $("#selectch2lota").attr("disabled", true);			 	

				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	

				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	


				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	

                }


	        else if(qtdaescola.val() == "0") 
			    {

     	          $("#txtinep1").attr("disabled",'true');			 
                  $("#txtqdtaaulas1").attr("disabled", true);			 	          
       			  $("#txtautacao1").attr("disabled", true);			 				  
      			  $("#txtdtlota11").attr("disabled", true);			 	
     			  $("#selectch1lota").attr("disabled", true);			 	


				  $("#txtinep2").attr("disabled",true);			 
                  $("#txtqdtaaulas2").attr("disabled", true);			 	          
       			  $("#txtautacao2").attr("disabled", true);			 				  
      			  $("#txtdtlota12").attr("disabled", true);			 	
     			  $("#selectch2lota").attr("disabled", true);			 	



				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	




				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	






                }


	            else if(qtdaescola.val() == "2")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				




				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	




				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	
				} 			  
        
	            else if(qtdaescola.val() == "3")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	


				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	



				} 			  
		
	            else if(qtdaescola.val() == "4")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	


				  $("#txtinep4").attr("disabled",'');			 
                  $("#txtqdtaaulas4").attr("disabled", '');			 	          
       			  $("#txtautacao4").attr("disabled", '');			 				  
      			  $("#txtdtlota14").attr("disabled", '');			 	
     			  $("#selectch4lota").attr("disabled", '');			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	
				} 			  

	            else if(qtdaescola.val() == "5")

				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	


				  $("#txtinep4").attr("disabled",'');			 
                  $("#txtqdtaaulas4").attr("disabled", '');			 	          
       			  $("#txtautacao4").attr("disabled", '');			 				  
      			  $("#txtdtlota14").attr("disabled", '');			 	
     			  $("#selectch4lota").attr("disabled", '');			 	


				  $("#txtinep5").attr("disabled",'');			 
                  $("#txtqdtaaulas5").attr("disabled", '');			 	          
       			  $("#txtautacao5").attr("disabled", '');			 				  
      			  $("#txtdtlota15").attr("disabled", '');			 	
     			  $("#selectch5lota").attr("disabled", '');			 	
				
				} 			  
		

		  
		  
		     });			  







}
       else if (texto.val() == "2")
		  {
	          $("#txtdpto").attr("disabled", true);
	          $("#txtgerencia").attr("disabled", true);
	
	
              
			 $("#selectqtdaescola").attr("disabled", '');			 
   			 $("#selectqtdaescola").attr("value", '0');			 


			  $("#txtdpto").attr("value", '');
			  $("#txtgerencia").attr("value", '');



             var qtdaescola = $("#selectqtdaescola");
             $("#selectqtdaescola").click(function(){
	         if(qtdaescola.val() == "1") 
			    {

     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	


          	    var txtcod_cargoescola1 = $("#txtcod_cargo");
                $("#txtcod_cargo").click(function(){
                if((txtcod_cargoescola1.val() != "1"))
		           {
				     $("#txtautacao1").attr("disabled", true);			 
			         $("#txtautacao1").attr("value", '');			 
     		       }
               else
                  {
				    $("#txtautacao1").attr("disabled", '');			 
       		        $("#txtautacao1").attr("value", '');			 

   				  $("#txtautacao2").attr("disabled", true);			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", true);			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", true);			 
			      $("#txtautacao4").attr("value", '');			 
				  $("#txtautacao5").attr("disabled", true);			 
			      $("#txtautacao5").attr("value", '');			 

                  }
                });
				  
				  
				  
				  
				  
				  
				  
				  $("#txtinep2").attr("disabled",true);			 
                  $("#txtqdtaaulas2").attr("disabled", true);			 	          
       			  $("#txtautacao2").attr("disabled", true);			 				  
      			  $("#txtdtlota12").attr("disabled", true);			 	
     			  $("#selectch2lota").attr("disabled", true);			 	

				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	

				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	


				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	

                }


	        else if(qtdaescola.val() == "0") 
			    {

     	          $("#txtinep1").attr("disabled",'true');			 
                  $("#txtqdtaaulas1").attr("disabled", true);			 	          
       			  $("#txtautacao1").attr("disabled", true);			 				  
      			  $("#txtdtlota11").attr("disabled", true);			 	
     			  $("#selectch1lota").attr("disabled", true);			 	


				  $("#txtinep2").attr("disabled",true);			 
                  $("#txtqdtaaulas2").attr("disabled", true);			 	          
       			  $("#txtautacao2").attr("disabled", true);			 				  
      			  $("#txtdtlota12").attr("disabled", true);			 	
     			  $("#selectch2lota").attr("disabled", true);			 	



				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	




				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	






                }


	            else if(qtdaescola.val() == "2")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

           	    var txtcod_cargoescola1 = $("#txtcod_cargo");
                $("#txtcod_cargo").click(function(){
                if((txtcod_cargoescola1.val() != "1"))
		          {
				  $("#txtautacao1").attr("disabled", true);			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", true);			 
			      $("#txtautacao2").attr("value", '');			 
                }
            else
                  {
				  $("#txtautacao1").attr("disabled", '');			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", '');			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", true);			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", true);			 
			      $("#txtautacao4").attr("value", '');			 
				  $("#txtautacao5").attr("disabled", true);			 
			      $("#txtautacao5").attr("value", '');			 
			
			
			
			
			}
             });




				  $("#txtinep3").attr("disabled",true);			 
                  $("#txtqdtaaulas3").attr("disabled", true);			 	          
       			  $("#txtautacao3").attr("disabled", true);			 				  
      			  $("#txtdtlota13").attr("disabled", true);			 	
     			  $("#selectch3lota").attr("disabled", true);			 	




				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	
				} 			  
        
	            else if(qtdaescola.val() == "3")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	




           	    var txtcod_cargoescola1 = $("#txtcod_cargo");
                $("#txtcod_cargo").click(function(){
                if((txtcod_cargoescola1.val() != "1"))
		          {
				  $("#txtautacao1").attr("disabled", true);			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", true);			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", true);			 
			      $("#txtautacao3").attr("value", '');			 

               }
            else
                  {
				  $("#txtautacao1").attr("disabled", '');			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", '');			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", '');			 
			      $("#txtautacao3").attr("value", '');			 

				  $("#txtautacao4").attr("disabled", true);			 
			      $("#txtautacao4").attr("value", '');			 
				  $("#txtautacao5").attr("disabled", true);			 
			      $("#txtautacao5").attr("value", '');			 


               }
             });

                  
				  
				  
				  
				  $("#txtinep4").attr("disabled",true);			 
                  $("#txtqdtaaulas4").attr("disabled", true);			 	          
       			  $("#txtautacao4").attr("disabled", true);			 				  
      			  $("#txtdtlota14").attr("disabled", true);			 	
     			  $("#selectch4lota").attr("disabled", true);			 	




				  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	



				} 			  
		
	            else if(qtdaescola.val() == "4")
				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	


				  $("#txtinep4").attr("disabled",'');			 
                  $("#txtqdtaaulas4").attr("disabled", '');			 	          
       			  $("#txtautacao4").attr("disabled", '');			 				  
      			  $("#txtdtlota14").attr("disabled", '');			 	
     			  $("#selectch4lota").attr("disabled", '');			 	




           	    var txtcod_cargoescola1 = $("#txtcod_cargo");
                $("#txtcod_cargo").click(function(){
                if((txtcod_cargoescola1.val() != "1"))
		          {
				  $("#txtautacao1").attr("disabled", true);			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", true);			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", true);			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", true);			 
			      $("#txtautacao4").attr("value", '');			 


               }
            else
                  {
				  $("#txtautacao1").attr("disabled", '');			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", '');			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", '');			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", '');			 
			      $("#txtautacao4").attr("value", '');			 

				  $("#txtautacao5").attr("disabled", true);			 
			      $("#txtautacao5").attr("value", '');			 


}
             });





                  $("#txtinep5").attr("disabled",true);			 
                  $("#txtqdtaaulas5").attr("disabled", true);			 	          
       			  $("#txtautacao5").attr("disabled", true);			 				  
      			  $("#txtdtlota15").attr("disabled", true);			 	
     			  $("#selectch5lota").attr("disabled", true);			 	
				} 			  

	            else if(qtdaescola.val() == "5")

				{
     	        
     	          $("#txtinep1").attr("disabled",'');			 
                  $("#txtqdtaaulas1").attr("disabled", '');			 	          
       			  $("#txtautacao1").attr("disabled", '');			 				  
      			  $("#txtdtlota11").attr("disabled", '');			 	
     			  $("#selectch1lota").attr("disabled", '');			 	
				
				
				  $("#txtinep2").attr("disabled",'');			 
                  $("#txtqdtaaulas2").attr("disabled", '');			 	          
       			  $("#txtautacao2").attr("disabled", '');			 				  
      			  $("#txtdtlota12").attr("disabled", '');			 	
     			  $("#selectch2lota").attr("disabled", '');			 	
				

				  $("#txtinep3").attr("disabled",'');			 
                  $("#txtqdtaaulas3").attr("disabled", '');			 	          
       			  $("#txtautacao3").attr("disabled", '');			 				  
      			  $("#txtdtlota13").attr("disabled", '');			 	
     			  $("#selectch3lota").attr("disabled", '');			 	


				  $("#txtinep4").attr("disabled",'');			 
                  $("#txtqdtaaulas4").attr("disabled", '');			 	          
       			  $("#txtautacao4").attr("disabled", '');			 				  
      			  $("#txtdtlota14").attr("disabled", '');			 	
     			  $("#selectch4lota").attr("disabled", '');			 	


				  $("#txtinep5").attr("disabled",'');			 
                  $("#txtqdtaaulas5").attr("disabled", '');			 	          
       			  $("#txtautacao5").attr("disabled", '');			 				  
      			  $("#txtdtlota15").attr("disabled", '');			 	
     			  $("#selectch5lota").attr("disabled", '');			 	
				


           	    var txtcod_cargo = $("#txtcod_cargo");
                $("#txtcod_cargo").click(function(){
                if((txtcod_cargo.val() != "1"))
		          {
				  $("#txtautacao1").attr("disabled", true);			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", true);			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", true);			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", true);			 
			      $("#txtautacao4").attr("value", '');			 
				  $("#txtautacao5").attr("disabled", true);			 
			      $("#txtautacao5").attr("value", '');			 


               }
            else
                  {
				  $("#txtautacao1").attr("disabled", '');			 
			      $("#txtautacao1").attr("value", '');			 
				  $("#txtautacao2").attr("disabled", '');			 
			      $("#txtautacao2").attr("value", '');			 
				  $("#txtautacao3").attr("disabled", '');			 
			      $("#txtautacao3").attr("value", '');			 
				  $("#txtautacao4").attr("disabled", '');			 
			      $("#txtautacao4").attr("value", '');			 
				  $("#txtautacao5").attr("disabled", '');			 
			      $("#txtautacao5").attr("value", '');			 

               }
             });



     } 			  
		  
		     });			  

	      }
	    });

//*********************************
// Fim Seleciona lotacao 1
//
//********************************



//********************************
//Seleciona lotacao 2
//********************************

   	    var selectlotacao2 = $("#selectlotacao2");
          $("#selectlotacao2").click(function(){
		  if(selectlotacao2.val() == "1") {
			 $("#txtgerencia1").attr("disabled", '');
	         $("#txtdpto1").attr("disabled", '');			 



              $("#txtinep21").attr("disabled",true);			 
	          $("#txtinep22").attr("disabled",true);			 
	          $("#txtinep23").attr("disabled",true);			 
	          $("#txtinep24").attr("disabled",true);			 
	          $("#txtinep25").attr("disabled",true);			 			  			     	

              $("#selectqtdaescola2").attr("disabled",true);			 			  			     	
			  $("#selectqtdaescola2").attr("value", '0');			              
        
   
			 $("#txtqdtaaulas21").attr("disabled", true);			 
			 $("#txtqdtaaulas22").attr("disabled", true);			 
			 $("#txtqdtaaulas23").attr("disabled", true);			 
			 $("#txtqdtaaulas24").attr("disabled", true);			 
			 $("#txtqdtaaulas25").attr("disabled", true);			 

			 $("#txtqdtaaulas21").attr("value", '0');			 
			 $("#txtqdtaaulas22").attr("value", '0');			 
			 $("#txtqdtaaulas23").attr("value", '0');			 
			 $("#txtqdtaaulas24").attr("value", '0');			 
			 $("#txtqdtaaulas25").attr("value", '0');			 			 			 			 

			 $("#txtautacao21").attr("disabled", true);			 	
			 $("#txtautacao22").attr("disabled", true);			 	
			 $("#txtautacao23").attr("disabled", true);			 	
			 $("#txtautacao24").attr("disabled", true);			 	
			 $("#txtautacao25").attr("disabled", true);			 				 			 			 


			 $("#txtautacao21").attr("value", '');			 
			 $("#txtautacao22").attr("value", '');			 
			 $("#txtautacao23").attr("value", '');			 
			 $("#txtautacao24").attr("value", '');			 
			 $("#txtautacao25").attr("value", '');		
			 
			 
			 $("#txtdtlotacontr21").attr("disabled", true);			 	
			 $("#txtdtlotacontr22").attr("disabled", true);			 	
			 $("#txtdtlotacontr23").attr("disabled", true);			 	
			 $("#txtdtlotacontr24").attr("disabled", true);			 	
			 $("#txtdtlotacontr25").attr("disabled", true);			 				 			 			 
			 

			 $("#txtdtlotacontr21").attr("value", '');			 
			 $("#txtdtlotacontr22").attr("value", '');			 
			 $("#txtdtlotacontr23").attr("value", '');			 
			 $("#txtdtlotacontr24").attr("value", '');			 
			 $("#txtdtlotacontr25").attr("value", '');		

			// $("#selectchcontrato21").attr("disabled", true);			 	
			 $("#selectchcontrato22").attr("disabled", true);			 	
			 $("#selectchcontrato23").attr("disabled", true);			 	
			 $("#selectchcontrato24").attr("disabled", true);			 	
			 $("#selectchcontrato25").attr("disabled", true);			 				 			 			 

			// $("#selectqtdaescola2").attr("disabled", true);			 				 			 			 
            // $("#selectqtdaescola2").attr("value", '0');			 


	}
		  
       else if (selectlotacao2.val() == "2")
		  {
	          $("#txtdpto1").attr("disabled", true);
	          $("#txtgerencia1").attr("disabled", true);
	
             $("#selectqtdaescola2").attr("disabled", '');			 
   			 $("#selectqtdaescola2").attr("value", '0');			 


			  $("#txtdpto1").attr("value", '');
			  $("#txtgerencia1").attr("value", '');



             var qtdaescola = $("#selectqtdaescola2");
             $("#selectqtdaescola2").click(function(){
	         if(qtdaescola.val() == "1") 
			    {

	              $("#txtinep21").attr("disabled",'');			 
     		      $("#txtqdtaaulas21").attr("disabled", '');			 
                  $("#selectchcontrato21").attr("disabled", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", '');			 	
			      $("#txtdtlotacontr21").attr("disabled",'');			 				 


          	    var txtcod_cargoescola2 = $("#txtcod_cargo1");
                $("#txtcod_cargo1").click(function(){
                if((txtcod_cargoescola2.val() != "1"))
		           {
				     $("#txtautacao21").attr("disabled", true);			 
			         $("#txtautacao21").attr("value", '');			 
     		       }
               else
                  {
				    $("#txtautacao21").attr("disabled", '');			 
       		        $("#txtautacao21").attr("value", '');			 

   				  $("#txtautacao22").attr("disabled", true);			 
			      $("#txtautacao22").attr("value", '');			 
				  $("#txtautacao23").attr("disabled", true);			 
			      $("#txtautacao23").attr("value", '');			 
				  $("#txtautacao24").attr("disabled", true);			 
			      $("#txtautacao24").attr("value", '');			 
				  $("#txtautacao25").attr("disabled", true);			 
			      $("#txtautacao25").attr("value", '');			 

                  }
                });
				  
				  
				  
				  $("#txtinep22").attr("disabled",true);			 
 			      $("#txtdescescola21").attr("value", '');			      		   
			      $("#txtqdtaaulas22").attr("disabled", true);			 
 			      $("#selectchcontrato22").attr("value", '0');			 
			      $("#txtautacao22").attr("disabled", true);			 	
			      $("#txtdtlotacontr22").attr("disabled",true);			 				 


	              $("#txtinep23").attr("disabled",true);			 
     		      $("#txtqdtaaulas23").attr("disabled", true);			 
                  $("#selectchcontrato23").attr("disabled", true);			 
				  $("#txtautacao23").attr("disabled", true);			 	
			      $("#txtdtlotacontr23").attr("disabled",true);			 				 


	              $("#txtinep24").attr("disabled",true);			 
                  $("#txtqdtaaulas24").attr("disabled", true);			 
                  $("#selectchcontrato24").attr("disabled", true);			 
				  $("#txtautacao24").attr("disabled", true);			 	
			      $("#txtdtlotacontr24").attr("disabled",true);			 				 


	              $("#txtinep25").attr("disabled",true);			 
     		      $("#txtqdtaaulas25").attr("disabled", true);			 
                  $("#selectchcontrato25").attr("disabled", true);			 
				  $("#txtautacao25").attr("disabled", true);			 	
			      $("#txtdtlotacontr25").attr("disabled",true);			 				 


	              $("#txtinep22").attr("value", '');			  
     		      $("#txtqdtaaulas22").attr("value", '');			  
                  $("#selectchcontrato22").attr("value", '');			  
				  $("#txtautacao22").attr("value", '');			  
			      $("#txtdtlotacontr22").attr("value", '');			  

	              $("#txtinep23").attr("value", '');			  
     		      $("#txtqdtaaulas23").attr("value", '');			  
                  $("#selectchcontrato23").attr("value", '');			  
				  $("#txtautacao23").attr("value", '');			  
			      $("#txtdtlotacontr23").attr("value", '');			  


	              $("#txtinep24").attr("value", '');			  
     		      $("#txtqdtaaulas24").attr("value", '');			  
                  $("#selectchcontrato24").attr("value", '');			  
				  $("#txtautacao24").attr("value", '');			  
			      $("#txtdtlotacontr24").attr("value", '');			  

	              $("#txtinep25").attr("value", '');			  
     		      $("#txtqdtaaulas25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '');			  
				  $("#txtautacao25").attr("value", '');			  
			      $("#txtdtlotacontr25").attr("value", '');			  



                  $("#selectchcontrato25").attr("value", '0');			  
   				  $("#selectchcontrato23").attr("value", '0');			  
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#selectchcontrato24").attr("value", '0');			 				


}


	        else if(qtdaescola.val() == "0") 
			    {


	              $("#txtinep21").attr("disabled",true);			 
				  $("#txtqdtaaulas21").attr("disabled", true);			 
                  $("#selectchcontrato21").attr("disabled", true);			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", true);			 	
			      $("#txtdtlotacontr21").attr("disabled",true);			 				 


	              $("#txtinep21").attr("value",'');			 
				  $("#txtqdtaaulas21").attr("value", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("value", '');			 	
			      $("#txtdtlotacontr21").attr("value",'');			 				 
	              $("#txtinep21").attr("value", '');			  




				  $("#txtinep22").attr("disabled",true);			 
     		      $("#txtqdtaaulas22").attr("disabled", true);			 
 			      $("#selectchcontrato22").attr("value", '0');			 
			      $("#txtautacao22").attr("disabled", true);			 	
			      $("#txtdtlotacontr22").attr("disabled",true);			 				 


	              $("#txtinep23").attr("disabled",true);			 
     		      $("#txtqdtaaulas23").attr("disabled", true);			 
                  $("#selectchcontrato23").attr("disabled", true);			 
				  $("#txtautacao23").attr("disabled", true);			 	
			      $("#txtdtlotacontr23").attr("disabled",true);			 				 


	              $("#txtinep24").attr("disabled",true);			 
                  $("#txtqdtaaulas24").attr("disabled", true);			 
                  $("#selectchcontrato24").attr("disabled", true);			 
				  $("#txtautacao24").attr("disabled", true);			 	
			      $("#txtdtlotacontr24").attr("disabled",true);			 				 


	              $("#txtinep25").attr("disabled",true);			 
     		      $("#txtqdtaaulas25").attr("disabled", true);			 
                  $("#selectchcontrato25").attr("disabled", true);			 
				  $("#txtautacao25").attr("disabled", true);			 	
			      $("#txtdtlotacontr25").attr("disabled",true);			 				 


	              $("#txtinep22").attr("value", '');			  
     		      $("#txtqdtaaulas22").attr("value", '');			  
                  $("#selectchcontrato22").attr("value", '');			  
				  $("#txtautacao22").attr("value", '');			  
			      $("#txtdtlotacontr22").attr("value", '');			  

	              $("#txtinep23").attr("value", '');			  
     		      $("#txtqdtaaulas23").attr("value", '');			  
                  $("#selectchcontrato23").attr("value", '');			  
				  $("#txtautacao23").attr("value", '');			  
			      $("#txtdtlotacontr23").attr("value", '');			  


	              $("#txtinep24").attr("value", '');			  
     		      $("#txtqdtaaulas24").attr("value", '');			  
                  $("#selectchcontrato24").attr("value", '');			  
				  $("#txtautacao24").attr("value", '');			  
			      $("#txtdtlotacontr24").attr("value", '');			  

	              $("#txtinep25").attr("value", '');			  
     		      $("#txtqdtaaulas25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '');			  
				  $("#txtautacao25").attr("value", '');			  
			      $("#txtdtlotacontr25").attr("value", '');			  



                  $("#selectchcontrato25").attr("value", '0');			  
   				  $("#selectchcontrato23").attr("value", '0');			  
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#selectchcontrato24").attr("value", '0');			 				


                }


	            else if(qtdaescola.val() == "2")
				{
     	        
	              $("#txtinep21").attr("disabled",'');			 
     		      $("#txtqdtaaulas21").attr("disabled", '');			 
                  $("#selectchcontrato21").attr("disabled", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", '');			 	
			      $("#txtdtlotacontr21").attr("disabled",'');			 				 


	              $("#txtinep22").attr("disabled",'');			 
     		      $("#txtqdtaaulas22").attr("disabled", '');			 
                  $("#selectchcontrato22").attr("disabled", '');			 
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#txtautacao22").attr("disabled", '');			 	
			      $("#txtdtlotacontr22").attr("disabled",'');			 				 



          	    var txtcod_cargoescola2 = $("#txtcod_cargo1");
                $("#txtcod_cargo1").click(function(){
                if((txtcod_cargoescola2.val() != "1"))
		           {
				     $("#txtautacao21").attr("disabled", true);			 
                     $("#txtautacao21").attr("value", '');			 
				     $("#txtautacao22").attr("disabled", true);			 
			         $("#txtautacao22").attr("value", '');			 
     	
		          }
               else
                  {
				    $("#txtautacao21").attr("disabled", '');			 
       		        $("#txtautacao21").attr("value", '');			 

   				  $("#txtautacao22").attr("disabled", '');			 
			      $("#txtautacao22").attr("value", '');			 
				  $("#txtautacao23").attr("disabled", true);			 
			      $("#txtautacao23").attr("value", '');			 
				  $("#txtautacao24").attr("disabled", true);			 
			      $("#txtautacao24").attr("value", '');			 
				  $("#txtautacao25").attr("disabled", true);			 
			      $("#txtautacao25").attr("value", '');			 

                  }
                });




	              $("#txtinep23").attr("disabled",true);			 
     		      $("#txtqdtaaulas23").attr("disabled", true);			 
                  $("#selectchcontrato23").attr("disabled", true);			 
				  $("#txtautacao23").attr("disabled", true);			 	
			      $("#txtdtlotacontr23").attr("disabled",true);			 				 


	              $("#txtinep24").attr("disabled",true);			 
                  $("#txtqdtaaulas24").attr("disabled", true);			 
                  $("#selectchcontrato24").attr("disabled", true);			 
				  $("#txtautacao24").attr("disabled", true);			 	
			      $("#txtdtlotacontr24").attr("disabled",true);			 				 


	              $("#txtinep25").attr("disabled",true);			 
     		      $("#txtqdtaaulas25").attr("disabled", true);			 
                  $("#selectchcontrato25").attr("disabled", true);			 
				  $("#txtautacao25").attr("disabled", true);			 	
			      $("#txtdtlotacontr25").attr("disabled",true);			 				 




	              $("#txtinep23").attr("value", '');			  
     		      $("#txtqdtaaulas23").attr("value", '');			  
                  $("#selectchcontrato23").attr("value", '');			  
				  $("#txtautacao23").attr("value", '');			  
			      $("#txtdtlotacontr23").attr("value", '');			  


	              $("#txtinep24").attr("value", '');			  
     		      $("#txtqdtaaulas24").attr("value", '');			  
                  $("#selectchcontrato24").attr("value", '');			  
				  $("#txtautacao24").attr("value", '');			  
			      $("#txtdtlotacontr24").attr("value", '');			  

	              $("#txtinep25").attr("value", '');			  
     		      $("#txtqdtaaulas25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '');			  
				  $("#txtautacao25").attr("value", '');			  
			      $("#txtdtlotacontr25").attr("value", '');			  



                  $("#selectchcontrato25").attr("value", '0');			  
   				  $("#selectchcontrato23").attr("value", '0');			  
				  $("#selectchcontrato24").attr("value", '0');			 				
				  
				} 			  
        

            else if(qtdaescola.val() == "3")
				{
     	        
	              $("#txtinep21").attr("disabled",'');			 
     		      $("#txtqdtaaulas21").attr("disabled", '');			 
                  $("#selectchcontrato21").attr("disabled", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", '');			 	
			      $("#txtdtlotacontr21").attr("disabled",'');			 				 


	              $("#txtinep22").attr("disabled",'');			 
     		      $("#txtqdtaaulas22").attr("disabled", '');			 
                  $("#selectchcontrato22").attr("disabled", '');			 
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#txtautacao22").attr("disabled", '');			 	
			      $("#txtdtlotacontr22").attr("disabled",'');			 				 
				

	              $("#txtinep23").attr("disabled",'');			 
     		      $("#txtqdtaaulas23").attr("disabled", '');			 
                  $("#selectchcontrato23").attr("disabled", '');			 
				  $("#selectchcontrato23").attr("value", '0');			 
				  $("#txtautacao23").attr("disabled", '');			 	
			      $("#txtdtlotacontr23").attr("disabled",'');			 				 




          	    var txtcod_cargoescola2 = $("#txtcod_cargo1");
                $("#txtcod_cargo1").click(function(){
                if((txtcod_cargoescola2.val() != "1"))
		           {
				     $("#txtautacao21").attr("disabled", true);			 
                     $("#txtautacao21").attr("value", '');			 
				     $("#txtautacao22").attr("disabled", true);			 
			         $("#txtautacao22").attr("value", '');			 
				     $("#txtautacao23").attr("disabled", true);			 
			         $("#txtautacao23").attr("value", '');			 
     	
		          }
               else
                  {
				    $("#txtautacao21").attr("disabled", '');			 
       		        $("#txtautacao21").attr("value", '');			 

   				  $("#txtautacao22").attr("disabled", '');			 
			      $("#txtautacao22").attr("value", '');			 
				  $("#txtautacao23").attr("disabled", '');			 
			      $("#txtautacao23").attr("value", '');			 
				  $("#txtautacao24").attr("disabled", true);			 
			      $("#txtautacao24").attr("value", '');			 
				  $("#txtautacao25").attr("disabled", true);			 
			      $("#txtautacao25").attr("value", '');			 

                  }
                });





                  $("#txtinep24").attr("disabled",true);			 
                  $("#txtqdtaaulas24").attr("disabled", true);			 
                  $("#selectchcontrato24").attr("disabled", true);			 
				  $("#txtautacao24").attr("disabled", true);			 	
			      $("#txtdtlotacontr24").attr("disabled",true);			 				 


	              $("#txtinep25").attr("disabled",true);			 
     		      $("#txtqdtaaulas25").attr("disabled", true);			 
                  $("#selectchcontrato25").attr("disabled", true);			 
				  $("#txtautacao25").attr("disabled", true);			 	
			      $("#txtdtlotacontr25").attr("disabled",true);			 				 






	              $("#txtinep24").attr("value", '');			  
     		      $("#txtqdtaaulas24").attr("value", '');			  
                  $("#selectchcontrato24").attr("value", '');			  
				  $("#txtautacao24").attr("value", '');			  
			      $("#txtdtlotacontr24").attr("value", '');			  

	              $("#txtinep25").attr("value", '');			  
     		      $("#txtqdtaaulas25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '');			  
				  $("#txtautacao25").attr("value", '');			  
			      $("#txtdtlotacontr25").attr("value", '');			  



                  $("#selectchcontrato25").attr("value", '0');			  
   				  $("#selectchcontrato23").attr("value", '0');			  
				  $("#selectchcontrato24").attr("value", '0');			 				



				} 			  
		
	            else if(qtdaescola.val() == "4")
				{
	              $("#txtinep21").attr("disabled",'');			 
     		      $("#txtqdtaaulas21").attr("disabled", '');			 
                  $("#selectchcontrato21").attr("disabled", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", '');			 	
			      $("#txtdtlotacontr21").attr("disabled",'');			 				 


	              $("#txtinep22").attr("disabled",'');			 
     		      $("#txtqdtaaulas22").attr("disabled", '');			 
                  $("#selectchcontrato22").attr("disabled", '');			 
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#txtautacao22").attr("disabled", '');			 	
			      $("#txtdtlotacontr22").attr("disabled",'');			 				 
				

	              $("#txtinep23").attr("disabled",'');			 
     		      $("#txtqdtaaulas23").attr("disabled", '');			 
                  $("#selectchcontrato23").attr("disabled", '');			 
				  $("#selectchcontrato23").attr("value", '0');			 
				  $("#txtautacao23").attr("disabled", '');			 	
			      $("#txtdtlotacontr23").attr("disabled",'');			 				 


	              $("#txtinep24").attr("disabled",'');			 
     		      $("#txtqdtaaulas24").attr("disabled", '');			 
                  $("#selectchcontrato24").attr("disabled", '');			 
				  $("#selectchcontrato24").attr("value", '0');			 
				  $("#txtautacao24").attr("disabled", '');			 	
			      $("#txtdtlotacontr24").attr("disabled",'');			 				 




          	    var txtcod_cargoescola2 = $("#txtcod_cargo1");
                $("#txtcod_cargo1").click(function(){
                if((txtcod_cargoescola2.val() != "1"))
		           {
				     $("#txtautacao21").attr("disabled", true);			 
                     $("#txtautacao21").attr("value", '');			 
				     $("#txtautacao22").attr("disabled", true);			 
			         $("#txtautacao22").attr("value", '');			 
				     $("#txtautacao23").attr("disabled", true);			 
			         $("#txtautacao23").attr("value", '');			 
				     $("#txtautacao24").attr("disabled", true);			 
			         $("#txtautacao24").attr("value", '');			 


		          }
               else
                  {
				    $("#txtautacao21").attr("disabled", '');			 
       		        $("#txtautacao21").attr("value", '');			 

   				  $("#txtautacao22").attr("disabled", '');			 
			      $("#txtautacao22").attr("value", '');			 
				  $("#txtautacao23").attr("disabled", '');			 
			      $("#txtautacao23").attr("value", '');			 
				  $("#txtautacao24").attr("disabled", '');			 
			      $("#txtautacao24").attr("value", '');			 
				  $("#txtautacao25").attr("disabled", true);			 
			      $("#txtautacao25").attr("value", '');			 

                  }
                });




                  $("#txtinep25").attr("disabled",true);			 
     		      $("#txtqdtaaulas25").attr("disabled", true);			 
                  $("#selectchcontrato25").attr("disabled", true);			 
				  $("#txtautacao25").attr("disabled", true);			 	
			      $("#txtdtlotacontr25").attr("disabled",true);			 				 



	              $("#txtinep25").attr("value", '');			  
     		      $("#txtqdtaaulas25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '');			  
				  $("#txtautacao25").attr("value", '');			  
			      $("#txtdtlotacontr25").attr("value", '');			  
                  $("#selectchcontrato25").attr("value", '0');			  







} 			  

	            else if(qtdaescola.val() == "5")

				{
     	        
	              $("#txtinep21").attr("disabled",'');			 
     		      $("#txtqdtaaulas21").attr("disabled", '');			 
                  $("#selectchcontrato21").attr("disabled", '');			 
				  $("#selectchcontrato21").attr("value", '0');			 
				  $("#txtautacao21").attr("disabled", '');			 	
			      $("#txtdtlotacontr21").attr("disabled",'');			 				 


	              $("#txtinep22").attr("disabled",'');			 
     		      $("#txtqdtaaulas22").attr("disabled", '');			 
                  $("#selectchcontrato22").attr("disabled", '');			 
				  $("#selectchcontrato22").attr("value", '0');			 
				  $("#txtautacao22").attr("disabled", '');			 	
			      $("#txtdtlotacontr22").attr("disabled",'');			 				 
				

	              $("#txtinep23").attr("disabled",'');			 
     		      $("#txtqdtaaulas23").attr("disabled", '');			 
                  $("#selectchcontrato23").attr("disabled", '');			 
				  $("#selectchcontrato23").attr("value", '0');			 
				  $("#txtautacao23").attr("disabled", '');			 	
			      $("#txtdtlotacontr23").attr("disabled",'');			 				 


	              $("#txtinep24").attr("disabled",'');			 
     		      $("#txtqdtaaulas24").attr("disabled", '');			 
                  $("#selectchcontrato24").attr("disabled", '');			 
				  $("#selectchcontrato24").attr("value", '0');			 
				  $("#txtautacao24").attr("disabled", '');			 	
			      $("#txtdtlotacontr24").attr("disabled",'');			 				 


	              $("#txtinep25").attr("disabled",'');			 
     		      $("#txtqdtaaulas25").attr("disabled", '');			 
                  $("#selectchcontrato25").attr("disabled", '');			 
				  $("#selectchcontrato25").attr("value", '0');			 
				  $("#txtautacao25").attr("disabled", '');			 	
			      $("#txtdtlotacontr25").attr("disabled",'');			 				 





          	    var txtcod_cargoescola2 = $("#txtcod_cargo1");
                $("#txtcod_cargo1").click(function(){
                if((txtcod_cargoescola2.val() != "1"))
		           {
				     $("#txtautacao21").attr("disabled", true);			 
                     $("#txtautacao21").attr("value", '');			 
				     $("#txtautacao22").attr("disabled", true);			 
			         $("#txtautacao22").attr("value", '');			 
				     $("#txtautacao23").attr("disabled", true);			 
			         $("#txtautacao23").attr("value", '');			 
				     $("#txtautacao24").attr("disabled", true);			 
			         $("#txtautacao24").attr("value", '');			 
				     $("#txtautacao25").attr("disabled", true);			 
			         $("#txtautacao25").attr("value", '');			 


		          }
               else
                  {
				    $("#txtautacao21").attr("disabled", '');			 
       		        $("#txtautacao21").attr("value", '');			 

   				  $("#txtautacao22").attr("disabled", '');			 
			      $("#txtautacao22").attr("value", '');			 
				  $("#txtautacao23").attr("disabled", '');			 
			      $("#txtautacao23").attr("value", '');			 
				  $("#txtautacao24").attr("disabled", '');			 
			      $("#txtautacao24").attr("value", '');			 
				  $("#txtautacao25").attr("disabled", '');			 
			      $("#txtautacao25").attr("value", '');			 

                  }
                });






} 			  


		  
		   });			  
		


	      }		  
	    });


//*************************************************************
//  Fim Seleciona lotacao 2
//*************************************************************




//********Contrato 2******************************************
//********Contrato 3******************************************

   	    var texto3 = $("#selectlotacao3");
         $("#selectlotacao3").click(function(){
	      if(texto3.val() == "ADM") {
	         $("#txtgerencia2").attr("disabled", '');
	         $("#txtdpto2").attr("disabled", '');			 
			 $("#txtinep3").attr("disabled", true);			 
			 $("#txtinep3").attr("value", '');			 



			 $("#txtqdtaaulas3").attr("disabled", true);			 
			 $("#txtqdtaaulas3").attr("value", '0');			 

			 $("#txtautacao3").attr("disabled", true);			 	
			 $("#txtautacao3").attr("value", '');			 


	      } else 
		  {
	          $("#txtdpto2").attr("disabled", true);
	          $("#txtgerencia2").attr("disabled", true);
	          $("#txtinep3").attr("disabled",'');			 



			 $("#txtqdtaaulas3").attr("disabled", '');			 
			 $("#txtqdtaaulas3").attr("value", '0');			 


			 $("#txtautacao3").attr("disabled", '');			 	

			  $("#txtdpto2").attr("value", '');
			  $("#txtgerencia2").attr("value", '');
			  $("#txtinep3").attr("value", '');			 
	      }
	    });




//********Contrato 1******************************************
$("#txtdescescola").attr("readonly", true);
$("#txtdescescola").attr("value", '');


//********Contrato 2******************************************
$("#txtdescescola2").attr("readonly", true);
$("#txtdescescola2").attr("value", '');


//********Contrato 3******************************************
$("#txtdescescola3").attr("readonly", true);
$("#txtdescescola3").attr("value", '');


 });



$(document).ready(function() {
  $("input").keyup(function(){
    $(this).val($(this).val().toUpperCase());
     })
}) 


		$(function(){
			$('#txtcod_cargo').change(function(){

				if( $(this).val() ) {
					$('#cod_funcao0').hide();
					$('.carregando').show();
   	 				//alert($(this).val());
					$.getJSON('funcao.ajax.php?search=',{txtcod_cargo: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++)
						 {
							options += '<option value="' + j[i].cod_funcao + '">' + j[i].descricao + '</option>';
						    
						  }	
						$('#cod_funcao0').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_funcao0').html('<option value="">– Escolha cargo –</option>');

				}
			});
		});




		$(function(){
			$('#txtgerencia').change(function(){
 				if( $(this).val() ) {
					$('#txtdpto').hide();
					$('.carregando').show();
					$.getJSON('dpto.ajax.php?search=',{txtgerencia: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].codigo_dpto + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdpto').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdpto').html('<option value="">– Escolha Departamento –</option>');

				}
			});
		});





		$(function(){
			$('#txtcod_cargo1').change(function(){
		 
 				if( $(this).val() ) {
					$('#cod_funcao1').hide();
					$('.carregando').show();
					$.getJSON('funcao1.ajax.php?search=',{txtcod_cargo1: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].cod_funcao + '">' + j[i].descricao + '</option>';
						}	
						$('#cod_funcao1').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_funcao1').html('<option value="">– Escolha cargo –</option>');

				}
			});
		});





		$(function(){
			$('#txtgerencia1').change(function(){
 				if( $(this).val() ) {
					$('#txtdpto1').hide();
					$('.carregando').show();
					$.getJSON('dpto1.ajax.php?search=',{txtgerencia1: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].codigo_dpto + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdpto1').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdpto1').html('<option value="">– Escolha Departamento –</option>');

				}
			});
		});



		$(function(){
			$('#cod_cargo2').change(function(){
 				if( $(this).val() ) {
					$('#cod_funcao2').hide();
					$('.carregando').show();
					$.getJSON('funcao2.ajax.php?search=',{cod_cargo2: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].cod_funcao + '">' + j[i].descricao + '</option>';
						}	
						$('#cod_funcao2').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_funcao2').html('<option value="">– Escolha cargo –</option>');

				}
			});
		});




		$(function(){
			$('#txtgerencia2').change(function(){
 				if( $(this).val() ) {
					$('#txtdpto2').hide();
					$('.carregando').show();
					$.getJSON('dpto2.ajax.php?search=',{txtgerencia2: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].codigo_dpto + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdpto2').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdpto2').html('<option value="">– Escolha Departamento –</option>');

				}
			});
		});



		$(function(){
			$('#cod_estado').change(function(){
	 
 				if( $(this).val() ) {
					$('#cod_cidades').hide();
					$('.carregando').show();
					$.getJSON('cidades.ajax.php?search=',{cod_estado: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].cod_cidades + '">' + j[i].nome + '</option>';

						}	
						$('#cod_cidades').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_cidades').html('<option value="">– Escolha um estado –</option>');

				}
			});
		});



function Enum(num){  

 var tecla = num.which;
//alert(tecla);
if (document.all)
    var tecla = event.keyCode;
else if(document.layers)
  var tecla = num.which;
		
 //alert(tecla);
if (((tecla > 47) && (tecla < 58)) || (tecla == 0))
  {
   return true;
  }
else
 {
   if (tecla == 8)
    	 return true
   if (tecla != 8)
    	 return false
   else
    	 return false;
  }
}






function mascaradtrg(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtDataEmissao.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtDataEmissao.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtDataEmissao.value.substring(0,2)); 
		  mes = (document.recadastramento.txtDataEmissao.value.substring(3,5)); 
          ano = (document.recadastramento.txtDataEmissao.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtDataEmissao.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtDataEmissao.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtDataEmissao.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtDataEmissao.value.substring(0,2)); 
		  mes = (document.recadastramento.txtDataEmissao.value.substring(3,5)); 
          ano = (document.recadastramento.txtDataEmissao.value.substring(6,10)); 

          return true;
	   }
   
   }

function mascaradtte(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txttdtte.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txttdtte.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txttdtte.value.substring(0,2)); 
		  mes = (document.recadastramento.txttdtte.value.substring(3,5)); 
          ano = (document.recadastramento.txttdtte.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txttdtte.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txttdtte.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txttdtte.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txttdtte.value.substring(0,2)); 
		  mes = (document.recadastramento.txttdtte.value.substring(3,5)); 
          ano = (document.recadastramento.txttdtte.value.substring(6,10)); 

          return true;
	   }
   
   }


function mascaradtnasc(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtnascimento.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtnascimento.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtnascimento.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtnascimento.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtnascimento.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtnascimento.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtnascimento.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtnascimento.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtnascimento.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtnascimento.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtnascimento.value.substring(6,10)); 

          return true;
	   }
   
   }




		$(function(){
			$('#txtinep1').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola1').hide();
					$('.carregando').show();
					$.getJSON('escola1.ajax.php?search=',{txtinep1: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola1').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola1').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});





		$(function(){
			$('#txtinep2').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola2').hide();
					$('.carregando').show();
					$.getJSON('escola2.ajax.php?search=',{txtinep1: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola2').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola2').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});






		$(function(){
			$('#txtinep2').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola2').hide();
					$('.carregando').show();
					$.getJSON('escola2.ajax.php?search=',{txtinep2: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola2').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola2').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



		$(function(){
			$('#txtinep3').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola3').hide();
					$('.carregando').show();
					$.getJSON('escola3.ajax.php?search=',{txtinep3: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola3').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola3').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



		$(function(){
			$('#txtinep4').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola4').hide();
					$('.carregando').show();
					$.getJSON('escola4.ajax.php?search=',{txtinep4: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola4').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola4').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});




		$(function(){
			$('#txtinep5').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola5').hide();
					$('.carregando').show();
					$.getJSON('escola5.ajax.php?search=',{txtinep5: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola5').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola5').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});








/*
function mascaradtadmissao2(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtadmissao2.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtadmissao2.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtadmissao2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtadmissao2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtadmissao2.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtadmissao2.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtadmissao2.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtadmissao2.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtadmissao2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtadmissao2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtadmissao2.value.substring(6,10)); 

          return true;
	   }
   
   }







function mascaradtdecreto2(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtdecreto2.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtdecreto2.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtdecreto2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtdecreto2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtdecreto2.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtdecreto2.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtdecreto2.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtdecreto2.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtdecreto2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtdecreto2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtdecreto2.value.substring(6,10)); 

          return true;
	   }
   
   }



function mascaradtdiario2(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtdiario2.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtdiario2.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtdiario2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtdiario2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtdiario2.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtdiario2.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtdiario2.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtdiario2.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtdiario2.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtdiario2.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtdiario2.value.substring(6,10)); 

          return true;
	   }
   
   }







function mascaradtlotacao21(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtlotacontr21.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtlotacontr21.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtlotacontr21.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr21.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr21.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr21.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr21.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtlotacontr21.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtlotacontr21.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr21.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr21.value.substring(6,10)); 

          return true;
	   }
   
   }



function mascaradtlotacao22(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtlotacontr22.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtlotacontr22.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtlotacontr22.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr22.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr22.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr22.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr22.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtlotacontr22.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtlotacontr22.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr22.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr22.value.substring(6,10)); 

          return true;
	   }
   
   }




function mascaradtlotacao23(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtlotacontr23.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtlotacontr23.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtlotacontr23.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr23.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr23.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr23.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr23.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtlotacontr23.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtlotacontr23.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr23.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr23.value.substring(6,10)); 

          return true;
	   }
   
   }



function mascaradtlotacao24(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtlotacontr24.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtlotacontr24.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtlotacontr24.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr24.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr24.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr24.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr24.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtlotacontr24.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtlotacontr24.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr24.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr24.value.substring(6,10)); 

          return true;
	   }
   
   }


function mascaradtlotacao25(campoData){
 
   var data = campoData;
   if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.recadastramento.txtdtlotacontr25.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.recadastramento.txtdtlotacontr25.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.recadastramento.txtdtlotacontr25.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr25.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr25.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr25.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.recadastramento.txtdtlotacontr25.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.recadastramento.txtdtlotacontr25.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.recadastramento.txtdtlotacontr25.value.substring(0,2)); 
		  mes = (document.recadastramento.txtdtlotacontr25.value.substring(3,5)); 
          ano = (document.recadastramento.txtdtlotacontr25.value.substring(6,10)); 

          return true;
	   }
   
   }


*/






		$(function(){
			$('#txtinep21').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola21').hide();
					$('.carregando').show();
					$.getJSON('escola21.ajax.php?search=',{txtinep21: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola21').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola21').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



		$(function(){
			$('#txtinep22').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola22').hide();
					$('.carregando').show();
					$.getJSON('escola22.ajax.php?search=',{txtinep22: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola22').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola22').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



		$(function(){
			$('#txtinep23').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola23').hide();
					$('.carregando').show();
					$.getJSON('escola23.ajax.php?search=',{txtinep23: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola23').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola23').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



		$(function(){
			$('#txtinep24').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola24').hide();
					$('.carregando').show();
					$.getJSON('escola24.ajax.php?search=',{txtinep24: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola24').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola24').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});


		$(function(){
			$('#txtinep25').change(function(){
	 
 				if( $(this).val() ) {
					$('#txtdescescola25').hide();
					$('.carregando').show();
					$.getJSON('escola25.ajax.php?search=',{txtinep25: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].inep + '">' + j[i].descricao + '</option>';
						}	
						$('#txtdescescola25').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#txtdescescola25').html('<option value="">– Selecione a Escola –</option>');

				}
			});
		});



jQuery(function($){
   $("#txtdtdiario1").mask("99/99/9999");
   $("#txtdtdecreto1").mask("99/99/9999"); 
   $("#txtdtadmissao1").mask("99/99/9999");    
   $("#selectch1").mask("99");   

});





	$(function() {
		$( "#txtdtadmissao1" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtadmissao1").datepicker();
        $('#txtdtadmissao1').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


	$(function() {
		$( "#txtdtdecreto1" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtdecreto1").datepicker();
        $('#txtdtdecreto1').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

	$(function() {
		$( "#txtdtdiario1" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txtdtdiario1").datepicker();
        $('#txtdtdiario1').datepicker('option', 'dateFormat', 'dd/mm/yy');
});






