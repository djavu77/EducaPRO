<?php
session_start();
if (isset($_SESSION["login_usuario"])) {
    $login = $_SESSION["login_usuario"];
    $nte = $_SESSION["nivel_usuario"];
    $inep = $_SESSION["inep_usuario"];
    $ntelogin = $_SESSION["nte_login"];
    $cpf1 = $_SESSION["cpf_usuario"];
    $form_menu = $_SESSION["form_menu"];
    $txtano_fechado = $_SESSION["txtano_fechado"];

    include ("../../funcoes.php");
} else {
    header("Location: ../../login.php");
}

if ($form_menu == "mnadmescola_ano_fechado")
    $txtano = $txtano_fechado;

/* * ********************************************************* */

$aluno_foi_promovido_ano_corrente = 0;

$id = $_GET['codigo'];

$totalcaracter = strlen($id);
$posicao = strpos($id, '*');
$aluno = substr($id, 0, $posicao);
$posicao2 = strpos($id, '-');
$turma = substr($id, $posicao + 1, $posicao2 - $posicao - 1);
$n_chamadax = substr($id, $posicao2 + 1, $totalcaracter - $posicao2);

$sql = "SELECT ano FROM turma where id = '$turma'";
$resultado = mysql_query($sql) or die(mysql_error());
$linhas = mysql_num_rows($resultado);
if ($linhas > 0) {
    while ($pegar = mysql_fetch_assoc($resultado)) {
        $txtano = $pegar["ano"];
    }
}

$sqlgerencia = "select * from ficha_individual_obs where inep ='$inep' and id_aluno = '$aluno' and ano= '$txtano'";
$resultadoger = mysql_query($sqlgerencia) or die(mysql_error());
$linhas = mysql_num_rows($resultadoger);
if ($linhas > 0) { // retorna para associar
    while ($pegar = mysql_fetch_assoc($resultadoger)) {
        $txtobs = $pegar["obs"];
    }
}

/* * **********Verificando se o aluno foi transferido cursando ou conclunte************************* */

$aluno_transferido = 0;

$sqltransferencia = "SELECT ma.id_status,ma.dt_situacao,ta.id_turma,ta.n_chamada
                    FROM movimenta_aluno ma, turma_aluno ta
                    WHERE ma.id_aluno = '$aluno'
                    and ma.id_turmaaluno = ta.id
                    and ma.id_movimento = '3'
                    and ta.inep = '$inep'
                    and ta.situacao = ma.id_movimento";
$resultadotransferencia = mysql_query($sqltransferencia) or die(mysql_error());
$linhastransferencia = mysql_num_rows($resultadotransferencia);
if ($linhastransferencia > 0) {
    while ($pegartransferencia = mysql_fetch_assoc($resultadotransferencia)) {
        $nr_chamada_transferencia = $pegartransferencia["n_chamada"];
        $id_turma_transferencia = $pegartransferencia["id_turma"];
        $id_status_transferencia = $pegartransferencia["id_status"];
        $dt_transferencia = date("d/m/Y", strtotime($pegartransferencia["dt_situacao"]));
        $aluno_transferido = 1;

        if (($dt_transferencia == "") || ($dt_transferencia == "1969/12/31"))
            $dt_transferencia = "";
    }
}

/* * ******************Promovido************************************** */

$sql_promovido = "select ta.situacao,t.id from turma_aluno ta, turma t
                    where ta.inep ='$inep'
                    and ta.id_aluno = '$aluno'
                    and ta.id_turma = '$turma'
                    and ta.situacao = '7'
                    and t.id=ta.id_turma
                    and t.ano= ta.ano
                    and t.inep = ta.inep";
$resultado_promovido = mysql_query($sql_promovido) or die(mysql_error());
$linhas_promovido = mysql_num_rows($resultado_promovido);
if ($linhas_promovido > 0) { // retorna para associar
    while ($pegar_promovido = mysql_fetch_assoc($resultado_promovido)) {
        $id_turma_promovido = $pegar_promovido["id"];
        $aluno_foi_promovido_ano_corrente = '1';
    }
}

/* * ********************************************************************************* */

$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni,e.tipo
                from escola e , municipio m  
                where inep ='$inep' "
        . "     and e.municipio = m.codigo ";
$resultadoger = mysql_query($sqlgerencia) or die(mysql_error());
$linhas = mysql_num_rows($resultadoger);
if ($linhas > 0) {
    while ($pegar = mysql_fetch_assoc($resultadoger)) {
        $descescola = $pegar["descescola"];
        $descmunici = $pegar["descmuni"];
        $endereco = $pegar["endereco"];
        $bairro = $pegar["bairro"];
        $numero = $pegar["numero"];
        $zona = $pegar["tipo"];
        $fone = $pegar["fone"];
        $regularizada = $pegar["regularizada"];
    }
}

$total_aluno_repetido = 0;

$sqlaluno = "select count(ta.id_aluno) as total_repetido from turma t,turma_aluno ta where t.id=ta.id_turma
            and ta.id_aluno = '$aluno'
            and t.id = '$turma'";
$resultadoaluno = mysql_query($sqlaluno) or die(mysql_error());
$linhasaluno = mysql_num_rows($resultadoaluno);
if ($linhasaluno > 0) {
    while ($pegaraluno = mysql_fetch_assoc($resultadoaluno)) {
        $total_aluno_repetido = $pegaraluno["total_repetido"];
    }
}

/* descobrindo qual se o aluno faz dependencia e qual e o codigo da turma */

$sqlaluno = "select t.id 
            from turma t,turma_aluno ta 
            where t.id=ta.id_turma
            and ta.id_aluno = '$aluno'
            and t.ano='$txtano'
            and t.turmas in (75,76,77,78,79,100,101)";

$resultadoaluno = mysql_query($sqlaluno) or die(mysql_error());
$linhasaluno = mysql_num_rows($resultadoaluno);
if ($linhasaluno > 0) {
    while ($pegaraluno = mysql_fetch_assoc($resultadoaluno)) {
        $id_turma_dependencia = $pegaraluno["id"];
    }
}

$sqlaluno = "select *
            from turma t,turma_aluno ta 
            where t.id=ta.id_turma
            and ta.id_aluno = '$aluno'
            and t.ano='$txtano'
            and t.id = '$turma'
            and n_chamada = '$n_chamadax'";
$resultadoaluno = mysql_query($sqlaluno) or die(mysql_error());
$linhasaluno = mysql_num_rows($resultadoaluno);
if ($linhasaluno > 0) {
    while ($pegaraluno = mysql_fetch_assoc($resultadoaluno)) {
        $turmadesc = $pegaraluno["DESCRICAO"];
        $n_chamada = $pegaraluno["n_chamada"];
        $modalidade = $pegaraluno["MODALIDADE"];
        $turma_dep = $pegaraluno["turmas"];
        $id_grade = $pegaraluno["id_grade"];
        $ano_letivo = $pegaraluno["ANO"];
        $situacao_aluno = $pegaraluno["situacao"];
        $grade_curricular_x = $pegaraluno["id_grade"];
        $grade_curricular = $pegaraluno["id_grade"];
        $dtfecha_turma = date("d/m/Y", strtotime($pegaraluno["dtfecha_turma"]));
        $turma_dep = $pegaraluno["TURMAS"];
        $semestre = $pegaraluno["SEMESTRE"];
        $situacao = $pegaraluno["situacao"];
        $turmasserie = $pegaraluno["id_grade"];

        if (($dtfecha_turma == '31/12/1969') || ($dtfecha_turma == '30/11/-0001')) {
            $dtfecha_turma = 'Turma Aberta';
        }
    }
}

$adere_exame_final = 0;

$sqletapa = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa  =  '9'
               and id_modalidade = '$modalidade'
               and inep = '$inep'";
$resultadoetapa = mysql_query($sqletapa) or die(mysql_error());
$linhasetapa = mysql_num_rows($resultadoetapa);

if ($linhasetapa > 0) { // retorna para associar
    while ($pegaretapa = mysql_fetch_assoc($resultadoetapa)) {
        $adere_exame_final = 1;
    }
}

$banco_vazio = 0;

//$re = mysql_query("select count(*) as total from nota_aluno n, habilitacao h where h.codigo = n.id_disciplina");

$re = mysql_query("select count(*) as total from nota_aluno  where  id_aluno = '$aluno'  ");
$total = mysql_result($re, 0, "total");

if ($total == 0) {
    $banco_vazio = 1;
}

/* * ***********************Totaliznado Faltas********************************************************************************* */

$total_conta_faltas = 0;

$re_abono_faltas = mysql_query("select sum(falta) as t_faltas from abono_faltas where  id_aluno = '$aluno' and ano = '$txtano' and inep = '$inep' and cancelado = 'N'");
$total_abono_faltas = mysql_result($re_abono_faltas, 0, "t_faltas");
if ($total_abono_faltas == '')
    $total_abono_faltas = 0;

/* * ******************************Tipo de Recuperacao************************************************************************** */

$sql_tp_recuperacao = "select id_recuperacao from recuperacao_escola
     where  ano = '$txtano' and inep = '$inep' and id_modalidade='$modalidade'";
$resultado_tp_recuperacao = mysql_query($sql_tp_recuperacao) or die(mysql_error());
$linhas_tp_recuperacao = mysql_num_rows($resultado_tp_recuperacao);

if ($linhas_tp_recuperacao > 0) { // retorna para associar
    while ($pegar_tp_recuperacao = mysql_fetch_assoc($resultado_tp_recuperacao)) {
        $tp_recuperacao = $pegar_tp_recuperacao["id_recuperacao"];
    }
} else {
    if ($form_menu != "mnadmescola_ano_fechado") {
        echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Recupera��o n�o definida ou Aluno sem n�mero no di�rio!</font></center>";
    } else {
        echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Recupera��o n�o definida ou Aluno sem n�mero no di�rio!</font></center>";
    }
}

if (($modalidade == '1') || ($modalidade == '3')) {

    if (($turma_dep == '75') || ($turma_dep == '76') || ($turma_dep == '77') || ($turma_dep == '78') || ($turma_dep == '79') || ($turma_dep == '100') || ($turma_dep == '101')) {
        $sql = mysql_query(" SELECT *
            FROM nota_aluno n, habilitacao h, turma_dep_aluno_disciplina t
            WHERE h.codigo = n.id_disciplina
            AND n.id_aluno = '$aluno'
            AND n.id_turmaprofessor = '$turma'
            AND t.id_turma = n.id_turmaprofessor
            AND n.inep = t.inep
            AND t.id_disciplina = h.codigo
            and t.ano = '$txtano'
            AND t.id_aluno = n.id_aluno  order by h.impressao");
    } else {
        if ($total_aluno_repetido > 1) {

            $sql = mysql_query("SELECT n.id, n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, recuperacao3, recuperacao4,
                                n.examefinal, n.id_disciplina, t_falta1,t_falta2,t_falta3,t_falta4,t_falta_rec1,t_falta_rec2,t_falta_rec3,t_falta_rec4,
                                h.codigo, t.situacao, bim1, bim2, bim3, bim4,h.descricao
                                FROM nota_aluno n, habilitacao h, turma_aluno t
                                WHERE h.codigo = n.id_disciplina
                                AND t.id_aluno = '$aluno'
                                AND t.id_grade = '$turmasserie'
                                and t.ano = '$txtano'
                                AND t.id_aluno = n.id_aluno
                                AND t.id_turma = n.id_turma
                                AND t.situacao in (1,2,3)
                                GROUP BY n.id
                                order by h.impressao");
        } else {
            if ($situacao == '7') {
                $sql = mysql_query("SELECT n.id_disciplina,n.nota,n.id_aluno
                                    FROM componente_eliminado n, habilitacao h, turma_aluno t
                                    WHERE h.codigo = n.id_disciplina
                                    AND t.id_aluno = '$aluno'
                                    AND t.id_grade = '$turmasserie'
                                    and t.ano = '$txtano'
                                    AND t.id_aluno = n.id_aluno
                                    AND t.id_turma = n.id_turma
                                    AND t.situacao = 7 order by h.impressao");
            } else {
                if ($aluno_foi_promovido_ano_corrente == 0) {

                    $sql = mysql_query("SELECT *
                                    FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta, grade_curricular g
                                    WHERE t.id_grade = '$turmasserie'
                                    and   t.ano = '$txtano'
                                    AND   t.id_grade = g.id_serie
                                    AND   n.id_aluno = '$aluno'
                                    AND   n.id_disciplina = g.id_disciplina
                                    AND   h.codigo   = n.id_disciplina
                                    AND   h.codigo   = g.id_disciplina
                                    AND   ta.id_aluno = n.id_aluno
                                    AND   ta.id_turma = t.id
                                    AND   g.id_modalidade = t.modalidade
                                    AND   g.ano = t.ano
                                    AND   n.id_turma = t.id
                                    AND ta.situacao
                                    IN ( 1, 2, 3, 5 ) group by  n.id_disciplina
                                    ORDER BY h.impressao");
                } else {
                    /* caso aluno tenha sido promovido no ano corrente */
                    $sql = mysql_query("SELECT *
                                       FROM nota_aluno n, habilitacao h, turma_aluno t
                                       WHERE h.codigo = n.id_disciplina
                                       AND t.id_aluno = '$aluno'
                                       AND t.id_grade = '$turmasserie'
                                       and t.ano = '$txtano'
                                       AND n.id_turma = t.id
                                       AND t.id_aluno = n.id_aluno
                                        AND t.situacao in (1,2,3)
                                        group by  n.id_disciplina
                                        order by h.impressao");
                }
            }
        }
    }
} else {
    $sql = mysql_query("select *
                    from nota_aluno n, habilitacao h, turma t
                     where h.codigo = n.id_disciplina
                     and id_aluno = '$aluno'
                     and t.id_grade = '$turmasserie'
                     and t.semestre = '$semestre'
                     and t.ano = '$txtano'
                     and t.id = n.id_turma
                     and t.modalidade = '$modalidade' 
                     order by h.impressao");
}

/* * ******Inicio do pocesso dos alunos******** */

$conta = mysql_num_rows($sql);

/* Pegando o numero de chamado */
$sqlaluno = "SELECT *,id, nome  as nome_aluno, nome_pai, nome_mae, dt_nascimento, mod_certidao, n_certidao_novo, termo_certidao,foto, livro_certidao,
            folha_certidao, dtemissao_certidao ,(YEAR(CURDATE( )) - YEAR(dt_nascimento )) as idade,uf_nascimento,muni_nascimento,
            pais_estrangeiro,estado_estrangeiro,municipio_estrangeiro
            FROM aluno  where id = '$id' order by nome";


$resultadoaluno = mysql_query($sqlaluno) or die(mysql_error());
$linhasaluno = mysql_num_rows($resultadoaluno);
if ($linhasaluno > 0) {
    while ($pegaraluno = mysql_fetch_assoc($resultadoaluno)) {

        $alunodesc = $pegaraluno["nome_aluno"];
        $nomepai = $pegaraluno["nome_pai"];
        $nomemae = $pegaraluno["nome_mae"];
        $endaluno = $pegaraluno["endereco"];
        $numeroaluno = $pegaraluno["numero"];
        $bairroaluno = $pegaraluno["bairro"];
        $dtnacimento = date("d/m/Y", strtotime($pegaraluno["dt_nascimento"]));
        $termo_certidao = $pegaraluno["termo_certidao"];
        $livro_certidao = $pegaraluno["livro_certidao"];
        $folha_certidao = $pegaraluno["folha_certidao"];
        $dtemissao_certidao = date("d/m/Y", strtotime($pegaraluno["dtemissao_certidao"]));
        $id_nacional = $pegaraluno["id_nacional"];
        $id = $pegaraluno["id"];
        $cidade = $pegaraluno["cidade"];
        $idade = $pegaraluno["idade"];
        $sigla = $pegaraluno["sigla"];
        $mod_certidao = $pegaraluno["mod_certidao"];
        $termo_certidao_nova = $pegaraluno["n_certidao_novo"];
        $termo_certidao = $pegaraluno["termo_certidao"];

        if ($termo_certidao == "")
            $termo_certidao = $termo_certidao_nova;

        if (($dtemissao_certidao == '31/12/1969') || ($dtemissao_certidao == '30/11/-0001')) {
            $dtemissao_certidao = '';
        }

        $id_ufnascimento = $pegaraluno["uf_nascimento"];
        $muni_nascimento = $pegaraluno["muni_nascimento"];

        $pais_estrangeiro = $pegaraluno["pais_estrangeiro"];
        $estado_estrangeiro = $pegaraluno["estado_estrangeiro"];
        $municipio_estrangeiro = $pegaraluno["municipio_estrangeiro"];
    }
}

$sqluf = "select * from estados where cod_estados = '$id_ufnascimento'";
$resultadouf = mysql_query($sqluf) or die(mysql_error());
$linhasuf = mysql_num_rows($resultadouf);

if ($linhasuf > 0) {
    while ($pegaruf = mysql_fetch_assoc($resultadouf)) {
        $sigla = $pegaruf["sigla"];
    }
}

$sqlmuni = "select *  from cidades where cod_ibge = '$muni_nascimento'";
$resultadomuni = mysql_query($sqlmuni) or die(mysql_error());
$linhasmuni = mysql_num_rows($resultadomuni);
if ($linhasmuni > 0) {
    while ($pegarmuni = mysql_fetch_assoc($resultadomuni)) {
        $cidade = $pegarmuni["nome"];
    }
} else {
    $sqlmuni = "select *  from cidades where cod_cidades = '$muni_nascimento'";
    $resultadomuni = mysql_query($sqlmuni) or die(mysql_error());
    $linhasmuni = mysql_num_rows($resultadomuni);
    if ($linhasmuni > 0) {
        while ($pegarmuni = mysql_fetch_assoc($resultadomuni)) {
            $cidade = $pegarmuni["nome"];
        }
    }
}

if ($id_ufnascimento == '28') {
    $sigla = $estado_estrangeiro . " / " . $pais_estrangeiro;
    $cidade = $municipio_estrangeiro;
}

if ($mod_certidao == '1') { //modelo novo
    $termo_certidao = $termo_certidao_nova;
    $livro_certidao = "-";
    $folha_certidao = "-";
}

$total_etapas_ava_fora_rede = 0;

/* * ******************************Avalia��o fora do estado**************************************************** */
$sql_avaliaca_fora_rede = "select *  from tp_avaliacao_recebida where id_aluno  = '$aluno'";
$resultado_avaliaca_fora_rede = mysql_query($sql_avaliaca_fora_rede) or die(mysql_error());
$linhas_avaliaca_fora_rede = mysql_num_rows($resultado_avaliaca_fora_rede);

if ($linhasuf > 0) {
    while ($pegar_avaliaca_fora_rede = mysql_fetch_assoc($resultado_avaliaca_fora_rede)) {
        $total_etapas_ava_fora_rede = $pegar_avaliaca_fora_rede["id_etapa"];
    }
}
?><html>
    <head>
        <title>BOLETIM</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
        <script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
        <script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">
        <script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
        <link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
    </head>
    <style>
        .titulopagina { font-size: 11px; color:    #000099; background-color:#E8E8E8; height:25px; font-family: verdana , arial }
        table.bordasimples {border-collapse: collapse;}
        table.bordasimples tr td {border:1px solid #CCCCCC;}
        .subtitulo { font-family: verdana ; font-size: 9pt; color: #22408f; font-weight: bold; }
        .nomecampo { font-size: 9px; color: midnightblue; font-family: verdana, arial; font-weight: bold; }
        .imprimi { font-size: 10px; color: #000000; font-family: verdana, arial }
        .escrita { font-size: 10px; color: #000000; font-family: verdana, arial }
        .escritanormal { font-size: 10px; color: #000000; font-family: verdana, arial; font-weight: normal; }
        .escritagrade { font-size: 7px; color: #000000; font-family: verdana, arial; font-weight: normal; }
        .button { background-color: #FFF; border: 1px solid #666; border-radius: 2px; }
        .text-center{ text-align: center; }
        .text-right { text-align: right; }
    </style>
    <style media="print">
        .hidden-print { display: none; }
    </style>
</head>
<body>
<center><img src= "../../public/img/logo-brasao-rondonia.png"></center>
<br>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
    <tr>
        <td class="nomecampo"><b>C�digo INEP:</b></td>
        <td><?php echo $inep; ?></td>
        <td class="nomecampo"><b>Raz�o Social:</b></td>
        <td class="escrita"><?php echo $descescola; ?></td>
        <td class="nomecampo"><b>Zona:</b></td>
        <td class="escrita"><?php echo $zona; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Endere�o:</b></td>
        <td class="escrita"><?php echo $endereco; ?></td>
        <td class="nomecampo">N�:</td>
        <td><?php echo $numero; ?></td>
        <td class="nomecampo"><b>Bairro</b></td>
        <td class="escrita"><?php echo $bairro; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>UF:</b></td>
        <td>RO</td>
        <td class="nomecampo"><b>Munic�pio:</b></td>
        <td class="escrita"><?php echo $descmunici; ?></td>
        <td class="nomecampo"><b>Regularizada:</b></td>
        <td><?php echo $regularizada; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Telefone:</b></td>
        <td><?php echo $fone; ?></td>
        <td class="nomecampo"><b>Dep. administrativa:</b></td>
        <td colspan="">Estadual</td>
        <td class="nomecampo"><b>Ano Letivo:</b></td>
        <td><?php echo $ano_letivo; ?></td>
    </tr>
</table>

<?php
while ($pegar = mysql_fetch_assoc($resultado)) {
    $iddisciplina = $pegar["disciplina"];
    $idturma = $pegar["idturma"];
    $cpfprofessor = $pegar["cpf"];
}
?>

<br>
<table border="0" class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
    <tr>
        <td colspan="8" class="escrita" align="center">
            <b>Dados do Estudante</b>
        </td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Nome:</b></td>
        <td class="escrita"><b><?php echo $alunodesc; ?></b></td>
        <td class="nomecampo"><b>Nascimento:</b></td>
        <td colspan="5" class="escrita"><b><?php echo $dtnacimento; ?></b></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Pai</b></td>
        <td class="escrita"><?php echo $nomepai; ?></td>
        <td class="nomecampo"><b>M�e</b></td>
        <td class="escrita" colspan="5"><?php echo $nomemae; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Endere�o</b></td>
        <td class="escrita"><?php echo $endaluno; ?></td>
        <td class="nomecampo"><b>Bairro</b></td>
        <td class="escrita"><?php echo $bairroaluno; ?></td>
        <td class="nomecampo"><b>N�</b></td>
        <td class="escrita" colspan="7" ><?php echo $numeroaluno; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>ID Nacional</b></td>
        <td class="escrita"><?php echo $id_nacional; ?></td>
        <td class="nomecampo"><b>ID Estadual:</b></td>
        <td class= "escrita" colspan="7"><b><?php echo $id; ?></b></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Certid�o</b></td>
        <td class= "escrita"><?php echo $termo_certidao; ?></td>
        <td class="nomecampo"><b>Livro</b></td>
        <td class="escrita" ><?php echo $livro_certidao; ?></td>
        <td class="nomecampo"><b>Folha</b></td>
        <td class="escrita" ><?php echo $folha_certidao; ?></td>
        <td class="nomecampo"><b>Data Emiss�o</b></td>
        <td class="escrita" colspan="5" ><?php echo $dtemissao_certidao; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Turma</b></td>
        <td class="escrita"><b><?php echo $turmadesc; ?></b></td>
        <td class="nomecampo"><b>Chamada</b></td>
        <td class="escrita" ><b><?php echo $n_chamada; ?></b></td>
        <td class="nomecampo"><b>Modalidade</b></td>
        <td class="escrita" colspan="5"><?php echo $modalidade; ?></td>
    </tr>
    <tr>
        <td class="nomecampo"><b>Idade</b></td>
        <td class="escrita"><b><?php echo $idade; ?></b></td>
        <td class="nomecampo"><b>Naturalidade</b></td>
        <td class="escrita" ><?php echo $cidade; ?></td>
        <td class="nomecampo"><b>UF</b></td>
        <td class="escrita" colspan="5"><?php echo $sigla; ?></td>
    </tr>
</table>

<h4 class="text-center">BOLETIM</h4>

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
    <?php
    /*     * ***Quando n�o existir nenhumar imforma��o e o aluno e transferido********************************************************************************************** */
    if ($conta == 0) {
        /* Caso o aluno seja transferido */
        if (($aluno_transferido == 1) && ($id_turma_transferencia == $turma) && ($nr_chamada_transferencia == $n_chamada)) {
            ?>
            <tr>
                <td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left">
                    <b>Data de Fechamento: <?php echo $dtfecha_turma; ?> </b>
                </td>
            </tr>
            <tr>
                <td colspan="6" bgcolor="#EAEAEA" class="subtitulo" align="left">
                    <b>Situa��o Final: TRANSFERIDO </b>
                </td>
            </tr>
            <tr>
                <td colspan="6" bgcolor="#EAEAEA" class="subtitulo" align="left">
                    <b>Transferido :<?php echo $dt_transferencia; ?> </b>
                </td>
            </tr>            
            <?php
            /*             * ***********Aqui termina transferido sem nenhuma movimenta��o************************************************************************************* */
            /*             * ***********************Caso o aluno seja transferido******************************************** */
        } else {
            if ($form_menu != "mnadmescola_ano_fechado") {
                echo "<center><img src=\"../../faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Banco de Dados Sem Lan�amento!</font></center>";
            } else {
                echo "<center><img src=\"../../faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Banco de Dados Sem Lan�amento!</font></center>";
            }
        }
    }//conta

    /* Quando n�o existir nenhumar imforma��o e o aluno e transferido */
    /* Banco Sem Informa��o */
    if ($total == 0) {
        /* Buscando o Status do aluno Ex Transferindo */

        $sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
        $resultado_turma_aluno = mysql_query($sql_turma_aluno) or die(mysql_error());
        $linhas_turma_aluno = mysql_num_rows($resultado_turma_aluno);
        if ($linhas_turma_aluno > 0) {
            while ($linhas_turma_aluno = mysql_fetch_assoc($resultado_turma_aluno)) {
                $id_situacao = $linhas_turma_aluno["situacao"];
            }
        }

        $sqlsitua = "select * from tipo_mov_aluno  where id = '$id_situacao'";
        $resultadositua = mysql_query($sqlsitua) or die(mysql_error());
        $linhassitua = mysql_num_rows($resultadositua);

        if ($linhassitua > 0) {
            while ($pegarsitua = mysql_fetch_assoc($resultadositua)) {
                $situa_desc = $pegarsitua["descricao"];
            }
        }

        if ($id_situacao == '1') {
            $situa_desc = 'CURSANDO';
        }
        ?>

        <table width="100%">
            <tr>
                <td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center">
                    <b><?php echo $situa_desc; ?></b>
                </td>
            </tr>
        </table>

        <table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
            <tr>    
                <td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left">
                    <b>Total de Faltas :<?php echo $soma_faltas; ?></b>
                </td>
            </tr>
            <tr>
                <td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left">
                    <b>Data de Fechamento :<?php echo $dtfecha_turma; ?></b>
                </td>
            </tr>
            <?php
            if (($aluno_transferido == 1) && ($id_turma_transferencia == $turma) && ($nr_chamada_transferencia == $n_chamada)) {
                ?>
                <tr>
                    <td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left">
                        <b>Transferido :<?php echo $dt_transferencia; ?></b>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>

        <?php
    }

    /*     * ************************* Recupera��o bimestral e Semestral**************************************************** */
    if (($tp_recuperacao == 1) || ($tp_recuperacao == 2)) {
        /*         * ************************* modalidade regular e especial**************************************************** */

        if (($modalidade == '1') || ($modalidade == '3')) {
            ?>

            <tr>
                <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
                <td class="nomecampo" align="center"><b>1�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 1�B</b></td>
                <td class="nomecampo" align="center"><b>2�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 2�B</b></td>
                <td class="nomecampo" align="center"><b>3�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 3�B</b></td>
                <td class="nomecampo" align="center"><b>4�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 4�B</b></td>
                <td class="nomecampo" align="center"><b>R 1�B</b></td>
                <td class="nomecampo" align="center"><b>R 2�B</b></td>
                <td class="nomecampo" align="center"><b>R 3�B</b></td>
                <td class="nomecampo" align="center"><b>R 4�B</b></td>
                <td class="nomecampo" align="center"><b>Soma </b></td>
                <td class="nomecampo" align="center"><b>M.A</b></td>
                <td class="nomecampo" align="center"><b>Ex.Final</b></td>
                <td class="nomecampo" align="center"><b>Total Faltas</b></td>
                <td class="nomecampo" align="center"><b>M.F</b></td>
            </tr>

            <?php
        } else {
            ?>
            <tr>
                <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
                <td class="nomecampo" align="center"><b>1�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 1�B</b></td>
                <td class="nomecampo" align="center"><b>2�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 2�B</b></td>
                <td class="nomecampo" align="center"><b>R 1�B</b></td>
                <td class="nomecampo" align="center"><b>R 2�B</b></td>
                <td class="nomecampo" align="center"><b>Soma </b></td>
                <td class="nomecampo" align="center"><b>M.A</b></td>
                <td class="nomecampo" align="center"><b>Ex.Final</b></td>
                <td class="nomecampo" align="center"><b>Total Faltas</b></td>
                <td class="nomecampo" align="center"><b>M.F</b></td>
            </tr>

            <?php
        }//else
        //$totalfaltas = 0;
        $soma_faltas = 0;
        $passou = 0;
        $retido = 0;
        $aprovado = 0;
        $cursando = 0;
        $aluno_promovido = 0;

        $id_disciplina_retido = "";

        $conta_obs_conselho_professores = 0;
        $conta_obs_provao = 0;
        $conta_obs_enem = 0;
        $conta_obs_modular = 0;
        $conta_obs_telensino = 0;
        $conta_obs_reclassificacao = 0;
        $conta_obs_proenco = 0;
        $conta_obs_enceja = 0;
        $conta_obs_lacuna = 0;

        $total_faltas_final = 0;
        $total_faltas = 0;

        while ($dado = mysql_fetch_assoc($sql)) {
            $dtabertura = date("d/m/Y", strtotime($dado["data"]));
            $id_disciplina = $dado["id_disciplina"];
            /* Verifica a situacao do aluno */

            $sql_turma_aluno = "select situacao from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
            $resultado_turma_aluno = mysql_query($sql_turma_aluno) or die(mysql_error());
            $linhas_turma_aluno = mysql_num_rows($resultado_turma_aluno);
            if ($linhas_turma_aluno > 0) {
                while ($linhas_turma_aluno = mysql_fetch_assoc($resultado_turma_aluno)) {
                    $id_situacao = $linhas_turma_aluno["situacao"];
                }
            }

            $sqlsitua = "select descricao from tipo_mov_aluno  where id = '$id_situacao'";
            $resultadositua = mysql_query($sqlsitua) or die(mysql_error());
            $linhassitua = mysql_num_rows($resultadositua);
            if ($linhassitua > 0) {
                while ($pegarsitua = mysql_fetch_assoc($resultadositua)) {
                    $situa_desc = $pegarsitua["descricao"];
                }
            }

            $mfinal = 0;

            $n1 = $dado["nota1"];
            $n2 = $dado["nota2"];
            $n3 = $dado["nota3"];
            $n4 = $dado["nota4"];

            $examefinal = $dado["examefinal"];

            $nrec1 = $dado["recuperacao1"];
            $nrec2 = $dado["recuperacao2"];
            $nrec3 = $dado["recuperacao3"];
            $nrec4 = $dado["recuperacao4"];

            $bim1 = $dado["bim1"];
            $bim2 = $dado["bim2"];
            $bim3 = $dado["bim3"];
            $bim4 = $dado["bim4"];

            $sqlCargaHoraria = "SELECT ch
                                FROM grade_curricular g, turma t
                                WHERE  g.inep = '$inep'
                                    AND g.ano = '$txtano'
                                    AND g.id_modalidade = t.MODALIDADE
                                    AND g.id_disciplina = '$id_disciplina'
                                    AND t.id_grade = g.id_serie
                                    AND t.id = '$turma'";
            $queryCargaHoraria = mysql_query($sqlCargaHoraria) or die(mysql_error());
            $pegarCargaHoraria = mysql_fetch_assoc($queryCargaHoraria);
            $cargaHoraria = $pegarCargaHoraria["ch"];

            if ($id_disciplina != '20') {
                $t_falta1 = $dado["t_falta1"];
                $t_falta2 = $dado["t_falta2"];
                $t_falta3 = $dado["t_falta3"];
                $t_falta4 = $dado["t_falta4"];

                /**                 * ************Aluno foi promovido no ano corrente******************** */
                if ($aluno_foi_promovido_ano_corrente == 0) {
                    $total_faltas = ($t_falta1 + $t_falta2 + $t_falta3 + $t_falta4); //por disciplina
                } else {
                    $total_faltas = ($t_falta2 + $t_falta3 + $t_falta4); //por disciplina
                }

                $soma_faltas = $total_faltas + $soma_faltas;
            }

            $id_disciplina = $dado["id_disciplina"];


            if ($n1 > $nrec1) {
                $notareal1 = $n1;
            } else {
                $notareal1 = $nrec1;
            }

            if ($n2 > $nrec2) {
                $notareal2 = $n2;
            } else {
                $notareal2 = $nrec2;
            }

            if ($n3 > $nrec3) {
                $notareal3 = $n3;
            } else {
                $notareal3 = $nrec3;
            }

            if ($n4 > $nrec4) {
                $notareal4 = $n4;
            } else {
                $notareal4 = $nrec4;
            }

            $sqlgrade = "select reprova from grade_curricular
                         where id_disciplina = '$id_disciplina'
                         and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade' and ano = '$txtano' and inep = '$inep'";

            $resultadograde = mysql_query($sqlgrade) or die(mysql_error());
            $linhasgrade = mysql_num_rows($resultadograde);
            if ($linhasgrade > 0) {
                while ($pegargrade = mysql_fetch_assoc($resultadograde)) {
                    $reprova = $pegargrade["reprova"];
                }
            }

            /* modalidade regular e especial */

            if (($modalidade == '1') || ($modalidade == '3')) { // regular e especial
                /** Cursando * */
                if (($id_situacao == '1') || ($id_situacao == '8')) {

                    /**                     * ******Caso o aluno seja promovido o aluno devera ser durante os 25 por cento******** */
                    if ($aluno_foi_promovido_ano_corrente == 0) {
                        $soma = ($notareal1 + $notareal2 + $notareal3 + $notareal4);
                        $media = ($soma) / 4;
                    } else {
                        $soma = ($notareal2 + $notareal3 + $notareal4);
                        $media = ($soma) / 3;
                    }

                    if ($total_etapas_ava_fora_rede > 0) {
                        $soma = ($notareal2 + $notareal3 + $notareal4);
                        $media = ($soma) / (4 - $total_etapas_ava_fora_rede);
                    }

                    $mfinal = 0;

                    if (($reprova == 'S') || ($reprova == '')) {

                        if (($media < 6.0)) {
                            /*                             * *Aderencia de Exame Final* */
                            if ($adere_exame_final == 1) {
                                $mfinal = ($media * 6 + $examefinal * 4);

                                if ($mfinal < 50.0) {
                                    $situacao = "RETIDO";
                                    $retido = "1";
                                    $id_disciplina_retido = $id_disciplina;
                                    $mfinal = $mfinal / 10;
                                } else {
                                    //$retido = "0";
                                    if ($retido != "1")
                                        $situacao = "APROVADO";

                                    $mfinal = $mfinal / 10;
                                }
                            }
                            else { /* n�o adere a exame final */

                                if ($nrec1 > $media) {
                                    $mfinal = $media;
                                } else {
                                    $mfinal = $media;
                                }

                                $situacao = "RETIDO";
                                $retido = "1";
                                $id_disciplina_retido = $id_disciplina;
                            }
                        } else {
                            if ($retido != "1")
                                $situacao = "APROVADO";
                            // if ($nrec1 > $media)
                            //       $mfinal = $nrec1 ;
                            //else
                            $mfinal = $media;
                        }
                    }
                    else {
                        // SE A DISCIPLINA N�O REPROVA
                        if ($retido != "1")
                            $situacao = "APROVADO";

                        if (($media < 6.0)) {
                            if ($adere_exame_final == 1) {
                                $mfinal = ($media * 6 + $examefinal * 4) / 10;
                            } else
                                $mfinal = $media;
                        } else
                            $mfinal = $media;
                    }

                    if (($bim1 != 'S') || ($bim2 != 'S') || ($bim3 != 'S') || ($bim4 != 'S')) {
                        $situacao = "CURSANDO";

                        /*                         * ***Verifica se alguma disciplina n esta com os quatro bimestre fechados* */
                        if ($cursando == 0) /* WTF ????? */
                            $cursando = 1;
                    }

                    if ($situacao_aluno == 3) {
                        $situacao = "TRANSFERIDO";
                    }
                }// if situacao
                else {
                    $situacao = $situa_desc;
                }

                /*                 * *****************Analisando Situacoes especiais como Provao Modular Enem*********************** */
                /*                 * ************************************Proenco, enseja, reclassifica��o*************************** */
                /*                 * **************************Analisando Situacoes especiais como Provao Modular Enem*********************** */


                if ((($turmasserie >= "13") && ($turmasserie <= "15")) || (($turmasserie >= "93") && ($turmasserie <= "95")) || (($turmasserie >= "28") && ($turmasserie <= "30"))) {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino,c.ano
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '2') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                } else {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino,c.ano
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '1') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                }

                $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
                $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);

                if ($linhas_prova_especial > 0) {
                    $id_provao = mysql_result($resultado_prova_especial, 0, "id_provao");
                    $tp_ano_avaespecial = mysql_result($resultado_prova_especial, 0, "ano");
                }

                /*                 * ************** */

                if ((($turmasserie >= "13") && ($turmasserie <= "15")) || (($turmasserie >= "93") && ($turmasserie <= "95")) || (($turmasserie >= "28") && ($turmasserie <= "30"))) {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino,c.ano
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '2') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                } else {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino,c.ano
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '1') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                }

                $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
                $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);

                /*                 * ******** */
                if (
                        (($id_provao == '6') && ($tp_ano_avaespecial == $txtano)) ||
                        (($id_provao == '1') || ($id_provao == '2') || ($id_provao == '3') || ($id_provao == '4') || ($id_provao == '5') ||
                        ($id_provao == '7') || ($id_provao == '8') || ($id_provao == '9'))) {

                    if ($linhas_prova_especial > 0) {
                        while ($pegar_prova_especial = mysql_fetch_assoc($resultado_prova_especial)) {
                            /*                             * ************************************************************* */
                            /*                             * *Verificase se o aluno foi reclassificado ou nao
                              Verificase se o aluno foi reclassificado ou nao codigo do
                              id_provao = 1 Provao;
                              id_provao = 2 Enem;
                              id_provao = 3 Conselho de professores;
                              id_provao = 4 Modular;
                              id_provao = 5 telensinoConselho de professores;
                              id_provao = 6 Reclassificado;
                              id_provao = 7 Proenco;
                              id_provao = 8 Enceja;
                              id_provao = 9 Preenchimento de lacuna;
                             */
                            $tp__prova_descricao = $pegar_prova_especial["descricao"];
                            $tp__nota_especial = $pegar_prova_especial["nota"];
                            $tp_obs = $pegar_prova_especial["obs"];
                            $desc_disciplina = $pegar_prova_especial["desc_disciplina"];
                            $id_provao = $pegar_prova_especial["id_provao"];
                            $tp_avaliacao_especial = $pegar_prova_especial["id_provao"];
                            $tp__legenda = $pegar_prova_especial["legenda"];
                            $id_ensino_prova_especial = $pegar_prova_especial["id_ensino"];
                            $tp_ano_avaespecial = $pegar_prova_especial["ano"];

                            /*
                              Caso  a disciplina retida == disciplina  retido volta ao estao zero
                             */
                            if ($id_disciplina_retido == $id_disciplina)
                                $retido = "0";

                            if (($tp_avaliacao_especial == 1) && ($conta_obs_provao == 0)) {//provao
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_provao = 1;
                            } else if (($tp_avaliacao_especial == 2) && ($conta_obs_enem == 0)) {//Enem
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_enem = 1;
                            } else if (($tp_avaliacao_especial == 3)) {//&& ($conta_obs_conselho_professores == 0)) {//conselho de professores
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_conselho_professores = 1;
                            } else if (($tp_avaliacao_especial == 4) && ($conta_obs_modular == 0)) {//modular
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_modular = 1;
                            } else if (($tp_avaliacao_especial == 5) && ($conta_obs_telensino == 0)) {//teleensino
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_telensino = 1;
                            } else if (($tp_avaliacao_especial == 6) && ($conta_obs_reclassificacao == 0) && ($id_turma_promovido == $turma)) {//Reclassificado
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_reclassificacao = 1;
                            } else if (($tp_avaliacao_especial == 7) && ($conta_obs_proenco == 0)) {//proenco
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_proenco = 1;
                            } else if (($tp_avaliacao_especial == 8) && ($conta_obs_enceja == 0)) {//enceja
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_enceja = 1;
                            } else if (($tp_avaliacao_especial == 9) && ($conta_obs_lacuna == 0)) {//enceja
                                $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                                $conta_obs_lacuna = 1;
                            }
                        }

                        if ($passou != '1')
                            $situacao = "Aprovado";

                        if ($passou_obs_provao == 0) {
                            $txtobs = $txtobs;
                            $passou_obs_provao++;
                        }

                        //         $total_conta_faltas = $total_conta_faltas - $somafalta;
                        $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

                        //$total_faltas_final =$total_faltas_final + $soma_faltas;
                        $somafalta = 0;


                        /*                         * ***********************Se o provao for atraves de reclassifica��o************************************************************************** */

                        if (($id_provao == '6')) {
                            $aluno_promovido = 1;

                            if (($id_turma_promovido == $turma)) {
                                ?>

                                <!-- colocando os dados em uma tabela -->
                                <tr>
                                    <td class="escrita"><?php echo $desc_disciplina; ?></td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>

                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>


                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center"><?php echo "-" ?></td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>

                                    <td class="escrita" align="center"><?php echo "-"; ?></td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                                </tr>

                                <?php
                            } else {
                                /*                                 * **********Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente************ */
                                ?>

                                <!-- colocando os dados em uma tabela -->
                                <tr>
                                    <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center">-</td>
                                    <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                                    <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                                    <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["recuperacao2"]; ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["recuperacao3"]; ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["recuperacao4"]; ?></td>
                                    <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                                    <td class="escrita" align="center"><?php echo number_format(($soma / 3), 2, ',', '.'); ?></td>
                                    <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                                    <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                                    <td class="escrita" align="center"><?php
                                        if ($mfinal == 0)
                                            echo number_format($media, 2, ',', '.');
                                        else
                                            echo number_format($mfinal, 2, ',', '.');
                                        ?></td>
                                </tr>
                                <?php
                                /* FIM provao for atraves de reclassifica��o */
                            }
                        }
                        else if ($id_provao == '3') {
                            ?>
                            <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                                <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                                <td class="escrita" align="center"><?php echo $dado["recuperacao2"]; ?></td>
                                <td class="escrita" align="center"><?php echo $dado["recuperacao3"]; ?></td>
                                <td class="escrita" align="center"><?php echo $dado["recuperacao4"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                                <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                                <td class="escrita" align="center"><?php
                                    if ($mfinal == 0)
                                        echo $tp__legenda . number_format($media, 2, ',', '.');
                                    else
                                        echo $tp__legenda . number_format($mfinal, 2, ',', '.');
                                    ?></td>
                            </tr>
                        <?php } else { ?>
                            <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $desc_disciplina; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo "-" ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo "-"; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                            </tr>
                            <?php
                            /*                             * ***********************Fim provas reclassifica��o************************************************************************** */
                        }
                    }
                } else {
                    //$total_faltas_final  = $total_faltas_final + $soma_faltas;
                    $total_faltas_final = $soma_faltas;

                    /* Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota */

                    if ($aluno_promovido == 1) {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao2"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao3"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao4"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php
                                if ($mfinal == 0)
                                    echo number_format($media, 2, ',', '.');
                                else
                                    echo number_format($mfinal, 2, ',', '.');
                                ?></td>
                        </tr>
                        <?php
                    } else {
                        ?>
                        <!------Caso n�o tenha nenhuma avalia��o especial   -------->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao2"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao3"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao4"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($mfinal, 2, ',', '.'); ?></td>
                        </tr>
                        <?php
                    }
                }
                ?>
                <?php
            } else {
                /*                 * ************************************************************************************************************** */
                /*                 * ****************************************Ensino EJA************************************************************ */
                /*                 * **************************************Recupera��o Semestral e Bimestral************************************************************ */
                /*                 * ************************************************************************************************************ */

                $sqlgrade = "select * from grade_curricular where id_disciplina = '$id_disciplina'
                            and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
                $resultadograde = mysql_query($sqlgrade) or die(mysql_error());
                $linhasgrade = mysql_num_rows($resultadograde);
                if ($linhasgrade > 0) {
                    while ($pegargrade = mysql_fetch_assoc($resultadograde)) {
                        $reprova = $pegargrade["reprova"];
                        $ch = $pegargrade["ch"];
                    }
                }

                $soma = ($notareal1 + $notareal2);
                $media = ($soma) / 2;

                $somafalta = ($t_falta1 + $t_falta2);
                //  $totalfaltas = $totalfaltas + $somafalta;
                // $total_faltas_final  = $total_faltas_final + $soma_faltas;

                $soma = ($notareal1 + $notareal2);
                $media = ($soma) / 2;
                $mfinal = 0;

                /*                 * ****situacao = 1 - matriculado *** Situa��o = 7 - promovido************************************************* */
                if (($id_situacao == '1')) {
                    $soma = ($notareal1 + $notareal2);
                    $media = ($soma) / 2;
                    $mfinal = 0;

                    if (($reprova == 'S') || ($reprova == '')) {
                        if (($media < 6.0)) {
                            /*                             * *Aderencia de Exame Final* */
                            if ($adere_exame_final == 1) {
                                $mfinal = ($media * 6 + $examefinal * 4);

                                if ($mfinal < 50.0) {
                                    $situacao = "RETIDO";
                                    $retido = "1";
                                    $id_disciplina_retido = $id_disciplina;
                                    $mfinal = $mfinal / 10;
                                } else {
                                    $situacao = "APROVADO";
                                    $mfinal = $mfinal / 10;
                                }
                            } else/* n�o adere a exame final */ {
                                if ($nrec1 > $media)
                                    $mfinal = $nrec1;
                                else
                                    $mfinal = $media;
                                $situacao = "RETIDO";
                                $retido = "1";
                                $id_disciplina_retido = $id_disciplina;
                            }
                        }
                        else {
                            if ($situacao != "RETIDO") {
                                $situacao = "APROVADO";
                            }
                            $mfinal = $media;
                        }
                    } else {
                        // SE A DISCIPLINA N�O REPROVA
                        $situacao = "APROVADO";
                        if (($media < 6.0)) {
                            if ($adere_exame_final == 1) {
                                $mfinal = ($media * 6 + $examefinal * 4) / 10;
                            } else
                                $mfinal = $media;
                        } else
                            $mfinal = $media;
                    }

                    if (($bim1 != 'S') || ($bim2 != 'S'))
                        $situacao = "CURSANDO";

                    if ($situacao_aluno == 3)
                        $situacao = "TRANSFERIDO";
                }// if situacao
                else {
                    $situacao = $situa_desc;
                }

                if ($situacao_aluno == 2)
                    $situacao = "DESISTENTE";

                /**                 * ***************************************Ensino EJA************************************************************ */
                /**                 * ****************Analisando Situacoes especiais como Provao Modular Enem*********************** */
                /**                 * ***********************************Proenco, enseja, reclassifica��o*************************** */
                /**                 * *************************Analisando Situacoes especiais como Provao Modular Enem*********************** */
                /* ensino medio */
                if ((($turmasserie >= "13") && ($turmasserie <= "15")) || (($turmasserie >= "93") && ($turmasserie <= "95")) || (($turmasserie >= "28") && ($turmasserie <= "30"))) {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '2') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                } else {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                         and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '1') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
                }

                $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
                $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);
                if ($linhas_prova_especial > 0) {
                    while ($pegar_prova_especial = mysql_fetch_assoc($resultado_prova_especial)) {
                        /*                         * ************************************************************* */
                        /*                         * *Verificase se o aluno foi reclassificado ou nao
                          Verificase se o aluno foi reclassificado ou nao codigo do
                          id_provao = 1 Provao;
                          id_provao = 2 Enem;
                          id_provao = 3 Conselho de professores;
                          id_provao = 4 Modular;
                          id_provao = 5 telensinoConselho de professores;
                          id_provao = 6 Reclassificado;
                          id_provao = 7 Proenco;
                          id_provao = 8 Enceja;
                          id_provao = 9 Preenchimento de lacuna;
                         */

                        $tp__prova_descricao = $pegar_prova_especial["descricao"];
                        $tp__nota_especial = $pegar_prova_especial["nota"];
                        $tp_obs = $pegar_prova_especial["obs"];
                        $desc_disciplina = $pegar_prova_especial["desc_disciplina"];
                        $id_provao = $pegar_prova_especial["id_provao"];
                        $tp_avaliacao_especial = $pegar_prova_especial["id_provao"];
                        $tp__legenda = $pegar_prova_especial["legenda"];
                        $id_ensino_prova_especial = $pegar_prova_especial["id_ensino"];

                        /* Caso  a disciplina retida == disciplina  retido volta ao estao zero */
                        if ($id_disciplina_retido == $id_disciplina)
                            $retido = "0";

                        if (($tp_avaliacao_especial == 1) && ($conta_obs_provao == 0)) {//provao
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_provao = 1;
                            $passou = ($tp__nota_especial >= 5) ? 0 : 1;
                        } else if (($tp_avaliacao_especial == 2) && ($conta_obs_enem == 0)) {//Enem
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_enem = 1;
                        } else if (($tp_avaliacao_especial == 3) && ($conta_obs_conselho_professores == 0)) {//conselho de professores
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_conselho_professores = 1;
                        } else if (($tp_avaliacao_especial == 4) && ($conta_obs_modular == 0)) {//modular
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_modular = 1;
                        } else if (($tp_avaliacao_especial == 5) && ($conta_obs_telensino == 0)) {//teleensino
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_telensino = 1;
                        } else if (($tp_avaliacao_especial == 6) && ($conta_obs_reclassificacao == 0)) {//reclassifica��o
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_reclassificacao = 1;
                        } else if (($tp_avaliacao_especial == 7) && ($conta_obs_proenco == 0)) {//proenco
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_proenco = 1;
                        } else if (($tp_avaliacao_especial == 8) && ($conta_obs_enceja == 0)) {//enceja
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_enceja = 1;
                        } else if (($tp_avaliacao_especial == 9) && ($conta_obs_lacuna == 0)) {//enceja
                            $tp_obs_ava_especial = $tp__legenda . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_lacuna = 1;
                        }
                    }

                    if ($passou != '1' && $situacao != 'RETIDO')
                        $situacao = "Aprovado";

                    if ($passou_obs_provao == 0) {
                        $txtobs = $txtobs;
                        $passou_obs_provao++;
                    }

                    //         $total_conta_faltas = $total_conta_faltas - $somafalta;
                    $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

                    //$total_faltas_final =$total_faltas_final + $soma_faltas;
                    $somafalta = 0;

                    /*                     * ***********************Se o provao for atraves de reclassifica��o************************************************************************** */

                    if ($id_provao == '6') {
                        $aluno_promovido = 1;

                        if ($id_turma_promovido == $turma) {
                            ?>
                            <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $desc_disciplina; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo "-" ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo "-"; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                            </tr>

                            <?php
                            /*                             * **********Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente************ */
                        } else {
                            ?>
                            <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["recuperacao1"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo number_format($soma, 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo number_format(($soma / 1), 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                                <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                                <td class="escrita" align="center"><?php
                                    if ($mfinal == 0)
                                        echo number_format($media, 2, ',', '.');
                                    else
                                        echo number_format($mfinal / 10, 2, ',', '.');
                                    ?></td>
                            </tr>
                            <?php
                            /*                             * ***********************FIM provao for atraves de reclassifica��o************************************************************************** */
                            /*                             * ******************************************************************************************************************************************* */
                        }
                    }
                    else if ($id_provao == '3') {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php
                                if ($mfinal == 0)
                                    $tp__legenda . number_format($media, 2, ',', '.');
                                else
                                    $tp__legenda . number_format($mfinal, 2, ',', '.');
                                ?></td>
                        </tr>
                        <?php
                    } else {
                        ?>

                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $desc_disciplina; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo "-" ?></td>
                            <td class="escrita" align="center"><?php echo "-"; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                        </tr>
                        <?php
                        /* Fim provas reclassifica��o */
                    }
                } else {
                    /* Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota */
                    if ($aluno_promovido == 1) {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>

                            <td class="escrita" align="center"><?php echo number_format($dado["recuperacao1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>

                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php
                                if ($mfinal == 0)
                                    echo number_format($media, 2, ',', '.');
                                else
                                    echo number_format($mfinal, 2, ',', '.');
                                ?></td>
                        </tr>
                        <?php
                    } else {
                        $total_faltas_final = $total_faltas_final + $somafalta;
                        ?>

                        <!------Caso n�o tenha nenhuma avalia��o especial   -------->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["recuperacao1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>

                            <td class="escrita" align="center"><?php echo number_format($dado["examefinal"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php
                                if ($mfinal == 0)
                                    echo number_format($media, 2, ',', '.');
                                else
                                    echo number_format($mfinal, 2, ',', '.');
                                ?></td>
                        </tr>
                        <?php
                    }
                }

                /*                 * ************************************************Fim***************************************************************** */
            }
        }//loop
    } //Fim da recupera��o bimestral e semestral

    /*     * ******************************aqui come�a...Recupera��o anual******************************************************************************* */
    /*     * ******************************aqui come�a...Recupera��o anual******************************************************************************* */
    else {
        if (($modalidade == '1') || ($modalidade == '3')) {
            ?>

            <tr>
                <td class="nomecampo"><b>Componente Curricular</b></td>
                <td class="nomecampo"><b>1�Bim</b></td>
                <td class="nomecampo"><b>F 1�B</b></td>
                <td class="nomecampo"><b>2�Bim</b></td>
                <td class="nomecampo"><b>F 2�B</b></td>
                <td class="nomecampo"><b>3�Bim</b></td>
                <td class="nomecampo"><b>F 3�B</b></td>
                <td class="nomecampo"><b>4�Bim</b></td>
                <td class="nomecampo"><b>F 4�B</b></td>
                <td class="nomecampo"><b>Soma </b></td>
                <td class="nomecampo"><b>M.A</b></td>
                <td class="nomecampo"><b>Rec</b></td>
                <td class="nomecampo"><b>Ex.Final</b></td>
                <td class="nomecampo"><b>Total Faltas</b></td>
                <td class="nomecampo"><b>M.F</b></td>
            </tr>

            <?php
        } else {
            ?>
            <tr>
                <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
                <td class="nomecampo" align="center"><b>1�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 1�B</b></td>
                <td class="nomecampo" align="center"><b>2�Bim</b></td>
                <td class="nomecampo" align="center"><b>F 2�B</b></td>
                <td class="nomecampo" align="center"><b>Soma </b></td>
                <td class="nomecampo" align="center"><b>M.A</b></td>
                <td class="nomecampo" align="center"><b>REC</b></td>
                <td class="nomecampo" align="center"><b>Ex.Final</b></td>
                <td class="nomecampo" align="center"><b>Total Faltas</b></td>
                <td class="nomecampo" align="center"><b>M.F</b></td>
            </tr>
            <?php
        }//else

        $soma_faltas = 0;
        $passou = 0;
        $passou_obs_provao = 0;

        while ($dado = mysql_fetch_assoc($sql)) {
            $dtabertura = date("d/m/Y", strtotime($dado["data"]));
            $id_disciplina = $dado["id_disciplina"];

            /* Verifica a situacao do aluno */

            $sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
            $resultado_turma_aluno = mysql_query($sql_turma_aluno) or die(mysql_error());
            $linhas_turma_aluno = mysql_num_rows($resultado_turma_aluno);
            if ($linhas_turma_aluno > 0) {
                while ($linhas_turma_aluno = mysql_fetch_assoc($resultado_turma_aluno)) {
                    $id_situacao = $linhas_turma_aluno["situacao"];
                }
            }

            $sqlsitua = "select * from tipo_mov_aluno  where id = '$id_situacao'";
            $resultadositua = mysql_query($sqlsitua) or die(mysql_error());
            $linhassitua = mysql_num_rows($resultadositua);
            if ($linhassitua > 0) {
                while ($pegarsitua = mysql_fetch_assoc($resultadositua)) {
                    $situa_desc = $pegarsitua["descricao"];
                }
            }

            $mediacalculo = 0;
            $mfinal = 0;
            $n1 = $dado["nota1"];
            $n2 = $dado["nota2"];
            $n3 = $dado["nota3"];
            $n4 = $dado["nota4"];

            $nrec1 = $dado["recuperacao1"];
            $nrec2 = $dado["recuperacao2"];
            $nrec3 = $dado["recuperacao3"];
            $nrec4 = $dado["recuperacao4"];

            $bim1 = $dado["bim1"];
            $bim2 = $dado["bim2"];
            $bim3 = $dado["bim3"];
            $bim4 = $dado["bim4"];

            $sqlCargaHoraria = "SELECT ch
                    FROM grade_curricular g, turma t
                    WHERE  g.inep = '$inep'
                        AND g.ano = '$txtano'
                        AND g.id_modalidade = t.MODALIDADE
                        AND g.id_disciplina = '$id_disciplina'
                        AND t.id_grade = g.id_serie
                        AND t.id = '$turma'";
            $queryCargaHoraria = mysql_query($sqlCargaHoraria) or die(mysql_error());
            $pegarCargaHoraria = mysql_fetch_assoc($queryCargaHoraria);
            $cargaHoraria = $pegarCargaHoraria["ch"];

            $notareal1 = $n1;
            $notareal2 = $n2;
            $notareal3 = $n3;
            $notareal4 = $n4;

            if ($aluno_foi_promovido_ano_corrente == 0) {
                $soma = ($notareal1 + $notareal2 + $notareal3 + $notareal4);
                $media = ($soma) / 4;
            } else {
                $soma = ($notareal2 + $notareal3 + $notareal4);
                $media = ($soma) / 3;
            }

            /*             * **************Avaliacao Recebida Fora da Rede********************************************************************** */

            if ($total_etapas_ava_fora_rede > 0) {
                $soma = ($notareal2 + $notareal3 + $notareal4);
                $media = ($soma) / (4 - $total_etapas_ava_fora_rede);
            }

            $examefinal = $dado["examefinal"];
            $t_falta1 = $dado["t_falta1"];
            $t_falta2 = $dado["t_falta2"];
            $t_falta3 = $dado["t_falta3"];
            $t_falta4 = $dado["t_falta4"];

            /*             * *************Aluno foi promovido no ano corrente******************** */
            if ($aluno_foi_promovido_ano_corrente == 0)
                $total_faltas = ($t_falta1 + $t_falta2 + $t_falta3 + $t_falta4); //por disciplina
            else
                $total_faltas = ($t_falta2 + $t_falta3 + $t_falta4); //por disciplina


            $soma_faltas = $total_faltas + $soma_faltas;
            /*             * A soma total das faltas sao realizadas com as disciplinas n�o dispensadas* */
            //   $total_faltas_final  = $total_faltas_final + $total_faltas;

            $id_disciplina = $dado["id_disciplina"];

            $sqlgrade = "select * from grade_curricular where id_disciplina = '$id_disciplina'
        and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade'     and inep = '$inep'";
            $resultadograde = mysql_query($sqlgrade) or die(mysql_error());
            $linhasgrade = mysql_num_rows($resultadograde);
            if ($linhasgrade > 0) {
                while ($pegargrade = mysql_fetch_assoc($resultadograde)) {
                    $reprova = $pegargrade["reprova"];
                }
            }

            if (($modalidade == '1') || ($modalidade == '3')) { // regular e especial
                if (($id_situacao == '1') || ($id_situacao == '8') || ($id_situacao == '5') || (($id_situacao == '3') && ($id_status_transferencia == '1'))) {
                    $mfinal = 0;

                    if (($reprova == 'S') || ($reprova == '')) {

                        if (($media < 6.0)) {
                            if (($nrec1 < 6.0)) {
                                if ($media > $nrec1) {
                                    $mediacalculo = $media;
                                } else {
                                    $mediacalculo = $nrec1;
                                }

                                /*                                 * *Aderencia de Exame Final* */
                                if ($adere_exame_final == 1) {
                                    $mfinal = ($mediacalculo * 6 + $examefinal * 4);

                                    if ($mfinal < 50.0) {
                                        $situacao = "RETIDO";
                                        $retido = "1";
                                        $id_disciplina_retido = $id_disciplina;
                                    } else {
                                        $situacao = "APROVADO";
                                    }
                                    $mfinal = $mfinal / 10;
                                } else/* n�o adere a exame final */ {
                                    if ($nrec1 > $media)
                                        $mfinal = $nrec1;
                                    else
                                        $mfinal = $media;

                                    $situacao = "RETIDO";
                                    $retido = "1";
                                    $id_disciplina_retido = $id_disciplina;
                                }
                            }
                            else {
                                $situacao = "APROVADO";

                                if ($nrec1 > $media)
                                    $mfinal = $nrec1;
                                else
                                    $mfinal = $media;
                            }
                        }
                        else {
                            $situacao = "APROVADO";

                            if ($nrec1 > $media)
                                $mfinal = $nrec1;
                            else
                                $mfinal = $media;
                        }
                    }
                    else { // disciplina que nao reprovao  nao reprova
                        $situacao = "APROVADO";

                        if (($media < 6.0)) {
                            if (($nrec1 < 6.0)) {
                                if ($media > $nrec1) {
                                    $mediacalculo = $media;
                                } else {
                                    $mediacalculo = $nrec1;
                                }

                                if ($nrec1 > $media)
                                    $mediacalculo = $nrec1;
                                else
                                    $mediacalculo = $media;

                                if ($adere_exame_final == 1) {
                                    $mfinal = ($mediacalculo * 6 + $examefinal * 4);
                                    $mfinal = $mfinal / 10;
                                } else {
                                    if ($nrec1 > $media)
                                        $mfinal = $nrec1;
                                    else
                                        $mfinal = $media;
                                }
                            }
                            else /* caso a media seja maior que 6.0 */ {
                                $mfinal = $nrec1;
                            }
                        } else {
                            if ($nrec1 > $media)
                                $mfinal = $nrec1;
                            else
                                $mfinal = $media;
                        }
                    }

                    if (($bim1 != 'S') || ($bim2 != 'S') || ($bim3 != 'S') || ($bim4 != 'S')) {
                        $situacao = "CURSANDO";
                        /*                         * ***Verifica se alguma disciplina n esta com os quatro bimestre fechados* */
                        if ($cursando == 0)
                            $cursando = 1;
                    }

                    if ($situacao_aluno == 3)
                        $situacao = "TRANSFERIDO";
                }// if situacao == 1
                else {
                    $situacao = $situa_desc;
                }


                /*                 * *****************Analisando Situacoes especiais como Provao Modular Enem*********************** */
                /*                 * ************************************Proenco, enseja, reclassifica��o*************************** */

                if ((($turmasserie >= "13") && ($turmasserie <= "15")) || (($turmasserie >= "93") && ($turmasserie <= "95")) || (($turmasserie >= "28") && ($turmasserie <= "30"))) {
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                             from componente_eliminado c, tp_provao tp,habilitacao h
                             where id_aluno = '$aluno'
                                 and c.id_turma = '$turma'
                             and id_disciplina = '$id_disciplina'
                             and tp.id= c.tp_avaliacao
                             and c.cancelado = 'N'
                             and ((c.id_ensino = '2') || (c.id_ensino = '0'))
                             and h.codigo = c.id_disciplina";
                    $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
                    $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);
                } else if (($turmasserie <> "75") && ($turmasserie <> "76") && ($turmasserie <> "77") && ($turmasserie <> "78") && ($turmasserie <> "79")) {
                    /* Exclui as turmas de dependencias. */
                    $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                             from componente_eliminado c, tp_provao tp,habilitacao h
                             where id_aluno = '$aluno'
                                 and c.id_turma = '$turma'
                             and id_disciplina = '$id_disciplina'
                             and tp.id= c.tp_avaliacao
                             and c.cancelado = 'N'
                             and ((c.id_ensino = '1') || (c.id_ensino = '0'))
                             and h.codigo = c.id_disciplina";
                    $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
                    $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);
                } else {/* Caso n�o ocorra nenhuma das opcoes  linha igual a zero */
                    $linhas_prova_especial = 0;
                }


                if ($linhas_prova_especial > 0) {
                    while ($pegar_prova_especial = mysql_fetch_assoc($resultado_prova_especial)) {
                        $tp__prova_descricao = $pegar_prova_especial["descricao"];
                        $tp_obs = $pegar_prova_especial["obs"];
                        $desc_disciplina = $pegar_prova_especial["desc_disciplina"];
                        $id_provao = $pegar_prova_especial["id_provao"];
                        $tp_avaliacao_especial = $pegar_prova_especial["id_provao"];
                        $tp__nota_especial = $pegar_prova_especial["nota"];
                        $tp__legenda = $pegar_prova_especial["legenda"];
                        $id_ensino_prova_especial = $pegar_prova_especial["id_ensino"];
                        $tp_ano_avaespecial = $pegar_prova_especial["ano"];
                        /*
                          Caso  a disciplina retida == disciplina  retido volta ao estao zero
                         */
                        if ($id_disciplina_retido == $id_disciplina) {
                            $retido = "0";
                        }

                        if (($tp_avaliacao_especial == 1) && ($conta_obs_provao == 0)) {//provao
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_provao = 1;
                        } else if (($tp_avaliacao_especial == 2) && ($conta_obs_enem == 0)) {//Enem
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_enem = 1;
                        } else if (($tp_avaliacao_especial == 3)) {//conselho de professores
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_conselho_professores = 1;
                        } else if (($tp_avaliacao_especial == 4) && ($conta_obs_modular == 0)) {//modular
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_modular = 1;
                        } else if (($tp_avaliacao_especial == 5) && ($conta_obs_telensino == 0)) {//teleensino
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_telensino = 1;
                        } else if (($tp_avaliacao_especial == 6) && ($conta_obs_reclassificacao == 0)) {//reclassifica��o
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_reclassificacao = 1;
                        } else if (($tp_avaliacao_especial == 7) && ($conta_obs_proenco == 0)) {//proenco
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_proenco = 1;
                        } else if (($tp_avaliacao_especial == 8) && ($conta_obs_enceja == 0)) {//enceja
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_enceja = 1;
                        } else if (($tp_avaliacao_especial == 9) && ($conta_obs_lacuna == 0)) {//enceja
                            $tp_obs_ava_especial = $tp__legenda . " " . $tp_obs_ava_especial . "-" . $pegar_prova_especial["obs"];
                            $conta_obs_lacuna = 1;
                        }
                    }

                    if ($passou != '1')
                        $situacao = "Aprovado";

                    if ($passou_obs_provao == 0) {
                        //$txtobs  =  $txtobs  ." * ".  $tp_obs;
                        $txtobs = $txtobs;
                        $passou_obs_provao++;
                    }

                    //$total_conta_faltas = $total_conta_faltas - $somafalta;
                    $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

                    //$total_faltas_final =$total_faltas_final + $soma_faltas;
                    $somafalta = 0;

                    /*                     * ***********************Se o provao for atraves de reclassifica��o************************************************************************** */

                    if ($id_provao == '6') {
                        $aluno_promovido = 1;

                        if ($id_turma_promovido == $turma) {
                            ?>

                            <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $desc_disciplina; ?></td>

                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo "-" ?></td>
                                <td class="escrita" align="center"><?php echo "-"; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                            <tr>
                                <?php
                            } else {
                                /*                                 * **********Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente************ */
                                ?>

                                <!-- colocando os dados em uma tabela -->
                            <tr>
                                <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center">-</td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                                <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                                <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                                <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                                <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                                <td class="escrita" align="center">
                                    <?php
                                    if ($mfinal == 0)
                                        echo number_format($media, 2, ',', '.');
                                    else
                                        echo number_format($mfinal, 2, ',', '.');
                                    ?></td>
                            </tr>
                            <?php
                            /*                             * *******FIM provao for atraves de reclassifica��o********* */
                        }
                    }
                    else if ($id_provao == '3') {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center"><?php echo $tp__legenda . number_format($media, 2, ',', '.'); ?></td>
                        </tr>   
                        <?php
                    } else {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $desc_disciplina; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo "-" ?></td>
                            <td class="escrita" align="center"><?php echo "-"; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo $tp__legenda . $tp__nota_especial; ?></td>
                        </tr>
                        <?php
                        /*                         * ***********************Fim provas reclassifica��o******** */
                    }
                } //caso n�o tenha nenhuma nota
                else {
                    $total_faltas_final = $total_faltas_final + $total_faltas;
                    /*                     * ***********************Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota************************************************************************** */
                    if ($aluno_promovido == 1) {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>

                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center">
                                <?php
                                if ($mfinal == 0)
                                    echo number_format($media, 2, ',', '.');
                                else
                                    echo number_format($mfinal, 2, ',', '.');
                                ?>
                            </td>
                        </tr>
                        <?php
                    }
                    else {
                        ?>
                        <!------Caso n�o tenha nenhuma avalia��o especial ou senha todas as noas  -------->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota3"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta3"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota4"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta4"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                            <td class="escrita" align="center">
                                <?php
                                if ($mfinal == 0)
                                    echo number_format($media, 2, ',', '.');
                                else
                                    echo number_format($mfinal, 2, ',', '.');
                                ?>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </tr>
            <?php
        }  //fim da modaliade reglar e especial
        else /* Eja Recupera��o anual */ {

            /*             * *************************Comeca o ejaEnsino EJA************************************************************ */
            /*             * **************************************Recupera��o Anual************************************************************ */

            $sqlgrade = "select * from grade_curricular where id_disciplina = '$id_disciplina'
                and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
            $resultadograde = mysql_query($sqlgrade) or die(mysql_error());
            $linhasgrade = mysql_num_rows($resultadograde);

            if ($linhasgrade > 0) {
                while ($pegargrade = mysql_fetch_assoc($resultadograde)) {
                    $reprova = $pegargrade["reprova"];
                }
            }

            $t_falta1 = $dado["t_falta1"];
            $t_falta2 = $dado["t_falta2"];

            /*             * *************Aluno foi promovido no ano corrente******************** */
            if ($aluno_foi_promovido_ano_corrente == 0)
                $somafalta = ($t_falta1 + $t_falta2);
            else
                $somafalta = ($t_falta2);

            $soma = ($notareal1 + $notareal2);
            $media = ($soma) / 2;
            $mfinal = 0;

            /*             * ****situacao = 1 - matriculado *** Situa��o = 7 - promovido************************************************* */
            if (($id_situacao == '1')) {
                $soma = ($notareal1 + $notareal2);
                $media = ($soma) / 2;
                $mfinal = 0;
                if ($nrec1 > $media) {
                    $mfinal = $nrec1;
                }

                if (($reprova == 'S') || ($reprova == '')) {
                    if (($media < 6.0)) {
                        if (($nrec1 < 6.0)) {
                            if ($media > $nrec1) {
                                $mediacalculo = $media;
                            } else {
                                $mediacalculo = $nrec1;
                            }
                            /*                             * *Aderencia de Exame Final* */
                            if ($adere_exame_final == 1) {
                                $mfinal = ($mediacalculo * 6 + $examefinal * 4);
                                if ($mfinal < 50.0) {
                                    $situacao = "RETIDO";
                                    $retido = "1";
                                    $id_disciplina_retido = $id_disciplina;
                                } else {
                                    $situacao = "APROVADO";
                                }
                                $mfinal = $mfinal / 10;
                            } else/* n�o adere a exame final */ {
                                if ($nrec1 > $media)
                                    $mfinal = $nrec1;
                                else
                                    $mfinal = $media;

                                $situacao = "RETIDO";
                                $retido = "1";
                                $id_disciplina_retido = $id_disciplina;
                            }

                            if (($bim1 != 'S') || ($bim2 != 'S') || ($bim3 != 'S') || ($bim4 != 'S')) {
                                $situacao = "CURSANDO";
                                /*                                 * ***Verifica se alguma disciplina n esta com os quatro bimestre fechados* */
                                if ($cursando == 0)
                                    $cursando = 1;
                            }
                        }//****************************//
                        else {
                            $situacao = "APROVADO";

                            if ($nrec1 > $media)
                                $mfinal = $nrec1;
                            else
                                $mfinal = $media;
                        }
                    }
                    else {
                        $situacao = "APROVADO";

                        if ($nrec1 > $media)
                            $mfinal = $nrec1;
                        else
                            $mfinal = $media;
                    }
                }
                else { // disciplina que nao reprovao  nao reprova
                    $situacao = "APROVADO";

                    if ($nrec1 > $media)
                        $mfinal = $nrec1;
                    else
                        $mfinal = $media;
                }

                if (($bim1 != 'S') || ($bim2 != 'S'))
                    $situacao = "CURSANDO";

                if ($situacao_aluno == 3)
                    $situacao = "TRANSFERIDO";
            }// if situacao
            else
                $situacao = $situa_desc;

            if ($situacao_aluno == 2)
                $situacao = "DESISTENTE";

            /*             * ****************************************Ensino EJA************************************************************ */
            /*             * *****************Analisando Situacoes especiais como Provao Modular Enem******************************************** */
            /*             * ************************************Proenco, enseja, reclassifica��o*************************** */


            if ((($turmasserie >= "13") && ($turmasserie <= "15")) || (($turmasserie >= "93") && ($turmasserie <= "95")) || (($turmasserie >= "28") && ($turmasserie <= "30")) || (($turmasserie >= "23") && ($turmasserie <= "26"))) {

                $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                             and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '2') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
            } else {
                $sql_prova_especial = "select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino
                         from componente_eliminado c, tp_provao tp,habilitacao h
                         where id_aluno = '$aluno'
                             and c.id_turma = '$turma'
                         and id_disciplina = '$id_disciplina'
                         and tp.id= c.tp_avaliacao
                         and c.cancelado = 'N'
                         and ((c.id_ensino = '1') || (c.id_ensino = '0'))
                         and h.codigo = c.id_disciplina";
            }
            $resultado_prova_especial = mysql_query($sql_prova_especial) or die(mysql_error());
            $linhas_prova_especial = mysql_num_rows($resultado_prova_especial);
            if ($linhas_prova_especial > 0) {
                while ($pegar_prova_especial = mysql_fetch_assoc($resultado_prova_especial)) {
                    if ($id_disciplina_retido == $id_disciplina)
                        $retido = "0";

                    $tp__prova_descricao = $pegar_prova_especial["descricao"];
                    $tp__nota_especial = $pegar_prova_especial["nota"];
                    $tp_obs = $pegar_prova_especial["obs"];
                    $desc_disciplina = $pegar_prova_especial["desc_disciplina"];
                    $id_provao = $pegar_prova_especial["id_provao"];
                    $tp_avaliacao_especial = $pegar_prova_especial["id_provao"];
                    $id_ensino_prova_especial = $pegar_prova_especial["id_ensino"];

                    if (($tp_avaliacao_especial == 1) && ($conta_obs_provao == 0)) {//provao
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_provao = 1;
                    } else if (($tp_avaliacao_especial == 2) && ($conta_obs_enem == 0)) {//Enem
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_enem = 1;
                    } else if (($tp_avaliacao_especial == 3) && ($conta_obs_conselho_professores == 0)) {//conselho de professores
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_conselho_professores = 1;
                    } else if (($tp_avaliacao_especial == 4) && ($conta_obs_modular == 0)) {//modular
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_modular = 1;
                    } else if (($tp_avaliacao_especial == 5) && ($conta_obs_telensino == 0)) {//teleensino
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_telensino = 1;
                    } else if (($tp_avaliacao_especial == 6) && ($conta_obs_reclassificacao == 0)) {//reclassifica��o
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_reclassificacao = 1;
                    } else if (($tp_avaliacao_especial == 7) && ($conta_obs_proenco == 0)) {//proenco
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_proenco = 1;
                    } else if (($tp_avaliacao_especial == 8) && ($conta_obs_enceja == 0)) {//enceja
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_enceja = 1;
                    } else if (($tp_avaliacao_especial == 9) && ($conta_obs_lacuna == 0)) {//enceja
                        $tp_obs_ava_especial = $tp_obs_ava_especial . "*" . $pegar_prova_especial["obs"];
                        $conta_obs_lacuna = 1;
                    }
                }

                if ($passou != '1')
                    $situacao = "Aprovado";

                if ($passou_obs_provao == 0) {
                    //$txtobs  =  $txtobs  ." * ".  $tp_obs;
                    $txtobs = $txtobs;
                    $passou_obs_provao++;
                }

                $total_conta_faltas = $total_conta_faltas - $total_faltas_final;
                $somafalta = 0;

                /*                 * ***********************Se o provao for atraves de reclassifica��o************************************************************************** */

                if ($id_provao == '6') {
                    $aluno_promovido = 1;

                    if ($id_turma_promovido == $turma) {
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $desc_disciplina; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo "-" ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo "*" . $tp__nota_especial; ?></td>
                        </tr>
                        <?php
                    } else {
                        /*                         * **********Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente************ */
                        ?>
                        <!-- colocando os dados em uma tabela -->
                        <tr>
                            <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center">-</td>
                            <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                            <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                            <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                            <td class="escrita" align="center"><?php echo $somafalta; ?></td>
                            <td class="escrita" align="center">
                                <?php
                                if ($mfinal == 0)
                                    echo number_format($mfinal, 2, ',', '.');
                                else
                                    echo number_format($mfinal / 10, 2, ',', '.');
                                ?>
                            </td>
                        </tr>
                        <?php
                        /*                         * ***********************FIM provao for atraves de reclassifica��o************************************************************************** */
                    }
                }
                else if ($id_provao == '3') {
                    ?>
                    <!-- colocando os dados em uma tabela -->
                    <tr>
                        <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($soma, 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo number_format($media, 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["recuperacao1"]; ?></td>
                        <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                        <td class="escrita" align="center"><?php echo $total_faltas; ?></td>
                        <td class="escrita" align="center"><?php
                            if ($mfinal == 0)
                                echo "*" . number_format($media, 2, ',', '.');
                            else
                                echo "*" . number_format($mfinal, 2, ',', '.');
                            ?></td>
                    </tr>
                    <?php
                } else {
                    ?>
                    <!-- colocando os dados em uma tabela -->
                    <tr>
                        <td class="escrita"><?php echo $desc_disciplina; ?></td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center"><?php echo "-" ?></td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center"><?php echo "*" . $tp__nota_especial; ?></td>
                    </tr>
                    <?php
                    /* Fim provas reclassifica��o */
                }
            } else {

                /* Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota */

                if ($aluno_promovido == 1) {
                    ?>
                    <!-- colocando os dados em uma tabela -->
                    <tr>
                        <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center">-</td>
                        <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($soma, 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo number_format($media, 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                        <td class="escrita" align="center"><?php echo $somafalta; ?></td>
                        <td class="escrita" align="center"><?php
                            if ($mfinal == 0)
                                echo number_format($media, 2, ',', '.');
                            else
                                echo number_format($mfinal / 10, 2, ',', '.');
                            ?></td>

                    </tr>
                    <?php
                } else {
                    $total_faltas_final = $somafalta + $total_faltas_final;
                    ?>

                    <!------Caso n�o tenha nenhuma avalia��o especial   -------->
                    <tr>
                        <td class="escrita"><?php echo $dado["descricao"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["nota1"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["t_falta1"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["nota2"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["t_falta2"]; ?></td>
                        <td class="escrita" align="center"><?php echo number_format($soma, 2, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo number_format($media, 2, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo number_format($dado["recuperacao2"], 1, ',', '.'); ?></td>
                        <td class="escrita" align="center"><?php echo $dado["examefinal"]; ?></td>
                        <td class="escrita" align="center"><?php echo $somafalta; ?></td>
                        <td class="escrita" align="center"><?php
                            if ($mfinal == 0)
                                echo number_format($media, 2, ',', '.');
                            else
                                echo number_format($mfinal, 2, ',', '.');
                            ?></td>

                    </tr>
                    <?php
                }
            }
            /*             * ************************************************Fim***************************************************************** */

            // } // Fim do Else modadliade de recupera��o anual eja
            /*             * **************Fim******************************************************************* */
        } // Fim do Else modadliade de recupera��o anual eja
    }//loop recuperacao anual
}// fim d o else quando comeca a recupera��o anual   fundamental e eja
?>

</table>

<br>

<?php
$sqlgrade = "select * from tp_provao";
$resultadograde = mysql_query($sqlgrade) or die(mysql_error());
?>
<table border="0"  class="bordasimples" cellspacing="0"  align="left" width="100%" bgcolor=#ffffff>
    <tr>
        <td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="center">
            <b>Legenda / Descri��o</b>
        </td>
    </tr>
    <tr>
        <td colspan="6" class="escritagrade" align="center">
            <?php while ($pegargrade = mysql_fetch_assoc($resultadograde)) { ?>
                <b><?php echo $pegargrade["legenda"] ?></b>
                <?php echo $pegargrade["descricao"] . "; " ?>
            <?php } ?>
        </td>
    </tr>
</table>

<br>
<div style="text-align:center" class="hidden-print">
    <br>
    <button class="button" onclick="window.print()" title = "Click para imprimir - formul�rio em modo paissagem.">
        <img src= "../../imagem/impressora.jpg" width="30px">
        Imprimir
    </button>
</div>
</body>
</html>