<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }





$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }




$aluno_foi_promovido_ano_corrente= 0;





  $id =  $_GET['codigo'];



/* $totalcaracter = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $turma           = substr($id, $posicao+1,  $totalcaracter);
  */
 $totalcaracter  = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $posicao2       = strpos($id, '-');
 $turma          = substr($id, $posicao+1,$posicao2-$posicao-1);
 $n_chamadax     = substr($id, $posicao2+1, $totalcaracter-$posicao2);


















$sqlgerencia = "select * from ficha_individual_obs where inep ='$inep' and id_aluno = '$aluno' and ano= '$txtano'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =  mysql_num_rows($resultadoger);
if($linhas>0) // retorna para associar
{
  while($pegar=mysql_fetch_array($resultadoger))
      {
          $txtobs    = $pegar["obs"];
      }

}


/************Verificando se o aluno foi transferido cursando ou conclunte**************************/

$aluno_transferido = 0;

$sqltransferencia = "SELECT ma.id_status,ma.dt_situacao FROM
movimenta_aluno ma, turma_aluno ta
WHERE ma.id_aluno = '$aluno'
and ma.id_turmaaluno = ta.id
and ma.id_movimento = '3'
and ta.inep = '$inep'";
$resultadotransferencia = mysql_query($sqltransferencia) or die (mysql_error());
$linhastransferencia     =mysql_num_rows($resultadotransferencia);
if($linhastransferencia > 0)
{
   while($pegartransferencia=mysql_fetch_array($resultadotransferencia))
	{
    	$id_status_transferencia  =$pegartransferencia["id_status"];
        $dt_transferencia =date("d/m/Y",strtotime($pegartransferencia["dt_situacao"]));
        $aluno_transferido=1;
        
       if  (($dt_transferencia=="") || ($dt_transferencia=="1969/12/31"))
              $dt_transferencia= "";

    	
    }
 }
/***********************************************************************************************************/




/********************Promovido***************************************/

$sql_promovido = "select ta.situacao,t.id from turma_aluno ta, turma t
where ta.inep ='$inep'
and ta.id_aluno = '$aluno'
and ta.ano= '$txtano'
and ta.situacao = '7'
and t.id=ta.id_turma
and t.ano= ta.ano
and t.inep = ta.inep";
$resultado_promovido=mysql_query($sql_promovido) or die (mysql_error());
$linhas_promovido   =  mysql_num_rows($resultado_promovido);
if($linhas_promovido>0) // retorna para associar
{
  while($pegar_promovido=mysql_fetch_array($resultado_promovido))
      {
          $id_turma_promovido  =  $pegar_promovido["id"];
          $aluno_foi_promovido_ano_corrente =  '1';
      }

}


/************************************************************************************/



$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni 
from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo ";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];
    }
 }


/**/
$total_aluno_repetido= 0;

$sqlaluno="select count(ta.id_aluno) as total_repetido from turma t,turma_aluno ta where t.id=ta.id_turma
and ta.id_aluno = '$aluno' and t.ano='$txtano'
and t.id = '$turma'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
        $total_aluno_repetido         = $pegaraluno["total_repetido"];
    }
 }

/*descobrindo qual se o aluno faz dependencia e qual e o codigo da turma*/

$sqlaluno="select t.id from turma t,turma_aluno ta where t.id=ta.id_turma
and ta.id_aluno = '$aluno' and t.ano='$txtano' and t.turmas in (75,76,77,78,79,100,101)";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
     {
        $id_turma_dependencia   =  $pegaraluno["id"];
     }
 }



$sqlaluno="select * from turma t,turma_aluno ta where t.id=ta.id_turma  and ta.id_aluno = '$aluno' and t.ano='$txtano' and t.id = $turma
and n_chamada = '$n_chamadax'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
      $turmadesc            = $pegaraluno["DESCRICAO"];
	  $n_chamada            = $pegaraluno["n_chamada"];
	  $modalidade           = $pegaraluno["MODALIDADE"];
	  $turma_dep            = $pegaraluno["turmas"];
	  $id_grade             = $pegaraluno["id_grade"];
 	  $ano_letivo           = $pegaraluno["ANO"];
 	  $situacao_aluno       = $pegaraluno["situacao"];
      $grade_curricular_x   = $pegaraluno["id_grade"];
      $grade_curricular     = $pegaraluno["id_grade"];
      $dtfecha_turma        = date("d/m/Y",strtotime($pegaraluno["dtfecha_turma"]));
   	  $turma_dep            = $pegaraluno["TURMAS"];
   	  $semestre             = $pegaraluno["SEMESTRE"];
   	  $situacao             = $pegaraluno["situacao"];
 	  $turmasserie     = $pegaraluno["TURMAS"];

        if (($dtfecha_turma=='31/12/1969')  || ($dtfecha_turma=='30/11/-0001'))
		        {
		            $dtfecha_turma='Turma Aberta';
		        }
      }
 }






 $adere_exame_final = 0;

$sqletapa = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa  =  '9'
               and id_modalidade = '$modalidade'
               and inep = '$inep'";
$resultadoetapa=mysql_query($sqletapa) or die (mysql_error());
$linhasetapa   =  mysql_num_rows($resultadoetapa);
if($linhasetapa>0) // retorna para associar
{
  while($pegaretapa=mysql_fetch_array($resultadoetapa))
      {
           $adere_exame_final = 1;
      }

}




$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$dia.".".$mes.".".$ano;

$banco_vazio = 0;

//$re = mysql_query("select count(*) as total from nota_aluno n, habilitacao h where h.codigo = n.id_disciplina");

$re = mysql_query("select count(*) as total from nota_aluno  where  id_aluno = '$aluno' ");
$total = mysql_result($re, 0, "total");
if ($total==0)
  {
	
       $banco_vazio = 1;
   }



/*************************Totaliznado Faltas**********************************************************************************/

$total_conta_faltas = 0;
/*
 $re = mysql_query("select  sum( t_falta1 + t_falta2 + t_falta3 + t_falta4 ) as total from nota_aluno
 where  id_aluno = '$aluno'  and ano = '$txtano' and id_disciplina <> '20'");
 $total_conta_faltas = mysql_result($re, 0, "total");
 */

 $re_abono_faltas = mysql_query("select sum(falta) as t_faltas from abono_faltas where  id_aluno = '$aluno' and ano = '$txtano' and inep = '$inep' and cancelado = 'N'");
 $total_abono_faltas = mysql_result($re_abono_faltas, 0, "t_faltas");
     if ($total_abono_faltas=='')
          $total_abono_faltas =0;



/********************************Tipo de Recuperacao***************************************************************************/

 /*    $sql_tp_recuperacao = mysql_query("select id_recuperacao from recuperacao_escola
     where  ano = '$txtano' and inep = '$inep' and id_modalidade='$modalidade'");
     $tp_recuperacao = mysql_result($sql_tp_recuperacao, 0, "id_recuperacao ");

 */





$sql_tp_recuperacao = "select id_recuperacao from recuperacao_escola
     where  ano = '$txtano' and inep = '$inep' and id_modalidade='$modalidade'";
$resultado_tp_recuperacao=mysql_query($sql_tp_recuperacao) or die (mysql_error());
$linhas_tp_recuperacao   =  mysql_num_rows($resultado_tp_recuperacao);
if($linhas_tp_recuperacao>0) // retorna para associar
{
  while($pegar_tp_recuperacao=mysql_fetch_array($resultado_tp_recuperacao))
      {
         $tp_recuperacao    =  $pegar_tp_recuperacao["id_recuperacao"];
      }

}
else
{
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Recupera��o n�o definida ou Aluno sem n�mero no di�rio!</font></center>";
    echo "<br><br><center><a href=\"form_imprimi_fichaindividual.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

}

//echo "tipo de recuperacao$tp_recuperacao";






/****************************************************************************************************************************/







if (($modalidade=='1') || ($modalidade=='3') )
 {
   if  (($turma_dep=='75') || ($turma_dep=='76') || ($turma_dep=='77') ||($turma_dep=='78') ||($turma_dep=='79')
       ||($turma_dep=='100') ||($turma_dep=='101'))
       {



$sql=mysql_query(" SELECT *
FROM nota_aluno n, habilitacao h, turma_dep_aluno_disciplina t
WHERE h.codigo = n.id_disciplina
AND n.id_aluno = '$aluno'
AND n.ano = '$txtano'
AND n.id_turmaprofessor = '$turma'
AND t.id_turma = n.id_turmaprofessor
AND n.inep = t.inep
AND t.id_disciplina = h.codigo
AND t.id_aluno = n.id_aluno  order by h.impressao");




       }
     else
      {
   if ($total_aluno_repetido > 1)
         {




                  $sql=mysql_query("SELECT n.id, n.id_aluno, nota1, nota2, nota3, nota4, recuperacao1, recuperacao2, recuperacao3, recuperacao4,
                    n.examefinal, n.id_disciplina, t_falta1,t_falta2,t_falta3,t_falta4,t_falta_rec1,t_falta_rec2,t_falta_rec3,t_falta_rec4,
			 h.codigo, t.situacao, bim1, bim2, bim3, bim4,h.descricao
                            FROM nota_aluno n, habilitacao h, turma_aluno t
				  WHERE h.codigo = n.id_disciplina
				  AND t.id_aluno = '$aluno'
				  AND n.ano = '$txtano'
				  AND t.id_aluno = n.id_aluno
                          AND t.id_turma = n.id_turma
                              AND t.situacao in (1,2,3)
    			GROUP BY n.id
			 order by h.impressao");

/*
       $sql = mysql_query("SELECT *
				FROM nota_aluno n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.n_chamada = '$n_chamadax'
                AND t.situacao in (1,2,3) order by h.impressao");
*/
         }
       else
        {
           if ($situacao=='7')
             {
           



                 $sql=mysql_query("SELECT n.id_disciplina,n.nota,n.id_aluno
			 	FROM componente_eliminado n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.situacao = 7 order by h.impressao");

              }
            else
              {

                if ($aluno_foi_promovido_ano_corrente==0)
                 {


                /*  $sql=mysql_query("SELECT *
			      FROM nota_aluno n, habilitacao h, turma_aluno t
				  WHERE h.codigo = n.id_disciplina
				  AND t.id_aluno = '$aluno'
				  AND n.ano = '$txtano'
				  AND t.id_aluno = n.id_aluno
                  AND t.id_turma = n.id_turma
                  AND t.situacao in (1,2,3,5) order by h.impressao");
                  */

if ($aluno=='274286')
   echo "passou";


$sql=mysql_query("SELECT *
FROM turma t, nota_aluno n, habilitacao h, turma_aluno ta, grade_curricular g
WHERE t.ano    = '$txtano'
AND   n.id_aluno = '$aluno'
AND   t.inep = '$inep'
AND   h.codigo   = n.id_disciplina
AND   h.codigo   = g.id_disciplina
AND   n.id_disciplina = g.id_disciplina
AND   ta.id_aluno = n.id_aluno
AND   ta.id_turma = t.id
AND   t.id_grade = g.id_serie
AND   g.id_modalidade = t.modalidade
AND   g.inep = t.inep
AND   g.ano = t.ano
AND   ta.n_chamada = '$n_chamadax'
AND   n.id_turma <> '$id_turma_dependencia'
AND ta.situacao
IN ( 1, 2, 3, 5 ) group by  n.id_disciplina
ORDER BY h.impressao
");
                   }
                 else
                 {
                   
                    /*caso aluno tenha sido promovido no ano corrente*/
                   $sql=mysql_query("SELECT *
			 	   FROM nota_aluno n, habilitacao h, turma_aluno t
				   WHERE h.codigo = n.id_disciplina
				   AND t.id_aluno = '$aluno'
				   AND n.ano = '$txtano'
				   AND t.id_aluno = n.id_aluno
                               AND t.n_chamada = '$n_chamadax' 
                               
                               AND t.situacao in (1,2,3)
                               group by  n.id_disciplina
                               order by h.impressao");
                  }
             
               }
         }
     }

  }
else
  {

   $sql=mysql_query("select *
   from nota_aluno n, habilitacao h, turma t
    where h.codigo = n.id_disciplina
    and id_aluno = '$aluno'
    and n.ano = '$txtano'
    and t.id = n.id_turma
    and t.semestre = '$semestre' 
    and t.modalidade = '$modalidade' 
    order by h.impressao");

 }




/********Inicio do pocesso dos alunos*********/

$conta = mysql_num_rows($sql);
/*Pegando o numero de chamado*/






$sqlaluno="SELECT *,id, nome  as nome_aluno, nome_pai, nome_mae, dt_nascimento, mod_certidao, n_certidao_novo, termo_certidao,foto, livro_certidao,
folha_certidao, dtemissao_certidao ,(YEAR(CURDATE( )) - YEAR(dt_nascimento )) as idade,uf_nascimento,muni_nascimento,
pais_estrangeiro,estado_estrangeiro,municipio_estrangeiro
FROM aluno  where id = '$id' order by nome";


$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {

      $alunodesc      = $pegaraluno["nome_aluno"];
      $nomepai        = $pegaraluno["nome_pai"];
      $nomemae        = $pegaraluno["nome_mae"];
      $endaluno       = $pegaraluno["endereco"];
      $numeroaluno    = $pegaraluno["numero"];
      $bairroaluno    = $pegaraluno["bairro"];
      $dtnacimento    = date("d/m/Y",strtotime($pegaraluno["dt_nascimento"]));
      $termo_certidao        = $pegaraluno["termo_certidao"];
      $livro_certidao        = $pegaraluno["livro_certidao"];
      $folha_certidao          = $pegaraluno["folha_certidao"];

      $dtemissao_certidao    = date("d/m/Y",strtotime($pegaraluno["dtemissao_certidao"]));
      $id_nacional        = $pegaraluno["id_nacional"];
      $id                 = $pegaraluno["id"];
      $cidade                 = $pegaraluno["cidade"];
      $idade                 = $pegaraluno["idade"];
      $sigla                 = $pegaraluno["sigla"];

      $mod_certidao            = $pegaraluno["mod_certidao"];
       $termo_certidao_nova          = $pegaraluno["n_certidao_novo"];
   
        $termo_certidao        = $pegaraluno["termo_certidao"];


      if ($termo_certidao=="")
              $termo_certidao =$termo_certidao_nova;
      
               

        if (($dtemissao_certidao=='31/12/1969')  || ($dtemissao_certidao=='30/11/-0001'))
		   {
		     $dtemissao_certidao='';
		   }


      $id_ufnascimento          = $pegaraluno["uf_nascimento"];
      $muni_nascimento     = $pegaraluno["muni_nascimento"];


       $pais_estrangeiro                   = $pegaraluno["pais_estrangeiro"];
       $estado_estrangeiro                 = $pegaraluno["estado_estrangeiro"];
       $municipio_estrangeiro              = $pegaraluno["municipio_estrangeiro"];







	}
 }




 $sqluf = "select *  from estados where cod_estados = '$id_ufnascimento'";
$resultadouf=mysql_query($sqluf) or die (mysql_error());
$linhasuf   =mysql_num_rows($resultadouf);
if($linhasuf >0)
{
   while($pegaruf=mysql_fetch_array($resultadouf))
	{
         	$sigla    = $pegaruf["sigla"];
    }
 }



$sqlmuni = "select *  from cidades where cod_ibge = '$muni_nascimento'";
$resultadomuni=mysql_query($sqlmuni) or die (mysql_error());
$linhasmuni   =mysql_num_rows($resultadomuni);
if($linhasmuni>0)
{
   while($pegarmuni=mysql_fetch_array($resultadomuni))
	{

    	$cidade    = $pegarmuni["nome"];
    }
 }
else
 {
      $sqlmuni = "select *  from cidades where cod_cidades = '$muni_nascimento'";
      $resultadomuni=mysql_query($sqlmuni) or die (mysql_error());
      $linhasmuni   =mysql_num_rows($resultadomuni);
      if($linhasmuni>0)
      {
          while($pegarmuni=mysql_fetch_array($resultadomuni))
	       {
         	$cidade    = $pegarmuni["nome"];
           }
       }
 }






      if ($id_ufnascimento=='28')
         {
             $sigla = $estado_estrangeiro." / ". $pais_estrangeiro;
             $cidade=  $municipio_estrangeiro;
         }







     if  ($mod_certidao== '1') //modelo novo
         {
          $termo_certidao =  $termo_certidao_nova;
          $livro_certidao        = "-";
          $folha_certidao          = "-";

         }


$total_etapas_ava_fora_rede = 0;

/********************************Avalia��o fora do estado*****************************************************/
$sql_avaliaca_fora_rede = "select *  from tp_avaliacao_recebida where id_aluno  = '$aluno'";
$resultado_avaliaca_fora_rede=mysql_query($sql_avaliaca_fora_rede) or die (mysql_error());
$linhas_avaliaca_fora_rede   =mysql_num_rows($resultado_avaliaca_fora_rede);
if($linhasuf > 0)
{
   while($pegar_avaliaca_fora_rede=mysql_fetch_array($resultado_avaliaca_fora_rede))
	{
         	$total_etapas_ava_fora_rede    = $pegar_avaliaca_fora_rede["id_etapa"];
    }
 }


/************************************************************************************/






?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 9pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 9px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}


.imprimi
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}


.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}

.escritagrade
{
    font-size: 7px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>


<style media="print">
.botao {
display: none;
}
</style>



<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

</head>
<table width="100%">
<!--
<tr>
      <td class="nomecampo" align="center"><b><img src= "../img/brasao.jpg" /></b></td>
</tr>
-->

<tr>
 <td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
 </td>
</tr>

<tr>
	<td colspan="7"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo">N�:</td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>
  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="">&nbsp;Estadual</td>
	<td class="nomecampo"><b>Ano Letivo:</b></td>
       <td>&nbsp;<?echo $ano_letivo;?></td>

</tr>

</table>

<?

  while($pegar=mysql_fetch_array($resultado))
      {

        $iddisciplina           = $pegar["disciplina"];
        $idturma                = $pegar["idturma"];
        $cpfprofessor           = $pegar["cpf"];
     }
?>



<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="8"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Aluno(a)</b></td>
</tr>

<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td class = "escrita"><b>&nbsp;<?echo $alunodesc;?></b></td>
	<td class="nomecampo"><b>Nascimento:</b></td>
	<td colspan="5" class = "escrita"><b>&nbsp;<?echo $dtnacimento;?></b></td>

</tr>
<tr>
	<td class="nomecampo"><b>Pai</b></td>
	<td class = "escrita">&nbsp;<?echo $nomepai;?></td>
	<td class="nomecampo"><b>M�e</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $nomemae;?></td>


</tr>
<tr>
	<td class="nomecampo"><b>Endere�o</b></td>
	<td class = "escrita">&nbsp;<?echo $endaluno;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairroaluno;?></td>
	<td class="nomecampo"><b>N�</b></td>
	<td class = "escrita" colspan="7" >&nbsp;<?echo $numeroaluno;?></td>
</tr>




<tr>
	<td class="nomecampo"><b>ID Nacional</b></td>
	<td class = "escrita">&nbsp;<?echo $id_nacional;?></td>
	<td class="nomecampo"><b>ID Estadual:</b></td>
	<td class= "escrita" colspan="7"><b>&nbsp;<?echo $id;?></b></td>
</tr>


<tr>
	<td class="nomecampo"><b>Certid�o</b></td>
	<td class= "escrita">&nbsp;<?echo $termo_certidao;?></td>
	<td class="nomecampo"><b>Livro</b></td>
	<td class="escrita" >&nbsp;<?echo $livro_certidao;?></td>
	<td class="nomecampo"><b>Folha</b></td>
	<td class="escrita" >&nbsp;<?echo $folha_certidao;?></td>
	<td class="nomecampo"><b>Data Emiss�o</b></td>
	<td class="escrita" colspan="5" >&nbsp;<?echo $dtemissao_certidao;?></td>

</tr>








<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita"><b>&nbsp;<?echo $turmadesc;?></b></td>
	<td class="nomecampo"><b>Chamada</b></td>
	<td class = "escrita" ><b>&nbsp;<?echo $n_chamada;?></b></td>
	<td class="nomecampo"><b>Modalidade</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $modalidade;?></td>

</tr>


<tr>
	<td class="nomecampo"><b>Idade</b></td>
	<td class = "escrita"><b>&nbsp;<?echo $idade;?></b></td>
	<td class="nomecampo"><b>Naturalidade</b></td>
	<td class = "escrita" >&nbsp;<?echo $cidade;?></td>
	<td class="nomecampo"><b>UF</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $sigla ;?></td>

</tr>






</table>



<table width="100%">

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="19"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>FICHA INDIVIDUAL</b></td>
</tr>


<?

/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
if ($conta==0)
{
/*************************Caso o aluno seja transferido*********************************************/
 if ($aluno_transferido==1)
    {
  ?>

<table width="100%">
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Data de Fechamento :&nbsp<?echo  $dtfecha_turma;?> </b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Situa��o Final :&nbsp TRANSFERIDO </b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Transferido :&nbsp<?echo  $dt_transferencia;?> </b></td>

</tr>
</table>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Componente Curricular</b></td>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Carga Hor�ria</b></td>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Aulas Dadas</b></td>
</tr>




<?


  $sqlgrade="select g.id_modalidade,g.id_disciplina,g.ch as ch,g.ano,h.descricao as descricao,h.codigo from grade_curricular g,habilitacao h
  where id_modalidade='$modalidade'
  and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep' AND g.id_serie = ' $grade_curricular' order by h.impressao";
  $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
  $linhasgrade=mysql_num_rows($resultadograde);

//and g.id_s = $grade_curricular
$total_ch=0;
if ($linhasgrade>0)
   {
while($pegargrade=mysql_fetch_array($resultadograde))
    {

        $id_disciplina            = $pegargrade["codigo"];


/**********************C�lculo de Aulas Dadas********************************************************************************/



$sql_aulas_dada="SELECT count(tempo_aula) as total_aulas_dada FROM dias_diario
     where id_turma     = '$turma'
     and id_disciplina  = '$id_disciplina'
     and inep           = '$inep'
     and ano            = '$txtano'
     and registrado     = 'S'
     and tipo_aula      = '1'
     and tpbloqueio    = '1'";

$resultado_aulas_dada = mysql_query($sql_aulas_dada) or die (mysql_error());
$linhas_aulas_dada=mysql_num_rows($resultado_aulas_dada);
if ($linhas_aulas_dada>0)
 {
    while($pegar_aulas_dada=mysql_fetch_array($resultado_aulas_dada))
   {
         $total_aulas_dadas       = $pegar_aulas_dada["total_aulas_dada"];

         $Soma_total_aulas_dadas =  $Soma_total_aulas_dadas + $total_aulas_dadas;
   }
 }
/************************************************************************************************************************/

        $descdisciplina            = $pegargrade["descricao"];

        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $ch  = "-";
  		   $total_aulas_dadas = "-";
          }

      else if (($turmasserie>=17) && ($turmasserie<=21))  // cba eja
          {
                 $ch  = "0";
          }
         else
          {
              $ch  = $pegargrade["ch"];
              $total_ch = $total_ch+ $ch;
          }
?>

<tr>
	<td colspan="6" class="escrita">&nbsp<?echo  $descdisciplina;?></td>
	<td colspan="6" class="escrita" align="center">&nbsp<?echo  $ch;?> </td>

	<td colspan="6" class="escrita" align="center">&nbsp<?echo  $ch;?> </td>


<!--       <td colspan="6" class="escrita" align = "center">  &nbsp<?echo  $total_aulas_dadas;?> </td>-->




</tr>

<?
	}


        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $total_ch  = "800";
          }
        if (($turmasserie>=17) && ($turmasserie<=21))
          {
                 $total_ch  = "350";
          }


         else
            {
             /*
               $re    = mysql_query("SELECT sum(ch) as total from grade_curricular g,habilitacao h where id_modalidade='$modalidade'
               and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep'  AND g.id_serie = '$turmasserie'");
               $total = mysql_result($re, 0, "total");
              */
              }




  if (($turmasserie>=2) && ($turmasserie<=6))
          {
?>
	<td class="escrita" align = "center"><b> Dias Letivos  </b></td>
	<td colspan="6" align = "center">&nbsp200</td>
	 <td colspan="6" class="escrita" ><b>Total   </b></td>

	<td colspan="6" align = "center">&nbsp800 Horas</td>

<?
         }
else if (($turmasserie>=17) && ($turmasserie<=21))
           {
?>
<!--	<td colspan="6" class="escrita" align = "center"><b>  -  </b></td>-->
<?
         }
      else
        {
?>
<!--	<td colspan="6" class="escrita" align = "center"><b>  -  </b></td>-->

	 <td colspan="6"  class="escrita" ><b>Total   </b></td>
	 <td colspan="6" class="escrita" align="center"><b>&nbsp<?echo  $total_ch;?></b> </td>

	 <td colspan="6" class="escrita" align="center"><b>&nbsp<?echo  $total_ch;?></b> </td>


<!--        <td colspan="6" class="escrita" align = "center"><b>  &nbsp<?echo  $Soma_total_aulas_dadas;?></b> </td>-->


<?
         }
?>
<?
  }
?>

</table>







<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Aux Secretaria</b></td>
	<td>&nbsp;</td>


	<td class="nomecampo"><b>Secretaria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;</td>
</tr>
</table>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao" ><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>




<?


/*************Aqui termina transferido sem nenhuma movimenta��o**************************************************************************************/
/***************************************************************************************************/
/***************************************************************************************************/
/*************************Caso o aluno seja transferido*********************************************/
   exit;
  }
/*************************************************************************************************/
else
  {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Banco de Dados Sem Lan�amento!</font></center>";
    echo "<br><br><center><a href=\"form_imprimi_fichaindividual.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
  }

}//conta
/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
/*****Quando n�o existir nenhumar imforma��o e o aluno e transferido***********************************************************************************************/
































/***************************Banco Sem Informa��o***********************************************************/
if ($total==0)
  {



/***********************************************************************************************************************************************/
/******************************Buscando o Status do aluno Ex Transferindo*********************************************************************************/
/***********************************************************************************************************************************************/

$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao  = $linhas_turma_aluno["situacao"];
      }
 }


/***********************************************************************************************************************************************/
/***********************************************************************************************************************************************/










 

$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }

if($id_situacao=='1')
  {
  $situa_desc='CURSANDO'; 
 }







?>
</table>



<br><br><br><br><br>
<br><br><br><br><br>


<table width="100%">
<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b><?echo $situa_desc;?>  </b></td>
</tr>

</table>

<br><br><br>
<br><br><br><br><br>

<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Total de Faltas :&nbsp<?echo  $soma_faltas;?> </b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Data de Fechamento :&nbsp<?echo  $dtfecha_turma;?> </b></td>
</tr>


<?
 if ($aluno_transferido=='1')
{
?>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Transferido :&nbsp<?echo  $dt_transferencia;?> </b></td>
</tr>
<?
}
?>










</table>


<br><br><br><br><br>






<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Aux Secretaria</b></td>
	<td>&nbsp;</td>


	<td class="nomecampo"><b>Secretaria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;</td>
</tr>
</table>

<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao" ><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>















<?
exit;
}






/*************************** Recupera��o bimestral e Semestral*****************************************************/
/*************************** Recupera��o bimestral e Semestral*****************************************************/
/*************************** Recupera��o bimestral e Semestral*****************************************************/
if (($tp_recuperacao==1) ||  ($tp_recuperacao==2))
{
/*************************** modalidade regular e especial*****************************************************/
/*************************** modalidade regular e especial*****************************************************/
/*************************** modalidade regular e especial*****************************************************/


  if (($modalidade=='1')|| ($modalidade=='3'))
  {
?>

<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>3�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 3�B</b></td>
 <td class="nomecampo" align="center"><b>4�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 4�B</b></td>
 <td class="nomecampo" align="center"><b>R 1�B</b></td>
 <td class="nomecampo" align="center"><b>R 2�B</b></td>
 <td class="nomecampo" align="center"><b>R 3�B</b></td>
 <td class="nomecampo" align="center"><b>R 4�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
<!-- <td class="nomecampo" align="center"><b>Situa��o</b></td>-->
</tr>

<?
}
else
{
?>



<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>R 1�B</b></td>
 <td class="nomecampo" align="center"><b>R 2�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
<!-- <td class="nomecampo" align="center"><b>Situa��o</b></td>-->
</tr>

<?
}//else

//$totalfaltas = 0;
$soma_faltas =0;
$passou      =0;
$retido      =0;
$aprovado    =0;
$cursando    =0;
$aluno_promovido = 0;


$id_disciplina_retido="";

$conta_obs_conselho_professores =0;
$conta_obs_provao= 0;
$conta_obs_enem  = 0;
$conta_obs_modular=0;
$conta_obs_telensino = 0;
$conta_obs_reclassificacao = 0;
$conta_obs_proenco=0;
$conta_obs_enceja = 0;
$conta_obs_lacuna=0;

$total_faltas_final=0;
$total_faltas = 0;

while ($dado = mysql_fetch_array($sql))
  {




   $dtabertura     = date("d/m/Y",strtotime($dado["data"]));
   $id_disciplina  = $dado["id_disciplina"];
/*Verifica a situacao do aluno*/


$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }












   $mfinal=0;


   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];


   $examefinal =  $dado["examefinal"];


   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];


   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];

 if ($id_disciplina != '20')
  {

   $t_falta1  =$dado["t_falta1"];
   $t_falta2 = $dado["t_falta2"];
   $t_falta3 = $dado["t_falta3"];
   $t_falta4 = $dado["t_falta4"];








/***************Aluno foi promovido no ano corrente*********************/


 if( $aluno_foi_promovido_ano_corrente==0)
          $total_faltas=($t_falta1+$t_falta2+$t_falta3+$t_falta4); //por disciplina
 else
          $total_faltas=($t_falta2+$t_falta3+$t_falta4); //por disciplina


/***********************************************************************/


   $soma_faltas =$total_faltas + $soma_faltas;

   //$total_faltas_final  = $total_faltas_final + $soma_faltas;

  }

   $id_disciplina = $dado["id_disciplina"];


   if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }



  /**/




 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {


        $reprova      =  $pegargrade["reprova"];

    }

  }



/*************************** modalidade regular e especial*****************************************************/
/*************************** modalidade regular e esoecial*****************************************************/
/*************************** modalidade regular e especial*****************************************************/
/*************************** modalidade regular e esoecial*****************************************************/


if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {




        // if ($aluno == '159720')
        //     echo "passou";




/*************************** Cursando*****************************************************/
if (($id_situacao=='1') || ($id_situacao=='8'))
 {


/*********Caso o aluno seja promovido o aluno devera ser durante os 25 por cento*********/

 if( $aluno_foi_promovido_ano_corrente==0)
    {
       $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
       $media  = ($soma)/4;
     }
 else
    {
       $soma   = ($notareal2+$notareal3+$notareal4);
       $media  = ($soma)/3;
     }



 if ($total_etapas_ava_fora_rede > 0)
      {
              $soma   = ($notareal2+$notareal3+$notareal4);
              $media  = ($soma)/(4- $total_etapas_ava_fora_rede);
      }




   $mfinal = 0;




       /*******************************************************/

/*                  if ($nrec1 >  $media)
                    {
                       $mfinal = $nrec1 ;

                    }*/
         /*******************************************************/






if  (($reprova=='S') || ($reprova==''))
{


  if (($media < 6.0))
     {

/***Aderencia de Exame Final**/
    if ($adere_exame_final==1)
        {
          $mfinal = ($media*6 + $examefinal*4);
//if ($aluno=='252231' )
  // echo "$media";


          if ($mfinal < 50.0)
          {
               
               $situacao = "RETIDO";
               $retido = "1";
               $id_disciplina_retido = $id_disciplina;
              $mfinal= $mfinal/10;
             }
          else
            {
                $situacao = "APROVADO";
                $mfinal= $mfinal/10;
            }
         }
        else/*n�o adere a exame final*/
          {

                 if ($nrec1 >  $media)
                      $mfinal = $nrec1 ;
                 else
                    $mfinal =$media;
	         	    $situacao = "RETIDO";
	                $retido = "1";
                    $id_disciplina_retido = $id_disciplina;

          }
      }
   else
     {
            $situacao = "APROVADO";
        // if ($nrec1 > $media)
        //       $mfinal = $nrec1 ;
         //else
               $mfinal =$media;
     }

 }
else
{
       // SE A DISCIPLINA N�O REPROVA
         $situacao = "APROVADO";
      if (($media < 6.0))
        {
           if ($adere_exame_final==1)
                {
              $mfinal = ($media*6 + $examefinal*4)/10;
                }
             else
                $mfinal =$media;
         }
          else
             $mfinal =$media;

}






  if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))
       {
           $situacao = "CURSANDO";



         /*****Verifica se alguma disciplina n esta com os quatro bimestre fechados**/
           
              // echo "* $cursando";
		if ($cursando==0)
                 $cursando=1;
       }

  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


     }// if situacao
   else
      $situacao = $situa_desc;






/*******************Analisando Situacoes especiais como Provao Modular Enem************************/
/**************************************Proenco, enseja, reclassifica��o****************************/
/****************************Analisando Situacoes especiais como Provao Modular Enem************************/

$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'
                     and h.codigo = c.id_disciplina";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

/****************************************************************/
/***Verificase se o aluno foi reclassificado ou nao
Verificase se o aluno foi reclassificado ou nao codigo do
     id_provao = 1 Provao;
     id_provao = 2 Enem;
     id_provao = 3 Conselho de professores;
     id_provao = 4 Modular;
     id_provao = 5 telensinoConselho de professores;
     id_provao = 6 Reclassificado;
     id_provao = 7 Proenco;
     id_provao = 8 Enceja;
     id_provao = 9 Preenchimento de lacuna;
*/


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];
         $tp__legenda              =  $pegar_prova_especial["legenda"];

         /*
            Caso  a disciplina retida == disciplina  retido volta ao estao zero
         */

         if ($id_disciplina_retido == $id_disciplina)
                    $retido  = "0";



         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-".$pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }

	}

     if ($passou != '1')
           $situacao= "Aprovado";



     if ($passou_obs_provao==0)
        {
           $txtobs  =  $txtobs;
           $passou_obs_provao++;
        }


         //         $total_conta_faltas = $total_conta_faltas - $somafalta;
          $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

         //$total_faltas_final =$total_faltas_final + $soma_faltas;
           $somafalta = 0;




 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
//echo  "$id_turma_promovido";
//echo  "*$turma";

 

 if ($id_provao== '6')
    {
        $aluno_promovido = 1;

           if  ($id_turma_promovido == $turma)
             {
?>

<!-- colocando os dados em uma tabela -->
     <tr>
    	  <td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-"?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
          <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <?

             }
         else
           {
           /************Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente*************/

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format(($soma/3), 2, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************FIM provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
           }
     }

  else if ($id_provao== '3')
    {
?>
   <!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo $tp__legenda. number_format($media, 2, ',', '.');
                                                        else
                                                           echo $tp__legenda. number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

  <?
      }

    else
      {

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-"?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

        <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
        <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

<?
 /*************************Fim provas reclassifica��o***************************************************************************/
    }
 }

else
{

//$total_faltas_final  = $total_faltas_final + $soma_faltas;
$total_faltas_final  =  $soma_faltas;
/*if ($aluno  == '302490')
   {
     echo "*$soma_faltas";
     echo "*$total_faltas_final";
   }


 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

   if  ($aluno_promovido==1)
    {
?>



<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?
  }
 else
   {
?>


<!------Caso n�o tenha nenhuma avalia��o especial   -------->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  //if ($mfinal==0)
                                                        //   echo number_format($media, 2, ',', '.');
                                                        //else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?

   }

}

/********************************************************************************************************************/
?>



</tr>
<?
 }


else
{



/*****************************************************************************************************************/
/******************************************Ensino EJA*************************************************************/
/****************************************Recupera��o Semestral e Bimestral*************************************************************/
/***************************************************************************************************************/




 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
      $reprova      =  $pegargrade["reprova"];
	}

  }




   $soma = ($notareal1+$notareal2);
   $media = ($soma)/2;

   $somafalta   = ($t_falta1+$t_falta2);
   //  $totalfaltas = $totalfaltas + $somafalta;
  // $total_faltas_final  = $total_faltas_final + $soma_faltas;





     $soma   = ($notareal1+$notareal2);
     $media  = ($soma)/2;
     $mfinal = 0;

//$id_turma_promovido

/******situacao = 1 - matriculado *** Situa��o = 7 - promovido**************************************************/
if (($id_situacao=='1'))
 {

   $soma   = ($notareal1+$notareal2);
   $media  = ($soma)/2;
   $mfinal = 0;



/*if  (($reprova=='S'))
{


  if (($media < 6.0))
     {
           $mfinal = ($media*6 + $examefinal*4);
          if ($mfinal < 50.0)
            {
               $situacao = "RETIDO";
               $retido   = "1";
               $id_disciplina_retido = $id_disciplina;

              }
          else
            {
               $situacao = "APROVADO";

            }
      }
   else
            $situacao = "APROVADO";
   }
   else
            $situacao = "APROVADO";


  */

/**/

if  (($reprova=='S') || ($reprova==''))
{




  if (($media < 6.0))
     {

/***Aderencia de Exame Final**/
    if ($adere_exame_final==1)
        {
          $mfinal = ($media*6 + $examefinal*4);



          if ($mfinal < 50.0)
          {
               $situacao = "RETIDO";
               $retido = "1";
               $id_disciplina_retido = $id_disciplina;
               $mfinal= $mfinal/10;
             }
          else
            {
               $situacao = "APROVADO";
              $mfinal= $mfinal/10;
            }
         }
        else/*n�o adere a exame final*/
          {

                 if ($nrec1 >  $media)
                      $mfinal = $nrec1 ;
                 else
                      $mfinal =$media;
                      
                		 $situacao = "RETIDO";
                  		$retido = "1";

          }
      }
   else
     {
            $situacao = "APROVADO";
         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;
     }

 }
else
{
       $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;


}

/**/
















  if (($bim1 != 'S') || ($bim2 != 'S'))
       $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


}// if situacao
   else
      $situacao = $situa_desc;



                if ($situacao_aluno==2)
                     $situacao =  "DESISTENTE";






/******************************************Ensino EJA*************************************************************/

/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/
/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/
/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/








/******************************************Ensino EJA*************************************************************/

/*******************Analisando Situacoes especiais como Provao Modular Enem************************/
/**************************************Proenco, enseja, reclassifica��o****************************/
/****************************Analisando Situacoes especiais como Provao Modular Enem************************/

$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'
                     and h.codigo = c.id_disciplina";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

/****************************************************************/
/***Verificase se o aluno foi reclassificado ou nao
Verificase se o aluno foi reclassificado ou nao codigo do
     id_provao = 1 Provao;
     id_provao = 2 Enem;
     id_provao = 3 Conselho de professores;
     id_provao = 4 Modular;
     id_provao = 5 telensinoConselho de professores;
     id_provao = 6 Reclassificado;
     id_provao = 7 Proenco;
     id_provao = 8 Enceja;
     id_provao = 9 Preenchimento de lacuna;
*/


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];
         $tp__legenda              =  $pegar_prova_especial["legenda"];


                  /*
            Caso  a disciplina retida == disciplina  retido volta ao estao zero
         */

         //if ($id_disciplina_retido == $id_disciplina)
         //        $retido   = "0";



/*       if($aluno=='264524')
   {
     echo "-$id_disciplina_retido";
     echo "-$id_disciplina";
    echo "* $retido";
    //echo "soma $somafalta";
    // echo "total $totalfaltas"
     //echo "* $total_faltas_final";;
   }

  */


         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-".$pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda.$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }





	}

     if ($passou != '1')
           $situacao= "Aprovado";



     if ($passou_obs_provao==0)
        {
//           $txtobs  =  $txtobs  ." * ".  $tp_obs;
             $txtobs  =  $txtobs;
           $passou_obs_provao++;
        }


         //         $total_conta_faltas = $total_conta_faltas - $somafalta;
          $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

         //$total_faltas_final =$total_faltas_final + $soma_faltas;
           $somafalta = 0;



/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
//echo  "$id_turma_promovido";
//echo  "*$turma";



 if ($id_provao== '6')
    {
        $aluno_promovido = 1;

           if  ($id_turma_promovido == $turma)
             {
?>

<!-- colocando os dados em uma tabela -->
     <tr>
    	  <td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-"?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
          <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <?

             }
         else
           {
           /************Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente*************/

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>



      	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao2"], 1, ',', '.');?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format(($soma/1), 1, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************FIM provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

           }

     }

  else if ($id_provao== '3')
    {
?>
   <!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           $tp__legenda. number_format($media, 2, ',', '.');
                                                        else
                                                           $tp__legenda. number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

  <?
      }


    else
      {

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-"?></td>

        <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
        <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

<?
 /*************************Fim provas reclassifica��o***************************************************************************/
    }
 }

else
{




 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

   if  ($aluno_promovido==1)
    {
?>



<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao2"], 1, ',', '.');?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?
  }
 else
   {


//   $totalfaltas = $totalfaltas + $somafalta;
      $total_faltas_final  = $total_faltas_final + $somafalta;
?>


<!------Caso n�o tenha nenhuma avalia��o especial   -------->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>



      	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo  number_format($dado["recuperacao2"], 1, ',', '.');?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["examefinal"], 1, ',', '.');?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?

   }

}

/**************************************************Fim******************************************************************/
?>



</tr>

<?
   }


 }//loop

} //Fim da recupera��o bimestral e semestral






/*********************************.aqui come�a...Recupera��o anual******************************************************************************/

/********************************aqui come�a...Recupera��o anual********************************************************************************/
/********************************aqui come�a...Recupera��o anual********************************************************************************/
/********************************aqui come�a...Recupera��o anual********************************************************************************/
/********************************aqui come�a...Recupera��o anual********************************************************************************/
/********************************aqui come�a...Recupera��o anual********************************************************************************/











else
{



  if (($modalidade=='1')|| ($modalidade=='3'))
   {
?>

<tr>
 <td class="nomecampo"><b>Componente Curricular</b></td>
 <td class="nomecampo"><b>1�Bim</b></td>
 <td class="nomecampo"><b>F 1�B</b></td>
 <td class="nomecampo"><b>2�Bim</b></td>
 <td class="nomecampo"><b>F 2�B</b></td>
 <td class="nomecampo"><b>3�Bim</b></td>
 <td class="nomecampo"><b>F 3�B</b></td>
 <td class="nomecampo"><b>4�Bim</b></td>
 <td class="nomecampo"><b>F 4�B</b></td>
 <td class="nomecampo"><b>Soma </b></td>
 <td class="nomecampo"><b>M.A</b></td>
 <td class="nomecampo"><b>Rec</b></td>
 <td class="nomecampo"><b>Ex.Final</b></td>
 <td class="nomecampo"><b>M.F</b></td>
 <td class="nomecampo"><b>Total Faltas</b></td>
<!-- <td class="nomecampo"><b>Situa��o</b></td>-->
</tr>

<?
}
else
{
?>



<tr>
 <td class="nomecampo" align="center"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M.A</b></td>
 <td class="nomecampo" align="center"><b>REC</b></td>
 <td class="nomecampo" align="center"><b>Ex.Final</b></td>
 <td class="nomecampo" align="center"><b>M.F</b></td>
 <td class="nomecampo" align="center"><b>Total Faltas</b></td>
<!-- <td class="nomecampo" align="center"><b>Situa��o</b></td>-->
</tr>

<?
}//else

//$totalfaltas = 0;
$soma_faltas=0;

$passou = 0;


$passou_obs_provao = 0;

while ($dado = mysql_fetch_array($sql))
  {
   $dtabertura    = date("d/m/Y",strtotime($dado["data"]));
   $id_disciplina = $dado["id_disciplina"];
/*Verifica a situacao do aluno*/


$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno' and id_turma = '$turma'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }


   $mediacalculo=0;
   $mfinal=0;
   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];

   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];

   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];


   $notareal1 = $n1;
   $notareal2 = $n2;
   $notareal3 = $n3;
   $notareal4 = $n4;







 if( $aluno_foi_promovido_ano_corrente==0)
    {
       $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
       $media  = ($soma)/4;
     }
 else
    {
       $soma   = ($notareal2+$notareal3+$notareal4);
       $media  = ($soma)/3;
     }



/****************Avaliacao Recebida Fora da Rede***********************************************************************/

 if ($total_etapas_ava_fora_rede > 0)
      {
              $soma   = ($notareal2+$notareal3+$notareal4);
              $media  = ($soma)/(4- $total_etapas_ava_fora_rede);
      }

/***************************************************************************************/








   $examefinal   =  $dado["examefinal"];






   $t_falta1  =$dado["t_falta1"];
   $t_falta2 = $dado["t_falta2"];
   $t_falta3 = $dado["t_falta3"];
   $t_falta4 = $dado["t_falta4"];







/***************Aluno foi promovido no ano corrente*********************/
/***************Aluno foi promovido no ano corrente*********************/
/***************Aluno foi promovido no ano corrente*********************/
 if( $aluno_foi_promovido_ano_corrente==0)
        $total_faltas=($t_falta1+$t_falta2+$t_falta3+$t_falta4); //por disciplina
 else
     $total_faltas=($t_falta2+$t_falta3+$t_falta4); //por disciplina
/***********************************************************************/
/***********************************************************************/











   $soma_faltas =$total_faltas +$soma_faltas;
/**A soma total das faltas sao realizadas com as disciplinas n�o dispensadas**/
//   $total_faltas_final  = $total_faltas_final + $total_faltas;


   $id_disciplina = $dado["id_disciplina"];



 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular_x' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
        $reprova      =  $pegargrade["reprova"];

    }

  }



  /**/









if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {




if (($id_situacao=='1') || ($id_situacao=='8')   || ($id_situacao=='5')    || (($id_situacao=='3') && ($id_status_transferencia=='1')))
   {
       $mfinal = 0;





if  (($reprova=='S') || ($reprova==''))
{




//  if (($media < 6.0) && ($nrec1 < 6.0))

  if (($media < 6.0))
     {
      if (($nrec1 < 6.0))
        {
                   if ($media > $nrec1)
                       {
                          $mediacalculo = $media;
                      }
                    else
                      {
                           $mediacalculo  = $nrec1;
                      }





/***Aderencia de Exame Final**/
                if ($adere_exame_final==1)
                   {
                      $mfinal = ($mediacalculo*6 + $examefinal*4);




                      if ($mfinal < 50.0)
                          {
                              $situacao = "RETIDO";
                              $retido   = "1";
                              $id_disciplina_retido = $id_disciplina;
                          }
                      else
                          {
                             $situacao = "APROVADO";

                           }


                     $mfinal=  $mfinal/10;

                    }
           else/*n�o adere a exame final*/
              {

                 if ($nrec1 >  $media)
                      $mfinal = $nrec1 ;
                 else
                      $mfinal =$media;

                    		 $situacao = "RETIDO";
                       		 $retido = "1";
                              $id_disciplina_retido = $id_disciplina;






             }






     }//****************************//
          else
            {
               $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;


             }

      }
   else
      {
            $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;



/*     if (($aluno=='116377') && ($id_disciplina=='5'))
         {
           echo "ma $media";
            echo "r $nrec1";
            echo "mc $mediacalculo";
            echo "mf $mfinal";
         }
  */


      }
 }
else // disciplina que nao reprovao  nao reprova
{
            $situacao = "APROVADO";




               if (($media < 6.0))
                 {

                if ($nrec1 > $media)
                      $mediacalculo = $nrec1 ;
                else
                      $mediacalculo =$media;


                 if ($adere_exame_final==1)
                   {
                      $mfinal = ($mediacalculo*6 + $examefinal*4);
                      $mfinal=  $mfinal/10;

                    }
                 else
                   {
                            if ($nrec1 > $media)
                               $mfinal = $nrec1 ;
                            else
                              $mfinal =$media;
                    }
                 }
               else
               {

                            if ($nrec1 > $media)
                               $mfinal = $nrec1 ;
                            else
                              $mfinal =$media;


               }



}









  if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))
       {
           $situacao = "CURSANDO";
                    /*****Verifica se alguma disciplina n esta com os quatro bimestre fechados**/
           if ($cursando==0)
               $cursando=1;
       }

  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


   }// if situacao == 1
   else
      $situacao = $situa_desc;










/*******************Analisando Situacoes especiais como Provao Modular Enem************************/
/**************************************Proenco, enseja, reclassifica��o****************************/
/****************************Analisando Situacoes especiais como Provao Modular Enem************************/

$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'
                     and h.codigo = c.id_disciplina";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

/****************************************************************/
/***Verificase se o aluno foi reclassificado ou nao
Verificase se o aluno foi reclassificado ou nao codigo do
     id_provao = 1 Provao;
     id_provao = 2 Enem;
     id_provao = 3 Conselho de professores;
     id_provao = 4 Modular;
     id_provao = 5 telensinoConselho de professores;
     id_provao = 6 Reclassificado;
     id_provao = 7 Proenco;
     id_provao = 8 Enceja;
     id_provao = 9 Preenchimento de lacuna;
*/


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp__legenda              =  $pegar_prova_especial["legenda"];
         /*
            Caso  a disciplina retida == disciplina  retido volta ao estao zero
         */

         if ($id_disciplina_retido == $id_disciplina)
                {
                    $retido   = "0";
                }




          if ($tp_avaliacao_especial==3)
                {
                  // $media  = $tp__nota_especial;
                }


         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-".$pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp__legenda." ".$tp_obs_ava_especial ."-". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }




	}

     if ($passou != '1')
           $situacao= "Aprovado";



     if ($passou_obs_provao==0)
        {
           //$txtobs  =  $txtobs  ." * ".  $tp_obs;
             $txtobs  =  $txtobs;
           $passou_obs_provao++;
        }


         //         $total_conta_faltas = $total_conta_faltas - $somafalta;
          $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

         //$total_faltas_final =$total_faltas_final + $soma_faltas;
           $somafalta = 0;




 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
//echo  "$id_turma_promovido";
//echo  "*$turma";



 if ($id_provao== '6')
    {
        $aluno_promovido = 1;

           if  ($id_turma_promovido == $turma)
             {
?>

<!-- colocando os dados em uma tabela -->
     <tr>

    	  <td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>

     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-"?></td>

          <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
          <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <?

             }
         else
           {
           /************Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente*************/

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************FIM provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

           }

     }
  else if ($id_provao== '3')
    {

?>
   <!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo $tp__legenda. number_format($media, 2, ',', '.');
                                                        else
                                                           echo $tp__legenda. number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

  <?
      }
      else
       {

?>

<!-- colocando os dados em uma tabela -->
<tr>

    	  <td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-"?></td>

          <td class = "escrita" align="center">&nbsp;<?echo "-"; ?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
          <td class = "escrita" align="center">&nbsp;<?echo $tp__legenda.$tp__nota_especial;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

<?
 /*************************Fim provas reclassifica��o***************************************************************************/
    }
 } //caso n�o tenha nenhuma nota
else
{

    $total_faltas_final  = $total_faltas_final + $total_faltas;


 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

   if  ($aluno_promovido==1)
    {
?>



<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

<?
  }
 else
   {
?>

<!------Caso n�o tenha nenhuma avalia��o especial ou senha todas as noas  -------->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota3"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota4"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?



        if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>


<?

   }

}
/********************************************************************************************************************/
?>



</tr>
<?
 }  //fim da modaliade reglar e especial

else /*Eja Recupera��o anual*/
{

/*****************************************************************************************************************/
/***************************Comeca o ejaEnsino EJA*************************************************************/
/****************************************Recupera��o Anual*************************************************************/
/***************************************************************************************************************/





 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$grade_curricular' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
    {
      $reprova      =  $pegargrade["reprova"];
	}

  }





//   $somafalta   = ($t_falta1+$t_falta2);
   //$totalfaltas = $totalfaltas + $somafalta;

   $t_falta1  =$dado["t_falta1"];
   $t_falta2 = $dado["t_falta2"];


/***************Aluno foi promovido no ano corrente*********************/
 if( $aluno_foi_promovido_ano_corrente==0)
           $somafalta   = ($t_falta1+$t_falta2);
 else
           $somafalta   = ($t_falta2);
/***********************************************************************/









//   $soma_faltas = $total_faltas + $soma_faltas;





    $soma   = ($notareal1+$notareal2);
    $media  = ($soma)/2;
    $mfinal = 0;







//$id_turma_promovido

/******situacao = 1 - matriculado *** Situa��o = 7 - promovido**************************************************/
if (($id_situacao=='1'))
 {

   $soma   = ($notareal1+$notareal2);
   $media  = ($soma)/2;
   $mfinal = 0;



                 if ($nrec1 >  $media)
                    {
                       $mfinal = $nrec1 ;
 
                    }




if  (($reprova=='S') || ($reprova==''))
{




//  if (($media < 6.0) && ($nrec1 < 6.0))

  if (($media < 6.0))
     {
      if (($nrec1 < 6.0))
        {
                   if ($media > $nrec1)
                       {
                          $mediacalculo = $media;
                      }
                    else
                      {
                           $mediacalculo  = $nrec1;
                      }





/***Aderencia de Exame Final**/
                if ($adere_exame_final==1)
                   {
                      $mfinal = ($mediacalculo*6 + $examefinal*4);




                      if ($mfinal < 50.0)
                          {
                              $situacao = "RETIDO";
                              $retido   = "1";
                              $id_disciplina_retido = $id_disciplina;
                          }
                      else
                          {
                             $situacao = "APROVADO";

                           }


                     $mfinal=  $mfinal/10;

                    }
           else/*n�o adere a exame final*/
              {

                 if ($nrec1 >  $media)
                      $mfinal = $nrec1 ;
                 else
                      $mfinal =$media;

                    		 $situacao = "RETIDO";
                       		 $retido = "1";
                              $id_disciplina_retido = $id_disciplina;






             }






     }//****************************//
          else
            {
               $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;


             }

      }
   else
      {
            $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;



/*     if (($aluno=='116377') && ($id_disciplina=='5'))
         {
           echo "ma $media";
            echo "r $nrec1";
            echo "mc $mediacalculo";
            echo "mf $mfinal";
         }
  */


      }
 }
else // disciplina que nao reprovao  nao reprova
{
       $situacao = "APROVADO";

         if ($nrec1 > $media)
               $mfinal = $nrec1 ;
         else
               $mfinal =$media;


}










  if (($bim1 != 'S') || ($bim2 != 'S'))
       $situacao = "CURSANDO";


  if ($situacao_aluno==3)
        $situacao = "TRANSFERIDO";


}// if situacao
   else
      $situacao = $situa_desc;



                if ($situacao_aluno==2)
                     $situacao =  "DESISTENTE";






/******************************************Ensino EJA*************************************************************/

/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/
/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/
/*******************Analisando Situacoes especiais como Provao Modular Enem*********************************************/








/******************************************Ensino EJA*************************************************************/

/*******************Analisando Situacoes especiais como Provao Modular Enem************************/
/**************************************Proenco, enseja, reclassifica��o****************************/
/****************************Analisando Situacoes especiais como Provao Modular Enem************************/

$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and id_disciplina = '$id_disciplina'
                     and tp.id= c.tp_avaliacao 	 and c.cancelado = 'N'
                     and h.codigo = c.id_disciplina";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
 {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
    {

/****************************************************************/
/***Verificase se o aluno foi reclassificado ou nao
Verificase se o aluno foi reclassificado ou nao codigo do
     id_provao = 1 Provao;
     id_provao = 2 Enem;
     id_provao = 3 Conselho de professores;
     id_provao = 4 Modular;
     id_provao = 5 telensinoConselho de professores;
     id_provao = 6 Reclassificado;
     id_provao = 7 Proenco;
     id_provao = 8 Enceja;
     id_provao = 9 Preenchimento de lacuna;
*/


         if ($id_disciplina_retido == $id_disciplina)
                 $retido   = "0";


         $tp__prova_descricao      =  $pegar_prova_especial["descricao"];
         $tp__nota_especial        =  $pegar_prova_especial["nota"];
         $tp_obs                   =  $pegar_prova_especial["obs"];
         $desc_disciplina          =  $pegar_prova_especial["desc_disciplina"];
         $id_provao                =  $pegar_prova_especial["id_provao"];
         $tp_avaliacao_especial    =  $pegar_prova_especial["id_provao"];





         if (($tp_avaliacao_especial==1) && ($conta_obs_provao==0))//provao
               {
                  $tp_obs_ava_especial      = $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_provao= 1;
               }
         else if (($tp_avaliacao_especial==2) && ($conta_obs_enem==0))//Enem
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_enem = 1;
               }
         else if (($tp_avaliacao_especial==3) && ($conta_obs_conselho_professores==0))//conselho de professores
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_conselho_professores = 1;
               }

         else if (($tp_avaliacao_especial==4) && ($conta_obs_modular==0))//modular
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_modular = 1;
               }

         else if (($tp_avaliacao_especial==5) && ($conta_obs_telensino==0))//teleensino
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_telensino = 1;
               }

         else if (($tp_avaliacao_especial==6) && ($conta_obs_reclassificacao==0))//reclassifica��o
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_reclassificacao = 1;
               }

         else if (($tp_avaliacao_especial==7) && ($conta_obs_proenco==0))//proenco
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_proenco = 1;
               }

         else if (($tp_avaliacao_especial==8) && ($conta_obs_enceja==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_enceja = 1;
               }

         else if (($tp_avaliacao_especial==9) && ($conta_obs_lacuna==0))//enceja
               {
                  $tp_obs_ava_especial      =  $tp_obs_ava_especial ."*". $pegar_prova_especial["obs"];
                  $conta_obs_lacuna = 1;
               }










	}

     if ($passou != '1')
           $situacao= "Aprovado";



     if ($passou_obs_provao==0)
        {
              //$txtobs  =  $txtobs  ." * ".  $tp_obs;
              $txtobs  =  $txtobs;
              $passou_obs_provao++;
        }





         //         $total_conta_faltas = $total_conta_faltas - $somafalta;
          $total_conta_faltas = $total_conta_faltas - $total_faltas_final;

         //$total_faltas_final =$total_faltas_final + $soma_faltas;
           $somafalta = 0;



/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

 






 if ($id_provao== '6')
    {
        $aluno_promovido = 1;

           if  ($id_turma_promovido == $turma)
             {
?>

<!-- colocando os dados em uma tabela -->
     <tr>
    	  <td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-"?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
          <td class = "escrita" align="center">&nbsp;<?echo "*".$tp__nota_especial;?></td>
     	  <td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

          <?

             }
         else
           {
           /************Caso o aluno tenha prova especial reclassifica��o mais a turma_ diferente*************/

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>


        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["recuperacao2"], 1, ',', '.');?></td>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($mfinal, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 2, ',', '.');
                                                          ?></td>

     	<td class = "escrita" align="center">&nbsp;<?echo $somafalta;?></td>

<?

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************FIM provao for atraves de reclassifica��o***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

           }

     }

  else if ($id_provao== '3')
    {
?>
   <!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>



        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
       	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo "*". number_format($media, 2, ',', '.');
                                                        else
                                                           echo "*". number_format($mfinal, 2, ',', '.');
                                                          ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $total_faltas;?></td>

  <?
      }


    else
      {

?>

<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $desc_disciplina;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-"?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
        <td class = "escrita" align="center">&nbsp;<?echo "*". $tp__nota_especial;?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>


<?
 /*************************Fim provas reclassifica��o***************************************************************************/
    }
 }
else
{

 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/
 /*************************Se o aluno foi promovido pelomenos em uma nota deve zera a primeria nota***************************************************************************/
 /**********************************************************************************************************************************************/
 /**********************************************************************************************************************************************/

   if  ($aluno_promovido==1)
    {
?>
<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "-";?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>


        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["recuperacao2"], 1, ',', '.');?></td>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal/10, 2, ',', '.');
                                                          ?></td>

     	<td class = "escrita" align="center">&nbsp;<?echo $somafalta;?></td>




<?
  }
 else
   {




  $total_faltas_final  =  $somafalta +$total_faltas_final;
?>



<!------Caso n�o tenha nenhuma avalia��o especial   -------->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota1"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["nota2"], 1, ',', '.');?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>


        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 2, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 2, ',', '.'); ?></td>
      	<td class = "escrita" align="center">&nbsp;<?echo number_format($dado["recuperacao2"], 1, ',', '.');?></td>
    	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?  if ($mfinal==0)
                                                           echo number_format($media, 2, ',', '.');
                                                        else
                                                           echo number_format($mfinal, 2, ',', '.');
                                                          ?></td>

     	<td class = "escrita" align="center">&nbsp;<?echo $somafalta;?></td>

<?

   }

}

/**************************************************Fim******************************************************************/
?>



</tr>

<?

// } // Fim do Else modadliade de recupera��o anual eja
/****************Fim********************************************************************/
?>





   </tr>
<?
    } // Fim do Else modadliade de recupera��o anual eja

   }//loop recuperacao anual
 }// fim d o else quando comeca a recupera��o anual   fundamental e eja




/****************************Fim da ata Grade e computa��o de Faltas**************************************************/
?>









<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Total de Faltas Registradas :&nbsp<?echo  $total_faltas_final;?>
                   <b>&nbspTotal de Falta(s) Amparada(s) :&nbsp</b>
                   <?echo $total_abono_faltas;

                          if  ($total_faltas_final < $total_abono_faltas)
                                {
                                 $diferenca_total_faltas =0;
                                }
                          else
                                {
                                    $diferenca_total_faltas = $total_faltas_final - $total_abono_faltas;
                                 }

                          
                          
                  ?>
                   <b>&nbspTotal de Faltas :&nbsp <?echo  $diferenca_total_faltas;?> </b>
                  <?


//                     if ($aluno=='351803')
//                          echo "* $diferenca_total_faltas";





                  if ($id_situacao=="5")
                            $situacao ="Desistente";




     if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
        {
            // if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))

                if ($cursando==1)
                      $situacao = "CURSANDO";
        }
    else
       {
        if (($bim1 != 'S') || ($bim2 != 'S'))
                   $situacao = "CURSANDO";
       }



    if ($situacao_aluno==3)
             $situacao = "TRANSFERIDO";


     /***********************************/
    if  ($id_turma_promovido == $turma)
           $situacao = "APROVADO - AVALIA��O ESPECIAL RECLASSIFICA��O.";



    if ($retido=="1")
            $situacao ="Retido";




/***********Verificando situa�oes de reprova��o por falta********/
                      if ($modalidade== '2')
                       {
                        if ($diferenca_total_faltas > 100)
                         {
                             //echo " Aluno Reprovado Por Falta.";
                             $situacao ="Reprovado Por Falta";
                          }
                        }

                      else if ($modalidade== '1')
                       {
                         if (($turmasserie>=2) && ($turmasserie<=6))
                            {
                            if ($diferenca_total_faltas > 50)
                               {
                             //echo " Aluno Reprovado Por Falta.";
                             $situacao ="Reprovado Por Falta";
                                }
                             }
                          else if ($diferenca_total_faltas >= 201)
                               {
                               //   echo " Aluno Reprovado Por Falta.";
                                  $situacao ="Reprovado Por Falta";
                                }

                        }

/***************************************************************/


    if ($situacao_aluno==5)
             $situacao = "DESISTENTE";



  ?>


</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Data de Fechamento :&nbsp<?echo  $dtfecha_turma;?> </b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Situa��o Final :&nbsp<?echo  $situacao;?> </b></td>
</tr>




<?
 if ($aluno_transferido=='1')
{
?>
<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="left"><b>Transferido :&nbsp<?echo  $dt_transferencia;?> </b></td>
</tr>
<?
}
?>





</table>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Componente Curricular</b></td>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Carga Hor�ria</b></td>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Aulas Dadas</b></td>
</tr>




<?


  $sqlgrade="select g.id_modalidade,g.id_disciplina,g.ch as ch,g.ano,h.descricao as descricao,h.codigo from grade_curricular g,habilitacao h
  where id_modalidade='$modalidade'
  and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep' and g.ano = '$txtano' and g.id_serie = ' $grade_curricular' order by h.impressao";
  $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
  $linhasgrade=mysql_num_rows($resultadograde);
  
//and g.id_s = $grade_curricular
$total_ch=0;
if ($linhasgrade>0)
   {
while($pegargrade=mysql_fetch_array($resultadograde))
    {

        $id_disciplina            = $pegargrade["codigo"];


/**********************C�lculo de Aulas Dadas********************************************************************************/



$sql_aulas_dada="SELECT count(tempo_aula) as total_aulas_dada FROM dias_diario
     where id_turma     = '$turma'
     and id_disciplina  = '$id_disciplina'
     and inep           = '$inep'
     and ano            = '$txtano'
     and registrado     = 'S'
     and tipo_aula      = '1'
     and tpbloqueio    = '1'";
     
$resultado_aulas_dada = mysql_query($sql_aulas_dada) or die (mysql_error());
$linhas_aulas_dada=mysql_num_rows($resultado_aulas_dada);
if ($linhas_aulas_dada>0)
 {
    while($pegar_aulas_dada=mysql_fetch_array($resultado_aulas_dada))
   {
         $total_aulas_dadas       = $pegar_aulas_dada["total_aulas_dada"];

         $Soma_total_aulas_dadas =  $Soma_total_aulas_dadas + $total_aulas_dadas;
   }
 }




























/************************************************************************************************************************/
















        $descdisciplina            = $pegargrade["descricao"];

        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $ch  = "-";
  		   $total_aulas_dadas = "-";	
          }

      else if (($turmasserie>=17) && ($turmasserie<=21))  // cba eja
          {
                 $ch  = "0";
          }
         else
          { 
              $ch  = $pegargrade["ch"];
              $total_ch = $total_ch+ $ch;
          }
?>

<tr>
	<td colspan="6" class="escrita">&nbsp<?echo  $descdisciplina;?></td>
	<td colspan="6" class="escrita" align="center">&nbsp<?echo  $ch;?> </td>

	<td colspan="6" class="escrita" align="center">&nbsp<?echo  $ch;?> </td>


<!--       <td colspan="6" class="escrita" align = "center">  &nbsp<?echo  $total_aulas_dadas;?> </td>-->




</tr>

<?
	}


        if (($turmasserie>=2) && ($turmasserie<=6))
          {
                 $total_ch  = "800";
          }
        if (($turmasserie>=17) && ($turmasserie<=21))
          {
                 $total_ch  = "350";
          }


         else
            {
             /*  
               $re    = mysql_query("SELECT sum(ch) as total from grade_curricular g,habilitacao h where id_modalidade='$modalidade'
               and h.codigo = g.id_disciplina and h.disciplina = 'S' and g.inep = '$inep'  AND g.id_serie = '$turmasserie'");
               $total = mysql_result($re, 0, "total");
              */
              }




  if (($turmasserie>=2) && ($turmasserie<=6))
          {
?>
	<td class="escrita" align = "center"><b> Dias Letivos  </b></td>
	<td colspan="6" align = "center">&nbsp200</td>
	 <td colspan="6" class="escrita" ><b>Total   </b></td>

	<td colspan="6" align = "center">&nbsp800 Horas</td>

<?
         }
else if (($turmasserie>=17) && ($turmasserie<=21))
           {
?>
 	<td class="escrita" align = "center"><b> Dias Letivos  </b></td>
 	<td colspan="6" align = "center">&nbsp200</td>
	 <td colspan="6" class="escrita" ><b>Total   </b></td>

	<td colspan="6" align = "center">&nbsp350 Horas</td>

<?
         }
      else
        {
?>
<!--	<td colspan="6" class="escrita" align = "center"><b>  -  </b></td>-->

	 <td colspan="6"  class="escrita" ><b>Total   </b></td>
	 <td colspan="6" class="escrita" align="center"><b>&nbsp<?echo  $total_ch;?></b> </td>

	 <td colspan="6" class="escrita" align="center"><b>&nbsp<?echo  $total_ch;?></b> </td>


<!--        <td colspan="6" class="escrita" align = "center"><b>  &nbsp<?echo  $Soma_total_aulas_dadas;?></b> </td>-->


<?
         }
?>
<?
  }
?>

</table>





<table width="100%">
<tr>
      <td class = "escrita" align="Justify">
<h3> <?echo  $txtobs."/".$tp_obs_ava_especial;?></h3>
      </td>
</tr>
</table>






<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Aux Secretaria</b></td>
	<td>&nbsp;</td>


	<td class="nomecampo"><b>Secretaria</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;</td>
</tr>








</table>




<table border="0"  class="bordasimples" cellspacing="0"  align="left" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="escritagrade" align="center"><b>Legenda /Descri��o</b></td>
</tr>

<?

$descricao_legenda ="";

  $sqlgrade="select *  from tp_provao";
  $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
  $linhasgrade=mysql_num_rows($resultadograde);
if ($linhasgrade>0)
   {
while($pegargrade=mysql_fetch_array($resultadograde))
    {

        $descricao_grade            = $pegargrade["descricao"];
        $legenda_grade              = $pegargrade["legenda"];
        $descricao_legenda =  $descricao_legenda. $legenda_grade.$descricao_grade.";";
?>


<?
    }
   }

?>

<tr>
	<td colspan="6" class="escritagrade"><?echo  $descricao_legenda;?></td>
</tr>

</table>





<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao" ><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>

